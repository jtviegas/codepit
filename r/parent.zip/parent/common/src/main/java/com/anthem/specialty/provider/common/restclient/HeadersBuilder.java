package com.anthem.specialty.provider.common.restclient;

import org.springframework.util.MultiValueMap;

public interface HeadersBuilder {

  HeadersBuilder withAuthentication();

  HeadersBuilder withPatchOverride();

  HeadersBuilder withTenant(String tenant);

  MultiValueMap<String, String> build();

}