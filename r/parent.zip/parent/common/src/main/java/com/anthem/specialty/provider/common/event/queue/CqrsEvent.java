package com.anthem.specialty.provider.common.event.queue;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class CqrsEvent implements Serializable {

  private static final long serialVersionUID = 1L;

  private Long id;

  private EventType type;

  private String entity;

  private LocalDateTime ts;

  private List<Key> keys;

  private String destination;

  public CqrsEvent() {
  }

  public CqrsEvent(Long id, EventType type, String entity, LocalDateTime ts, List<Key> keys) {
    this.id = id;
    this.type = type;
    this.entity = entity;
    this.ts = ts;
    this.keys = keys;
  }

  @NotNull
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  @NotNull
  public EventType getType() {
    return type;
  }

  public void setType(EventType type) {
    this.type = type;
  }

  @NotNull
  public String getEntity() {
    return entity;
  }

  public void setEntity(String entity) {
    this.entity = entity;
  }

  @NotNull
  public LocalDateTime getTs() {
    return ts;
  }

  public void setTs(LocalDateTime ts) {
    this.ts = ts;
  }

  @NotNull
  public List<Key> getKeys() {
    return keys;
  }

  public void setKeys(List<Key> keys) {
    this.keys = keys;
  }

  public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((destination == null) ? 0 : destination.hashCode());
    result = prime * result + ((entity == null) ? 0 : entity.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((keys == null) ? 0 : keys.hashCode());
    result = prime * result + ((ts == null) ? 0 : ts.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    CqrsEvent other = (CqrsEvent) obj;
    if (destination == null) {
      if (other.destination != null)
        return false;
    } else if (!destination.equals(other.destination))
      return false;
    if (entity == null) {
      if (other.entity != null)
        return false;
    } else if (!entity.equals(other.entity))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (keys == null) {
      if (other.keys != null)
        return false;
    } else if (!keys.equals(other.keys))
      return false;
    if (ts == null) {
      if (other.ts != null)
        return false;
    } else if (!ts.equals(other.ts))
      return false;
    if (type != other.type)
      return false;
    return true;
  }

}
