package com.anthem.specialty.provider.common.event.application;

import org.springframework.context.ApplicationEvent;

public class AppEvent<T> extends ApplicationEvent {

  private static final long serialVersionUID = 1L;

  private final T context;

  public AppEvent(Object source, T context) {
    super(source);
    this.context = context;
  }

  protected T getContext() {
    return context;
  }

}
