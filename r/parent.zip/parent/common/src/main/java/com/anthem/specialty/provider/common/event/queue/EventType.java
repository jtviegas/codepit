package com.anthem.specialty.provider.common.event.queue;

public enum EventType {
  delta,;
}
