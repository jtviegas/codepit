package com.anthem.specialty.provider.common.restclient;

public interface AsyncRestClient extends AsyncRestFunctions, BaseRestFunctions {

}