package com.anthem.specialty.provider.common.restclient;

public interface RestClient extends SyncRestFunctions, BaseRestFunctions {

}