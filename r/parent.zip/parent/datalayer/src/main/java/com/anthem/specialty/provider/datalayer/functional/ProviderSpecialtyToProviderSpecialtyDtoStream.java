package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;

public class ProviderSpecialtyToProviderSpecialtyDtoStream implements
    Function<ProviderSpecialty, Stream<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty>> {

  private final ProviderSpecialtyToProviderSpecialtyDto mapper;

  public ProviderSpecialtyToProviderSpecialtyDtoStream() {
    this.mapper = new ProviderSpecialtyToProviderSpecialtyDto();
  }

  @Override
  public Stream<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty> apply(ProviderSpecialty p) {

    return Stream.of(mapper.apply(p));

  }

}
