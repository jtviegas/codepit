package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Clinic;
import com.anthem.specialty.provider.datamodel.dto.NewProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinicImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItemImpl;

public class NewProviderClinicToProviderClinicDto implements Function<NewProviderClinic, ProviderClinic> {

  private final Function<Long, Clinic> clinicFunction;

  public NewProviderClinicToProviderClinicDto(Function<Long, Clinic> cF) {

    this.clinicFunction = cF;
  }

  @Override
  public ProviderClinic apply(NewProviderClinic t) {
    ProviderClinic o = new ProviderClinicImpl();

    o.setBci(t.getBci());
    o.setClearLicenseNumber(t.getClearLicenseNumber());

    RelatedClinicItem clinicItem = new RelatedClinicItemImpl();
    o.setClinic(clinicItem);
    Clinic clinic = clinicFunction.apply(t.getClinic().getId());
    clinicItem.setId(clinic.getId());
    clinicItem.setCommonName(clinic.getCommonName());
    clinicItem.setLink(clinic.getLinks().stream().filter(l -> l.getRel().equals("self")).findFirst().get());

    o.setComments(t.getComments());
    o.setCorporatePayment(t.getCorporatePayment());
    o.setDataOwner(clinic.getDataOwner());
    o.setDeltaPrecertified(t.getDeltaPrecertified());
    o.setEffective(t.getEffective());
    o.setHours(t.getHours());
    o.setPayClinicProvider(t.getPayClinicProvider());
    o.setProfessionalReviewUnderway(t.getProfessionalReviewUnderway());
    o.setProviderClaimInReview(t.getProviderClaimInReview());
    o.setProviderCob(t.getProviderCob());
    o.setProviderRelationship(t.getProviderRelationship());
    o.setProviderSpecialistClinic(t.getProviderSpecialistClinic());
    o.setWitholdPayments(t.getWitholdPayments());

    return o;
  }

}
