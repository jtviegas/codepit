package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Dea;
import com.anthem.specialty.provider.datamodel.dto.DeaImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.License;
import com.anthem.specialty.provider.datamodel.dto.LicenseImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;

public class ProviderLicenseToLicense implements Function<ProviderLicense, License> {

  private final LinkResolver linkResolver;

  public ProviderLicenseToLicense() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public License apply(ProviderLicense t) {
    License o = new LicenseImpl();

    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));

    if (null != t.getDeaNumber()) {
      Dea dea = new DeaImpl();
      dea.setDeaNumber(t.getDeaNumber());
      dea.setExpiration(t.getDeaNumberExpires());
      dea.setMissingBecause(t.getDeaReason().toString());
      o.setDea(dea);
    }

    if (null != t.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(t.getEffectiveFrom());
      ep.setTo(t.getEffectiveTo());

      o.setEffective(ep);
    }
    o.setId(t.getId());
    o.setIssuingState(t.getIssuingState());
    o.setLicenseNumber(t.getLicenseNo());
    o.setOnHold('Y' == t.getOnHold() ? true : false);

    o.setTerminated(t.getTerminated());

    List<com.anthem.specialty.provider.datamodel.dto.Link> links = new ArrayList<com.anthem.specialty.provider.datamodel.dto.Link>();

    links.add(
        linkResolver.apply(new String[] { t.getProvider().getId().toString() }, LinkResolver.Type.provider, false));
    links.add(linkResolver.apply(new String[] { t.getProvider().getId().toString(), t.getLicenseNo() },
        LinkResolver.Type.provider_license, true));
    o.setLinks(links);

    return o;
  }

}
