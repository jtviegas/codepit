package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;

public interface CarrierRepository extends CrudRepository<Carrier, Long> {

  List<Carrier> findByClearCarrierNo(String clearCarrierNo);

  List<Carrier> findByContactName(String contactName);

  Page<Carrier> findByOrderByIdDesc(Pageable pageable);

  void deleteByIdIn(List<Long> ids);

}
