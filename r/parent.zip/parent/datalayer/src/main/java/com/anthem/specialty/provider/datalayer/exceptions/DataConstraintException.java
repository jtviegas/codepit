package com.anthem.specialty.provider.datalayer.exceptions;

public class DataConstraintException extends DataLayerException {

  private static final long serialVersionUID = 1L;

  public DataConstraintException() {
  }

  public DataConstraintException(String message) {
    super(message);
  }

  public DataConstraintException(Throwable cause) {
    super(cause);
  }

  public DataConstraintException(String message, Throwable cause) {
    super(message, cause);
  }

  public DataConstraintException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
