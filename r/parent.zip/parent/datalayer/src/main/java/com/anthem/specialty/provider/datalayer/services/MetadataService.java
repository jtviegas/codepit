package com.anthem.specialty.provider.datalayer.services;

import java.util.List;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.BusinessSegment;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.DentalProcedure;
import com.anthem.specialty.provider.datamodel.schemas.core.DocumentType;
import com.anthem.specialty.provider.datamodel.schemas.core.Language;
import com.anthem.specialty.provider.datamodel.schemas.core.LargeGroup;
import com.anthem.specialty.provider.datamodel.schemas.core.LineOfBusiness;
import com.anthem.specialty.provider.datamodel.schemas.core.ProviderRelationship;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;

public interface MetadataService {

  DataOwner getDataOwner(Long id) throws NoEntityFoundException;

  List<DataOwner> getDataOwners();

  TerminationLevel getTerminationLevel(Long id);

  List<TerminationLevel> getTerminationLevels();

  LineOfBusiness getTenant(Long id) throws NoEntityFoundException;

  List<LineOfBusiness> getTenants();

  Specialty getSpecialty(String code);

  List<Specialty> getSpecialties();

  LargeGroup getLargeGroup(Long id) throws NoEntityFoundException;

  List<LargeGroup> getLargeGroups();

  List<com.anthem.specialty.provider.datamodel.dto.LargeGroup> getLargeGroupDtos();

  BusinessSegment getBusinessSegment(Long id);

  List<BusinessSegment> getBusinessSegments();

  DocumentType getDocumentType(String code);

  List<DocumentType> getDocumentTypes();

  ProviderRelationship getProviderRelationship(String code);

  List<ProviderRelationship> getProviderRelationships();

  List<DentalProcedure> getDentalProcedures();

  List<Language> getLanguages();

}