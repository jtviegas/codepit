package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.SimpleClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class ClinicToSimpleClinicStream implements Function<Clinic, Stream<SimpleClinic>> {

  private final ClinicToSimpleClinic mapper;

  public ClinicToSimpleClinicStream() {
    this.mapper = new ClinicToSimpleClinic();
  }

  @Override
  public Stream<SimpleClinic> apply(Clinic o) {
    return Stream.of(mapper.apply(o));
  }

}
