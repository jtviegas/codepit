package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.dto.Address;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;

public class AddressToClinicAddress implements BiFunction<Clinic, Address, ClinicAddress> {

  @Override
  public ClinicAddress apply(Clinic c, Address t) {
    ClinicAddress o = new ClinicAddress();
    o.setCity(t.getCity());
    o.setCountry(t.getCountry());
    o.setCounty(t.getCounty());
    o.setClinic(c);
    o.setDataOwner(c.getDataOwner());
    o.setLatitude(t.getLatitude());
    o.setAddress1(t.getLine1());
    o.setAddress2(t.getLine2());
    o.setAddress3(t.getLine3());
    o.setLongitude(t.getLongitude());
    o.setProvince(t.getProvince());
    o.setState(t.getState());
    o.setType(t.getType().toChar());
    o.setZipCode(t.getzIPCode());
    o.setId(t.getId());

    return o;
  }

}
