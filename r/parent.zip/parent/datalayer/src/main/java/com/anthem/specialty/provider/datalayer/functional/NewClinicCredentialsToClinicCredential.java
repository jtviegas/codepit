package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;

public class NewClinicCredentialsToClinicCredential
    implements BiFunction<Clinic, NewClinicCredentials, ClinicCredential> {

  @Override
  public ClinicCredential apply(Clinic c, NewClinicCredentials t) {
    ClinicCredential o = new ClinicCredential();

    o.setCdcOshaRulesCompliance(t.isCDCAndOSHARulesCompliance() ? 'Y' : 'N');
    o.setClinic(c);
    o.setCprTrained(t.isCprTrained() ? 'Y' : 'N');
    o.setCredentialed(t.getCredentialed());
    o.setDataOwner(c.getDataOwner());
    o.setDeptHealthRulesCompliance(t.isDeptHealthRulesCompliance() ? 'Y' : 'N');
    o.setEmergencyKit(t.isEmergencyKit() ? 'Y' : 'N');
    o.setEmergencyTrained(t.isEmergencyTrained() ? 'Y' : 'N');
    o.setHandicappedParking(t.isHandicappedParking() ? 'Y' : 'N');
    o.setHandicapAccess(t.isHandicapAccess() ? 'Y' : 'N');
    o.setPublicTransport(t.isPublicTransport() ? 'Y' : 'N');

    return o;
  }

}
