package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Carrier;
import com.anthem.specialty.provider.datamodel.dto.CarrierImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;

public class CarrierToCarrierDto
    implements Function<com.anthem.specialty.provider.datamodel.schemas.lob.Carrier, Carrier> {

  private final LinkResolver linkResolver;

  public CarrierToCarrierDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public Carrier apply(com.anthem.specialty.provider.datamodel.schemas.lob.Carrier t) {
    Carrier r = new CarrierImpl();

    r.setClearCarrierNo(t.getClearCarrierNo());
    r.setComments(t.getComments());
    r.setContactName(t.getContactName());
    r.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    r.setDescription(t.getDescription());
    if (null != t.getEffectiveFrom())
      r.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));

    r.setId(t.getId());
    r.setManager(t.getManager());
    r.setLinks(
        Arrays.asList(linkResolver.apply(new String[] { t.getId().toString() }, LinkResolver.Type.carrier, true)));

    return r;
  }

}
