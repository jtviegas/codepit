package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.Sanction;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSanction;

public class ProviderSanctionToSanctionStream implements Function<ProviderSanction, Stream<Sanction>> {

  private final ProviderSanctionToSanction mapper;

  public ProviderSanctionToSanctionStream() {
    this.mapper = new ProviderSanctionToSanction();
  }

  @Override
  public Stream<Sanction> apply(ProviderSanction p) {
    return Stream.of(mapper.apply(p));
  }

}
