package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.ProviderCredentials;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;

public class ProviderCredentialToProviderCredentialsDtoStream
    implements Function<ProviderCredential, Stream<ProviderCredentials>> {

  private final ProviderCredentialToProviderCredentialsDto mapper;

  public ProviderCredentialToProviderCredentialsDtoStream() {
    this.mapper = new ProviderCredentialToProviderCredentialsDto();
  }

  @Override
  public Stream<ProviderCredentials> apply(ProviderCredential p) {
    return Stream.of(mapper.apply(p));
  }

}
