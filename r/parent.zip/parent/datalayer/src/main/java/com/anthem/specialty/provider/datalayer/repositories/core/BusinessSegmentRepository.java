package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.BusinessSegment;

public interface BusinessSegmentRepository extends CrudRepository<BusinessSegment, Long> {
  List<BusinessSegment>  findByDescription(String description);
  List<BusinessSegment>  findByDisplayName(String displayName);
}
