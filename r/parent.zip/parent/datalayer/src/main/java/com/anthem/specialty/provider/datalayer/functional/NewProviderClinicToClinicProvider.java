package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.OpeningHours;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class NewProviderClinicToClinicProvider implements Function<NewProviderClinic, ClinicProvider> {

  private final Provider provider;

  private final Clinic clinic;

  public NewProviderClinicToClinicProvider(Provider provider, Clinic clinic) {
    this.provider = provider;
    this.clinic = clinic;
  }

  @Override
  public ClinicProvider apply(NewProviderClinic t) {
    ClinicProvider o = new ClinicProvider();

    o.setClinic(clinic);
    o.setProvider(provider);
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setDataOwner(provider.getDataOwner());

    for (OpeningHours oh : t.getHours()) {
      o.addClinicProviderSchedule(
          new ClinicProviderSchedule(oh.getDayOfWeek(), oh.getFrom(), oh.getTo(), provider.getDataOwner()));
    }

    o.setComments(t.getComments());
    o.setClearLicenseNumber(t.getClearLicenseNumber() ? 'Y' : 'N');
    o.setProviderSpecialistClinic(t.getProviderSpecialistClinic() ? 'Y' : 'N');
    o.setProviderRelationship(t.getProviderRelationship());
    o.setPayClinicProvider(t.getPayClinicProvider());
    o.setDeltaPrecertified(t.getDeltaPrecertified() ? 'Y' : 'N');
    o.setCorporatePayment(t.getCorporatePayment() ? 'Y' : 'N');
    o.setWitholdPayments(t.getWitholdPayments() ? 'Y' : 'N');
    o.setProviderCob(t.getProviderCob() ? 'Y' : 'N');
    if (null != t.getBci()) {
      o.setBciAccountBilled(t.getBci().getBilled());
      o.setBciTransactionId(t.getBci().getId());
    }
    o.setProviderClaimInReview(t.getProviderClaimInReview() ? 'Y' : 'N');
    o.setProfessionalReviewUnderway(t.getProfessionalReviewUnderway() ? 'Y' : 'N');

    return o;
  }

}
