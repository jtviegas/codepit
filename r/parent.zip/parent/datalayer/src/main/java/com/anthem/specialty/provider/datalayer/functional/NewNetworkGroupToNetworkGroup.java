package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;

public class NewNetworkGroupToNetworkGroup
    implements Function<com.anthem.specialty.provider.datamodel.dto.NewNetworkGroup, NetworkGroup> {

  private DataOwnerRepository doRepository;

  public NewNetworkGroupToNetworkGroup(DataOwnerRepository doRep) {
    doRepository = doRep;
  }

  @Override
  public NetworkGroup apply(com.anthem.specialty.provider.datamodel.dto.NewNetworkGroup src) {
    com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup ret = new com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup();
    ret.setDescription(src.getDescription());
    ret.setDataOwner(doRepository.findById(src.getDataOwnerId()).get());
    return ret;
  }

}
