package com.anthem.specialty.provider.datalayer.functional;

import java.util.Optional;
import java.util.function.BiFunction;

import com.anthem.specialty.provider.datalayer.repositories.lob.CarrierRepository;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierEffectiveRelationship;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;

public class NewCarrierRelationshipToNetworkCarrier
    implements BiFunction<Network, NewCarrierEffectiveRelationship, NetworkCarrier> {

  private final CarrierRepository carrierRepository;

  public NewCarrierRelationshipToNetworkCarrier(CarrierRepository carrierRepository) {
    this.carrierRepository = carrierRepository;
  }

  @Override
  public NetworkCarrier apply(Network n, NewCarrierEffectiveRelationship t) {
    NetworkCarrier o = new NetworkCarrier();
    // we will really assume we have the carrier here
    Optional<Carrier> c = carrierRepository.findById(t.getCarrier().getId());
    o.setCarrier(c.get());
    o.setDataOwner(c.get().getDataOwner());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setNetwork(n);

    return o;
  }

}
