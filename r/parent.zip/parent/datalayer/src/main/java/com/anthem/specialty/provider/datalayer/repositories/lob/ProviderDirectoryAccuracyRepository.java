package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.stream.Stream;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.Repository;

import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderDirectoryAccuracy;

public interface ProviderDirectoryAccuracyRepository extends Repository<ProviderDirectoryAccuracy, Long> {

  Page<ProviderDirectoryAccuracy> findAll(Pageable pageable);

  Stream<ProviderDirectoryAccuracy> findByNetworkId(Long networkId);

  Stream<ProviderDirectoryAccuracy> findByLargeGroupId(Long largeGroupId);

}
