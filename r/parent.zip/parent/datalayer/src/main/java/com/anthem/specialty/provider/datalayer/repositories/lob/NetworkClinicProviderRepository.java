package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface NetworkClinicProviderRepository extends CrudRepository<NetworkClinicProvider, Long> {
  List<NetworkClinicProvider> findByOfficeNo(String officeNo);

  List<NetworkClinicProvider> findByNetworkClinic(NetworkClinic networkClinic);

  List<NetworkClinicProvider> findByProvider(Provider provider);

  List<NetworkClinicProvider> findByProviderId(Long providerId);

  @Query(value = "select ncp.* from network_clinic_provider ncp inner join network_clinic nc "
      + "on ncp.network_clinic_id=nc.id where nc.network_id = ?1", nativeQuery = true)
  List<NetworkClinicProvider> findByNetworkId(Long networkId);

  @Query(value = "select ncp.id as id from network_clinic_provider ncp inner join network_clinic nc "
      + "on ncp.network_clinic_id=nc.id where nc.network_id = ?1 and nc.clinic_id= ?2 and ncp.provider_id = ?3", nativeQuery = true)
  List<BigDecimal> findIdByNetworkIdAndClinicIdAndProviderId(Long networkId, Long clinicId, Long providerId);

  void deleteByIdIn(List<Long> ids);

  List<NetworkClinicProvider> findByNetworkClinicIdIn(List<Long> ncIds);

  List<NetworkClinicProvider> findByNetworkClinicId(Long networkClinicId);
}
