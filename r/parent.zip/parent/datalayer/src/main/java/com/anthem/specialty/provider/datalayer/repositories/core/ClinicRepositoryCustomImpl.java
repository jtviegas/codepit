package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

@Repository
public class ClinicRepositoryCustomImpl implements ClinicRepositoryCustom {


	@PersistenceContext	 
	private EntityManager em;
			
	@Override
	public Optional<Clinic> findOneByStateMedicaidNo(String stateMedicaidNo) 
	{
	
		List<Clinic> listClinic = em.createQuery("select u from Clinic u where u.stateMedicaidNo = :stateMedicaidNo", Clinic.class)
		            .setParameter("stateMedicaidNo", stateMedicaidNo)
		            .setMaxResults(1)
		            .getResultList();
		if ( listClinic.size() != 0 )
	    {
	          return Optional.of(listClinic.get(0));
		}	
		else
	    {
		  return Optional.empty();
		}
		
		
    
	}
}
