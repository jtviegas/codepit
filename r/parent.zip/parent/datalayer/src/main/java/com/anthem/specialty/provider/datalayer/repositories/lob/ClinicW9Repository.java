package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public interface ClinicW9Repository extends CrudRepository<ClinicW9, Long> {

  List<ClinicW9> findByOfficeNumber(int officeNumber);

  List<ClinicW9> findByClinic(Clinic clinic);

  List<ClinicW9> findByClinicId(Long clinicId);

  List<ClinicW9> findByW9LegalEntity(W9LegalEntity w9LegalEntity);

  Optional<ClinicW9> findByIdAndClinicId(Long id, Long clinicId);

  Optional<ClinicW9> findByW9LegalEntityIdAndClinicId(Long w9Id, Long clinicId);

}
