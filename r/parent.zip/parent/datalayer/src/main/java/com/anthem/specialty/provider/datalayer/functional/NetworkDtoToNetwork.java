package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;

public class NetworkDtoToNetwork
    implements Function<com.anthem.specialty.provider.datamodel.dto.Network, Network> {

  private DataOwnerRepository doRepository;

  public NetworkDtoToNetwork(DataOwnerRepository doRep) {
    doRepository = doRep;
  }

  @Override
  public Network apply(com.anthem.specialty.provider.datamodel.dto.Network t) {
    Network o = new Network();

    o.setCapitationPayment(t.isCapitationPayment() ? 'Y' : 'N');
    o.setComments(t.getComments());
    o.setCustomerServiceDisplayed(t.isCustomerServiceDisplayed() ? 'Y' : 'N');
    o.setDataOwner(doRepository.findById(t.getDataOwner().getId()).get());
    o.setDescription(t.getDescription());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setManager(t.getManager());
    o.setShortDescription(t.getShortDescription());
    o.setId(t.getId());

    return o;
  }

}
