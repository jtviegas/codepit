package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicOpeningHours;

public interface ClinicOpeningHoursRepository extends CrudRepository<ClinicOpeningHours, Long> {
  List<ClinicOpeningHours> findByClinic(Clinic clinic);
}
