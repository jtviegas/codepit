package com.anthem.specialty.provider.datalayer.repositories.core;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.DocumentType;

public interface DocumentTypeRepository extends CrudRepository<DocumentType, String> {

}
