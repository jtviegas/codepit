package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

public class PageDtoTransformerImpl<R, T> implements PageDtoTransformer<R, T> {

  private final Function<R, T> functional;

  public PageDtoTransformerImpl(Function<R, T> functional) {
    this.functional = functional;
  }

  @Override
  public Page<T> apply(Page<R> t) {
    Page<T> r = new PageImpl<>(t.getContent().stream().map(this.functional).collect(Collectors.toList()),
        t.getPageable(), t.getTotalElements());
    return r;
  }

}
