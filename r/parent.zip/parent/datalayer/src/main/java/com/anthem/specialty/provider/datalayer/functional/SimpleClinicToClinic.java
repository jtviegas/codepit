package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.SimpleClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class SimpleClinicToClinic implements Function<SimpleClinic, Clinic> {

  @Override
  public Clinic apply(SimpleClinic o) {
    Clinic r = new Clinic();
    if (null == o)
      throw new IllegalArgumentException("!!! SimpleClinic is null !!!");

    r.setCommonName(o.getCommonName());
    return r;
  }

}
