package com.anthem.specialty.provider.datalayer.functional;

import static java.lang.String.format;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.SimpleProvider;
import com.anthem.specialty.provider.datamodel.dto.SimpleProviderImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class ProviderToSimpleProvider implements Function<Provider, SimpleProvider> {

  private final LinkResolver linkResolver;

  public ProviderToSimpleProvider() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public SimpleProvider apply(Provider provider) {

    if (null == provider.getFirstName() && null == provider.getMiddleName() && null == provider.getLastName())
      throw new IllegalArgumentException("!!! provider has no name (neither first, middle nor last) !!!");
    SimpleProvider r = new SimpleProviderImpl();
    String name = format("%s %s %s", null == provider.getFirstName() ? "" : provider.getFirstName(),
        null == provider.getMiddleName() ? "" : provider.getMiddleName(),
        null == provider.getLastName() ? "" : provider.getLastName());
    r.setName(name);

    r.setLinks(Arrays
        .asList(linkResolver.apply(new String[] { provider.getId().toString() }, LinkResolver.Type.provider, true)));
    r.setDataOwner(new DataOwnerToDataOwnerDto().apply(provider.getDataOwner()));
    r.setId(provider.getId());

    return r;
  }

}
