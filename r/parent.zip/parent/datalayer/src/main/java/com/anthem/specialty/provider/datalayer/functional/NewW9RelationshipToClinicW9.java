package com.anthem.specialty.provider.datalayer.functional;

import com.anthem.specialty.provider.datalayer.utils.TriFunction;
import com.anthem.specialty.provider.datamodel.dto.NewW9EffectiveRelationship;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public class NewW9RelationshipToClinicW9 implements TriFunction<Clinic, W9LegalEntity, NewW9EffectiveRelationship, ClinicW9> {

  @Override
  public ClinicW9 apply(Clinic c, W9LegalEntity w9, NewW9EffectiveRelationship t) {
    ClinicW9 o = new ClinicW9();
    o.setDataOwner(c.getDataOwner());
    o.setClinic(c);
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setW9LegalEntity(w9);
    o.setOfficeNumber(t.getOfficeNumber());
    return o;
  }

}
