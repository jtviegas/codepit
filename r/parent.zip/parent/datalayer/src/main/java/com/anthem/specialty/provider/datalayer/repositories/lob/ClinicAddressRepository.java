package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;

public interface ClinicAddressRepository extends CrudRepository<ClinicAddress, Long> {
  List<ClinicAddress> findByClinic(Clinic clinic);

  List<ClinicAddress> findByClinicId(Long clinicId);

  Optional<ClinicAddress> findByIdAndClinicId(Long addressId, Long clinicId);

  Optional<ClinicAddress> findByClinicIdAndType(Long clinicId, Character type);
}
