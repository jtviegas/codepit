package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.CoreDataEntityImpl;
import com.anthem.specialty.provider.datamodel.dto.FocusReviewTermination;
import com.anthem.specialty.provider.datamodel.dto.FocusReviewTerminationImpl;
import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReviewImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;

public class FocusReviewToProviderFocusReview implements Function<FocusReview, ProviderFocusReview> {

  private final LinkResolver linkResolver;

  public FocusReviewToProviderFocusReview() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public ProviderFocusReview apply(FocusReview t) {
    ProviderFocusReview o = new ProviderFocusReviewImpl();

    o.setClinic(new CoreDataEntityImpl(t.getClinic().getId()));
    o.setNetworkGroup(new CoreDataEntityImpl(t.getNetworkGroup().getId()));
    o.setAuditNumber(t.getAuditNumber());
    o.setCommenced(t.getCommenced());
    o.setComments(t.getComments());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setId(t.getId());
    o.setProcedureCodes(t.getProcedureCodes());
    o.setTerminated(getTerminatedAsTermination(t));

    List<com.anthem.specialty.provider.datamodel.dto.Link> links = new ArrayList<com.anthem.specialty.provider.datamodel.dto.Link>();
    links.add(linkResolver.apply(new String[] { t.getClinic().getId().toString() }, LinkResolver.Type.clinic, false));
    links.add(
        linkResolver.apply(new String[] { t.getProvider().getId().toString() }, LinkResolver.Type.provider, false));
    links.add(linkResolver.apply(new String[] { t.getNetworkGroup().getId().toString() },
        LinkResolver.Type.networkgroup, false));
    links.add(linkResolver.apply(new String[] { t.getProvider().getId().toString(), t.getId().toString() },
        LinkResolver.Type.provider_focus_review, true));
    o.setLinks(links);

    return o;
  }

  public FocusReviewTermination getTerminatedAsTermination(FocusReview t) {
    FocusReviewTermination r = null;
    if (null != t.getTerminated()) {
      r = new FocusReviewTerminationImpl();
      r.setFrom(t.getTerminated());
      if (null != t.getReason())
        r.setReason(t.getReason());
    }
    return r;
  }

}
