package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;

public class CarrierPhoneContactDtoToCarrierPhoneContact implements
    BiFunction<Carrier, com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact, CarrierPhoneContact> {

  public CarrierPhoneContactDtoToCarrierPhoneContact() {
  }

  @Override
  public CarrierPhoneContact apply(Carrier t, com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact u) {
    CarrierPhoneContact o = new CarrierPhoneContact();

    o.setAccessCode(u.getAccessCode());
    o.setAreaCode(u.getAreaCode());
    o.setCarrier(t);
    o.setCityCode(u.getCityCode());
    o.setCountryCode(u.getCountryCode());
    o.setDataOwner(t.getDataOwner());
    o.setExtension(u.getExtension());
    o.setId(u.getId());
    o.setNumber(u.getNumber());
    o.setType(u.getType().asChar());

    return o;
  }

}
