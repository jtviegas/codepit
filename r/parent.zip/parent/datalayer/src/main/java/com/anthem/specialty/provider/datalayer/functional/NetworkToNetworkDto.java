package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;

public class NetworkToNetworkDto
    implements Function<Network, com.anthem.specialty.provider.datamodel.dto.Network> {

  private final LinkResolver linkResolver;

  public NetworkToNetworkDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Network apply(Network t) {
    com.anthem.specialty.provider.datamodel.dto.Network o = new com.anthem.specialty.provider.datamodel.dto.NetworkImpl();

    o.setCapitationPayment(t.getCapitationPayment().equals('Y'));
    o.setComments(t.getComments());
    o.setCustomerServiceDisplayed(t.getCustomerServiceDisplayed().equals('Y'));
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setDescription(t.getDescription());
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));
    o.setId(t.getId());
    o.setManager(t.getManager());
    o.setShortDescription(t.getShortDescription());
    o.setLinks(
        Arrays.asList(linkResolver.apply(new String[] { t.getId().toString() }, LinkResolver.Type.network, true)));
    return o;
  }

}
