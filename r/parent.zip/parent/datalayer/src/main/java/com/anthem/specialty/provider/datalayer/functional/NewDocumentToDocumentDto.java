package com.anthem.specialty.provider.datalayer.functional;

import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.dto.DocumentImpl;
import com.anthem.specialty.provider.datamodel.dto.Link;
import com.anthem.specialty.provider.datamodel.dto.NewDocument;

public class NewDocumentToDocumentDto implements Function<NewDocument, Document> {

  private final DataOwner dOwner;

  private List<Link> links;

  private Long id;

  public NewDocumentToDocumentDto(DataOwner dOwner, Long id, List<Link> links) {
    this.dOwner = dOwner;
    this.id = id;
    this.links = links;
  }

  @Override
  public Document apply(NewDocument t) {
    Document o = new DocumentImpl();

    o.setControlNumber(t.getControlNumber());
    o.setSource(t.getSource());
    o.setType(t.getType());
    o.setDataOwner(dOwner);
    o.setId(id);
    o.setLinks(links);
    return o;
  }

}
