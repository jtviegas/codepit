package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.EssentialCommunityProvider;
import com.anthem.specialty.provider.datamodel.dto.EssentialCommunityProviderImpl;
import com.anthem.specialty.provider.datamodel.dto.GeneralInsurance;
import com.anthem.specialty.provider.datamodel.dto.GeneralInsuranceImpl;
import com.anthem.specialty.provider.datamodel.dto.HearingService;
import com.anthem.specialty.provider.datamodel.dto.HearingServiceImpl;
import com.anthem.specialty.provider.datamodel.dto.IntensiveTherapyUnitService;
import com.anthem.specialty.provider.datamodel.dto.IntensiveTherapyUnitServiceImpl;
import com.anthem.specialty.provider.datamodel.dto.Link;
import com.anthem.specialty.provider.datamodel.dto.OpeningHours;
import com.anthem.specialty.provider.datamodel.dto.OpeningHoursImpl;
import com.anthem.specialty.provider.datamodel.dto.Patients;
import com.anthem.specialty.provider.datamodel.dto.PatientsImpl;
import com.anthem.specialty.provider.datamodel.dto.Services;
import com.anthem.specialty.provider.datamodel.dto.ServicesImpl;
import com.anthem.specialty.provider.datamodel.dto.Staffing;
import com.anthem.specialty.provider.datamodel.dto.StaffingImpl;
import com.anthem.specialty.provider.datamodel.dto.VisionService;
import com.anthem.specialty.provider.datamodel.dto.VisionServiceImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicOpeningHours;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;

public class ClinicToClinicDto implements Function<Clinic, com.anthem.specialty.provider.datamodel.dto.Clinic> {

  private final LinkResolver linkResolver;

  public ClinicToClinicDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Clinic apply(Clinic o) {
    com.anthem.specialty.provider.datamodel.dto.Clinic r = new com.anthem.specialty.provider.datamodel.dto.ClinicImpl();
    if (null == o)
      throw new IllegalArgumentException("!!! clinic is null !!!");

    r.setAlphabeticalSortBy(o.getAlphabeticalSortBy());
    r.setComments(o.getComments());
    r.setCommonName(o.getCommonName());
    r.setContactName(o.getContactName());
    r.setDataOwner(new DataOwnerToDataOwnerDto().apply(o.getDataOwner()));
    if (null != o.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(o.getEffectiveFrom());
      ep.setTo(o.getEffectiveTo());
      r.setEffective(ep);
    }
    r.setElectronicClaimsSubmissionSupported(o.getEcsCapable().equals('Y') ? true : false);
    r.setEmailAddress(o.getEmailAddress());
    r.setEmergencyInstructions(o.getEmergencyInstructions().equals('Y') ? true : false);
    if (null != o.getEssentialCommunityProvider()) {
      EssentialCommunityProvider ecp = new EssentialCommunityProviderImpl();
      ecp.setEcpType(o.getEssentialCommunityProvider().toString());
      r.setEssentialCommunityProvider(ecp);
    }

    if (o.getGeneralInsurance().equals('Y')) {
      GeneralInsurance gi = new GeneralInsuranceImpl();
      gi.setInsurer(o.getGeneralInsuranceCo());
      gi.setLimit(o.getGeneralInsuranceLimit());
      gi.setPolicy(o.getGeneralInsurancePolicy());
      gi.setRenewal(o.getGeneralInsuranceRenewal());
      r.setGeneralInsurance(gi);
    }

    if (!o.getClinicOpeningHours().isEmpty()) {
      List<OpeningHours> oh = new ArrayList<OpeningHours>();
      for (ClinicOpeningHours h : o.getClinicOpeningHours())
        oh.add(new OpeningHoursImpl(h.getDayOfWeek(), h.getOpens(), h.getCloses()));
      r.setHours(oh);
    }

    r.setId(o.getId());
    List<Link> links = new ArrayList<Link>();
    r.setLinks(links);
    links.add(linkResolver.apply(new String[] { o.getId().toString() }, LinkResolver.Type.clinic, true));

    for (ClinicAddress e : o.getClinicAddresses())
      links.add(linkResolver.apply(new String[] { o.getId().toString(), e.getId().toString() },
          LinkResolver.Type.clinic_address, false));

    for (ClinicW9 e : o.getClinicW9s())
      links.add(linkResolver.apply(new String[] { o.getId().toString(), e.getId().toString() },
          LinkResolver.Type.clinic_w9, false));

    for (ClinicPhoneContact e : o.getClinicPhoneContacts())
      links.add(linkResolver.apply(new String[] { o.getId().toString(), e.getId().toString() },
          LinkResolver.Type.clinic_phoneContacts, false));

    for (ClinicCredential e : o.getClinicCredentials())
      links.add(linkResolver.apply(new String[] { o.getId().toString(), e.getId().toString() },
          LinkResolver.Type.clinic_credential, false));

    for (ClinicLanguage e : o.getClinicLanguages())
      links.add(linkResolver.apply(new String[] { o.getId().toString(), e.getId().toString() },
          LinkResolver.Type.clinic_language, false));

    for (FocusReview e : o.getFocusReviews())
      links.add(linkResolver.apply(new String[] { o.getId().toString(), e.getId().toString() },
          LinkResolver.Type.clinic_focus_review, false));

    links.add(
        linkResolver.apply(new String[] { o.getDataOwner().getId().toString() }, LinkResolver.Type.data_owner, false));

    r.setMaRating(o.getMaRating());
    r.setMemberEmailAddress(o.getMemberEmailAddress());

    r.setPatients(resolvePatients(o));
    r.setPaymentName(o.getPaymentName());
    r.setPracticeManagementSoftware(o.getPracticeManagementSoftware());
    // TODO r.setProfessionalReviewUnderway(o.getP...);
    r.setReimburseContinuedEducation(o.getReimburseContinuedEducation().equals('Y') ? true : false);
    r.setServices(resolveServices(o));
    r.setStaffing(resolveStaffing(o));
    r.setStateMedicaidNo(o.getStateMedicaidNo());
    r.setUcrRegionCode(o.getUcrRegionCode());
    r.setVisitedNursingHomes(o.getVisitedNursingHomes());
    r.setWebAddress(o.getWebAddress());
    r.setWheelchairAccessible(o.getWheelchairAccessible().equals('Y') ? true : false);

    return r;
  }

  private Patients resolvePatients(Clinic o) {
    Patients r = new PatientsImpl();

    r.setAcceptsNewMedicaidPatients(o.getAcceptsNewMedicaidPatients().equals('Y'));
    r.setAcceptsNewPatients(o.getAcceptsNewPatients().equals('Y'));
    r.setHygienistMonthlyPatients(o.getHygienistCount());
    r.setMedicaidMonthlyPatients(o.getMedicaidMonthlyPatients());
    r.setMedicaidPatientsConverted(o.getMedicaidPatientsConverted().equals('Y'));
    r.setNewMedicaidPatientPolicy(o.getNewMedicaidPatientPolicy());
    r.setProviderMonthlyPatients(o.getProviderMonthlyPatients());
    r.setUnderEighteens(o.getAcceptsUnderEighteens().equals('Y'));
    r.setUnderThrees(o.getAcceptsUnderThrees().equals('Y'));

    return r;
  }

  private Services resolveServices(Clinic o) {
    Services r = new ServicesImpl();

    r.setAdultDisabilitySupported(o.getAdultDisabilitySupported().equals('Y'));
    r.setChildDisabilitySupported(o.getChildDisabilitySupported().equals('Y'));
    r.setDevelopmentallyDisabledServices(o.getDevelopmentallyDisabledSvc().equals('Y'));
    r.setDiagnosticService(o.getDiagnosticService().equals('Y'));
    r.setEndodonticService(o.getEndodonticService().equals('Y'));

    HearingService hs = new HearingServiceImpl();
    hs.setType(o.getHearingServicesType());
    r.setHearing(hs);

    r.setHivServices(o.getHivServices().equals('Y'));

    IntensiveTherapyUnitService itu = new IntensiveTherapyUnitServiceImpl();
    itu.setType(o.getItuClinicType());
    r.setIntensiveTherapyUnit(itu);

    r.setMobilityServices(o.getMobilityServices().equals('Y'));
    r.setNursingHomeVisits(o.getNursingHomeVisits().equals('Y'));
    r.setOralSurgeryService(o.getOralSurgeryService().equals('Y'));
    r.setOrthodonticService(o.getOrthodonticService().equals('Y'));
    r.setPedodonticService(o.getPedodonticService().equals('Y'));
    r.setPeriodonticService(o.getPeriodonticService().equals('Y'));
    r.setPreventiveService(o.getPreventiveService().equals('Y'));
    r.setProsthodonticService(o.getProsthodonticService().equals('Y'));
    r.setRestorativeService(o.getRestorativeService().equals('Y'));
    r.setSpecialAccommodations(o.getSpecialAccommodations());
    r.setTmjService(o.getTmjService().equals('Y'));
    VisionService vs = new VisionServiceImpl();
    vs.setType(o.getVisionServicesType());
    r.setVision(vs);

    return r;
  }

  private Staffing resolveStaffing(Clinic o) {
    Staffing r = new StaffingImpl();

    r.setAdvancedDentalHygienistCount(o.getAdvancedDentHygienistCount());
    r.setAdvancedDentalTherapistCount(o.getAdvancedDentTherapistCount());
    r.setAssistantCount(o.getAssistantCount());
    r.setCollaborativeHygienistCount(o.getCollaborativeHygienistCount());
    r.setDentalTherapistCount(o.getDentalTherapistCount());
    r.setHygienistCount(o.getHygienistCount());
    r.setProviderCount(o.getProviderCount());
    r.setSpecialistCount(o.getSpecialistCount());

    return r;
  }

}
