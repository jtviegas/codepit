package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface FocusReviewRepository extends CrudRepository<FocusReview, Long> {
  List<FocusReview> findByAuditNumber(int auditNumber);

  List<FocusReview> findByNetworkGroup(NetworkGroup networkGroup);

  List<FocusReview> findByClinic(Clinic clinic);

  List<FocusReview> findByProvider(Provider provider);

  List<FocusReview> findByProviderId(Long providerId);

  Optional<FocusReview> findByIdAndProviderId(Long id, Long providerId);

  void deleteByIdAndProviderId(Long id, Long providerId);

  Optional<FocusReview> findByIdAndClinicId(Long id, Long clinicId);

  List<FocusReview> findByClinicId(Long clinicId);

}
