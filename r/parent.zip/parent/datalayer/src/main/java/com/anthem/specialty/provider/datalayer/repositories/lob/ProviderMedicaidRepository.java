package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;

public interface ProviderMedicaidRepository extends CrudRepository<ProviderMedicaid, Long> {
  List<ProviderMedicaid> findByProvider(Provider provider);

  List<ProviderMedicaid> findByProviderId(Long providerId);

  Optional<ProviderMedicaid> findByProviderIdAndMedicaidState(Long providerId, String medicaidState);

  Optional<ProviderMedicaid> findByProviderIdAndMedicaidNo(Long providerId, String medicaidNo);
}
