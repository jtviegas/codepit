package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetworkBuilder;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetworkItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetworkItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;

public class NetworkToRelatedNetwork implements Function<Network, RelatedNetwork> {

  private final LinkResolver linkResolver;

  public NetworkToRelatedNetwork() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedNetwork apply(Network t) {

    if (null == t)
      throw new IllegalArgumentException("network must not be null");

    RelatedNetworkItem network = new RelatedNetworkItemImpl();
    network.setName(t.getShortDescription());
    network.setId(t.getId());
    network.setLink(linkResolver.apply(new String[] { t.getId().toString() }, LinkResolver.Type.network, true));

    RelatedNetworkBuilder builder = new RelatedNetworkBuilder(t.getId(),
        new DataOwnerToDataOwnerDto().apply(t.getDataOwner()), network);

    if (null != t.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(t.getEffectiveFrom());
      if (null != t.getEffectiveTo())
        ep.setTo(t.getEffectiveTo());
      builder.withEffective(ep);
    }

    return builder.build();
  }

}
