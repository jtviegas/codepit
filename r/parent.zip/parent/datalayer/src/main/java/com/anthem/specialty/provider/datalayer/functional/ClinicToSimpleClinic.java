package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.SimpleClinic;
import com.anthem.specialty.provider.datamodel.dto.SimpleClinicImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class ClinicToSimpleClinic implements Function<Clinic, SimpleClinic> {

  private final LinkResolver linkResolver;

  public ClinicToSimpleClinic() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public SimpleClinic apply(Clinic o) {
    SimpleClinic r = new SimpleClinicImpl();
    if (null == o)
      throw new IllegalArgumentException("!!! clinic is null !!!");

    r.setCommonName(o.getCommonName());
    r.setDataOwner(new DataOwnerToDataOwnerDto().apply(o.getDataOwner()));
    r.setId(o.getId());
    r.setLinks(
        Arrays.asList(linkResolver.apply(new String[] { o.getId().toString() }, LinkResolver.Type.clinic, true)));
    return r;
  }

}
