package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class ClinicToRelatedClinic implements Function<Clinic, RelatedClinic> {

  public ClinicToRelatedClinic() {
  }

  @Override
  public RelatedClinic apply(Clinic clinic) {
    RelatedClinic r = new RelatedClinicImpl();
    if (null == clinic)
      throw new IllegalArgumentException("!!! clinic is null !!!");

    r.setClinic(new ClinicToRelatedClinicItem().apply(clinic));
    r.setDataOwner(new DataOwnerToDataOwnerDto().apply(clinic.getDataOwner()));
    r.setEffective(clinic.getEffectivePeriod());
    r.setId(clinic.getId());

    return r;
  }

}
