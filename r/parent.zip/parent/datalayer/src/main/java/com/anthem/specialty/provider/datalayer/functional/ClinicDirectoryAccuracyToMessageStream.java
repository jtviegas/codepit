package com.anthem.specialty.provider.datalayer.functional;

import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.specialty.provider.datamodel.dto.UpdateableAddress;
import com.anthem.specialty.provider.datamodel.dto.UpdateableAddressImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.Accessibility;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.AccessibilityImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicElementImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElement;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElementImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.Contacts;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.ContactsImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.W9ElementImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicDirectoryAccuracy;

/**
 * ClinicDirectoryAccuracyToMessageStream
 * 
 * Is a stream mapper applies transformation in a clinic directory accuracy query row, resolving its elements, keeping
 * track of its references and completing them as the stream of related rows is fed in.
 * 
 * As an example, once a given row denotes a new aggregation/clinic directory, it creates a new top level element,
 * DirectoryVerificationElement, returns it inside an Optional, and keeps processing the next lines related to this
 * element, adding the related data to its reference, and in the mean time returning an empty optional, once it receives
 * a row related to a new top level element, releases the previous DirectoryVerificationElement reference and creates a
 * new one, and goes on with the same rationale, until there is no more rows.
 * 
 * @author jviegas
 *
 */
public class ClinicDirectoryAccuracyToMessageStream
    implements Function<ClinicDirectoryAccuracy, Optional<ClinicVerificationElement>> {

  private static final Logger logger = LoggerFactory.getLogger(ClinicDirectoryAccuracyToMessageStream.class);

  private ClinicVerificationElementImpl clinicDirectoryPointer;

  private final LinkResolver linkResolver = new LinkResolver();

  @Override
  public Optional<ClinicVerificationElement> apply(ClinicDirectoryAccuracy t) {
    logger.trace("[apply] in");
    Optional<ClinicVerificationElement> r = Optional.empty();

    if (null == clinicDirectoryPointer
        || (null == t.getLargeGroupId() && (clinicDirectoryPointer.getLargeGroupName() != null))
        || (!t.getLargeGroupName().equals(clinicDirectoryPointer.getLargeGroupName()))) {
      clinicDirectoryPointer = new ClinicVerificationElementImpl();
      clinicDirectoryPointer.setLargeGroupName(t.getLargeGroupName());
      logger.debug("[apply] new clinicDirectoryPointer: {}", clinicDirectoryPointer);
      r = Optional.of(clinicDirectoryPointer);
    }

    clinicDirectoryPointer.increaseRows();

    // hand over analysis of row to the W9 section
    Optional<W9ElementImpl> newW9 = parseW9(t);
    if (newW9.isPresent())
      clinicDirectoryPointer.getW9().add(newW9.get());

    logger.trace("[apply] out");
    // stream over whatever we've realized here
    return r;
  }

  private W9ElementImpl w9Pointer;

  private Optional<W9ElementImpl> parseW9(ClinicDirectoryAccuracy t) {
    logger.trace("[parseW9] in");
    Optional<W9ElementImpl> r = Optional.empty();
    if (null == w9Pointer || (!w9Pointer.getId().equals(t.getW9BusinessId()))) {
      // new W9 in the stream
      w9Pointer = new W9ElementImpl();
      w9Pointer.setId(t.getW9BusinessId());
      // TODO w9Pointer.setLink(t.get);
      w9Pointer.setName(t.getW9IrsName());
      w9Pointer.setTin(t.getTin());
      logger.debug("[parseW9] new w9Pointer: {}", w9Pointer);
      r = Optional.of(w9Pointer);
    }

    // hand over analysis of row to the Clinic section
    w9Pointer.getClinics().add(parseClinic(t));

    logger.trace("[parseW9] out");
    // return whatever we've realized here
    return r;
  }

  private ClinicElementImpl parseClinic(ClinicDirectoryAccuracy t) {
    logger.trace("[parseClinic] in");

    ClinicElementImpl r = new ClinicElementImpl();
    r.setId(t.getClinicId());
    r.setLink(linkResolver.apply(new String[] { t.getClinicId().toString() }, LinkResolver.Type.clinic, false));
    r.setName(t.getClinic());
    UpdateableAddress address = new UpdateableAddressImpl();
    address.setCity(t.getCity());
    address.setLine1(t.getAddress1());
    address.setState(t.getState());
    address.setzIPCode(t.getZipCode());
    r.setAddress(address);
    if (null != t.getClinicNpi() && 0 < t.getClinicNpi().length()) {
      r.setClinicNpi(Stream.of(t.getClinicNpi().split(",")).map(s -> s.trim()).filter(s -> 0 < s.length()).distinct()
          .collect(Collectors.toList()));
    }
    if (null != t.getCorporateNpi() && 0 < t.getCorporateNpi().length()) {
      r.setCorporateNpi(Stream.of(t.getCorporateNpi().split(",")).map(s -> s.trim()).filter(s -> 0 < s.length())
          .distinct().collect(Collectors.toList()));
    }
    r.setDiversified(t.getDiversified().equals('Y'));

    if (null != t.getCorrespondenceAddress1()) {
      UpdateableAddress correspondence = new UpdateableAddressImpl();
      correspondence.setLine1(t.getCorrespondenceAddress1());
      correspondence.setzIPCode(t.getCorrespondenceZip());
      correspondence.setCity(t.getCorrespondenceCity());
      correspondence.setState(t.getCorrespondenceState());
      r.setCorrespondence(correspondence);
    }

    if (null != t.getBillingAddress1()) {
      UpdateableAddress billing = new UpdateableAddressImpl();
      billing.setLine1(t.getBillingAddress1());
      billing.setzIPCode(t.getBillingZip());
      billing.setCity(t.getBillingCity());
      billing.setState(t.getBillingState());
      r.setBilling(billing);
    }

    Contacts contacts = new ContactsImpl();
    // TODO contacts.setCarrierEmail();
    contacts.setFax(t.getFaxNumber());
    contacts.setMemberEmail(t.getMemberEmail());
    contacts.setPhone(t.getPhoneNumber());
    r.setContacts(contacts);

    Accessibility accessibility = new AccessibilityImpl();
    accessibility.setHandicapAccess(t.getHandicapAccessible().equals("Y"));
    if (null != t.getLanguagesSpoken() && 0 < t.getLanguagesSpoken().length()) {
      accessibility.setLanguages(Stream.of(t.getLanguagesSpoken().split(",")).map(s -> s.trim())
          .filter(s -> 0 < s.length()).distinct().collect(Collectors.toList()));
    }
    accessibility.setWheelchairAccess(t.getWheelChairAccessible().equalsIgnoreCase("Y"));
    r.setAccessibility(accessibility);

    logger.debug("[parseClinic] new clinic: {}", r);

    logger.trace("[parseClinic] out");
    // return whatever we've realized here
    return r;
  }

}
