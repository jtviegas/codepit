package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;

public class DocumentControlToDocumentStream implements Function<DocumentControl, Stream<Document>> {

  private final DocumentControlToDocument mapper;

  public DocumentControlToDocumentStream() {
    this.mapper = new DocumentControlToDocument();
  }

  @Override
  public Stream<Document> apply(DocumentControl t) {

    return Stream.of(mapper.apply(t));
  }

}
