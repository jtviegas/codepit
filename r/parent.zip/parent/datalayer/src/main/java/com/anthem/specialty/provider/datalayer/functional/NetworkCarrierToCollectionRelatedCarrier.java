package com.anthem.specialty.provider.datalayer.functional;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkCarrierRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkRepository;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrier;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrierImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;

public class NetworkCarrierToCollectionRelatedCarrier implements Function<NetworkCarrier, CollectionRelatedCarrier> {

  private final NetworkCarrierRepository repository;

  private final NetworkRepository nRepository;

  public NetworkCarrierToCollectionRelatedCarrier(NetworkCarrierRepository repository, NetworkRepository nRepository) {
    this.repository = repository;
    this.nRepository = nRepository;
  }

  @Override
  public CollectionRelatedCarrier apply(NetworkCarrier t) {
    CollectionRelatedCarrier o = new CollectionRelatedCarrierImpl();

    o.setCarrier(new CarrierToRelatedCarrierItem().apply(t.getCarrier()));
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));
    o.setId(t.getId());

    List<Long> nwIds = repository.findRelatedNetworkIdById(t.getCarrier().getId()).stream().map(n -> n.longValue())
        .collect(Collectors.toList());

    o.setNetworks(nRepository.findByIdIn(nwIds).map(new NetworkToRelatedNetwork()).collect(Collectors.toList()));

    return o;
  }

}
