package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.Optional;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface ProviderRepositoryCustom {
		Optional<Provider> findOneByTin(String tin);
	
}
