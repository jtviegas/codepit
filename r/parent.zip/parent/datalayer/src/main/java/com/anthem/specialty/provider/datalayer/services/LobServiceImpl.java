package com.anthem.specialty.provider.datalayer.services;

import static java.lang.String.format;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import javax.transaction.Transactional;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.anthem.specialty.provider.datalayer.exceptions.DataConstraintException;
import com.anthem.specialty.provider.datalayer.exceptions.DataIntegrityException;
import com.anthem.specialty.provider.datalayer.exceptions.DataLayerException;
import com.anthem.specialty.provider.datalayer.exceptions.DataValidationException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.AddressToClinicAddress;
import com.anthem.specialty.provider.datalayer.functional.CarrierDtoToCarrier;
import com.anthem.specialty.provider.datalayer.functional.CarrierPhoneContactDtoToCarrierPhoneContact;
import com.anthem.specialty.provider.datalayer.functional.CarrierPhoneContactToCarrierPhoneContactDto;
import com.anthem.specialty.provider.datalayer.functional.CarrierToCarrierDto;
import com.anthem.specialty.provider.datalayer.functional.ClinicAddressToAddress;
import com.anthem.specialty.provider.datalayer.functional.ClinicCredentialDtoToClinicCredential;
import com.anthem.specialty.provider.datalayer.functional.ClinicCredentialToClinicCredentialDto;
import com.anthem.specialty.provider.datalayer.functional.ClinicDirectoryAccuracyToMessageStream;
import com.anthem.specialty.provider.datalayer.functional.ClinicDtoToClinic;
import com.anthem.specialty.provider.datalayer.functional.ClinicFocusReviewToFocusReview;
import com.anthem.specialty.provider.datalayer.functional.ClinicLanguageToLanguage;
import com.anthem.specialty.provider.datalayer.functional.ClinicPhoneContactToPhoneContact;
import com.anthem.specialty.provider.datalayer.functional.ClinicProviderToClinicProviderDto;
import com.anthem.specialty.provider.datalayer.functional.ClinicProviderToProviderClinicDto;
import com.anthem.specialty.provider.datalayer.functional.ClinicProviderToProviderClinicDtoStream;
import com.anthem.specialty.provider.datalayer.functional.ClinicToClinicDto;
import com.anthem.specialty.provider.datalayer.functional.ClinicToSimpleClinic;
import com.anthem.specialty.provider.datalayer.functional.ClinicToSimpleClinicStream;
import com.anthem.specialty.provider.datalayer.functional.ClinicW9ToRelatedW9;
import com.anthem.specialty.provider.datalayer.functional.CollectionRelatedCarrierToNetworkCarrier;
import com.anthem.specialty.provider.datalayer.functional.DataOwnerToDataOwnerDto;
import com.anthem.specialty.provider.datalayer.functional.DisciplinaryActionDtoToDisciplinaryAction;
import com.anthem.specialty.provider.datalayer.functional.DisciplinaryActionToDisciplinaryActionDto;
import com.anthem.specialty.provider.datalayer.functional.DisciplinaryActionToDisciplinaryActionDtoStream;
import com.anthem.specialty.provider.datalayer.functional.DocumentControlToDocument;
import com.anthem.specialty.provider.datalayer.functional.DocumentControlToDocumentStream;
import com.anthem.specialty.provider.datalayer.functional.FocusReviewToClinicFocusReview;
import com.anthem.specialty.provider.datalayer.functional.FocusReviewToProviderFocusReview;
import com.anthem.specialty.provider.datalayer.functional.LegalAddressDtoToLegalAddress;
import com.anthem.specialty.provider.datalayer.functional.LegalAddressToLegalAddressDto;
import com.anthem.specialty.provider.datalayer.functional.LicenseToProviderLicense;
import com.anthem.specialty.provider.datalayer.functional.MedicaidToProviderMedicaid;
import com.anthem.specialty.provider.datalayer.functional.NetworkCarrierToCollectionRelatedCarrier;
import com.anthem.specialty.provider.datalayer.functional.NetworkCarrierToRelatedNetwork;
import com.anthem.specialty.provider.datalayer.functional.NetworkClinicProviderRelationshipToNetworkClinicProvider;
import com.anthem.specialty.provider.datalayer.functional.NetworkClinicProviderToNetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datalayer.functional.NetworkClinicProviderToRelatedProvider;
import com.anthem.specialty.provider.datalayer.functional.NetworkClinicRelationshipToNetworkClinic;
import com.anthem.specialty.provider.datalayer.functional.NetworkClinicToNetworkClinicRelationship;
import com.anthem.specialty.provider.datalayer.functional.NetworkClinicToRelatedClinic;
import com.anthem.specialty.provider.datalayer.functional.NetworkDtoToNetwork;
import com.anthem.specialty.provider.datalayer.functional.NetworkToNetworkDto;
import com.anthem.specialty.provider.datalayer.functional.NetworkToRelatedNetwork;
import com.anthem.specialty.provider.datalayer.functional.NewAddressToClinicAddress;
import com.anthem.specialty.provider.datalayer.functional.NewCarrierDtoToCarrier;
import com.anthem.specialty.provider.datalayer.functional.NewCarrierPhoneContactToCarrierPhoneContact;
import com.anthem.specialty.provider.datalayer.functional.NewCarrierRelationshipToNetworkCarrier;
import com.anthem.specialty.provider.datalayer.functional.NewClinicCredentialsToClinicCredential;
import com.anthem.specialty.provider.datalayer.functional.NewClinicProviderToClinicProvider;
import com.anthem.specialty.provider.datalayer.functional.NewClinicToClinic;
import com.anthem.specialty.provider.datalayer.functional.NewDisciplinaryActionToDisciplinaryAction;
import com.anthem.specialty.provider.datalayer.functional.NewDocumentToDocumentControl;
import com.anthem.specialty.provider.datalayer.functional.NewFocusReviewToFocusReview;
import com.anthem.specialty.provider.datalayer.functional.NewLanguageToClinicLanguage;
import com.anthem.specialty.provider.datalayer.functional.NewLanguageToProviderLanguage;
import com.anthem.specialty.provider.datalayer.functional.NewLegalAddressToLegalAddress;
import com.anthem.specialty.provider.datalayer.functional.NewLicenseToProviderLicense;
import com.anthem.specialty.provider.datalayer.functional.NewNetworkClinicProviderRelationshipToNetworkClinicProvider;
import com.anthem.specialty.provider.datalayer.functional.NewNetworkClinicRelationshipToNetworkClinic;
import com.anthem.specialty.provider.datalayer.functional.NewNetworkDtoToNetwork;
import com.anthem.specialty.provider.datalayer.functional.NewPhoneContactToClinicPhoneContact;
import com.anthem.specialty.provider.datalayer.functional.NewProviderClinicToClinicProvider;
import com.anthem.specialty.provider.datalayer.functional.NewProviderCredentialToProviderCredential;
import com.anthem.specialty.provider.datalayer.functional.NewProviderSpecialtyToProviderSpecialty;
import com.anthem.specialty.provider.datalayer.functional.NewProviderToProvider;
import com.anthem.specialty.provider.datalayer.functional.NewSanctionToProviderSanction;
import com.anthem.specialty.provider.datalayer.functional.NewW9RelationshipToClinicW9;
import com.anthem.specialty.provider.datalayer.functional.NewW9ToW9LegalEntity;
import com.anthem.specialty.provider.datalayer.functional.PageDtoTransformerImpl;
import com.anthem.specialty.provider.datalayer.functional.PhoneContactToClinicPhoneContact;
import com.anthem.specialty.provider.datalayer.functional.ProviderClinicDtoToClinicProvider;
import com.anthem.specialty.provider.datalayer.functional.ProviderCredentialToProviderCredentialsDto;
import com.anthem.specialty.provider.datalayer.functional.ProviderCredentialToProviderCredentialsDtoStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderDirectoryAccuracyToMessageStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderDtoToProvider;
import com.anthem.specialty.provider.datalayer.functional.ProviderFocusReviewToFocusReview;
import com.anthem.specialty.provider.datalayer.functional.ProviderLanguageToLanguage;
import com.anthem.specialty.provider.datalayer.functional.ProviderLanguageToLanguageStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderLicenseToLicense;
import com.anthem.specialty.provider.datalayer.functional.ProviderLicenseToLicenseStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderMedicaidToMedicaid;
import com.anthem.specialty.provider.datalayer.functional.ProviderMedicaidToMedicaidStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderSanctionToSanction;
import com.anthem.specialty.provider.datalayer.functional.ProviderSanctionToSanctionStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderSpecialtyToProviderSpecialtyDtoStream;
import com.anthem.specialty.provider.datalayer.functional.ProviderToProviderDto;
import com.anthem.specialty.provider.datalayer.functional.ProviderToSimpleProvider;
import com.anthem.specialty.provider.datalayer.functional.ProviderToSimpleProviderStream;
import com.anthem.specialty.provider.datalayer.functional.QueryParamsToObjectProperties;
import com.anthem.specialty.provider.datalayer.functional.SimpleClinicToClinic;
import com.anthem.specialty.provider.datalayer.functional.W9LegalEntityToW9;
import com.anthem.specialty.provider.datalayer.functional.W9ToW9LegalEntity;
import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.TerminationLevelRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.CarrierPhoneContactRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.CarrierRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicAddressRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicCredentialRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicDirectoryAccuracyRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicLanguageRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicOpeningHoursRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicPhoneContactRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicProviderRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicProviderScheduleRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ClinicW9Repository;
import com.anthem.specialty.provider.datalayer.repositories.lob.DisciplinaryActionRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.DocumentControlRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.FocusReviewRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.LegalAddressRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkCarrierRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkClinicProviderRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkClinicRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkGroupRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkPhoneContactRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkPlanRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.NetworkRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderCredentialRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderDirectoryAccuracyRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderLanguageRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderLicenseRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderMedicaidRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderSanctionRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderSpecialtyHospitalRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderSpecialtyRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.W9LegalEntityRepository;
import com.anthem.specialty.provider.datamodel.dto.Address;
import com.anthem.specialty.provider.datamodel.dto.AddressType;
import com.anthem.specialty.provider.datamodel.dto.ClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.ClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.ClinicMatch;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrier;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.License;
import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkGroupImpl;
import com.anthem.specialty.provider.datamodel.dto.NewAddress;
import com.anthem.specialty.provider.datamodel.dto.NewCarrier;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierEffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewClinic;
import com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.NewClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewClinicProvider;
import com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.NewDocument;
import com.anthem.specialty.provider.datamodel.dto.NewLanguage;
import com.anthem.specialty.provider.datamodel.dto.NewLegalAddress;
import com.anthem.specialty.provider.datamodel.dto.NewLicense;
import com.anthem.specialty.provider.datamodel.dto.NewNetwork;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.NewProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.NewProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.NewProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty;
import com.anthem.specialty.provider.datamodel.dto.NewSanction;
import com.anthem.specialty.provider.datamodel.dto.NewW9;
import com.anthem.specialty.provider.datamodel.dto.NewW9EffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.PhoneContact;
import com.anthem.specialty.provider.datamodel.dto.PhoneContactType;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.ProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.RelatedProvider;
import com.anthem.specialty.provider.datamodel.dto.RelatedW9;
import com.anthem.specialty.provider.datamodel.dto.Sanction;
import com.anthem.specialty.provider.datamodel.dto.SimpleClinic;
import com.anthem.specialty.provider.datamodel.dto.SimpleClinicImpl;
import com.anthem.specialty.provider.datamodel.dto.SimpleProvider;
import com.anthem.specialty.provider.datamodel.dto.UpdatableAddress;
import com.anthem.specialty.provider.datamodel.dto.UpdatableCarrier;
import com.anthem.specialty.provider.datamodel.dto.UpdatableCarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.UpdatableClinic;
import com.anthem.specialty.provider.datamodel.dto.UpdatableClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.UpdatableClinicProvider;
import com.anthem.specialty.provider.datamodel.dto.UpdatableDisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.UpdatableFocusReview;
import com.anthem.specialty.provider.datamodel.dto.UpdatableLicense;
import com.anthem.specialty.provider.datamodel.dto.UpdatableNetwork;
import com.anthem.specialty.provider.datamodel.dto.UpdatableNetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.UpdatablePhoneContact;
import com.anthem.specialty.provider.datamodel.dto.UpdatableProvider;
import com.anthem.specialty.provider.datamodel.dto.UpdatableProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.UpdateableW9;
import com.anthem.specialty.provider.datamodel.dto.W9;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderVerificationElement;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicDirectoryAccuracy;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicOpeningHours;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;
import com.anthem.specialty.provider.datamodel.schemas.lob.LegalAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPlan;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderDirectoryAccuracy;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSanction;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialtyHospital;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LobServiceImpl implements LobService {

  private final static Logger logger = LoggerFactory.getLogger(LobServiceImpl.class);

  @Autowired
  private ProviderRepository providerRepository;

  @Autowired
  private ProviderMedicaidRepository providerMedicaidRepository;

  @Autowired
  private ProviderCredentialRepository providerCredentialRepository;

  @Autowired
  private ProviderLicenseRepository providerLicenseRepository;

  @Autowired
  private DisciplinaryActionRepository disciplinaryActionRepository;

  @Autowired
  private ProviderLanguageRepository providerLanguageRepository;

  @Autowired
  private ProviderSpecialtyRepository providerSpecialtyRepository;

  @Autowired
  private ProviderSpecialtyHospitalRepository providerSpecialtyHospitalRepository;

  @Autowired
  private W9LegalEntityRepository w9LegalEntityRepository;

  @Autowired
  private LegalAddressRepository legalAddressRepository;

  @Autowired
  private NetworkRepository networkRepository;

  @Autowired
  private NetworkPhoneContactRepository networkPhoneContactRepository;

  @Autowired
  private NetworkPlanRepository networkPlanRepository;

  @Autowired
  private NetworkGroupRepository networkGroupRepository;

  @Autowired
  private CarrierRepository carrierRepository;

  @Autowired
  private CarrierPhoneContactRepository carrierPhoneContactRepository;

  @Autowired
  private NetworkCarrierRepository networkCarrierRepository;

  @Autowired
  private ClinicRepository clinicRepository;

  @Autowired
  private ClinicAddressRepository clinicAddressRepository;

  @Autowired
  private ClinicPhoneContactRepository clinicPhoneContactRepository;

  @Autowired
  private ClinicOpeningHoursRepository clinicOpeningHoursRepository;

  @Autowired
  private ClinicCredentialRepository clinicCredentialRepository;

  @Autowired
  private ClinicLanguageRepository clinicLanguageRepository;

  @Autowired
  private ProviderSanctionRepository providerSanctionRepository;

  @Autowired
  private DocumentControlRepository documentControlRepository;

  @Autowired
  private ClinicProviderRepository clinicProviderRepository;

  @Autowired
  private ClinicProviderScheduleRepository clinicProviderScheduleRepository;

  @Autowired
  private ClinicW9Repository clinicW9Repository;

  @Autowired
  private NetworkClinicRepository networkClinicRepository;

  @Autowired
  private NetworkClinicProviderRepository networkClinicProviderRepository;

  @Autowired
  private FocusReviewRepository focusReviewRepository;

  @Autowired
  private DataOwnerRepository dataOwnerRepository;

  @Autowired
  private TerminationLevelRepository terminationLevelRepository;

  @Autowired
  private ProviderDirectoryAccuracyRepository providerDirectoryAccuracyRepository;

  @Autowired
  private ClinicDirectoryAccuracyRepository clinicDirectoryAccuracyRepository;

  @Autowired
  private ObjectMapper jsonMapper;

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElement> getClinicsDirectoryAccuracyByLargeGroup(
      Long largeGroupId) {
    logger.trace("[getClinicsDirectoryAccuracy] in");

    List<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElement> r = new ArrayList<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElement>();

    Stream<ClinicDirectoryAccuracy> stream = null;
    stream = clinicDirectoryAccuracyRepository.findByLargeGroupId(largeGroupId);

    r = stream.map(new ClinicDirectoryAccuracyToMessageStream()).filter(o -> o.isPresent()).map(o -> o.get())
        .collect(Collectors.toList());

    logger.trace("[getClinicsDirectoryAccuracy] out");
    return r;

  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<ProviderVerificationElement> getProviderDirectoryAccuracyByLargeGroup(Long largeGroupId) {
    logger.trace("[getProviderDirectoryAccuracy] in [largeGroupId: {}]", largeGroupId);

    List<ProviderVerificationElement> r = new ArrayList<ProviderVerificationElement>();

    Stream<ProviderDirectoryAccuracy> stream = null;

    Function<String, DataOwner> dataOwnerResolver = new Function<String, DataOwner>() {
      @Override
      public DataOwner apply(String t) {
        List<com.anthem.specialty.provider.datamodel.schemas.core.DataOwner> dos = dataOwnerRepository
            .findByDisplayName(t);
        if (dos.isEmpty())
          return null;
        else
          return new DataOwnerToDataOwnerDto().apply(dos.get(0));
      }
    };

    stream = providerDirectoryAccuracyRepository.findByLargeGroupId(largeGroupId);

    r = stream.map(new ProviderDirectoryAccuracyToMessageStream(dataOwnerResolver)).filter(o -> o.isPresent())
        .map(o -> o.get()).collect(Collectors.toList());

    logger.trace("[getProviderDirectoryAccuracy] out");
    return r;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<ProviderVerificationElement> getProviderDirectoryAccuracyByNetwork(Long networkId) {
    logger.trace("[getProviderDirectoryAccuracy] in [networkId: {}]", networkId);

    List<ProviderVerificationElement> r = new ArrayList<ProviderVerificationElement>();

    Stream<ProviderDirectoryAccuracy> stream = null;

    Function<String, DataOwner> dataOwnerResolver = new Function<String, DataOwner>() {
      @Override
      public DataOwner apply(String t) {
        List<com.anthem.specialty.provider.datamodel.schemas.core.DataOwner> dos = dataOwnerRepository
            .findByDisplayName(t);
        if (dos.isEmpty())
          return null;
        else
          return new DataOwnerToDataOwnerDto().apply(dos.get(0));
      }
    };

    stream = providerDirectoryAccuracyRepository.findByNetworkId(networkId);

    r = stream.map(new ProviderDirectoryAccuracyToMessageStream(dataOwnerResolver)).filter(o -> o.isPresent())
        .map(o -> o.get()).collect(Collectors.toList());

    logger.trace("[getProviderDirectoryAccuracy] out");
    return r;
  }

  @Override
  public List<SimpleProvider> getRelatedProviders() {
    logger.trace("[getRelatedProviders] in");
    List<SimpleProvider> result = StreamSupport.stream(providerRepository.findAll().spliterator(), false)
        .flatMap(new ProviderToSimpleProviderStream()).collect(Collectors.toList());
    logger.trace("[getRelatedProviders] out", result);
    return result;
  }

  @Override
  public Provider setProvider(Provider provider) {
    logger.trace("[setProvider] in", provider);
    Provider result = providerRepository.save(provider);
    logger.trace("[setProvider] out", result);
    return result;
  }

  @Override
  public Provider setProvider(NewProvider p) {
    logger.trace("[setNewProvider] in", p);
    if (null == p)
      throw new IllegalArgumentException("must provide provider");

    Provider o = new NewProviderToProvider(new Function<Long, TerminationLevel>() {

      @Override
      public TerminationLevel apply(Long t) {
        Optional<TerminationLevel> r = terminationLevelRepository.findById(t);
        if (r.isPresent())
          return r.get();
        return null;
      }
    }, new Function<Long, com.anthem.specialty.provider.datamodel.schemas.core.DataOwner>() {

      @Override
      public com.anthem.specialty.provider.datamodel.schemas.core.DataOwner apply(Long t) {
        Optional<com.anthem.specialty.provider.datamodel.schemas.core.DataOwner> r = dataOwnerRepository.findById(t);
        if (r.isPresent())
          return r.get();
        return null;
      }
    }).apply(p);

    Provider result = providerRepository.save(o);
    logger.trace("[setNewProvider] out", result);
    return result;
  }

  @Override
  public SimpleProvider createNewProvider(NewProvider p) {
    logger.trace("[createNewProvider] in", p);
    if (null == p)
      throw new IllegalArgumentException("must provide provider");
    SimpleProvider result = null;
    Provider o = providerRepository.save(new NewProviderToProvider(new Function<Long, TerminationLevel>() {

      @Override
      public TerminationLevel apply(Long t) {
        Optional<TerminationLevel> r = terminationLevelRepository.findById(t);
        if (r.isPresent())
          return r.get();
        return null;
      }
    }, new Function<Long, com.anthem.specialty.provider.datamodel.schemas.core.DataOwner>() {

      @Override
      public com.anthem.specialty.provider.datamodel.schemas.core.DataOwner apply(Long t) {
        Optional<com.anthem.specialty.provider.datamodel.schemas.core.DataOwner> r = dataOwnerRepository.findById(t);
        if (r.isPresent())
          return r.get();
        return null;
      }
    }).apply(p));

    if (null != o)
      result = new ProviderToSimpleProvider().apply(o);

    logger.trace("[createNewProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Provider patchProvider(Long providerId,
      Map<String, Object> changes) throws DataConstraintException, DataValidationException, DataLayerException {
    logger.trace("[patchProvider] in", providerId, changes);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    com.anthem.specialty.provider.datamodel.dto.Provider result = null;
    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableProvider.class);

      Optional<Provider> optEntity = providerRepository.findById(providerId);
      if (!optEntity.isPresent())
        throw new NoEntityFoundException(format("no provider for id: %d", providerId));

      ProviderToProviderDto dtoMapper = new ProviderToProviderDto();
      com.anthem.specialty.provider.datamodel.dto.Provider dto = dtoMapper.apply(optEntity.get());

      Map<String, Object> map = jsonMapper.convertValue(dto, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      dto = jsonMapper.convertValue(map, com.anthem.specialty.provider.datamodel.dto.Provider.class);

      result = dtoMapper.apply(providerRepository
          .save(new ProviderDtoToProvider(terminationLevelRepository, dataOwnerRepository).apply(dto)));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw ia;
    }

    logger.trace("[patchProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinicRelationship patchNetworkClinic(Long networkId, Long networkClinicId, Map<String, Object> changes)
      throws DataLayerException {
    logger.trace("[patchNetworkClinic] in", networkId, networkClinicId, changes);
    if (null == networkId)
      throw new IllegalArgumentException("must provide networkId");
    if (null == networkClinicId)
      throw new IllegalArgumentException("must provide networkClinicId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    NetworkClinicRelationship result = null;
    Optional<NetworkClinic> optResult = networkClinicRepository.findByIdAndNetworkId(networkClinicId, networkId);

    if (!optResult.isPresent())
      throw new NoEntityFoundException(
          format("no NetworkClinic for id: %s and networkId:%s", networkClinicId.toString(), networkId.toString()));

    try {
      NetworkClinicRelationship o = new NetworkClinicToNetworkClinicRelationship().apply(optResult.get());

      Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      o = jsonMapper.convertValue(map, NetworkClinicRelationship.class);

      result = new NetworkClinicToNetworkClinicRelationship().apply(networkClinicRepository
          .save(new NetworkClinicRelationshipToNetworkClinic(clinicRepository).apply(optResult.get().getNetwork(), o)));

    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    }

    logger.trace("[patchNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ClinicCredentials patchClinicCredential(Long clinicId, Long id, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException {
    logger.trace("[patchClinicCredential] in", changes);
    if (null == clinicId)
      throw new IllegalArgumentException("must provide clinicId");
    if (null == id)
      throw new IllegalArgumentException("must provide id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");
    ClinicCredentials result = null;
    try {
      // get the client's view of the clinic
      Optional<Clinic> optClinic = clinicRepository.findById(clinicId);
      if (!optClinic.isPresent())
        throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

      // get the client's view of the clinic
      Optional<ClinicCredential> o = clinicCredentialRepository.findById(id);
      if (!o.isPresent())
        throw new NoEntityFoundException(format("no clinic credential for id: %s", id.toString()));

      // validate the map
      jsonMapper.convertValue(changes, UpdatableClinicCredentials.class);

      ClinicCredentials current = new ClinicCredentialToClinicCredentialDto().apply(o.get());
      Map<String, Object> map = jsonMapper.convertValue(current, new TypeReference<Map<String, Object>>() {
      });
      // apply the changes
      for (Map.Entry<String, Object> change : changes.entrySet()) {
        map.put(change.getKey(), change.getValue());
      }
      current = jsonMapper.convertValue(map, ClinicCredentials.class);

      result = new ClinicCredentialToClinicCredentialDto().apply(
          clinicCredentialRepository.save(new ClinicCredentialDtoToClinicCredential().apply(optClinic.get(), current)));

    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException nef) {
      throw nef;
    }

    logger.trace("[patchClinicCredential] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Address patchClinicAddress(Long clinicId, Long addressId, Map<String, Object> changes)
      throws DataConstraintException, DataValidationException, NoEntityFoundException, DataLayerException {
    logger.trace("[patchClinicAddress] in", clinicId, addressId, changes);
    if (null == clinicId)
      throw new IllegalArgumentException("must provide clinicId");
    if (null == addressId)
      throw new IllegalArgumentException("must provide addressId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    Address result = null;
    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableAddress.class);

      ClinicAddressToAddress clinicAddressToDtoMapper = new ClinicAddressToAddress();

      Optional<Clinic> optClinic = clinicRepository.findById(clinicId);
      if (!optClinic.isPresent())
        throw new NoEntityFoundException(format("no clinic for id: %d", clinicId));

      Optional<ClinicAddress> o = clinicAddressRepository.findByIdAndClinicId(addressId, clinicId);
      if (!o.isPresent())
        throw new NoEntityFoundException(
            format("no address for id: %s and clinic id: %s", addressId.toString(), clinicId.toString()));

      Address address = clinicAddressToDtoMapper.apply(o.get());
      Map<String, Object> map = jsonMapper.convertValue(address, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      address = jsonMapper.convertValue(map, Address.class);

      result = clinicAddressToDtoMapper
          .apply(clinicAddressRepository.save(new AddressToClinicAddress().apply(optClinic.get(), address)));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }
    logger.trace("[patchClinicAddress] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ProviderFocusReview patchProviderFocusReview(Long providerId, Long id, Map<String, Object> changes)
      throws DataLayerException {
    logger.trace("[patchProviderFocusReview] in", providerId, id, changes);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == id)
      throw new IllegalArgumentException("must provide focus review id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    ProviderFocusReview result = null;

    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableProviderFocusReview.class);

      // get the client's view of the clinic
      Optional<FocusReview> o = focusReviewRepository.findByIdAndProviderId(id, providerId);
      if (!o.isPresent())
        throw new NoEntityFoundException(format("no focus review for id: %d and provider id: %d", id, providerId));

      FocusReviewToProviderFocusReview dtoMapper = new FocusReviewToProviderFocusReview();
      ProviderFocusReview existent = dtoMapper.apply(o.get());

      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, ProviderFocusReview.class);

      NetworkGroup group = o.get().getNetworkGroup();
      if (!existent.getNetworkGroup().getId().equals(o.get().getNetworkGroup().getId()))
        group = networkGroupRepository.findById(existent.getNetworkGroup().getId()).get();

      result = dtoMapper.apply(focusReviewRepository.save(
          new ProviderFocusReviewToFocusReview(o.get().getProvider(), o.get().getClinic(), group).apply(existent)));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }

    logger.trace("[patchProviderFocusReview] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ClinicFocusReview patchClinicFocusReview(Long providerId, Long id, Map<String, Object> changes)
      throws DataLayerException {
    logger.trace("[patchProviderFocusReview] in", providerId, id, changes);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == id)
      throw new IllegalArgumentException("must provide focus review id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    ClinicFocusReview result = null;

    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableProviderFocusReview.class);

      // get the client's view of the clinic
      Optional<FocusReview> o = focusReviewRepository.findByIdAndProviderId(id, providerId);
      if (!o.isPresent())
        throw new NoEntityFoundException(format("no focus review for id: %d and provider id: %d", id, providerId));

      FocusReviewToClinicFocusReview dtoMapper = new FocusReviewToClinicFocusReview();
      ClinicFocusReview existent = dtoMapper.apply(o.get());

      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, ClinicFocusReview.class);

      NetworkGroup group = o.get().getNetworkGroup();
      if (!existent.getNetworkGroup().getId().equals(o.get().getNetworkGroup().getId()))
        group = networkGroupRepository.findById(existent.getNetworkGroup().getId()).get();

      result = dtoMapper.apply(focusReviewRepository
          .save(new ClinicFocusReviewToFocusReview(o.get().getProvider(), o.get().getClinic(), group).apply(existent)));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }

    logger.trace("[patchProviderFocusReview] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public PhoneContact patchClinicPhoneContact(Long clinicId, Long id, Map<String, Object> changes)
      throws DataLayerException {
    logger.trace("[patchClinicPhoneContact] in", clinicId, id, changes);
    if (null == clinicId)
      throw new IllegalArgumentException("must provide clinicId");
    if (null == id)
      throw new IllegalArgumentException("must provide phone contact id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    PhoneContact result = null;
    try {

      // validate the map
      jsonMapper.convertValue(changes, UpdatablePhoneContact.class);

      Optional<Clinic> optClinic = clinicRepository.findById(clinicId);
      if (!optClinic.isPresent())
        throw new NoEntityFoundException(format("no clinic for id: %d", clinicId));

      Optional<ClinicPhoneContact> o = clinicPhoneContactRepository.findByIdAndClinicId(id, clinicId);
      if (!o.isPresent())
        throw new NoEntityFoundException(
            format("no phone contact for id: %s and clinic id: %s", id.toString(), clinicId.toString()));

      ClinicPhoneContactToPhoneContact dtoMapper = new ClinicPhoneContactToPhoneContact();
      PhoneContact existent = dtoMapper.apply(o.get());

      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, PhoneContact.class);
      ClinicPhoneContact cpc = new PhoneContactToClinicPhoneContact(optClinic.get()).apply(existent);
      result = dtoMapper.apply(clinicPhoneContactRepository.save(cpc));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }
    logger.trace("[patchClinicPhoneContact] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Clinic patchClinic(Long clinicId, Map<String, Object> changes)
      throws DataLayerException {
    logger.trace("[patchClinic] in", clinicId, changes);
    if (null == clinicId)
      throw new IllegalArgumentException("must provide clinicId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");
    com.anthem.specialty.provider.datamodel.dto.Clinic result = null;

    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableClinic.class);

      // get the client's view of the clinic
      Optional<Clinic> o = clinicRepository.findById(clinicId);
      if (!o.isPresent())
        throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

      ClinicToClinicDto dtoMapper = new ClinicToClinicDto();
      com.anthem.specialty.provider.datamodel.dto.Clinic existent = dtoMapper.apply(o.get());

      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, com.anthem.specialty.provider.datamodel.dto.Clinic.class);

      result = dtoMapper.apply(clinicRepository.save(new ClinicDtoToClinic(dataOwnerRepository).apply(existent)));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }
    logger.trace("[patchClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public CollectionRelatedCarrier patchNetworkCarrier(Long networkId, Long networkCarrierId,
      Map<String, Object> changes) throws DataValidationException, NoEntityFoundException, DataLayerException {
    logger.trace("[patchNetworkCarrier] in", networkId, networkCarrierId, changes);
    if (null == networkId)
      throw new IllegalArgumentException("must provide networkId");
    if (null == networkCarrierId)
      throw new IllegalArgumentException("must provide networkCarrierId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");
    CollectionRelatedCarrier result = null;
    try {

      // get the client's view of the clinic
      Optional<NetworkCarrier> o = networkCarrierRepository.findByIdAndNetworkId(networkCarrierId, networkId);
      Optional<Network> n = networkRepository.findById(networkId);

      if (!o.isPresent())
        throw new NoEntityFoundException(
            format("no network carrier for id [%d] and network [%d]", networkCarrierId, networkId));

      if (!n.isPresent())
        throw new NoEntityFoundException(format("no network [%d]", networkId));

      NetworkCarrierToCollectionRelatedCarrier mapper = new NetworkCarrierToCollectionRelatedCarrier(
          networkCarrierRepository, networkRepository);
      CollectionRelatedCarrier current = mapper.apply(o.get());

      Map<String, Object> map = jsonMapper.convertValue(current, new TypeReference<Map<String, Object>>() {
      });
      // apply the changes
      for (Map.Entry<String, Object> change : changes.entrySet()) {
        map.put(change.getKey(), change.getValue());
      }
      current = jsonMapper.convertValue(map, CollectionRelatedCarrier.class);

      result = mapper.apply(networkCarrierRepository
          .save(new CollectionRelatedCarrierToNetworkCarrier(carrierRepository).apply(n.get(), current)));

    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException nef) {
      throw nef;
    }

    logger.trace("[patchNetworkCarrier] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public W9 patchW9(Long id, Map<String, Object> changes) throws DataValidationException, NoEntityFoundException {
    logger.trace("[patchW9] in", changes);

    if (null == id)
      throw new IllegalArgumentException("must provide w9Id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");
    W9 result = null;
    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdateableW9.class);

      W9LegalEntityToW9 dtoMapper = new W9LegalEntityToW9();

      // get the client's view of the clinic
      Optional<W9LegalEntity> o = w9LegalEntityRepository.findById(id);
      if (!o.isPresent())
        throw new NoEntityFoundException(format("no w9 for id: %s", id.toString()));

      W9 existent = dtoMapper.apply(o.get());
      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, W9.class);

      result = dtoMapper
          .apply(w9LegalEntityRepository.save(new W9ToW9LegalEntity(dataOwnerRepository).apply(existent)));

    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    }

    logger.trace("[patchW9] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Carrier patchCarrier(Long id, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException {
    logger.trace("[patchCarrier] in", changes);
    if (null == id)
      throw new IllegalArgumentException("must provide id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");
    com.anthem.specialty.provider.datamodel.dto.Carrier result = null;
    // get the client's view of the clinic
    Optional<Carrier> o = carrierRepository.findById(id);
    if (!o.isPresent())
      throw new NoEntityFoundException(format("no carrier for id: %s", id.toString()));

    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableCarrier.class);

      com.anthem.specialty.provider.datamodel.dto.Carrier current = new CarrierToCarrierDto().apply(o.get());
      Map<String, Object> map = jsonMapper.convertValue(current, new TypeReference<Map<String, Object>>() {
      });
      // apply the changes
      for (Map.Entry<String, Object> change : changes.entrySet()) {
        map.put(change.getKey(), change.getValue());
      }
      current = jsonMapper.convertValue(map, com.anthem.specialty.provider.datamodel.dto.Carrier.class);

      result = new CarrierToCarrierDto()
          .apply(carrierRepository.save(new CarrierDtoToCarrier(dataOwnerRepository).apply(current)));

    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    }

    logger.trace("[patchCarrier] out", result);
    return result;
  }

  @Override
  public void deleteProvider(Long id) throws NoEntityFoundException {
    logger.trace("[deleteProvider] in", id);
    try {
      providerRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteProvider] out");
  }

  @Override
  public Page<SimpleProvider> getSimpleProviders(String firstName, String lastName, int start, int size) {
    logger.trace("[getSimpleProviders] in", firstName, lastName);

    Page<Provider> providerEntities = null;
    Pageable pageable = PageRequest.of(start, size);

    if (null != firstName && null != lastName)
      providerEntities = providerRepository.findByFirstNameAndLastNameAndEffectiveFromNotNull(firstName, lastName,
          pageable);
    else if (null != firstName)
      providerEntities = providerRepository.findByFirstNameAndEffectiveFromNotNull(firstName, pageable);
    else if (null != lastName)
      providerEntities = providerRepository.findByLastNameAndEffectiveFromNotNull(lastName, pageable);
    else {
      providerEntities = providerRepository.findByOrderByEffectiveFromDesc(pageable);
    }

    Page<SimpleProvider> result = new PageDtoTransformerImpl<>(new ProviderToSimpleProvider()).apply(providerEntities);

    logger.trace("[getSimpleProviders] out", result);
    return result;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Provider getProvider(Long id) throws NoEntityFoundException {
    logger.trace("[getProvider] in", id);
    com.anthem.specialty.provider.datamodel.dto.Provider result = null;
    Optional<Provider> o = providerRepository.findById(id);
    if (o.isPresent())
      result = new ProviderToProviderDto().apply(o.get());
    else
      throw new NoEntityFoundException("Provider " + id + " not found");
    logger.trace("[getProvider] out", result);
    return result;
  }

  @Override
  public Provider findProvider(Long id) throws NoEntityFoundException {
    logger.trace("[getProvider] in", id);
    Provider result = null;
    Optional<Provider> o = providerRepository.findById(id);
    if (o.isPresent())
      result = o.get();
    else
      throw new NoEntityFoundException("Provider not found for id " + id);
    logger.trace("[getProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Provider getProvider(Long id, boolean eagerLoad) {
    logger.trace("[getProvider] in", id);
    Provider result = null;
    Optional<Provider> o = providerRepository.findById(id);

    if (o.isPresent()) {
      result = o.get();
      if (eagerLoad) {
        result.getDocumentControls();
        result.getClinicProviders();
        // result.getNetworkClinicProviders();
        result.getFocusReviews();
        result.getProviderSpecialties();
        result.getProviderLanguages();
        result.getProviderCredentials();
        result.getProviderLicenses();
        result.getProviderMedicaids();
        result.getDisciplinaryActions();
        result.getProviderSpecialtyHospitals();
      }
    }
    logger.trace("[getProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<ProviderClinic> getClinicsByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getClinicsByProvider] in", providerId);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");

    List<ProviderClinic> result = null;
    Optional<Provider> provider = providerRepository.findById(providerId);
    if (provider.isPresent())
      result = provider.get().getClinicProviders().stream().flatMap(new ClinicProviderToProviderClinicDtoStream())
          .collect(Collectors.toList());
    else
      throw new NoEntityFoundException(format("no provider for id %s", providerId.toString()));

    logger.trace("[getClinicsByProvider] out", result);
    return result;
  }

  @Override
  public ProviderMedicaid setProviderMedicaid(ProviderMedicaid o) {
    logger.trace("[setPProviderMedicaid] in", o);
    ProviderMedicaid result = providerMedicaidRepository.save(o);
    logger.trace("[setPProviderMedicaid] out", result);
    return result;
  }

  @Override
  public ProviderMedicaid getProviderMedicaid(Long id) {
    logger.trace("[getProviderMedicaid] in", id);
    ProviderMedicaid result = null;
    Optional<ProviderMedicaid> o = providerMedicaidRepository.findById(id);
    if (o.isPresent())
      result = o.get();
    logger.trace("[getProviderMedicaid] out", result);
    return result;
  }

  @Override
  public List<ProviderMedicaid> getProviderMedicaidsByProvider(Provider provider) {
    logger.trace("[getProviderMedicaid] in", provider);
    List<ProviderMedicaid> result = providerMedicaidRepository.findByProvider(provider);
    logger.trace("[getProviderMedicaid] out", result);
    return result;
  }

  @Override
  public List<ProviderCredential> getProviderCredentialsByProvider(Provider provider) {
    logger.trace("[getProviderCredentialsByProvider] in", provider);
    List<ProviderCredential> result = providerCredentialRepository.findByProvider(provider);
    logger.trace("[getProviderCredentialsByProvider] out", result);
    return result;
  }

  @Override
  public List<ProviderLicense> getProviderLicensesByProvider(Provider provider) {
    logger.trace("[getProviderLicensesByProvider] in", provider);
    List<ProviderLicense> result = providerLicenseRepository.findByProvider(provider);
    logger.trace("[getProviderLicensesByProvider] out", result);
    return result;
  }

  @Override
  public List<DisciplinaryAction> getDisciplinaryActionsByProvider(Provider provider) {
    logger.trace("[getDisciplinaryActionsByProvider] in", provider);
    List<DisciplinaryAction> result = disciplinaryActionRepository.findByProvider(provider);
    logger.trace("[getDisciplinaryActionsByProvider] out", result);
    return result;
  }

  @Override
  public List<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction> getDisciplinaryActionsByProvider(
      Long providerId) throws NoEntityFoundException {
    logger.trace("[getDisciplinaryActionsByProvider] in", providerId);
    findProvider(providerId); // validate id
    List<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction> result = disciplinaryActionRepository
        .findByProviderId(providerId).stream().flatMap(new DisciplinaryActionToDisciplinaryActionDtoStream())
        .collect(Collectors.toList());
    logger.trace("[getDisciplinaryActionsByProvider] out", result);
    return result;
  }

  @Override
  public List<ProviderLanguage> getProviderLanguagesByProvider(Provider provider) {
    logger.trace("[getProviderLanguagesByProvider] in", provider);
    List<ProviderLanguage> result = providerLanguageRepository.findByProvider(provider);
    logger.trace("[getProviderLanguagesByProvider] out", result);
    return result;
  }

  @Override
  public List<ProviderSpecialty> getProviderSpecialtiesByProvider(Provider provider) {
    logger.trace("[getProviderSpecialtiesByProvider] in", provider);
    List<ProviderSpecialty> result = providerSpecialtyRepository.findByProvider(provider);
    logger.trace("[getProviderSpecialtiesByProvider] out", result);
    return result;
  }

  @Override
  public List<ProviderSpecialtyHospital> getProviderSpecialtyHospitalsByProvider(Provider provider) {
    logger.trace("[getProviderSpecialtyHospitalsByProvider] in", provider);
    List<ProviderSpecialtyHospital> result = providerSpecialtyHospitalRepository.findByProvider(provider);
    logger.trace("[getProviderSpecialtyHospitalsByProvider] out", result);
    return result;
  }

  @Override
  public W9LegalEntity setW9LegalEntity(W9LegalEntity o) {
    logger.trace("[setW9LegalEntity] in", o);
    W9LegalEntity result = w9LegalEntityRepository.save(o);
    logger.trace("[setW9LegalEntity] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public W9LegalEntity getW9LegalEntity(Long id) throws NoEntityFoundException {
    logger.trace("[getW9LegalEntity] in", id);
    W9LegalEntity result = null;
    Optional<W9LegalEntity> o = w9LegalEntityRepository.findById(id);
    if (o.isPresent()) {
      result = o.get();
      result.getClinicW9s();
    } else {
      throw new NoEntityFoundException("No legal entity " + id);
    }
    logger.trace("[getW9LegalEntity] out", result);
    return result;
  }

  @Override
  public void deleteW9LegalEntity(Long id) throws NoEntityFoundException {
    logger.trace("[deleteW9LegalEntity] in", id);
    try {
      w9LegalEntityRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteW9LegalEntity] out");
  }

  @Override
  public List<LegalAddress> getLegalAddressesByW9LegalEntity(W9LegalEntity w9LegalEntity) {
    logger.trace("[getLegalAddressesByW9LegalEntity] in", w9LegalEntity);
    List<LegalAddress> result = legalAddressRepository.findByW9LegalEntity(w9LegalEntity);
    logger.trace("[getLegalAddressesByW9LegalEntity] out", result);
    return result;
  }

  @Override
  public Network setNetwork(Network o) {
    logger.trace("[setNetwork] in", o);
    Network result = networkRepository.save(o);
    logger.trace("[setNetwork] out", result);
    return result;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Network setNetworkDto(
      com.anthem.specialty.provider.datamodel.dto.Network o) {
    logger.trace("[setNetworkDto] in", o);

    com.anthem.specialty.provider.datamodel.dto.Network result = new NetworkToNetworkDto()
        .apply(networkRepository.save(new NetworkDtoToNetwork(dataOwnerRepository).apply(o)));
    logger.trace("[setNetworkDto] out", result);
    return result;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Network setNewNetwork(NewNetwork o) {
    logger.trace("[setNewNetwork] in", o);
    com.anthem.specialty.provider.datamodel.dto.Network result = new NetworkToNetworkDto()
        .apply(networkRepository.save(new NewNetworkDtoToNetwork(dataOwnerRepository).apply(o)));
    logger.trace("[setNewNetwork] out", result);
    return result;
  }

  @Override
  @Transactional(rollbackOn = Exception.class) // otherwise spring overrides our exception with TransactionException
  public com.anthem.specialty.provider.datamodel.dto.Carrier setNewCarrier(NewCarrier o) throws DataLayerException {
    logger.trace("[setNewCarrier] in", o);
    com.anthem.specialty.provider.datamodel.dto.Carrier result;
    result = new CarrierToCarrierDto()
        .apply(carrierRepository.save(new NewCarrierDtoToCarrier(dataOwnerRepository).apply(o)));
    logger.trace("[setNewCarrier] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Network getNetwork(Long id) throws NoEntityFoundException {
    logger.trace("[getNetwork] in", id);
    Network result = null;
    Optional<Network> o = networkRepository.findById(id);
    if (o.isPresent()) {
      // CHECKME: force loading of collections?
      result = o.get();
      result.getNetworkCarriers();
      result.getNetworkClinics();
    } else {
      throw new NoEntityFoundException("No network with id " + id);
    }
    logger.trace("[getNetwork] out", result);
    return result;
  }

  @Override
  public void deleteNetwork(Long id) throws NoEntityFoundException {
    logger.trace("[deleteNetwork] in", id);
    try {
      networkRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteNetwork] out");
  }

  @Override
  public List<NetworkPhoneContact> getNetworkPhoneContactsByNetwork(Network o) {
    logger.trace("[getNetworkPhoneContactsByNetwork] in", o);
    List<NetworkPhoneContact> result = networkPhoneContactRepository.findByNetwork(o);
    logger.trace("[getNetworkPhoneContactsByNetwork] out", result);
    return result;
  }

  @Override
  public List<NetworkPlan> getNetworkPlansByNetwork(Network o) {
    logger.trace("[getNetworkPlansByNetwork] in", o);
    List<NetworkPlan> result = networkPlanRepository.findByNetwork(o);
    logger.trace("[getNetworkPlansByNetwork] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkGroup getNetworkGroup(Long id) throws NoEntityFoundException {
    logger.trace("[getNetworkGroup] in", id);
    NetworkGroup result = null;
    Optional<NetworkGroup> o = networkGroupRepository.findById(id);
    if (o.isPresent()) {
      result = o.get();
      result.getFocusReviews();
    } else {
      throw new NoEntityFoundException("No network group " + id);
    }
    logger.trace("[getNetworkGroup] out", result);
    return result;
  }

  @Override
  public Carrier setCarrier(Carrier o) {
    logger.trace("[setCarrier] in", o);
    Carrier result = carrierRepository.save(o);
    logger.trace("[setCarrier] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Carrier getCarrier(Long id) throws NoEntityFoundException {
    logger.trace("[getCarrier] in", id);
    Carrier result = null;
    Optional<Carrier> o = carrierRepository.findById(id);
    if (o.isPresent()) {
      // CHECKME: why do we force instancing of collection?
      result = o.get();
      result.getNetworkCarriers();
    } else {
      throw new NoEntityFoundException("Carrier " + id + " not found");
    }
    logger.trace("[getCarrier] out", result);
    return result;
  }

  @Override
  public void deleteCarrier(Long id) throws NoEntityFoundException {
    logger.trace("[deleteCarrier] in", id);
    try {
      carrierRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteCarrier] out");
  }

  @Override
  public void deleteCarriers(List<Long> ids) throws NoEntityFoundException {
    logger.trace("[deleteCarriers] in", ids);
    try {
      carrierRepository.deleteByIdIn(ids);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteCarriers] out");
  }

  @Override
  public List<CarrierPhoneContact> getCarrierPhoneContactsByCarrier(Carrier o) {
    logger.trace("[getCarrierPhoneContactsByCarrier] in", o);
    List<CarrierPhoneContact> result = carrierPhoneContactRepository.findByCarrier(o);
    logger.trace("[getCarrierPhoneContactsByCarrier] out", result);
    return result;
  }

  @Override
  public List<NetworkCarrier> getNetworkCarriersByCarrier(Carrier o) {
    logger.trace("[getNetworkCarriersByCarrier] in", o);
    List<NetworkCarrier> result = networkCarrierRepository.findByCarrier(o);
    logger.trace("[getNetworkCarriersByCarrier] out", result);
    return result;
  }

  @Override
  public List<NetworkCarrier> getNetworkCarriersByNetwork(Network o) {
    logger.trace("[getNetworkCarriersByCarrier] in", o);
    List<NetworkCarrier> result = networkCarrierRepository.findByNetwork(o);
    logger.trace("[getNetworkCarriersByCarrier] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Clinic setClinicAndGetDto(NewClinic o) {
    logger.trace("[setClinicAndGetDto] in", o);
    com.anthem.specialty.provider.datamodel.dto.Clinic result = null;
    Clinic c = clinicRepository.save(new NewClinicToClinic(dataOwnerRepository).apply(o));
    if (null != c)
      result = new ClinicToClinicDto().apply(c);
    logger.trace("[setClinicAndGetDto] out", result);
    return result;
  }

  @Override
  public W9 setNewW9AndGetDto(NewW9 o) {
    logger.trace("[setNewW9AndGetDto] in", o);
    W9LegalEntity obj = new NewW9ToW9LegalEntity(dataOwnerRepository).apply(o);
    W9 result = new W9LegalEntityToW9().apply(w9LegalEntityRepository.save(obj));
    logger.trace("[setNewW9AndGetDto] out", result);
    return result;
  }

  @Override
  public Clinic setClinic(Clinic o) {
    logger.trace("[setClinic] in", o);
    Clinic result = clinicRepository.save(o);
    logger.trace("[setClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public W9 getW9(Long id) throws NoEntityFoundException {
    logger.trace("[getW9] in", id);
    W9 result = null;
    Optional<W9LegalEntity> o = w9LegalEntityRepository.findById(id);
    if (o.isPresent())
      result = new W9LegalEntityToW9().apply(o.get());
    else
      throw new NoEntityFoundException("No W9 with id " + id);
    logger.trace("[getW9] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Clinic getClinicDto(Long id) {
    logger.trace("[getSimpleClinic] in", id);
    Optional<Clinic> o = clinicRepository.findById(id);
    com.anthem.specialty.provider.datamodel.dto.Clinic result = o.isPresent() ? new ClinicToClinicDto().apply(o.get())
        : null;
    logger.trace("[getSimpleClinic] out", result);
    return result;
  }

  @Override
  public SimpleClinic getSimpleClinic(Long id) {
    logger.trace("[getSimpleClinic] in", id);
    Optional<Clinic> o = clinicRepository.findById(id);
    SimpleClinic result = o.isPresent() ? new ClinicToSimpleClinic().apply(o.get()) : null;
    logger.trace("[getSimpleClinic] out", result);
    return result;
  }

  @Override
  public Clinic findClinic(Long id) throws NoEntityFoundException {
    logger.trace("[getClinic] in", id);
    Clinic result = null;
    Optional<Clinic> o = clinicRepository.findById(id);
    if (o.isPresent())
      result = o.get();
    else
      throw new NoEntityFoundException("No clinic with id " + id);
    logger.trace("[getClinic] out", result);
    return result;
  }

  public NetworkGroup findNetworkGroup(Long id) throws NoEntityFoundException {
    logger.trace("[findNetworkGroup] in", id);
    NetworkGroup result = null;
    Optional<NetworkGroup> o = networkGroupRepository.findById(id);
    if (o.isPresent())
      result = o.get();
    else
      throw new NoEntityFoundException("No NetworkGroup with id " + id);
    logger.trace("[findNetworkGroup] out", result);
    return result;
  }

  public List<SimpleClinic> doClinicMatch(ClinicMatch o) {
    logger.trace("[doClinicMatch] in", o);
    if (o.getAddress() == null || o.getPhone() == null)
      throw new IllegalArgumentException("Address and phone are mandatory");
    List<SimpleClinic> result = null;
    List<Clinic> c = clinicRepository.findMatch(o.getAddress().getLine1(), o.getPhone().getDisplay(),
        o.getDataOwnerId());

    if (!c.isEmpty())
      result = c.stream().map(e -> new ClinicToSimpleClinic().apply(e)).collect(Collectors.toList());
    else
      result = new ArrayList<SimpleClinic>();

    logger.trace("[doClinicMatch] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Clinic getClinic(Long id, boolean eagerLoad) {
    logger.trace("[getClinic] in", id, eagerLoad);
    Clinic result = null;
    Optional<Clinic> o = clinicRepository.findById(id);
    if (o.isPresent()) {
      result = o.get();
      if (eagerLoad) {
        result.getDocumentControls();
        result.getClinicProviders();
        result.getNetworkClinics();
        result.getFocusReviews();
      }
    }
    logger.trace("[getClinic] out", result);
    return result;
  }

  @Override
  public void deleteClinic(Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinic] in", id);
    try {
      clinicRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinic] out");
  }

  @Override
  public List<ClinicAddress> getClinicAddressesByClinic(Clinic o) {
    logger.trace("[getClinicAddressesByClinic] in", o);
    List<ClinicAddress> result = clinicAddressRepository.findByClinic(o);
    logger.trace("[getClinicAddressesByClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<Language> getLanguagesFromClinic(Long id) throws NoEntityFoundException {
    logger.trace("[getLanguagesFromClinic] in", id);
    findClinic(id);
    List<Language> result = clinicLanguageRepository.findByClinicId(id).stream().map(new ClinicLanguageToLanguage())
        .collect(Collectors.toList());

    logger.trace("[getLanguagesFromClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<com.anthem.specialty.provider.datamodel.dto.LegalAddress> getW9LegalAddresses(Long id)
      throws NoEntityFoundException {
    logger.trace("[getW9LegalAddresses] in", id);
    getW9(id); // ensures valid ID
    List<com.anthem.specialty.provider.datamodel.dto.LegalAddress> result = legalAddressRepository
        .findByW9LegalEntityId(id).stream().map(new LegalAddressToLegalAddressDto()).collect(Collectors.toList());

    logger.trace("[getW9LegalAddresses] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<RelatedNetwork> getNetworksByCarrier(Long carrierId) throws NoEntityFoundException {
    logger.trace("[getNetworksByCarrier] in", carrierId);
    Carrier carrier = getCarrier(carrierId); // carrier id validation only
    List<RelatedNetwork> result = networkCarrierRepository.findByCarrierId(carrierId)
        .map(new NetworkCarrierToRelatedNetwork()).collect(Collectors.toList());

    logger.trace("[getNetworksByCarrier] out", result);
    return result;
  }

  @Override
  public List<ClinicCredentials> getCredentialsFromClinic(Long id) throws NoEntityFoundException {
    logger.trace("[getCredentialsFromClinic] in", id);
    findClinic(id); // id validation
    List<ClinicCredentials> result = clinicCredentialRepository.findByClinicId(id).stream()
        .map(new ClinicCredentialToClinicCredentialDto()).collect(Collectors.toList());

    logger.trace("[getCredentialsFromClinic] out", result);
    return result;
  }

  @Override
  public List<PhoneContact> getPhoneContactsFromClinic(Long id) throws NoEntityFoundException {
    logger.trace("[getPhoneContactsFromClinic] in", id);
    findClinic(id); // validate id
    List<PhoneContact> result = clinicPhoneContactRepository.findByClinicId(id).stream()
        .map(new ClinicPhoneContactToPhoneContact()).collect(Collectors.toList());

    logger.trace("[getPhoneContactsFromClinic] out", result);
    return result;
  }

  @Override
  @Transactional(rollbackOn = Exception.class)
  public List<com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact> getPhoneContactsFromCarrier(Long id)
      throws NoEntityFoundException {
    logger.trace("[getPhoneContactsFromCarrier] in", id);
    getCarrier(id); // validation
    List<com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact> result = carrierPhoneContactRepository
        .findByCarrierId(id).stream().map(new CarrierPhoneContactToCarrierPhoneContactDto())
        .collect(Collectors.toList());

    logger.trace("[getPhoneContactsFromCarrier] out", result);
    return result;
  }

  @Override

  public List<RelatedW9> getW9sFromClinic(Long id) throws NoEntityFoundException {

    logger.trace("[getW9sFromClinic] in", id);
    findClinic(id); // ensure valid ID
    List<RelatedW9> result = clinicW9Repository.findByClinicId(id).stream().map(new ClinicW9ToRelatedW9())
        .collect(Collectors.toList());

    logger.trace("[getW9sFromClinic] out", result);
    return result;
  }

  @Override
  public List<Address> getAddressesFromClinic(Long clinicId) throws NoEntityFoundException {
    logger.trace("[getAddressesFromClinic] in", clinicId);
    findClinic(clinicId);
    List<Address> result = clinicAddressRepository.findByClinicId(clinicId).stream().map(new ClinicAddressToAddress())
        .collect(Collectors.toList());

    logger.trace("[getAddressesFromClinic] out", result);
    return result;
  }

  @Override
  public Address getClinicAddress(Long addressId) throws NoEntityFoundException {
    logger.trace("[getClinicAddress] in", addressId);
    Address result = null;

    Optional<ClinicAddress> o = clinicAddressRepository.findById(addressId);
    if (o.isPresent())
      result = new ClinicAddressToAddress().apply(o.get());
    else
      throw new NoEntityFoundException("ClinicAddress " + addressId + " not found");

    logger.trace("[getClinicAddress] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<CollectionRelatedCarrier> getNetworkCarriers(Long networkId) throws NoEntityFoundException {
    logger.trace("[getNetworkCarriers] in", networkId);

    if (!networkRepository.existsById(networkId))
      throw new NoEntityFoundException(format("no network[%d]", networkId));

    List<CollectionRelatedCarrier> result = networkCarrierRepository.findByNetworkId(networkId).stream()
        .map(new NetworkCarrierToCollectionRelatedCarrier(networkCarrierRepository, networkRepository))
        .collect(Collectors.toList());

    logger.trace("[getNetworkCarriers] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<RelatedProvider> getNetworkProviders(Long networkId) throws NoEntityFoundException {
    logger.trace("[getNetworkProviders] in", networkId);

    getNetwork(networkId);
    List<RelatedProvider> r = networkClinicProviderRepository.findByNetworkId(networkId).stream()
        .map(new NetworkClinicProviderToRelatedProvider()).collect(Collectors.toList());

    logger.trace("[getNetworkProviders] out", r);
    return r;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.LegalAddress getW9LegalAddress(Long id)
      throws NoEntityFoundException {
    logger.trace("[getW9LegalAddress] in", id);
    com.anthem.specialty.provider.datamodel.dto.LegalAddress result = null;

    Optional<LegalAddress> o = legalAddressRepository.findById(id);
    if (o.isPresent())
      result = new LegalAddressToLegalAddressDto().apply(o.get());
    else
      throw new NoEntityFoundException("No legal address " + id);

    logger.trace("[getW9LegalAddress] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Address putClinicAddress(Long clinicId, NewAddress address)
      throws DataConstraintException, DataValidationException, NoEntityFoundException, DataLayerException {
    logger.trace("[putClinicAddress] in", clinicId, address);
    if (null == clinicId)
      throw new IllegalArgumentException("clinicId is null");
    if (null == address)
      throw new IllegalArgumentException("address is null");

    Address result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    try {
      result = new ClinicAddressToAddress()
          .apply(clinicAddressRepository.save(new NewAddressToClinicAddress().apply(clinic.get(), address)));
    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    }

    logger.trace("[putClinicAddress] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public PhoneContact putClinicPhoneContact(Long clinicId, NewPhoneContact o) throws DataLayerException {
    logger.trace("[putClinicPhoneContact] in", clinicId, o);
    if (null == clinicId)
      throw new IllegalArgumentException("clinicId is null");
    if (null == o)
      throw new IllegalArgumentException("phone contact is null");

    PhoneContact result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new DataValidationException(format("no clinic for id: %s", clinicId.toString()));

    Optional<ClinicPhoneContact> existent = clinicPhoneContactRepository.findByClinicIdAndType(clinicId,
        o.getType().asChar());
    if (existent.isPresent())
      clinicPhoneContactRepository.deleteById(existent.get().getId());

    result = new ClinicPhoneContactToPhoneContact()
        .apply(clinicPhoneContactRepository.save(new NewPhoneContactToClinicPhoneContact().apply(clinic.get(), o)));

    logger.trace("[putClinicPhoneContact] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.LegalAddress putW9LegalAddress(Long w9id,
      com.anthem.specialty.provider.datamodel.dto.LegalAddress o) throws NoEntityFoundException {
    logger.trace("[putW9LegalAddress] in", w9id, o);
    if (null == w9id)
      throw new IllegalArgumentException("w9id is null");
    if (null == o)
      throw new IllegalArgumentException("address is null");

    com.anthem.specialty.provider.datamodel.dto.LegalAddress result = null;

    Optional<W9LegalEntity> w9 = w9LegalEntityRepository.findById(w9id);
    if (!w9.isPresent())
      throw new NoEntityFoundException(format("no w9 for id: %s", w9id.toString()));

    LegalAddress toSave = new LegalAddressDtoToLegalAddress().apply(w9.get(), o);
    LegalAddress saved = legalAddressRepository.save(toSave);
    result = new LegalAddressToLegalAddressDto().apply(saved);

    logger.trace("[putW9LegalAddress] out", result);
    return result;
  }

  @Override
  public boolean hasAddress(Long clinicId, AddressType type) throws NoEntityFoundException {
    logger.trace("[hasAddress] in", clinicId, type);
    if (null == clinicId)
      throw new IllegalArgumentException("clinicId is null");
    if (null == type)
      throw new IllegalArgumentException("type is null");

    boolean result = false;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    Optional<ClinicAddress> existent = clinicAddressRepository.findByClinicIdAndType(clinicId, type.toChar());
    result = existent.isPresent();

    logger.trace("[hasAddress] out", result);
    return result;
  }

  @Override
  public boolean hasClinicPhoneContact(Long clinicId, PhoneContactType type) throws NoEntityFoundException {
    logger.trace("[hasClinicPhoneContact] in", clinicId, type);
    if (null == clinicId)
      throw new IllegalArgumentException("clinicId is null");
    if (null == type)
      throw new IllegalArgumentException("type is null");

    boolean result = false;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    Optional<ClinicPhoneContact> existent = clinicPhoneContactRepository.findByClinicIdAndType(clinicId, type.asChar());
    result = existent.isPresent();

    logger.trace("[hasClinicPhoneContact] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public RelatedW9 postClinicW9(Long clinicId, NewW9EffectiveRelationship o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException {
    logger.trace("[postClinicW9] in", o);
    if (null == clinicId)
      throw new DataValidationException("clinicId is null");
    if (null == o)
      throw new DataValidationException("NewW9Relationship is null");
    if (null == o.getW9())
      throw new DataValidationException("W9 in NewW9Relationship is null");

    RelatedW9 result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    Optional<W9LegalEntity> w9le = w9LegalEntityRepository.findById(o.getW9().getId());
    if (!w9le.isPresent())
      throw new NoEntityFoundException(format("no W9 for id: %s", o.getW9().getId().toString()));

    Optional<ClinicW9> cw9 = clinicW9Repository.findByW9LegalEntityIdAndClinicId(o.getW9().getId(), clinicId);
    if (cw9.isPresent())
      throw new DataIntegrityException(format("theres is already a record with w9id: %s and clinic Id: %s",
          o.getW9().getId().toString(), clinicId.toString()));

    result = new ClinicW9ToRelatedW9()
        .apply(clinicW9Repository.save(new NewW9RelationshipToClinicW9().apply(clinic.get(), w9le.get(), o)));

    logger.trace("[postClinicW9] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public CollectionRelatedCarrier postNetworkCarrier(Long networkId, NewCarrierEffectiveRelationship o)
      throws NoEntityFoundException, DataValidationException {
    logger.trace("[postNetworkCarrier] in", networkId, o);
    if (null == networkId)
      throw new DataValidationException("networkId is null");
    if (null == o)
      throw new DataValidationException("NewCarrierRelationship is null");
    if (null == o.getCarrier())
      throw new DataValidationException("Carrier is null");

    CollectionRelatedCarrier result = null;
    Optional<Network> optNw = networkRepository.findById(networkId);

    if (!optNw.isPresent())
      throw new NoEntityFoundException(format("no network [%s]", networkId));

    NetworkCarrier n = new NewCarrierRelationshipToNetworkCarrier(carrierRepository).apply(optNw.get(), o);
    result = new NetworkCarrierToCollectionRelatedCarrier(networkCarrierRepository, networkRepository)
        .apply(networkCarrierRepository.save(n));

    logger.trace("[postNetworkCarrier] out", result);
    return result;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact postCarrierPhoneContact(Long carrierId,
      NewCarrierPhoneContact o) throws DataConstraintException, DataValidationException, DataLayerException {
    logger.trace("[postCarrierPhoneContact] in", carrierId, o);
    if (null == carrierId)
      throw new DataValidationException("carrierId is null");
    if (null == o)
      throw new DataValidationException("NewCarrierRelationship is null");

    com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact result = null;
    Optional<Carrier> optNw = carrierRepository.findById(carrierId);

    if (!optNw.isPresent())
      throw new NoEntityFoundException(format("no carrier [%s]", carrierId));

    CarrierPhoneContact n = new NewCarrierPhoneContactToCarrierPhoneContact().apply(optNw.get(), o);

    try {
      result = new CarrierPhoneContactToCarrierPhoneContactDto().apply(carrierPhoneContactRepository.save(n));
    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    }

    logger.trace("[postCarrierPhoneContact] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinicRelationship postNetworkClinic(Long networkId, NewNetworkClinicRelationship o)
      throws NoEntityFoundException, DataValidationException {
    logger.trace("[postNetworkClinic] in", networkId, o);
    if (null == networkId)
      throw new DataValidationException("networkId is null");
    if (null == o)
      throw new DataValidationException("NewNetworkClinicRelationship is null");
    if (null == o.getClinic())
      throw new DataValidationException("Clinic is null");

    NetworkClinicRelationship result = null;
    Optional<Network> optNw = networkRepository.findById(networkId);

    if (!optNw.isPresent())
      throw new NoEntityFoundException(format("no network [%s]", networkId));

    NetworkClinic n = new NewNetworkClinicRelationshipToNetworkClinic(clinicRepository).apply(optNw.get(), o);
    result = new NetworkClinicToNetworkClinicRelationship().apply(networkClinicRepository.save(n));

    logger.trace("[postNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinicProviderRelationship postNetworkClinicProvider(Long networkClinicId,
      NewNetworkClinicProviderRelationship o) throws NoEntityFoundException, DataValidationException {
    logger.trace("[postNetworkClinicProvider] in", networkClinicId, o);
    if (null == networkClinicId)
      throw new DataValidationException("networkClinicId is null");
    if (null == o)
      throw new DataValidationException("NewNetworkClinicProviderRelationship is null");

    NetworkClinicProviderRelationship result = null;
    Optional<NetworkClinic> optNc = networkClinicRepository.findById(networkClinicId);

    if (!optNc.isPresent())
      throw new NoEntityFoundException(format("no network clinic relation [%d]", networkClinicId));

    NetworkClinicProvider n = new NewNetworkClinicProviderRelationshipToNetworkClinicProvider(providerRepository,
        terminationLevelRepository).apply(optNc.get(), o);
    result = new NetworkClinicProviderToNetworkClinicProviderRelationship()
        .apply(networkClinicProviderRepository.save(n));

    logger.trace("[postNetworkClinicProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ClinicCredentials postClinicClinicCredentials(Long clinicId, NewClinicCredentials o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException {
    logger.trace("[postClinicClinicCredentials] in", o);
    if (null == clinicId)
      throw new DataValidationException("clinicId is null");
    if (null == o)
      throw new DataValidationException("clinic credentials is null");

    ClinicCredentials result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    result = new ClinicCredentialToClinicCredentialDto()
        .apply(clinicCredentialRepository.save(new NewClinicCredentialsToClinicCredential().apply(clinic.get(), o)));

    logger.trace("[postClinicClinicCredentials] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Language postClinicLanguage(Long clinicId, NewLanguage o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException {
    logger.trace("[postClinicLanguage] in", o);
    if (null == clinicId)
      throw new DataValidationException("clinicId is null");
    if (null == o)
      throw new DataValidationException("clinic language is null");

    Language result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    result = new ClinicLanguageToLanguage()
        .apply(clinicLanguageRepository.save(new NewLanguageToClinicLanguage().apply(clinic.get(), o)));

    logger.trace("[postClinicLanguage] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public PhoneContact postClinicPhoneContact(Long clinicId, NewPhoneContact o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException {
    logger.trace("[postClinicPhoneContact] in", o);
    if (null == clinicId)
      throw new DataValidationException("clinicId is null");
    if (null == o)
      throw new DataValidationException("new phone contact is null");

    PhoneContact result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %s", clinicId.toString()));

    result = new ClinicPhoneContactToPhoneContact()
        .apply(clinicPhoneContactRepository.save(new NewPhoneContactToClinicPhoneContact().apply(clinic.get(), o)));

    logger.trace("[postClinicPhoneContact] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Address postClinicAddress(Long clinicId, NewAddress address) throws DataLayerException {
    logger.trace("[postClinicAddress] in", address);
    if (null == clinicId)
      throw new IllegalArgumentException("clinicId is null");
    if (null == address)
      throw new IllegalArgumentException("address is null");
    if (null == address.getType())
      throw new IllegalArgumentException("address type is null");

    Address result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new DataValidationException(format("no clinic for id: %s", clinicId.toString()));

    Optional<ClinicAddress> existent = clinicAddressRepository.findByClinicIdAndType(clinicId,
        address.getType().toChar());
    if (existent.isPresent())
      throw new DataIntegrityException(format("already an address in this clinic id: %s with type: %s",
          clinicId.toString(), address.getType().toString()));

    result = new ClinicAddressToAddress()
        .apply(clinicAddressRepository.save(new NewAddressToClinicAddress().apply(clinic.get(), address)));

    logger.trace("[postClinicAddress] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.LegalAddress postW9LegalAddress(Long w9id, NewLegalAddress address)
      throws NoEntityFoundException, DataIntegrityException {
    logger.trace("[postW9LegalAddress] in", w9id, address);
    if (null == w9id)
      throw new IllegalArgumentException("w9id is null");
    if (null == address)
      throw new IllegalArgumentException("address is null");

    com.anthem.specialty.provider.datamodel.dto.LegalAddress result = null;

    Optional<W9LegalEntity> w9 = w9LegalEntityRepository.findById(w9id);
    if (!w9.isPresent())
      throw new NoEntityFoundException(format("no W9 for id: %s", w9id.toString()));

    result = new LegalAddressToLegalAddressDto()
        .apply(legalAddressRepository.save(new NewLegalAddressToLegalAddress().apply(w9.get(), address)));

    logger.trace("[postW9LegalAddress] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ProviderFocusReview postProviderFocusReview(Long providerId, NewProviderFocusReview o)
      throws NoEntityFoundException, DataIntegrityException {
    logger.trace("[postProviderFocusReview] in", providerId, o);
    if (null == providerId)
      throw new IllegalArgumentException("providerId is null");
    if (null == o)
      throw new IllegalArgumentException("NewClinicFocusReview is null");

    ProviderFocusReview result = null;

    Optional<Clinic> clinic = clinicRepository.findById(o.getClinic().getId());
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %d", o.getClinic().getId()));

    Optional<Provider> provider = providerRepository.findById(providerId);
    if (!provider.isPresent())
      throw new NoEntityFoundException(format("no provider for id: %d", providerId));

    Optional<NetworkGroup> networkGroup = networkGroupRepository.findById(o.getNetworkGroup().getId());
    if (!networkGroup.isPresent())
      throw new NoEntityFoundException(format("no networkGroup for id: %d", o.getNetworkGroup().getId()));

    result = new FocusReviewToProviderFocusReview().apply(focusReviewRepository
        .save(new NewFocusReviewToFocusReview(provider.get(), clinic.get(), networkGroup.get()).apply(o)));

    logger.trace("[postProviderFocusReview] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ClinicFocusReview postClinicFocusReview(Long clinicId, NewClinicFocusReview o)
      throws NoEntityFoundException, DataIntegrityException {
    logger.trace("[postProviderFocusReview] in", clinicId, o);
    if (null == clinicId)
      throw new IllegalArgumentException("clinicId is null");
    if (null == o)
      throw new IllegalArgumentException("NewProviderFocusReview is null");

    ClinicFocusReview result = null;

    Optional<Clinic> clinic = clinicRepository.findById(clinicId);
    if (!clinic.isPresent())
      throw new NoEntityFoundException(format("no clinic for id: %d", clinicId));

    Optional<Provider> provider = providerRepository.findById(o.getProvider().getId());
    if (!provider.isPresent())
      throw new NoEntityFoundException(format("no provider for id: %d", o.getProvider().getId()));

    Optional<NetworkGroup> networkGroup = networkGroupRepository.findById(o.getNetworkGroup().getId());
    if (!networkGroup.isPresent())
      throw new NoEntityFoundException(format("no networkGroup for id: %d", o.getNetworkGroup().getId()));

    result = new FocusReviewToClinicFocusReview().apply(focusReviewRepository
        .save(new NewFocusReviewToFocusReview(provider.get(), clinic.get(), networkGroup.get()).apply(o)));

    logger.trace("[postProviderFocusReview] out", result);
    return result;
  }

  @Override
  public List<ClinicPhoneContact> getClinicPhoneContactsByClinic(Clinic o) {
    logger.trace("[getClinicPhoneContactsByClinic] in", o);
    List<ClinicPhoneContact> result = clinicPhoneContactRepository.findByClinic(o);
    logger.trace("[getClinicPhoneContactsByClinic] out", result);
    return result;
  }

  @Override
  public List<ClinicOpeningHours> getClinicOpeningHoursByClinic(Clinic o) {
    logger.trace("[getClinicOpeningHoursByClinic] in", o);
    List<ClinicOpeningHours> result = clinicOpeningHoursRepository.findByClinic(o);
    logger.trace("[getClinicOpeningHoursByClinic] out", result);
    return result;
  }

  @Override
  public List<ClinicCredential> getClinicCredentialsByClinic(Clinic o) {
    logger.trace("[getClinicCredentialsByClinic] in", o);
    List<ClinicCredential> result = clinicCredentialRepository.findByClinic(o);
    logger.trace("[getClinicCredentialsByClinic] out", result);
    return result;
  }

  @Override
  public List<ClinicLanguage> getClinicLanguagesByClinic(Clinic o) {
    logger.trace("[getClinicLanguagesByClinic] in", o);
    List<ClinicLanguage> result = clinicLanguageRepository.findByClinic(o);
    logger.trace("[getClinicLanguagesByClinic] out", result);
    return result;
  }

  @Override
  public ProviderSanction setProviderSanction(ProviderSanction o) {
    logger.trace("[setProviderSanction] in", o);
    ProviderSanction result = providerSanctionRepository.save(o);
    logger.trace("[setProviderSanction] out", result);
    return result;
  }

  @Override
  public ProviderSanction getProviderSanction(Long id) {
    logger.trace("[getProviderSanction] in", id);
    Optional<ProviderSanction> o = providerSanctionRepository.findById(id);
    ProviderSanction result = o.isPresent() ? o.get() : null;
    logger.trace("[getProviderSanction] out", result);
    return result;
  }

  @Override
  public void deleteProviderSanction(Long id) throws NoEntityFoundException {
    logger.trace("[deleteProviderSanction] in", id);
    try {
      providerSanctionRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteProviderSanction] out");
  }

  @Override
  public List<ProviderSanction> getProviderSanctionsByClinic(Clinic o) {
    logger.trace("[getProviderSanctionsByClinic] in", o);
    List<ProviderSanction> result = providerSanctionRepository.findByClinic(o);
    logger.trace("[getProviderSanctionsByClinic] out", result);
    return result;
  }

  @Override
  public List<ProviderSanction> getProviderSanctionsByProvider(Provider o) {
    logger.trace("[getProviderSanctionsByProvider] in", o);
    List<ProviderSanction> result = providerSanctionRepository.findByProvider(o);
    logger.trace("[getProviderSanctionsByProvider] out", result);
    return result;
  }

  @Override
  public List<Sanction> getProviderSanctionsByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getProviderSanctionsByProvider] in", providerId);
    findProvider(providerId);
    List<Sanction> result = providerSanctionRepository.findByProviderId(providerId).stream()
        .flatMap(new ProviderSanctionToSanctionStream()).collect(Collectors.toList());
    logger.trace("[getProviderSanctionsByProvider] out", result);
    return result;
  }

  @Override
  public DocumentControl setDocumentControl(DocumentControl o) {
    logger.trace("[setDocumentControl] in", o);
    DocumentControl result = documentControlRepository.save(o);
    logger.trace("[setDocumentControl] out", result);
    return result;
  }

  @Override
  public DocumentControl getDocumentControl(Long id) {
    logger.trace("[getDocumentControl] in", id);
    Optional<DocumentControl> o = documentControlRepository.findById(id);
    DocumentControl result = o.isPresent() ? o.get() : null;
    logger.trace("[getDocumentControl] out", result);
    return result;
  }

  @Override
  public void deleteDocumentControl(Long id) throws NoEntityFoundException {
    logger.trace("[deleteDocumentControl] in", id);
    try {
      documentControlRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteDocumentControl] out");
  }

  @Override
  public List<DocumentControl> getDocumentControlsByClinic(Clinic o) {
    logger.trace("[getDocumentControlsByClinic] in", o);
    List<DocumentControl> result = documentControlRepository.findByClinic(o);
    logger.trace("[getDocumentControlsByClinic] out", result);
    return result;
  }

  @Override
  public List<DocumentControl> getDocumentControlsByProvider(Provider o) {
    logger.trace("[getDocumentControlsByProvider] in", o);
    List<DocumentControl> result = documentControlRepository.findByProvider(o);
    logger.trace("[getDocumentControlsByProvider] out", result);
    return result;
  }

  @Override
  public List<Document> getDocumentControlsByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getDocumentControlsByProvider] in", providerId);
    findProvider(providerId); // validate provider id
    List<Document> result = documentControlRepository.findByProviderId(providerId).stream()
        .flatMap(new DocumentControlToDocumentStream()).collect(Collectors.toList());
    logger.trace("[getDocumentControlsByProvider] out", result);
    return result;
  }

  @Override
  public NetworkCarrier setNetworkCarrier(NetworkCarrier o) {
    logger.trace("[setNetworkCarrier] in", o);
    NetworkCarrier result = networkCarrierRepository.save(o);
    logger.trace("[setNetworkCarrier] out", result);
    return result;
  }

  @Override
  public NetworkCarrier getNetworkCarrier(Long id) {
    logger.trace("[getNetworkCarrier] in", id);
    Optional<NetworkCarrier> o = networkCarrierRepository.findById(id);
    NetworkCarrier result = o.isPresent() ? o.get() : null;
    logger.trace("[getNetworkCarrier] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public CollectionRelatedCarrier getNetworkCarrier(Long networkId, Long networkCarrierId)
      throws NoEntityFoundException {
    logger.trace("[getNetworkCarrier] in", networkId, networkCarrierId);
    CollectionRelatedCarrier result = null;

    Optional<Network> n = networkRepository.findById(networkId);
    if (!n.isPresent())
      throw new NoEntityFoundException(format("no network [%d]", networkId));

    Optional<NetworkCarrier> o = networkCarrierRepository.findById(networkCarrierId);

    if (o.isPresent()) {
      if (!o.get().getNetwork().getId().equals(networkId))
        throw new NoEntityFoundException(
            format("the networkCarrier [%d] is not associated with the network [%d]", networkCarrierId, networkId));

      result = new NetworkCarrierToCollectionRelatedCarrier(networkCarrierRepository, networkRepository).apply(o.get());
    }

    logger.trace("[getNetworkCarrier] out", result);
    return result;
  }

  @Override
  public void deleteNetworkCarrier(Long id) throws NoEntityFoundException {
    logger.trace("[deleteNetworkCarrier] in", id);
    try {
      networkCarrierRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteNetworkCarrier] out");
  }

  @Override
  public NetworkGroup setNetworkGroup(NetworkGroup o) {
    logger.trace("[setNetworkGroup] in", o);
    NetworkGroup result = networkGroupRepository.save(o);
    logger.trace("[setNetworkGroup] out", result);
    return result;
  }

  @Override
  public void deleteNetworkGroup(Long id) throws NoEntityFoundException {
    logger.trace("[deleteNetworkGroup] in", id);
    try {
      networkGroupRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteNetworkGroup] out");
  }

  @Override
  public ClinicProvider setClinicProvider(ClinicProvider o) {
    logger.trace("[setClinicProvider] in", o);
    ClinicProvider result = clinicProviderRepository.save(o);
    logger.trace("[setClinicProvider] out", result);
    return result;
  }

  @Override
  public ClinicProvider getClinicProvider(Long id) {
    logger.trace("[getClinicProvider] in", id);
    Optional<ClinicProvider> o = clinicProviderRepository.findById(id);
    ClinicProvider result = o.isPresent() ? o.get() : null;
    logger.trace("[getClinicProvider] out", result);
    return result;
  }

  @Override
  public void deleteClinicProvider(Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinicProvider] in", id);
    try {
      clinicProviderRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicProvider] out");
  }

  @Override
  public void deleteClinicAddress(Long clinicId, Long addressId) throws NoEntityFoundException {
    logger.trace("[deleteClinicProvider] in", clinicId, addressId);
    try {
      clinicAddressRepository.deleteById(addressId);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicProvider] out");
  }

  @Override
  public void deleteClinicLanguage(Long clinicId, Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinicLanguage] in", clinicId, id);
    try {
      clinicLanguageRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicLanguage] out");
  }

  @Override
  public void deleteClinicPhoneContact(Long clinicId, Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinicPhoneContact] in", clinicId, id);
    try {
      clinicPhoneContactRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicPhoneContact] out");
  }

  @Override
  public void deleteClinicFocusReview(Long clinicId, Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinicFocusReview] in", clinicId, id);
    try {
      focusReviewRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicFocusReview] out");
  }

  @Override
  public void deleteW9(Long id) throws NoEntityFoundException {
    logger.trace("[deleteW9] in", id);
    try {
      w9LegalEntityRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteW9] out");
  }

  @Override
  public void deleteClinicW9(Long clinicId, Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinicW9] in", clinicId, id);
    try {
      clinicW9Repository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicW9] out");
  }

  @Override
  public void deleteCarrierPhoneContact(Long id) throws NoEntityFoundException {
    logger.trace("[deleteCarrierPhoneContact] in", id);
    try {
      carrierPhoneContactRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteCarrierPhoneContact] out");
  }

  @Override
  public void deleteW9LegalAddress(Long legalAddressId) throws NoEntityFoundException {
    logger.trace("[deleteClinicW9] in", legalAddressId);
    try {
      legalAddressRepository.deleteById(legalAddressId);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicW9] out");
  }

  @Override
  public List<ClinicProvider> getClinicProvidersByClinic(Clinic o) {
    logger.trace("[getClinicProvidersByClinic] in", o);
    List<ClinicProvider> result = clinicProviderRepository.findByClinic(o);
    logger.trace("[getClinicProvidersByClinic] out", result);
    return result;
  }

  @Override
  public List<ClinicProvider> getClinicProvidersByProvider(Provider o) {
    logger.trace("[getClinicProvidersByProvider] in", o);
    List<ClinicProvider> result = clinicProviderRepository.findByProvider(o);
    logger.trace("[getClinicProvidersByProvider] out", result);
    return result;
  }

  @Override
  public List<ClinicProviderSchedule> getClinicProviderSchedulesByClinicProvider(ClinicProvider o) {
    logger.trace("[getClinicProviderSchedulesByClinicProvider] in", o);
    List<ClinicProviderSchedule> result = clinicProviderScheduleRepository.findByClinicProvider(o);
    logger.trace("[getClinicProviderSchedulesByClinicProvider] out", result);
    return result;
  }

  @Override
  public ClinicW9 setClinicW9(ClinicW9 o) {
    logger.trace("[setClinicW9] in", o);
    ClinicW9 result = clinicW9Repository.save(o);
    logger.trace("[setClinicW9] out", result);
    return result;
  }

  @Override
  public ClinicW9 getClinicW9(Long id) {
    logger.trace("[getClinicW9] in", id);
    Optional<ClinicW9> o = clinicW9Repository.findById(id);
    ClinicW9 result = o.isPresent() ? o.get() : null;
    logger.trace("[getClinicW9] out", result);
    return result;
  }

  @Override
  public List<ProviderFocusReview> getProviderFocusReviewsByProviderId(Long providerId) throws NoEntityFoundException {
    logger.trace("[getProviderFocusReviewsByProviderId] in", providerId);

    findProvider(providerId); // validation

    List<ProviderFocusReview> result = focusReviewRepository.findByProviderId(providerId).stream()
        .map(new FocusReviewToProviderFocusReview()).collect(Collectors.toList());

    logger.trace("[getProviderFocusReviewsByProviderId] out", result);
    return result;
  }

  @Override
  public List<ClinicFocusReview> getClinicFocusReviewsByClinicId(Long clinicId) throws NoEntityFoundException {
    logger.trace("[getClinicFocusReviewsByClinicId] in", clinicId);

    findClinic(clinicId); // validation

    List<ClinicFocusReview> result = focusReviewRepository.findByClinicId(clinicId).stream()
        .map(new FocusReviewToClinicFocusReview()).collect(Collectors.toList());

    logger.trace("[getClinicFocusReviewsByClinicId] out", result);
    return result;
  }

  @Override
  public void deleteClinicW9(Long id) throws NoEntityFoundException {
    logger.trace("[deleteClinicW9] in", id);
    try {
      clinicW9Repository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicW9] out");
  }

  @Override
  public List<ClinicW9> getClinicW9sByClinic(Clinic o) {
    logger.trace("[getClinicW9sByClinic] in", o);
    List<ClinicW9> result = clinicW9Repository.findByClinic(o);
    logger.trace("[getClinicW9sByClinic] out", result);
    return result;
  }

  @Override
  public List<ClinicW9> getClinicW9sByW9LegalEntity(W9LegalEntity o) {
    logger.trace("[getClinicW9sByW9LegalEntity] in", o);
    List<ClinicW9> result = clinicW9Repository.findByW9LegalEntity(o);
    logger.trace("[getClinicW9sByW9LegalEntity] out", result);
    return result;
  }

  @Override
  public NetworkClinic setNetworkClinic(NetworkClinic o) {
    logger.trace("[setNetworkClinic] in", o);
    NetworkClinic result = networkClinicRepository.save(o);
    logger.trace("[setNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinic getNetworkClinic(Long id) throws NoEntityFoundException {
    logger.trace("[getNetworkClinic] in", id);
    NetworkClinic result = null;
    Optional<NetworkClinic> o = networkClinicRepository.findById(id);
    if (o.isPresent()) {
      // CHECKME: load members?
      result = o.get();
      result.getNetworkClinicProviders();
    } else {
      throw new NoEntityFoundException("No network clinic for id " + id);
    }
    logger.trace("[getNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinicRelationship getNetworkClinic(Long networkId, Long networkClinicId)
      throws NoEntityFoundException {
    logger.trace("[getNetworkClinic] in", networkId, networkClinicId);
    NetworkClinicRelationship result = null;
    Optional<NetworkClinic> o = networkClinicRepository.findByIdAndNetworkId(networkClinicId, networkId);
    if (o.isPresent())
      result = new NetworkClinicToNetworkClinicRelationship().apply(o.get());
    else
      throw new NoEntityFoundException(
          "No clinic found for network id: " + networkId + "  clinic id: " + networkClinicId);

    logger.trace("[getNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteNetworkClinic(Long networkClinicId) throws NoEntityFoundException {
    logger.trace("[deleteNetworkClinic] in", networkClinicId);
    getNetworkClinic(networkClinicId); // validation
    networkClinicRepository.deleteById(networkClinicId);
    logger.trace("[deleteNetworkClinic] out");
  }

  @Override
  public List<NetworkClinic> getNetworkClinicsByClinic(Clinic o) {
    logger.trace("[getNetworkClinicsByClinic] in", o);
    List<NetworkClinic> result = networkClinicRepository.findByClinic(o);
    logger.trace("[getNetworkClinicsByClinic] out", result);
    return result;
  }

  @Override
  public List<NetworkClinic> getNetworkClinicsByNetwork(Network o) {
    logger.trace("[getNetworkClinicsByNetwork] in", o);
    List<NetworkClinic> result = networkClinicRepository.findByNetwork(o);
    logger.trace("[getNetworkClinicsByNetwork] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<RelatedClinic> getNetworkClinicsByNetworkId(Long id) throws NoEntityFoundException {
    logger.trace("[getNetworkClinicsByNetworkId] in", id);
    getNetwork(id); // validate network id
    List<RelatedClinic> result = networkClinicRepository.findByNetworkId(id).map(new NetworkClinicToRelatedClinic())
        .collect(Collectors.toList());
    logger.trace("[getNetworkClinicsByNetworkId] out", result);
    return result;
  }

  @Override
  public NetworkClinicProvider setNetworkClinicProvider(NetworkClinicProvider o) {
    logger.trace("[setNetworkClinicProvider] in", o);
    NetworkClinicProvider result = networkClinicProviderRepository.save(o);
    logger.trace("[setNetworkClinicProvider] out", result);
    return result;
  }

  @Override
  public NetworkClinicProvider getNetworkClinicProvider(Long id) throws NoEntityFoundException {
    logger.trace("[getNetworkClinicProvider] in", id);
    Optional<NetworkClinicProvider> o = networkClinicProviderRepository.findById(id);
    NetworkClinicProvider result = o.isPresent() ? o.get() : null;
    if (result == null)
      throw new NoEntityFoundException("No network clinic provider " + id);
    logger.trace("[getNetworkClinicProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinicProviderRelationship getNetworkClinicProviderDto(Long id) throws NoEntityFoundException {
    logger.trace("[getNetworkClinicProviderDto] in", id);
    NetworkClinicProviderRelationship result = null;
    Optional<NetworkClinicProvider> o = networkClinicProviderRepository.findById(id);
    if (o.isPresent()) {
      result = new NetworkClinicProviderToNetworkClinicProviderRelationship().apply(o.get());
    } else {
      throw new NoEntityFoundException("No NetworkClinicProvider found for provider id " + id);
    }
    logger.trace("[getNetworkClinicProviderDto] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteNetworkClinicProvider(Long id) throws NoEntityFoundException {
    logger.trace("[deleteNetworkClinicProvider] in", id);
    getNetworkClinicProvider(id); // validate provider id
    networkClinicProviderRepository.deleteById(id);

    logger.trace("[deleteNetworkClinicProvider] out");
  }

  @Override
  public List<NetworkClinicProvider> getNetworkClinicProvidersByNetworkClinic(NetworkClinic o) {
    logger.trace("[getNetworkClinicProvidersByNetworkClinic] in", o);
    List<NetworkClinicProvider> result = networkClinicProviderRepository.findByNetworkClinic(o);
    logger.trace("[getNetworkClinicProvidersByNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<RelatedProvider> getRelatedProvidersByNetworkClinicId(Long nwClinicId) throws NoEntityFoundException {
    logger.trace("[getRelatedProvidersByNetworkAndClinic] in", nwClinicId);
    getNetworkClinic(nwClinicId); // validation
    List<RelatedProvider> result = networkClinicProviderRepository.findByNetworkClinicId(nwClinicId).stream()
        .map(new NetworkClinicProviderToRelatedProvider()).collect(Collectors.toList());
    logger.trace("[getRelatedProvidersByNetworkAndClinic] out", result);
    return result;
  }

  @Override
  public List<NetworkClinicProvider> getNetworkClinicProvidersByProvider(Provider o) {
    logger.trace("[getNetworkClinicProvidersByProvider] in", o);
    List<NetworkClinicProvider> result = networkClinicProviderRepository.findByProvider(o);
    logger.trace("[getNetworkClinicProvidersByProvider] out", result);
    return result;
  }

  @Override
  public FocusReview setFocusReview(FocusReview o) {
    logger.trace("[setFocusReview] in", o);
    FocusReview result = focusReviewRepository.save(o);
    logger.trace("[setFocusReview] out", result);
    return result;
  }

  @Override
  public FocusReview getFocusReview(Long id) {
    logger.trace("[getFocusReview] in", id);
    Optional<FocusReview> o = focusReviewRepository.findById(id);
    FocusReview result = o.isPresent() ? o.get() : null;
    logger.trace("[getFocusReview] out", result);
    return result;
  }

  @Override
  public void deleteFocusReview(Long id) throws NoEntityFoundException {
    logger.trace("[deleteFocusReview] in", id);
    try {
      focusReviewRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteFocusReview] out");
  }

  @Override
  public List<FocusReview> getFocusReviewsByNetworkGroup(NetworkGroup o) {
    logger.trace("[getFocusReviewsByNetworkGroup] in", o);
    List<FocusReview> result = focusReviewRepository.findByNetworkGroup(o);
    logger.trace("[getFocusReviewsByNetworkGroup] out", result);
    return result;
  }

  @Override
  public List<FocusReview> getFocusReviewsByProvider(Provider o) {
    logger.trace("[getFocusReviewsByProvider] in", o);
    List<FocusReview> result = focusReviewRepository.findByProvider(o);
    logger.trace("[getFocusReviewsByProvider] out", result);
    return result;
  }

  @Override
  public List<FocusReview> getFocusReviewsByClinic(Clinic o) {
    logger.trace("[getFocusReviewsByClinic] in", o);
    List<FocusReview> result = focusReviewRepository.findByClinic(o);
    logger.trace("[getFocusReviewsByClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<SimpleClinic> getClinics(int start, int size) {
    logger.trace("[getClinics] in");

    List<SimpleClinic> result = clinicRepository.findByOrderByIdDesc(PageRequest.of(start, size))
        .flatMap(new ClinicToSimpleClinicStream()).collect(Collectors.toList());

    logger.trace("[getClinics] out", result.size());
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Page<com.anthem.specialty.provider.datamodel.dto.Carrier> getCarriers(int start, int size) {
    logger.trace("[getCarriers] in", start, size);

    Page<com.anthem.specialty.provider.datamodel.dto.Carrier> r = new PageDtoTransformerImpl<>(
        new CarrierToCarrierDto()).apply(carrierRepository.findByOrderByIdDesc(PageRequest.of(start, size)));

    logger.trace("[getCarriers] out");
    return r;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<W9> getW9s(int start, int size) {
    logger.trace("[getW9s] in");

    List<W9> result = w9LegalEntityRepository.findByOrderByIdDesc(PageRequest.of(start, size)).stream()
        .map(new W9LegalEntityToW9()).collect(Collectors.toList());

    logger.trace("[getW9s] out", result.size());
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<SimpleClinic> getClinics(Map<String, String> queryParams, int start, int size) {
    logger.trace("[getClinics] in");

    if (null == queryParams)
      throw new IllegalArgumentException("query params must never be null");

    Map<String, Object> propertiesMap = new QueryParamsToObjectProperties().apply(queryParams);

    if (propertiesMap.isEmpty())
      throw new IllegalArgumentException(
          String.format("!!!\n must provide valid query parameters: %s\n!!!", queryParams.toString()));

    SimpleClinic o = jsonMapper.convertValue(propertiesMap, SimpleClinicImpl.class);
    ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreCase().withIgnoreNullValues()
        .withStringMatcher(StringMatcher.CONTAINING);

    Example<Clinic> example = Example.of(new SimpleClinicToClinic().apply(o), matcher);

    List<SimpleClinic> result = StreamSupport
        .stream(clinicRepository.findAll(example, PageRequest.of(start, size)).spliterator(), false)
        .map(new ClinicToSimpleClinic()).collect(Collectors.toList());

    logger.trace("[getClinics] out", result.size());
    return result;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.ClinicProvider createClinicProvider(NewClinicProvider o,
      Long clinicId) throws NoEntityFoundException {
    logger.trace("[createClinicProvider] in", o);
    com.anthem.specialty.provider.datamodel.dto.ClinicProvider result = null;
    Clinic clinic = findClinic(clinicId);
    Provider provider = findProvider(o.getProvider().getId());

    ClinicProvider cp = clinicProviderRepository.save(new NewClinicProviderToClinicProvider(provider, clinic).apply(o));
    if (null != cp)
      result = new ClinicProviderToClinicProviderDto().apply(cp);

    logger.trace("[createClinicProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ProviderClinic createProviderClinic(Long providerId, NewProviderClinic o) throws DataLayerException {
    logger.trace("[createProviderClinic] in", o);
    ProviderClinic result = null;

    if (o.getClinic() == null)
      throw new DataValidationException("Clinic must not be null");
    Clinic clinic = findClinic(o.getClinic().getId());
    Provider provider = findProvider(providerId);

    ClinicProvider cp = clinicProviderRepository.save(new NewProviderClinicToClinicProvider(provider, clinic).apply(o));
    if (null != cp)
      result = new ClinicProviderToProviderClinicDto().apply(cp);

    logger.trace("[createProviderClinic] out", result);
    return result;
  }

  @Override
  public ClinicProvider patchClinicProvider(Long providerId, Long clinicProviderId, Map<String, Object> properties)
      throws DataLayerException {
    logger.trace("[patchClinicProvider] in", properties);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == clinicProviderId)
      throw new IllegalArgumentException("must provide clinicProviderId");
    if (null == properties)
      throw new IllegalArgumentException("must provide changes map");

    ClinicProvider result = null;

    try {
      // validate the map
      jsonMapper.convertValue(properties, UpdatableClinicProvider.class);

      Optional<ClinicProvider> optResult = clinicProviderRepository.findByIdAndProviderId(clinicProviderId, providerId);

      if (!optResult.isPresent())
        throw new NoEntityFoundException(format("no ClinicProvider for id: %s and providerId:%s",
            clinicProviderId.toString(), providerId.toString()));

      result = optResult.get();
      Map<String, Object> map = jsonMapper.convertValue(result, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : properties.entrySet()) {
        if (!change.getKey().equals("Hours"))
          map.put(change.getKey(), change.getValue());
      }

      result = jsonMapper.convertValue(map, ClinicProvider.class);

      @SuppressWarnings("unchecked")
      List<Map<String, Object>> hours = (List<Map<String, Object>>) properties.get("Hours");
      if (null != hours) {
        result.clearClinicProviderSchedules();
        for (Map<String, Object> e : hours) {
          result.addClinicProviderSchedule(new ClinicProviderSchedule((String) e.get("DayOfWeek"),
              (String) e.get("OpeningTime"), (String) e.get("ClosingTime"), result.getDataOwner()));
        }
      }

      result = clinicProviderRepository.save(result);

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }

    logger.trace("[patchClinicProvider] out", result);
    return result;

  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact patchCarrierPhoneContact(Long carrierId,
      Long carrierPhoneContactId, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException {
    logger.trace("[patchNetworkClinic] in", carrierId, carrierPhoneContactId, changes);
    if (null == carrierId)
      throw new IllegalArgumentException("must provide carrierId");
    if (null == carrierPhoneContactId)
      throw new IllegalArgumentException("must provide carrierPhoneContactId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact result = null;
    try {

      // validate the map
      jsonMapper.convertValue(changes, UpdatableCarrierPhoneContact.class);

      Optional<CarrierPhoneContact> optResult = carrierPhoneContactRepository.findById(carrierPhoneContactId);

      if (!optResult.isPresent())
        throw new NoEntityFoundException(format("no CarrierPhoneContact for id: %s", carrierPhoneContactId.toString()));

      com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact current = new CarrierPhoneContactToCarrierPhoneContactDto()
          .apply(optResult.get());

      Map<String, Object> map = jsonMapper.convertValue(current, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      current = jsonMapper.convertValue(map, com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact.class);

      Optional<Carrier> optC = carrierRepository.findById(carrierId);
      if (!optC.isPresent())
        throw new NoEntityFoundException(format("no Carrier for id: %ss", carrierId.toString()));

      CarrierPhoneContact newO = new CarrierPhoneContactDtoToCarrierPhoneContact().apply(optC.get(), current);

      result = new CarrierPhoneContactToCarrierPhoneContactDto().apply(carrierPhoneContactRepository.save(newO));

    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException nef) {
      throw nef;
    }

    logger.trace("[patchNetworkClinic] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public NetworkClinicProviderRelationship patchNetworkClinicProvider(Long networkClinicProviderId,
      Map<String, Object> changes) throws DataLayerException {
    logger.trace("[patchNetworkClinicProvider] in", networkClinicProviderId, changes);
    if (null == networkClinicProviderId)
      throw new IllegalArgumentException("must provide networkClinicProviderId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    NetworkClinicProviderRelationship result = null;
    UpdatableNetworkClinicProviderRelationship validated = jsonMapper.convertValue(changes,
        UpdatableNetworkClinicProviderRelationship.class);

    Optional<NetworkClinicProvider> optResult = networkClinicProviderRepository.findById(networkClinicProviderId);

    if (!optResult.isPresent())
      throw new NoEntityFoundException(format("no NetworkClinicProvider for id: %d", networkClinicProviderId));

    jsonMapper.convertValue(changes, UpdatableNetworkClinicProviderRelationship.class);

    NetworkClinicProviderRelationship o = new NetworkClinicProviderToNetworkClinicProviderRelationship()
        .apply(optResult.get());

    Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
    });
    for (Map.Entry<String, Object> change : changes.entrySet())
      map.put(change.getKey(), change.getValue());

    o = jsonMapper.convertValue(map, NetworkClinicProviderRelationship.class);

    result = new NetworkClinicProviderToNetworkClinicProviderRelationship().apply(networkClinicProviderRepository.save(
        new NetworkClinicProviderRelationshipToNetworkClinicProvider(providerRepository, terminationLevelRepository)
            .apply(optResult.get().getNetworkClinic(), o)));

    logger.trace("[patchNetworkClinicProvider] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public ProviderClinic patchProviderClinic(Long providerId, Long providerClinicId, Map<String, Object> changes)
      throws DataLayerException {
    logger.trace("[patchProviderClinic] in", changes);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == providerClinicId)
      throw new IllegalArgumentException("must provide providerClinicId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    ProviderClinic result = null;
    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableClinicProvider.class);

      Optional<ClinicProvider> optResult = clinicProviderRepository.findByIdAndProviderId(providerClinicId, providerId);

      if (!optResult.isPresent())
        throw new NoEntityFoundException(format("no ClinicProvider for id: %s and providerId:%s",
            providerClinicId.toString(), providerId.toString()));

      ClinicProviderToProviderClinicDto dtoMapper = new ClinicProviderToProviderClinicDto();
      ProviderClinic existent = dtoMapper.apply(optResult.get());

      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, ProviderClinic.class);

      result = dtoMapper.apply(clinicProviderRepository
          .save(new ProviderClinicDtoToClinicProvider(optResult.get().getClinic(), optResult.get().getProvider())
              .apply(existent)));

    } catch (DataIntegrityViolationException de) {
      if (de.getCause() instanceof ConstraintViolationException) {
        throw new DataConstraintException(de);
      } else
        throw new DataValidationException(de);
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    } catch (NoEntityFoundException ne) {
      throw ne;
    }
    logger.trace("[patchProviderClinic] out", result);
    return result;
  }

  @Override
  public List<Document> getClinicProviderDocuments(Long clinicProviderId) throws NoEntityFoundException {
    logger.trace("[getClinicProviderDocuments] in", clinicProviderId);

    Optional<ClinicProvider> cp = clinicProviderRepository.findById(clinicProviderId);
    if (!cp.isPresent())
      throw new NoEntityFoundException(format("no ClinicProvider for id: %s", clinicProviderId.toString()));

    List<Document> result = documentControlRepository
        .findByProviderIdAndClinicId(cp.get().getProvider().getId(), cp.get().getClinic().getId()).stream()
        .flatMap(new DocumentControlToDocumentStream()).collect(Collectors.toList());

    logger.trace("[getClinicProviderDocuments] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Document createClinicProviderDocument(NewDocument n, Long clinicProviderId) throws DataLayerException {
    logger.trace("[createClinicProviderDocument] in", n);

    Document result = null;

    Optional<ClinicProvider> cp = clinicProviderRepository.findById(clinicProviderId);
    if (!cp.isPresent())
      throw new DataValidationException(format("no ClinicProvider for id: %s", clinicProviderId.toString()));

    DocumentControl dc = documentControlRepository
        .save(new NewDocumentToDocumentControl(cp.get().getProvider(), cp.get().getClinic()).apply(n));
    if (null != dc)
      result = new DocumentControlToDocument().apply(dc);

    logger.trace("[createClinicProviderDocument] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteClinicProviderDocument(Long clinicProviderId, Long dcnId) throws NoEntityFoundException {
    logger.trace("[deleteClinicProviderDocument] in", clinicProviderId, dcnId);
    try {
      Optional<ClinicProvider> cp = clinicProviderRepository.findById(clinicProviderId);
      if (!cp.isPresent())
        throw new NoEntityFoundException(String.format("no clinic provider with id: %d", clinicProviderId));

      if (documentControlRepository
          .findByClinicIdAndProviderIdAndDcnId(cp.get().getClinic().getId(), cp.get().getProvider().getId(), dcnId)
          .isEmpty())
        throw new NoEntityFoundException(
            String.format("no clinic provider documents with clinicProviderId: %d and document control number: %d",
                clinicProviderId, dcnId));

      documentControlRepository.deleteByClinicIdAndProviderIdAndDcnId(cp.get().getClinic().getId(),
          cp.get().getProvider().getId(), dcnId);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteClinicProviderDocument] out");
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteProviderDocument(Long providerId, Long dcnId) throws NoEntityFoundException {
    logger.trace("[deleteProviderDocument] in", providerId, dcnId);
    findProvider(providerId); // validate id
    try {
      documentControlRepository.deleteByProviderIdAndDcnId(providerId, dcnId);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteProviderDocument] out");
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Set<RelatedNetwork> getProviderRelatedNetworks(Long providerId) throws NoEntityFoundException {
    logger.trace("[getProviderRelatedNetworks] in");
    findProvider(providerId); // validate id
    Set<RelatedNetwork> result = new HashSet<RelatedNetwork>();
    NetworkToRelatedNetwork functionImpl = new NetworkToRelatedNetwork();
    for (NetworkClinicProvider ncp : networkClinicProviderRepository.findByProviderId(providerId))
      result.add(functionImpl.apply(ncp.getNetworkClinic().getNetwork()));
    logger.trace("[getProviderRelatedNetworks] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Sanction createProviderSanction(Long providerId, NewSanction newSanction) throws DataLayerException {
    logger.trace("[createProviderSanction] in", providerId, newSanction);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == newSanction)
      throw new IllegalArgumentException("!!! must provide newSanction parameter !!!");

    Sanction result = null;
    try {
      Provider provider = findProvider(providerId);
      Clinic clinic = null;
      if (null != newSanction.getClinic()) {
        clinic = findClinic(newSanction.getClinic().getId());
      }

      ProviderSanction ps = providerSanctionRepository
          .save(new NewSanctionToProviderSanction(provider, clinic).apply(newSanction));
      if (null != ps)
        result = new ProviderSanctionToSanction().apply(ps);
    } catch (NoEntityFoundException nefe) {
      throw new DataValidationException(nefe);
    }
    logger.trace("[createProviderSanction] out", result);
    return result;
  }

  @Override
  public ProviderCredentials createProviderCredential(Long providerId, NewProviderCredentials n)
      throws DataLayerException {
    logger.trace("[createProviderCredential] in", providerId, n);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewProviderCredential parameter !!!");
    ProviderCredentials result = null;

    try {
      Provider provider = findProvider(providerId);
      ProviderCredential pc = providerCredentialRepository
          .save(new NewProviderCredentialToProviderCredential(provider).apply(n));
      if (null != pc)
        result = new ProviderCredentialToProviderCredentialsDto().apply(pc);
    } catch (NoEntityFoundException nefe) {
      throw new DataValidationException(nefe);
    }
    logger.trace("[createProviderCredential] out", result);
    return result;
  }

  @Override
  public List<ProviderCredentials> getProviderCredentialsByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getProviderCredentialsByProvider] in", providerId);
    findProvider(providerId); // validation
    List<ProviderCredentials> result = providerCredentialRepository.findByProviderId(providerId).stream()
        .flatMap(new ProviderCredentialToProviderCredentialsDtoStream()).collect(Collectors.toList());
    logger.trace("[getProviderCredentialsByProvider] out", result);
    return result;
  }

  @Override
  public List<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty> getProviderSpecialtiesByProvider(
      Long providerId) throws NoEntityFoundException {
    logger.trace("[getProviderSpecialtiesByProvider] in", providerId);
    findProvider(providerId); // validation
    List<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty> result = providerSpecialtyRepository
        .findByProviderId(providerId).stream().flatMap(new ProviderSpecialtyToProviderSpecialtyDtoStream())
        .collect(Collectors.toList());
    logger.trace("[getProviderSpecialtiesByProvider] out", result);
    return result;
  }

  @Override
  public ProviderSpecialty createProviderSpecialty(Long providerId, NewProviderSpecialty n) throws DataLayerException {
    logger.trace("[createProviderSpecialty] in", providerId, n);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewProviderCredential parameter !!!");

    ProviderSpecialty result = null;
    try {
      Provider provider = findProvider(providerId);

      result = new NewProviderSpecialtyToProviderSpecialty(provider).apply(n);

      result = providerSpecialtyRepository.save(result);
    } catch (NoEntityFoundException nefe) {
      throw new DataValidationException(nefe);
    }

    logger.trace("[createProviderSpecialty] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteProviderSpecialty(Long providerId, String specialtyCode) throws NoEntityFoundException {
    logger.trace("[deleteProviderSpecialty] in", providerId, specialtyCode);
    Optional<Provider> oProv = providerRepository.findById(providerId);
    if (!oProv.isPresent())
      throw new NoEntityFoundException(String.format("No provider found for providerId: %d", providerId));

    List<ProviderSpecialty> ret = providerSpecialtyRepository.findByProviderIdAndSpecialtyCode(providerId,
        specialtyCode);
    if (ret.size() != 0) {
      try {
        providerSpecialtyRepository.deleteAll(ret);
      } catch (EmptyResultDataAccessException e) {
        throw new NoEntityFoundException(e);
      }
    } else {
      throw new NoEntityFoundException(
          String.format("no licence with providerId %d and specialtyCode %s", providerId, specialtyCode));
    }

    logger.trace("[deleteProviderSpecialty] out");

  }

  @Override
  public List<Language> getLanguagesByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getLanguagesByProvider] in", providerId);
    findProvider(providerId); // validate provider id
    List<Language> result = providerLanguageRepository.findByProviderId(providerId).stream()
        .flatMap(new ProviderLanguageToLanguageStream()).collect(Collectors.toList());
    logger.trace("[getLanguagesByProvider] out", result);
    return result;
  }

  @Override
  public Language createProviderLanguage(Long providerId, NewLanguage n) throws DataLayerException {
    logger.trace("[createProviderLanguage] in", providerId, n);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewLanguage parameter !!!");

    Language result = null;

    Provider provider;
    try {
      provider = findProvider(providerId);
    } catch (NoEntityFoundException e) {
      throw new DataValidationException(e);
    }
    ProviderLanguage pl = providerLanguageRepository.save(new NewLanguageToProviderLanguage(provider).apply(n));
    if (null != pl)
      result = new ProviderLanguageToLanguage().apply(pl);

    logger.trace("[createProviderLanguage] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteProviderLanguage(Long providerId, Long languageId) throws NoEntityFoundException {
    logger.trace("[deleteProviderLanguage] in", providerId, languageId);
    // providerLanguageRepository.deleteByIdAndProviderId(languageId, providerId);
    List<ProviderLanguage> ret = providerLanguageRepository.findByIdAndProviderId(languageId, providerId);
    if (ret.size() == 0)
      throw new NoEntityFoundException("No language " + languageId + " for provider " + providerId);
    providerLanguageRepository.deleteAll(ret);
    logger.trace("[deleteProviderLanguage] out");
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public Document createProviderDocument(Long providerId, NewDocument n) throws DataLayerException {
    logger.trace("[createProviderDocument] in", providerId, n);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewDocumentControl parameter !!!");

    Document result = null;
    try {
      Provider provider = findProvider(providerId);

      DocumentControl dc = documentControlRepository.save(new NewDocumentToDocumentControl(provider, null).apply(n));
      if (null != dc)
        result = new DocumentControlToDocument().apply(dc);
    } catch (NoEntityFoundException nefe) {
      throw new DataValidationException(nefe);
    }
    logger.trace("[createProviderDocument] out", result);
    return result;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction createProviderDisciplinaryAction(
      Long providerId, NewDisciplinaryAction n) throws DataLayerException {
    logger.trace("[createProviderDisciplinaryAction] in", providerId, n);

    com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction result = null;

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewDisciplinaryAction parameter !!!");

    try {
      Provider provider = findProvider(providerId);

      DisciplinaryAction da = disciplinaryActionRepository
          .save(new NewDisciplinaryActionToDisciplinaryAction(provider).apply(n));
      if (null != da)
        result = new DisciplinaryActionToDisciplinaryActionDto().apply(da);
    } catch (NoEntityFoundException nefe) {
      throw new DataValidationException(nefe);
    }
    logger.trace("[createProviderDisciplinaryAction] out", result);
    return result;
  }

  @Override
  @Transactional(rollbackOn = Exception.class)
  public com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction patchDisciplinaryAction(Long providerId,
      Long disciplinaryActionId, Map<String, Object> changes)
      throws DataValidationException, IllegalArgumentException, NoEntityFoundException {
    logger.trace("[patchDisciplinaryAction] in", providerId, disciplinaryActionId, changes);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == disciplinaryActionId)
      throw new IllegalArgumentException("must provide disciplinaryActionId");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction result = null;

    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableDisciplinaryAction.class);

      Optional<Provider> optProv = providerRepository.findById(providerId);
      if (!optProv.isPresent())
        throw new NoEntityFoundException(format("no provider for id: %d", providerId));

      Optional<DisciplinaryAction> optDa = disciplinaryActionRepository.findById(disciplinaryActionId);
      if (!optDa.isPresent())
        throw new NoEntityFoundException(format("no DisciplinaryAction for id: %d", disciplinaryActionId));

      DisciplinaryActionToDisciplinaryActionDto dtoMapper = new DisciplinaryActionToDisciplinaryActionDto();

      com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction existent = dtoMapper.apply(optDa.get());
      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction.class);

      result = dtoMapper.apply(disciplinaryActionRepository
          .save(new DisciplinaryActionDtoToDisciplinaryAction(optProv.get()).apply(existent)));

    } catch (IllegalArgumentException e) {
      throw new DataValidationException(e);
    }

    logger.trace("[patchDisciplinaryAction] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteDisciplinaryAction(Long providerId, Long disciplinaryActionId) throws NoEntityFoundException {
    logger.trace("[deleteProviderLanguage] in", providerId, disciplinaryActionId);
    findProvider(providerId); // validate id
    try {
      disciplinaryActionRepository.deleteById(disciplinaryActionId);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteProviderLanguage] out");
  }

  @Override
  public List<License> getLicensesByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getLicensesByProvider] in", providerId);
    getProvider(providerId); // validation
    List<License> result = providerLicenseRepository.findByProviderId(providerId).stream()
        .flatMap(new ProviderLicenseToLicenseStream()).collect(Collectors.toList());
    logger.trace("[getLicensesByProvider] out", result);
    return result;
  }

  @Override
  public License createProviderLicense(Long providerId, NewLicense n) {
    logger.trace("[createProviderLicense] in", providerId, n);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewLicense parameter !!!");

    License result = null;

    Optional<Provider> provider = providerRepository.findById(providerId);
    if (!provider.isPresent())
      throw new IllegalArgumentException(
          String.format("!!! provider not existent (id: %s) !!!", providerId.toString()));

    ProviderLicense pl = providerLicenseRepository.save(new NewLicenseToProviderLicense(provider.get()).apply(n));
    if (null != pl)
      result = new ProviderLicenseToLicense().apply(pl);

    logger.trace("[createProviderLicense] out", result);
    return result;
  }

  @Override
  @Transactional(rollbackOn = Exception.class)
  public License patchProviderLicense(Long providerId, String licenseNumber, Map<String, Object> changes)
      throws IllegalArgumentException, DataValidationException, NoEntityFoundException {
    logger.trace("[patchProviderLicense] in", providerId, licenseNumber, changes);
    if (null == providerId)
      throw new IllegalArgumentException("must provide providerId");
    if (null == licenseNumber)
      throw new IllegalArgumentException("must provide licenseNumber");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    License result = null;

    try {
      // validate the map
      jsonMapper.convertValue(changes, UpdatableLicense.class);

      Optional<Provider> oProv = providerRepository.findById(providerId);
      if (!oProv.isPresent())
        throw new NoEntityFoundException(format("no provider for id: %d", providerId));

      Optional<ProviderLicense> optLic = providerLicenseRepository.findByProviderIdAndLicenseNo(providerId,
          licenseNumber);
      if (!optLic.isPresent())
        throw new NoEntityFoundException(format("no ProviderLicense for license number: %s and providerId:%s",
            licenseNumber, providerId.toString()));

      ProviderLicenseToLicense dtoMapper = new ProviderLicenseToLicense();
      License existent = dtoMapper.apply(optLic.get());
      Map<String, Object> map = jsonMapper.convertValue(existent, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      existent = jsonMapper.convertValue(map, License.class);

      result = dtoMapper
          .apply(providerLicenseRepository.save(new LicenseToProviderLicense(oProv.get()).apply(existent)));
    } catch (IllegalArgumentException e) {
      throw new DataValidationException(e);
    }

    logger.trace("[patchProviderLicense] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteProviderLicense(Long providerId, String licenseNumber) throws NoEntityFoundException {
    logger.trace("[deleteProviderLicense] in", providerId, licenseNumber);

    if (!providerLicenseRepository.findByProviderIdAndLicenseNo(providerId, licenseNumber).isPresent())
      throw new NoEntityFoundException(
          String.format("no licence with providerId %d and licenseNo %s", providerId, licenseNumber));

    try {
      providerLicenseRepository.deleteByLicenseNo(licenseNumber);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteProviderLicense] out");
  }

  @Override
  public List<Medicaid> getMedicaidsByProvider(Long providerId) throws NoEntityFoundException {
    logger.trace("[getMedicaidsByProvider] in", providerId);
    findProvider(providerId); // validate id
    List<Medicaid> result = providerMedicaidRepository.findByProviderId(providerId).stream()
        .flatMap(new ProviderMedicaidToMedicaidStream()).collect(Collectors.toList());
    logger.trace("[getMedicaidsByProvider] out", result);
    return result;
  }

  @Override
  public Medicaid createProviderMedicaid(Long providerId, Medicaid n) throws DataLayerException {
    logger.trace("[createProviderMedicaid] in", providerId, n);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == n)
      throw new IllegalArgumentException("!!! must provide NewMedicaid parameter !!!");
    Medicaid result = null;

    try {
      Provider provider = findProvider(providerId);

      ProviderMedicaid pm = providerMedicaidRepository.save(new MedicaidToProviderMedicaid(provider).apply(n));
      if (null != pm)
        result = new ProviderMedicaidToMedicaid().apply(pm);
    } catch (NoEntityFoundException nefe) {
      throw new DataValidationException(nefe);
    }
    logger.trace("[createProviderMedicaid] out", result);
    return result;
  }

  @Override
  public ProviderMedicaid putProviderMedicaid(Long providerId, String medicaidNumber, Medicaid o)
      throws NoEntityFoundException {
    logger.trace("[putProviderMedicaid] in", o);

    if (null == providerId)
      throw new IllegalArgumentException("!!! must provide providerId parameter !!!");
    if (null == o)
      throw new IllegalArgumentException("!!! must provide Medicaid parameter !!!");

    Optional<Provider> provider = providerRepository.findById(providerId);
    if (!provider.isPresent())
      throw new IllegalArgumentException(
          String.format("!!! provider not existent (id: %s) !!!", providerId.toString()));

    Optional<ProviderMedicaid> pm = providerMedicaidRepository.findByProviderIdAndMedicaidState(providerId,
        o.getState());
    if (!pm.isPresent())
      throw new NoEntityFoundException(
          "No existing medicaid number for provider " + providerId + " in state " + o.getState());

    pm.get().setMedicaidNo(o.getNumber());
    ProviderMedicaid result = providerMedicaidRepository.save(pm.get());

    logger.trace("[putProviderMedicaid] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteProviderMedicaid(Long providerId, String medicaidNumber) throws NoEntityFoundException {
    logger.trace("[deleteProviderMedicaid] in", providerId, medicaidNumber);
    findProvider(providerId); // validate provider id
    Optional<ProviderMedicaid> medicaid = providerMedicaidRepository.findByProviderIdAndMedicaidNo(providerId,
        medicaidNumber);
    if (medicaid.isPresent())
      providerMedicaidRepository.delete(medicaid.get());
    else
      throw new NoEntityFoundException("no medicaid " + medicaidNumber + " for provider " + providerId);
    logger.trace("[deleteProviderMedicaid] out");
  }

  /*
   * @Override
   * 
   * @Transactional(rollbackOn = Exception.class) public com.anthem.specialty.provider.datamodel.dto.FocusReview
   * createProviderFocusReview(Long providerId, Long clinicId, Long networkGroupId, NewFocusReview n) throws
   * DataLayerException { logger.trace("[createProviderFocusReview] in", providerId, n);
   * 
   * if (null == providerId) throw new IllegalArgumentException("!!! must provide providerId parameter !!!"); if (null
   * == clinicId) throw new IllegalArgumentException("!!! must provide clinicId parameter !!!"); if (null ==
   * networkGroupId) throw new IllegalArgumentException("!!! must provide networkGroupId parameter !!!"); if (null == n)
   * throw new IllegalArgumentException("!!! must provide NewFocusReview parameter !!!");
   * com.anthem.specialty.provider.datamodel.dto.FocusReview result = null;
   * 
   * try { Provider provider = findProvider(providerId); Clinic clinic = findClinic(clinicId); NetworkGroup ng =
   * findNetworkGroup(networkGroupId); FocusReview o = focusReviewRepository.save(new
   * NewFocusReviewToFocusReview(provider, clinic, ng).apply(n)); if (null != o) result = new
   * FocusReviewToClinicFocusReview().apply(o); } catch (NoEntityFoundException nefe) { throw new
   * DataValidationException(nefe); }
   * 
   * logger.trace("[createProviderFocusReview] out", result); return result; }
   */

  // CHECKME/TODO: function ?
  public FocusReview apply(FocusReview existent, UpdatableFocusReview properties) {
    if (properties.getAuditNumber() != null)
      existent.setAuditNumber(properties.getAuditNumber());
    if (properties.getCommenced() != null)
      existent.setCommenced(properties.getCommenced());
    if (properties.getComments() != null)
      existent.setComments(properties.getComments());
    if (properties.getLinks() != null) {
      // TODO - what to do with these?
    }
    if (properties.getProcedureCodes() != null) {
      if (properties.getProcedureCodes().getRangeEnd() != null)
        existent.setProcedureCodeRangeEnd(properties.getProcedureCodes().getRangeEnd());
      if (properties.getProcedureCodes().getRangeStart() != null)
        existent.setProcedureCodeRangeStart(properties.getProcedureCodes().getRangeStart());
    }
    if (properties.getTerminated() != null) {
      existent.setReason(properties.getTerminated().getReason());
      existent.setTerminated(properties.getTerminated().getFrom());
    }
    return existent;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public void deleteProviderFocusReview(Long providerId, Long id) throws NoEntityFoundException {
    logger.trace("[deleteProviderFocusReview] in", id, providerId);
    findProvider(providerId); // validate provider id
    try {
      focusReviewRepository.deleteById(id);
    } catch (EmptyResultDataAccessException e) {
      throw new NoEntityFoundException(e);
    }
    logger.trace("[deleteProviderFocusReview] out");
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<RelatedNetwork> getNetworks(int start, int size) {
    logger.trace("[getNetworks] in");

    List<RelatedNetwork> result = networkRepository.findByOrderByIdDesc(PageRequest.of(start, size))
        .map(new NetworkToRelatedNetwork()).collect(Collectors.toList());

    logger.trace("[getNetworks] out", result.size());
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Network patchNetwork(Long id, Map<String, Object> changes)
      throws NoEntityFoundException, DataLayerException {
    logger.trace("[patchNetwork] in", id, changes);
    if (null == id)
      throw new IllegalArgumentException("must provide id");
    if (null == changes)
      throw new IllegalArgumentException("must provide changes map");

    com.anthem.specialty.provider.datamodel.dto.Network result = null;
    final NetworkToNetworkDto dtoMapper = new NetworkToNetworkDto();

    try {

      // validate the map
      jsonMapper.convertValue(changes, UpdatableNetwork.class);

      Optional<Network> optResult = networkRepository.findById(id);

      if (!optResult.isPresent())
        throw new NoEntityFoundException(format("no network for id: %s", id.toString()));
      // TODO check for Illegal Argument
      com.anthem.specialty.provider.datamodel.dto.Network n = dtoMapper.apply(optResult.get());

      Map<String, Object> map = jsonMapper.convertValue(n, new TypeReference<Map<String, Object>>() {
      });
      for (Map.Entry<String, Object> change : changes.entrySet())
        map.put(change.getKey(), change.getValue());

      n = jsonMapper.convertValue(map, com.anthem.specialty.provider.datamodel.dto.Network.class);

      result = dtoMapper.apply(networkRepository.save(new NetworkDtoToNetwork(dataOwnerRepository).apply(n)));

    } catch (NoEntityFoundException nef) {
      throw nef;
    } catch (IllegalArgumentException ia) {
      throw new DataValidationException(ia);
    }

    logger.trace("[patchNetwork] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public com.anthem.specialty.provider.datamodel.dto.Network getNetworkDto(Long id)
      throws NoEntityFoundException, DataLayerException {
    logger.trace("[getNetworkDto] in", id);
    com.anthem.specialty.provider.datamodel.dto.Network result = null;

    try {
      Optional<Network> optResult = networkRepository.findById(id);

      if (!optResult.isPresent())
        throw new NoEntityFoundException(format("no network for id: %s", id.toString()));

      result = new NetworkToNetworkDto().apply(optResult.get());

    } catch (NoEntityFoundException nef) {
      throw nef;
    }

    logger.trace("[getNetworkDto] out", result);
    return result;
  }

  @Transactional(rollbackOn = Exception.class)
  @Override
  public List<com.anthem.specialty.provider.datamodel.dto.NetworkGroup> getNetworkGroups() {
    List<com.anthem.specialty.provider.datamodel.dto.NetworkGroup> ret = new ArrayList<com.anthem.specialty.provider.datamodel.dto.NetworkGroup>();
    Iterable<NetworkGroup> list = networkGroupRepository.findAll();
    for (NetworkGroup ng : list) {
      NetworkGroupImpl nng = new NetworkGroupImpl();
      nng.setId(ng.getId());
      nng.setDescription(ng.getDescription());
      nng.setDataOwner(new DataOwnerToDataOwnerDto().apply(ng.getDataOwner()));
      ret.add(nng);
    }
    return ret;
  }
}
