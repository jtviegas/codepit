package com.anthem.specialty.provider.datalayer.functional;

import static java.lang.String.format;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.RelatedProviderItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedProviderItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class ProviderToRelatedProviderItem implements Function<Provider, RelatedProviderItem> {

  private final LinkResolver linkResolver;

  public ProviderToRelatedProviderItem() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedProviderItem apply(Provider provider) {
    RelatedProviderItem result = null;
    if (null == provider.getFirstName() && null == provider.getMiddleName() && null == provider.getLastName())
      throw new IllegalArgumentException("!!! provider has no name (neither first, middle nor last) !!!");

    String name = format("%s %s %s", null == provider.getFirstName() ? "" : provider.getFirstName(),
        null == provider.getMiddleName() ? "" : provider.getMiddleName(),
        null == provider.getLastName() ? "" : provider.getLastName());
    com.anthem.specialty.provider.datamodel.dto.Link link = linkResolver
        .apply(new String[] { provider.getId().toString() }, LinkResolver.Type.provider, true);

    result = new RelatedProviderItemImpl();
    result.setId(provider.getId());
    result.setLink(link);
    result.setName(name);

    return result;
  }

}
