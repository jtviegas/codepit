package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;

public class MedicaidToProviderMedicaid implements Function<Medicaid, ProviderMedicaid> {

  private final Provider provider;

  public MedicaidToProviderMedicaid(Provider provider) {
    this.provider = provider;
  }

  @Override
  public ProviderMedicaid apply(Medicaid t) {
    ProviderMedicaid o = new ProviderMedicaid();

    o.setProvider(provider);
    o.setDataOwner(provider.getDataOwner());
    o.setMedicaidNo(t.getNumber());
    o.setMedicaidState(t.getState());

    return o;
  }

}
