package com.anthem.specialty.provider.datalayer.functional;

import java.util.Optional;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Link;
import com.anthem.specialty.provider.datamodel.dto.Linkable;
import com.anthem.specialty.provider.datamodel.dto.MultiLinkable;
import com.anthem.specialty.provider.datamodel.dto.SingleLinkable;

public class LinkLocationResolver implements Function<Linkable, Optional<String>> {

  @Override
  public Optional<String> apply(Linkable t) {
    Optional<String> r = null;

    if (t instanceof MultiLinkable)
      r = findLink((MultiLinkable) t);
    else
      r = findLink((SingleLinkable) t);

    return r;
  }

  private Optional<String> findLink(MultiLinkable t) {
    Optional<String> r = null;
    Optional<Link> oLink = t.getLinks().stream().filter(o -> o.getRel().equals(LinkResolver.DEFAULT_REL)).findFirst();
    if (oLink.isPresent())
      r = Optional.of(oLink.get().getHref());
    else
      r = Optional.empty();

    return r;
  }

  private Optional<String> findLink(SingleLinkable o) {
    Optional<String> r = null;
    if (null != o.getLink() && o.getLink().getRel().equals(LinkResolver.DEFAULT_REL))
      r = Optional.of(o.getLink().getHref());
    else
      r = Optional.empty();
    return r;
  }

}
