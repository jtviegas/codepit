package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.dto.NewCarrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;

public class NewCarrierDtoToCarrier implements Function<NewCarrier, Carrier> {

  private final DataOwnerRepository doRep;

  public NewCarrierDtoToCarrier(final DataOwnerRepository doRep) {
    this.doRep = doRep;
  }

  @Override
  public Carrier apply(NewCarrier t) {
    Carrier r = new Carrier();

    r.setClearCarrierNo(t.getClearCarrierNo());
    r.setComments(t.getComments());
    r.setContactName(t.getContactName());
    if (t.getDataOwnerId() == null)
      throw new IllegalArgumentException("Null data owner ID!");
    r.setDataOwner(doRep.findById(t.getDataOwnerId()).get());
    r.setDescription(t.getDescription());
    if (null != t.getEffective()) {
      r.setEffectiveFrom(t.getEffective().getFrom());
      r.setEffectiveTo(t.getEffective().getTo());
    }
    r.setManager(t.getManager());

    return r;
  }

}
