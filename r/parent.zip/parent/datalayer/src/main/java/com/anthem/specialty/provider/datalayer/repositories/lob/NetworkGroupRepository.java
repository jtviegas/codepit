package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;

public interface NetworkGroupRepository extends CrudRepository<NetworkGroup, Long> {
  List<NetworkGroup> findByDescription(String description);
	 
}
