package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.CoreDataEntityImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationshipImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;

public class NetworkClinicToNetworkClinicRelationship implements Function<NetworkClinic, NetworkClinicRelationship> {

  private final LinkResolver linkResolver;

  public NetworkClinicToNetworkClinicRelationship() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public NetworkClinicRelationship apply(NetworkClinic t) {
    NetworkClinicRelationship o = new NetworkClinicRelationshipImpl();

    o.setClinic(new CoreDataEntityImpl(t.getClinic().getId()));
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));

    o.setFrozenFrom(t.getFrozenFrom());
    o.setId(t.getId());
    o.setIsFrozen(t.getIsFrozen().equals('Y'));
    o.setOfficeNumber(t.getOfficeNo());
    o.setLinks(Arrays.asList(
        linkResolver.apply(new String[] { t.getNetwork().getId().toString(), t.getId().toString() },
            LinkResolver.Type.network_clinic, true),
        linkResolver.apply(new String[] { t.getNetwork().getId().toString() }, LinkResolver.Type.network, false),
        linkResolver.apply(new String[] { t.getClinic().getId().toString() }, LinkResolver.Type.clinic, false)));
    return o;
  }

}
