package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.Provider;
import com.anthem.specialty.provider.datamodel.dto.ProviderImpl;

public class NewProviderToProviderDto implements Function<NewProvider, Provider> {

  private final Function<Long, DataOwner> doF;

  public NewProviderToProviderDto(Function<Long, DataOwner> doF) {
    this.doF = doF;
  }

  @Override
  public Provider apply(NewProvider p) {

    Provider o = new ProviderImpl();
    o.setTin(p.getTin());
    o.setStateProviderNo(p.getStateProviderNo());
    o.setNamePrefix(p.getNamePrefix());
    o.setFirstName(p.getFirstName());
    o.setMiddleName(p.getMiddleName());
    o.setLastName(p.getLastName());
    o.setNameSuffix(p.getNameSuffix());
    if (null != p.getGender())
      o.setGender(p.getGender());
    o.setBirthDate(p.getBirthDate());
    o.setSchoolOfDentistry(p.getSchoolOfDentistry());
    o.setGraduationYear(p.getGraduationYear());
    o.setPracticeEffectiveFrom(p.getPracticeEffectiveFrom());
    o.setComments(p.getComments());
    o.setTerminated(p.getTerminated());

    o.setRetired(p.getRetired());
    o.setDeceased(p.getDeceased());
    o.setEffective(p.getEffective());

    o.setMedicareNo(p.getMedicareNo());
    o.setFirstBnotice(p.getFirstBnotice());
    o.setSecondBnotice(p.getSecondBnotice());
    o.setMalpracticeInsurance(p.getMalpracticeInsurance());

    o.setConsentFormSigned(p.getConsentFormSigned());
    o.setConsentSignatureDate(p.getConsentSignatureDate());
    o.setNoDEANumericReason(p.getNoDEANumericReason());
    o.setSpecialtySchool(p.getSpecialtySchool());
    o.setAnesthesiaCertificateExpiry(p.getAnesthesiaCertificateExpiry());
    o.setEmailAddress(p.getEmailAddress());
    o.setCollaborationAgreement(p.getCollaborationAgreement());
    o.setParaLicenseNumber(p.getParaLicenseNumber());
    o.setParaLicenseState(p.getParaLicenseState());
    o.setSpecialtyGradYear(p.getSpecialtyGradYear());
    o.setFWAComplianceDate(p.getFWAComplianceDate());
    o.setDegree1(p.getDegree1());
    o.setDegree2(p.getDegree2());
    o.setDataOwner(doF.apply(p.getDataOwnerId()));

    return o;

  }

}
