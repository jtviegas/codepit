package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.NewProviderImpl;
import com.anthem.specialty.provider.datamodel.dto.Provider;

public class ProviderToNewProvider implements Function<Provider, NewProvider> {

  @Override
  public NewProvider apply(Provider t) {
    NewProvider o = new NewProviderImpl();

    o.setAnesthesiaCertificateExpiry(t.getAnesthesiaCertificateExpiry());
    o.setBirthDate(t.getBirthDate());
    o.setCollaborationAgreement(t.getCollaborationAgreement());
    o.setComments(t.getComments());
    o.setConsentFormSigned(t.getConsentFormSigned());
    o.setConsentSignatureDate(t.getConsentSignatureDate());
    o.setDataOwnerId(t.getDataOwner().getId());
    o.setDeceased(t.getDeceased());
    o.setDegree1(t.getDegree1());
    o.setDegree2(t.getDegree2());
    o.setEffective(t.getEffective());
    o.setEmailAddress(t.getEmailAddress());
    o.setFirstBnotice(t.getFirstBnotice());
    o.setFirstName(t.getFirstName());
    o.setFWAComplianceDate(t.getFWAComplianceDate());
    o.setGender(t.getGender());
    o.setGraduationYear(t.getGraduationYear());
    o.setLastName(t.getLastName());
    o.setMalpracticeInsurance(t.getMalpracticeInsurance());
    o.setMedicareNo(t.getMedicareNo());
    o.setMiddleName(t.getMiddleName());
    o.setNamePrefix(t.getNamePrefix());
    o.setNameSuffix(t.getNameSuffix());
    o.setNoDEANumericReason(t.getNoDEANumericReason());
    o.setParaLicenseNumber(t.getParaLicenseNumber());
    o.setParaLicenseState(t.getParaLicenseState());
    o.setPracticeEffectiveFrom(t.getPracticeEffectiveFrom());
    o.setRetired(t.getRetired());
    o.setSchoolOfDentistry(t.getSchoolOfDentistry());
    o.setSecondBnotice(t.getSecondBnotice());
    o.setSpecialtyGradYear(t.getSpecialtyGradYear());
    o.setSpecialtySchool(t.getSpecialtySchool());
    o.setStateProviderNo(t.getStateProviderNo());
    o.setTerminated(t.getTerminated());
    o.setTin(t.getTin());

    return o;
  }

}
