package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;

public class ProviderLanguageToLanguageStream implements Function<ProviderLanguage, Stream<Language>> {

  private ProviderLanguageToLanguage mapper;

  public ProviderLanguageToLanguageStream() {
    mapper = new ProviderLanguageToLanguage();
  }

  @Override
  public Stream<Language> apply(ProviderLanguage n) {
    return Stream.of(mapper.apply(n));
  }

}
