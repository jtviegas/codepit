package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;

public class NewProviderSpecialtyToProviderSpecialty implements Function<NewProviderSpecialty, ProviderSpecialty> {

  private final Provider provider;

  public NewProviderSpecialtyToProviderSpecialty(Provider p) {
    this.provider = p;
  }

  @Override
  public ProviderSpecialty apply(NewProviderSpecialty p) {

    ProviderSpecialty o = new ProviderSpecialty();

    o.setCertifiedFrom(p.getCertifiedFrom());
    o.setCertifyingBoardId(p.getCertifyingBoardId());
    o.setComments(p.getComments());
    o.setDataOwner(provider.getDataOwner());
    o.setEligibleFrom(p.getEligibleFrom());
    o.setProvider(provider);
    o.setRenewalDate(p.getRenewalDate());
    o.setRenewalPeriod(p.getRenewalPeriod());
    if (null != p.getSpecialtyCode()) {
      Specialty sp = new Specialty(p.getSpecialtyCode().getCode(), p.getSpecialtyCode().getDescription());
      o.setSpecialty(sp);
      o.setSpecialtyType(p.getSpecialtyCode().getType().asChar());
    }

    return o;
  }

}
