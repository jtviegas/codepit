package com.anthem.specialty.provider.datalayer.functional;

import static com.anthem.specialty.provider.datalayer.utils.Validation.yesNo;

import java.util.Optional;
import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EssentialCommunityProvider;
import com.anthem.specialty.provider.datamodel.dto.GeneralInsurance;
import com.anthem.specialty.provider.datamodel.dto.HearingService;
import com.anthem.specialty.provider.datamodel.dto.IntensiveTherapyUnitService;
import com.anthem.specialty.provider.datamodel.dto.NewClinic;
import com.anthem.specialty.provider.datamodel.dto.Patients;
import com.anthem.specialty.provider.datamodel.dto.Services;
import com.anthem.specialty.provider.datamodel.dto.Staffing;
import com.anthem.specialty.provider.datamodel.dto.VisionService;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class NewClinicToClinic implements Function<NewClinic, Clinic> {

  private final DataOwnerRepository repository;

  public NewClinicToClinic(DataOwnerRepository repository) {
    this.repository = repository;
  }

  @Override
  public Clinic apply(NewClinic o) {
    if (null == o)
      throw new IllegalArgumentException("!!! new clinic is null !!!");

    Clinic r = new Clinic();

    r.setStateMedicaidNo(o.getStateMedicaidNo());
    r.setCommonName(o.getCommonName());
    r.setComments(o.getComments());
    r.setContactName(o.getContactName());
    r.setPaymentName(o.getPaymentName());
    r.setUcrRegionCode(o.getUcrRegionCode());
    GeneralInsurance gi = o.getGeneralInsurance();
    if (null != gi) {
      r.setGeneralInsurance('Y');
      r.setGeneralInsuranceCo(gi.getInsurer());
      r.setGeneralInsuranceLimit(gi.getLimit());
      r.setGeneralInsurancePolicy(gi.getPolicy());
      r.setGeneralInsuranceRenewal(gi.getRenewal());
    } else
      r.setGeneralInsurance('N');

    Services s = o.getServices();
    if (null != s) {
      r.setDiagnosticService(s.getDiagnosticService() ? 'Y' : 'N');
      r.setPreventiveService(s.getPreventiveService() ? 'Y' : 'N');
      r.setRestorativeService(s.getRestorativeService() ? 'Y' : 'N');
      r.setPeriodonticService(s.getPeriodonticService() ? 'Y' : 'N');
      r.setPedodonticService(s.getPedodonticService() ? 'Y' : 'N');
      r.setEndodonticService(s.getEndodonticService() ? 'Y' : 'N');
      r.setOrthodonticService(s.getOrthodonticService() ? 'Y' : 'N');
      r.setOralSurgeryService(s.getOralSurgeryService() ? 'Y' : 'N');
      r.setProsthodonticService(s.getProsthodonticService() ? 'Y' : 'N');
      r.setTmjService(s.getTmjService() ? 'Y' : 'N');
      r.setAdultDisabilitySupported(s.getAdultDisabilitySupported() ? 'Y' : 'N');
      r.setChildDisabilitySupported(s.getChildDisabilitySupported() ? 'Y' : 'N');
      r.setDevelopmentallyDisabledSvc(s.getDevelopmentallyDisabledServices() ? 'Y' : 'N');
      HearingService hs = s.getHearing();
      if (null != hs) {
        r.setHearingServices('Y');
        r.setHearingServicesType(hs.getType());
      } else
        r.setHearingServices('N');

      r.setHivServices(s.getHivServices() ? 'Y' : 'N');
      IntensiveTherapyUnitService itus = s.getIntensiveTherapyUnit();
      if (null != itus) {
        r.setItuClinic('Y');
        r.setItuClinicType(itus.getType());
      } else
        r.setItuClinic('N');

      r.setMobilityServices(s.getMobilityServices() ? 'Y' : 'N');
      r.setNursingHomeVisits(s.getNursingHomeVisits() ? 'Y' : 'N');
      r.setSpecialAccommodations(s.getSpecialAccommodations());

      VisionService vs = s.getVision();
      if (null != vs) {
        r.setVisionServices('Y');
        r.setVisionServicesType(vs.getType());
      } else
        r.setVisionServices('N');
    }

    r.setEcsCapable(yesNo(o.getElectronicClaimsSubmissionSupported()));
    Patients ps = o.getPatients();
    if (null != ps) {
      r.setHygienistMonthlyPatients(ps.getHygienistMonthlyPatients());
      r.setAcceptsNewMedicaidPatients(ps.getAcceptsNewMedicaidPatients() ? 'Y' : 'N');
      r.setAcceptsNewPatients(ps.getAcceptsNewPatients() ? 'Y' : 'N');
      r.setMedicaidMonthlyPatients(ps.getMedicaidMonthlyPatients());
      r.setMedicaidPatientsConverted(ps.getMedicaidPatientsConverted() ? 'Y' : 'N');
      r.setNewMedicaidPatientPolicy(ps.getNewMedicaidPatientPolicy());
      r.setProviderMonthlyPatients(ps.getProviderMonthlyPatients());
      r.setAcceptsUnderEighteens(ps.getUnderEighteens() ? 'Y' : 'N');
      r.setAcceptsUnderThrees(ps.getUnderThrees() ? 'Y' : 'N');
    }

    Staffing st = o.getStaffing();
    if (null != st) {
      r.setProviderCount(st.getProviderCount());
      r.setHygienistCount(st.getHygienistCount());
      r.setAssistantCount(st.getAssistantCount());
      r.setSpecialistCount(st.getSpecialistCount());
      r.setAdvancedDentHygienistCount(st.getAdvancedDentalHygienistCount());
      r.setAdvancedDentTherapistCount(st.getAdvancedDentalTherapistCount());
      r.setCollaborativeHygienistCount(st.getCollaborativeHygienistCount());
      r.setDentalTherapistCount(st.getDentalTherapistCount());
    }

    r.setReimburseContinuedEducation(o.getReimburseContinuedEducation() ? 'Y' : 'N');
    EssentialCommunityProvider ecp = o.getEssentialCommunityProvider();
    if (null != ecp) {
      r.setEssentialCommunityProvider('Y');
      r.setEcpType(ecp.getEcpType());
    } else
      r.setEssentialCommunityProvider('N');

    r.setEmergencyInstructions(o.getEmergencyInstructions() ? 'Y' : 'N');
    r.setPracticeManagementSoftware(o.getPracticeManagementSoftware());
    r.setVisitedNursingHomes(o.getVisitedNursingHomes());
    r.setWheelchairAccessible(o.getWheelchairAccessible() ? 'Y' : 'N');

    EffectivePeriod ep = o.getEffective();
    if (null != ep) {
      r.setEffectiveFrom(ep.getFrom());
      r.setEffectiveTo(ep.getTo());
    }

    r.setAlphabeticalSortBy(o.getAlphabeticalSortBy());
    r.setMaRating(o.getMaRating());
    r.setEmailAddress(o.getEmailAddress());
    r.setMemberEmailAddress(o.getMemberEmailAddress());
    r.setWebAddress(o.getWebAddress());

    Optional<DataOwner> oD = repository.findById(o.getDataOwnerId());
    if (oD.isPresent())
      r.setDataOwner(oD.get());

    return r;
  }

}
