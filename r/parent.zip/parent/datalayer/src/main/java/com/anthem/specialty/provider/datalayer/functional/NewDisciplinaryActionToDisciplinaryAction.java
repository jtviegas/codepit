package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class NewDisciplinaryActionToDisciplinaryAction implements Function<NewDisciplinaryAction, DisciplinaryAction> {

  private final Provider provider;

  public NewDisciplinaryActionToDisciplinaryAction(Provider provider) {
    this.provider = provider;
  }

  @Override
  public DisciplinaryAction apply(NewDisciplinaryAction t) {
    DisciplinaryAction o = new DisciplinaryAction();

    o.setProvider(provider);
    o.setComments(t.getComments());
    o.setDataOwner(provider.getDataOwner());
    o.setDescription(t.getDescription());
    o.setOriginatorCode(t.getOriginatorCode());

    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }

    return o;
  }

}
