package com.anthem.specialty.provider.datalayer.functional;

import com.anthem.specialty.provider.datamodel.schemas.core.LargeGroup;
import java.util.function.Function;

public class LargeGroupToLargeGroupDto implements Function<LargeGroup, com.anthem.specialty.provider.datamodel.dto.LargeGroup> {

  @Override
  public com.anthem.specialty.provider.datamodel.dto.LargeGroup apply(LargeGroup t) {
    com.anthem.specialty.provider.datamodel.dto.LargeGroup lgDto = new com.anthem.specialty.provider.datamodel.dto.LargeGroupImpl();
      lgDto.setId(t.getId());
      lgDto.setName(t.getGroupName());
    return lgDto;
  }
}
