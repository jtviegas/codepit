package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface DocumentControlRepository extends CrudRepository<DocumentControl, Long> {
  List<DocumentControl> findBySource(char source);

  List<DocumentControl> findByClinic(Clinic clinic);

  List<DocumentControl> findByProvider(Provider provider);

  List<DocumentControl> findByProviderId(Long providerId);

  List<DocumentControl> findByProviderIdAndClinicId(Long providerId, Long clinicId);

  void deleteByIdAndProviderId(Long docId, Long providerId);

  void deleteByClinicIdAndProviderIdAndDcnId(Long clinicId, Long providerId, Long dcnId);

  List<DocumentControl> findByClinicIdAndProviderIdAndDcnId(Long clinicId, Long providerId, Long dcnId);

  void deleteByProviderIdAndDcnId(Long providerId, Long dcnId);

  void deleteByClinicIdAndDcnId(Long clinicId, Long dcnId);

  List<DocumentControl> findByProviderIdAndDcnId(Long providerId, Long dcnId);

  List<DocumentControl> findByClinicIdAndDcnId(Long clinicId, Long dcnId);
}
