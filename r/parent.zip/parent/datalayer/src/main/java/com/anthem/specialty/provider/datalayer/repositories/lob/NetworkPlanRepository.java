package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPlan;

public interface NetworkPlanRepository extends CrudRepository<NetworkPlan, Long> {

  List<NetworkPlan> findByNetwork(Network network);

}
