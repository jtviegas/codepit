package com.anthem.specialty.provider.datalayer.utils;

public class Validation {

  public static Character yesNo(Boolean any) {
    if (any == null)
      throw new IllegalArgumentException("Boolean cannot be null");
    if (any)
      return 'Y';
    return 'N';
  }
}
