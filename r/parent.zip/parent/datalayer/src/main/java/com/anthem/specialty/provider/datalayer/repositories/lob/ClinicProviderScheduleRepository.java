package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;

public interface ClinicProviderScheduleRepository extends CrudRepository<ClinicProviderSchedule, Long> {
  List<ClinicProviderSchedule> findByClinicProvider(ClinicProvider clinicProvider);
}
