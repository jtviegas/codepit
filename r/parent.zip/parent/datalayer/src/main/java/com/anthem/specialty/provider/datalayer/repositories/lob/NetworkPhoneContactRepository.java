package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPhoneContact;

public interface NetworkPhoneContactRepository extends CrudRepository<NetworkPhoneContact, Long> {

  List<NetworkPhoneContact> findByNetwork(Network network);

}
