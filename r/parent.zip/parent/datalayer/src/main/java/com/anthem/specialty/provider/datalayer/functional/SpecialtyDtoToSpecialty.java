package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;

public class SpecialtyDtoToSpecialty
    implements Function<com.anthem.specialty.provider.datamodel.dto.Specialty, Specialty> {

  @Override
  public Specialty apply(com.anthem.specialty.provider.datamodel.dto.Specialty t) {
    Specialty o = new Specialty();

    o.setCode(t.getCode());
    o.setDescription(t.getDescription());

    return o;
  }

}
