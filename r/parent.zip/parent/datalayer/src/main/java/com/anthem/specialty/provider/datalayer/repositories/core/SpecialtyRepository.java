package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;

public interface SpecialtyRepository extends CrudRepository<Specialty, String> {
  Optional<Specialty> findByDescription(String description);
}
