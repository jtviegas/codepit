package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;

public class NewLanguageToProviderLanguage implements Function<NewLanguage, ProviderLanguage> {

  private final Provider provider;

  public NewLanguageToProviderLanguage(Provider p) {
    this.provider = p;
  }

  @Override
  public ProviderLanguage apply(NewLanguage n) {

    ProviderLanguage o = new ProviderLanguage();
    o.setDataOwner(provider.getDataOwner());
    o.setProvider(provider);
    o.setLanguage(n.getName());

    return o;
  }

}
