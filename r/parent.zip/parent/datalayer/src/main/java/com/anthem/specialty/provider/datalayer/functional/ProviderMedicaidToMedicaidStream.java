package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;

public class ProviderMedicaidToMedicaidStream implements Function<ProviderMedicaid, Stream<Medicaid>> {

  private final ProviderMedicaidToMedicaid mapper;

  public ProviderMedicaidToMedicaidStream() {
    this.mapper = new ProviderMedicaidToMedicaid();
  }

  @Override
  public Stream<Medicaid> apply(ProviderMedicaid t) {
    return Stream.of(mapper.apply(t));
  }

}
