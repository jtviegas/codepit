package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;

public interface DataOwnerRepository extends CrudRepository<DataOwner, Long> {
  List<DataOwner> findByDisplayName(String displayName);
}
