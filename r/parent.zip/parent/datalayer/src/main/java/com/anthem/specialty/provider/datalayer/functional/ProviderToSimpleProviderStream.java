package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.SimpleProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class ProviderToSimpleProviderStream implements Function<Provider, Stream<SimpleProvider>> {

  private ProviderToSimpleProvider mapper;

  public ProviderToSimpleProviderStream() {
    this.mapper = new ProviderToSimpleProvider();
  }

  @Override
  public Stream<SimpleProvider> apply(Provider provider) {
    return Stream.of(mapper.apply(provider));
  }

}
