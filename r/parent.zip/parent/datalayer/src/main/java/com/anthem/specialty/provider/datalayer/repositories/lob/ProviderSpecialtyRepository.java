package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;

public interface ProviderSpecialtyRepository extends CrudRepository<ProviderSpecialty, Long> {
  List<ProviderSpecialty> findByProvider(Provider provider);

  List<ProviderSpecialty> findByProviderId(Long providerId);

  // this method does not throw exception
  // void deleteByProviderIdAndSpecialtyCode(Long providerId, String specialtyCode);
  // so we find first and delete afterwards
  List<ProviderSpecialty> findByProviderIdAndSpecialtyCode(Long providerId, String specialtyCode);

}
