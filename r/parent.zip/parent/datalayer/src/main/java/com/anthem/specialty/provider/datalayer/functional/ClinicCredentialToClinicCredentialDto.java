package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.ClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.ClinicCredentialsImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;

public class ClinicCredentialToClinicCredentialDto implements Function<ClinicCredential, ClinicCredentials> {

  private final LinkResolver linkResolver;

  public ClinicCredentialToClinicCredentialDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public ClinicCredentials apply(ClinicCredential t) {
    ClinicCredentialsImpl o = new ClinicCredentialsImpl();

    o.setcDCAndOSHARulesCompliance(t.getCdcOshaRulesCompliance().equals('Y'));
    o.setCprTrained(t.getCprTrained().equals('Y'));
    o.setCredentialed(t.getCredentialed());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setDeptHealthRulesCompliance(t.getDeptHealthRulesCompliance().equals('Y'));
    o.setEmergencyKit(t.getEmergencyKit().equals('Y'));
    o.setEmergencyTrained(t.getEmergencyTrained().equals('Y'));
    o.setHadicappedParking(t.getHandicappedParking().equals('Y'));
    o.setHandicapAccess(t.getHandicapAccess().equals('Y'));
    o.setId(t.getId());
    o.setPublicTransport(t.getPublicTransport().equals('Y'));
    o.setLinks(Arrays.asList(
        linkResolver.apply(new String[] { t.getClinic().getId().toString(), o.getId().toString() },
            LinkResolver.Type.clinic_credential, true),
        linkResolver.apply(new String[] { t.getClinic().getId().toString() }, LinkResolver.Type.clinic, false)));
    return o;
  }

}
