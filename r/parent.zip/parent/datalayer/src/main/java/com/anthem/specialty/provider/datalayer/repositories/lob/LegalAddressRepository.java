package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.LegalAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public interface LegalAddressRepository extends CrudRepository<LegalAddress, Long> {

  List<LegalAddress> findByState(String state);

  List<LegalAddress> findByW9LegalEntity(W9LegalEntity w9LegalEntity);

  List<LegalAddress> findByW9LegalEntityId(Long w9LegalEntityId);

  List<LegalAddress> findByIdAndW9LegalEntityId(Long id, Long w9LegalEntityId);
}
