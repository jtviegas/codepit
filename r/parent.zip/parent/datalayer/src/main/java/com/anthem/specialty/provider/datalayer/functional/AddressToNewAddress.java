package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Address;
import com.anthem.specialty.provider.datamodel.dto.NewAddress;
import com.anthem.specialty.provider.datamodel.dto.NewAddressImpl;

public class AddressToNewAddress implements Function<Address, NewAddress> {

  @Override
  public NewAddress apply(Address t) {

    NewAddressImpl o = new NewAddressImpl();
    o.setCity(t.getCity());
    o.setCountry(t.getCountry());
    o.setCounty(t.getCounty());
    o.setLatitude(t.getLatitude());
    o.setLine1(t.getLine1());
    o.setLine2(t.getLine2());
    o.setLine3(t.getLine3());
    o.setLongitude(t.getLongitude());
    o.setProvince(t.getProvince());
    o.setState(t.getState());
    o.setType(t.getType());
    o.setZipCode(t.getzIPCode());

    return o;
  }

}
