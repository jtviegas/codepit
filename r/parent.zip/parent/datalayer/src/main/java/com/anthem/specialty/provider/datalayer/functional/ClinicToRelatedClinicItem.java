package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class ClinicToRelatedClinicItem implements Function<Clinic, RelatedClinicItem> {

  private final LinkResolver linkResolver;

  public ClinicToRelatedClinicItem() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedClinicItem apply(Clinic clinic) {
    RelatedClinicItem result = null;
    if (null == clinic)
      throw new IllegalArgumentException("!!! clinic is null !!!");

    com.anthem.specialty.provider.datamodel.dto.Link link = linkResolver
        .apply(new String[] { clinic.getId().toString() }, LinkResolver.Type.clinic, true);

    result = new RelatedClinicItemImpl();
    result.setId(clinic.getId());
    result.setLink(link);
    result.setCommonName(clinic.getCommonName());

    return result;
  }

}
