package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.schemas.core.DocumentType;

public class DocumentTypeDtoToDocumentType
    implements Function<com.anthem.specialty.provider.datamodel.dto.DocumentType, DocumentType> {

  @Override
  public DocumentType apply(com.anthem.specialty.provider.datamodel.dto.DocumentType t) {

    if (null == t)
      throw new IllegalArgumentException("document type can't be null");

    if (null == t.getCode() || null == t.getDescription())
      throw new IllegalArgumentException("document type properties can't be null");

    DocumentType o = new DocumentType();

    o.setCode(t.getCode());
    o.setDescription(t.getDescription());

    return o;
  }

}
