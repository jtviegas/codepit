package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datalayer.repositories.core.TerminationLevelRepository;
import com.anthem.specialty.provider.datalayer.repositories.lob.ProviderRepository;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkProviderTermination;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;

public class NetworkClinicProviderRelationshipToNetworkClinicProvider
    implements BiFunction<NetworkClinic, NetworkClinicProviderRelationship, NetworkClinicProvider> {

  private final ProviderRepository repository;

  private final TerminationLevelRepository tlRepository;

  public NetworkClinicProviderRelationshipToNetworkClinicProvider(final ProviderRepository repository,
      final TerminationLevelRepository tlRepository) {
    this.repository = repository;
    this.tlRepository = tlRepository;
  }

  @Override
  public NetworkClinicProvider apply(NetworkClinic nc, NetworkClinicProviderRelationship t) {
    NetworkClinicProvider o = new NetworkClinicProvider();

    o.setDataOwner(nc.getDataOwner());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setFrozenFrom(t.getFrozenFrom());
    o.setHoldCodeApplied(t.isHoldCodeApplied() ? 'Y' : 'N');
    o.setId(t.getId());
    o.setInDirectory(t.isInDirectory() ? 'Y' : 'N');
    o.setIsFrozen(t.isIsFrozen() ? 'Y' : 'N');
    o.setNetworkClinic(nc);
    o.setOfficeNo(t.getOfficeNumber());
    o.setOverrideExceptions(t.isOverrideExceptions() ? 'Y' : 'N');
    o.setProvider(repository.findById(t.getProvider().getId()).get());
    NetworkProviderTermination npt = null;
    if (null != (npt = t.getTerminated())) {
      o.setTerminated(npt.getFrom());
      o.setTerminationClauseFrom(npt.getClauseActiveFrom());
      o.setTerminationLevel(tlRepository.findById(npt.getTerminationLevelCode()).get());
      o.setTerminationReceipt(npt.getReceived());
    }

    return o;
  }

}
