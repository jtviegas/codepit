package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialtyHospital;

public interface ProviderSpecialtyHospitalRepository extends CrudRepository<ProviderSpecialtyHospital, Long> {
  List<ProviderSpecialtyHospital> findByProvider(Provider provider);
}
