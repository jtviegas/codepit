package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

@Repository
public class ProviderRepositoryCustomImpl implements ProviderRepositoryCustom {

	@PersistenceContext	 
	private EntityManager em;
		
	 
	@Override
	public Optional<Provider> findOneByTin(String tin) {
		
	
		List<Provider> listProviders = em.createQuery("select u from Provider u where u.tin = :tin", Provider.class)
		            .setParameter("tin", tin)
		            .setMaxResults(1)
		            .getResultList();
		if ( listProviders.size() != 0 )
	    {
	          return Optional.of(listProviders.get(0));
		}	
		else
	    {
		  return Optional.empty();
		}
    }
}
