package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewSanction;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSanction;

public class NewSanctionToProviderSanction implements Function<NewSanction, ProviderSanction> {

  private final Provider provider;

  private final Clinic clinic;

  public NewSanctionToProviderSanction(Provider p, Clinic c) {
    this.provider = p;
    this.clinic = c;
  }

  @Override
  public ProviderSanction apply(NewSanction p) {

    ProviderSanction o = new ProviderSanction();

    o.setClinic(clinic);
    o.setProvider(provider);
    o.setDataOwner(provider.getDataOwner());
    if (null != p.getEffective()) {
      o.setEffectiveFrom(p.getEffective().getFrom());
      o.setEffectiveTo(p.getEffective().getTo());
    }
    o.setSanctionAgency(p.getSanctionAgency());
    o.setSanctionCode(p.getSanctionCode());

    return o;
  }

}
