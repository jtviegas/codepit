package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewProviderFocusReviewImpl;

public class ProviderFocusReviewToNewProviderFocusReview implements Function<ProviderFocusReview, NewProviderFocusReview> {

  @Override
  public NewProviderFocusReview apply(ProviderFocusReview t) {
    NewProviderFocusReview o = new NewProviderFocusReviewImpl();

    o.setClinic(t.getClinic());
    o.setNetworkGroup(t.getNetworkGroup());
    o.setAuditNumber(t.getAuditNumber());
    o.setCommenced(t.getCommenced());
    o.setComments(t.getComments());
    o.setProcedureCodes(t.getProcedureCodes());
    o.setLinks(t.getLinks());
    o.setTerminated(t.getTerminated());

    return o;
  }

}
