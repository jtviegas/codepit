package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.dto.NewW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public class NewW9ToW9LegalEntity implements Function<NewW9, W9LegalEntity> {

  private DataOwnerRepository d;

  public NewW9ToW9LegalEntity(DataOwnerRepository d) {
    this.d = d;
  }

  @Override
  public W9LegalEntity apply(NewW9 t) {
    if (t.getDataOwnerId() == null) // to clarify what exactly is missing
      throw new IllegalArgumentException("W9 data owner ID is null");

    W9LegalEntity o = new W9LegalEntity();

    o.setBackupWithholdingTax(t.isBackupWithholdingTax() ? 'Y' : 'N');
    o.setByPhone(t.getByPhone());
    o.setCorporatePayment(t.isCorporatePayment() ? 'Y' : 'N');
    o.setDataOwner(d.findById(t.getDataOwnerId()).get());
    // TODO check this - no delegatedCreditAgreement in NewW9
    o.setDelegatedCreditAgreement(t.isDelegatedCreditAgreement() ? 'Y' : 'N');
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }

    o.setIrsName(t.getIrsName());
    // TODO check this - no largeGroup in NewW9
    // o.setLargeGroup(largeGroup);
    o.setReceived(t.getReceived());
    o.setSubmittedBy(t.getSubmittedBy());
    o.setTaxExempt(t.isTaxExempt() ? 'Y' : 'N');
    o.setTin(t.getTin());
    o.setTinType(t.getType().asChar());

    return o;
  }

}
