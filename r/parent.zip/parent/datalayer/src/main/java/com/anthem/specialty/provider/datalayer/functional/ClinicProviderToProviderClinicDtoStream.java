package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;

public class ClinicProviderToProviderClinicDtoStream implements Function<ClinicProvider, Stream<ProviderClinic>> {

  private ClinicProviderToProviderClinicDto mapper;

  public ClinicProviderToProviderClinicDtoStream() {
    this.mapper = new ClinicProviderToProviderClinicDto();
  }

  @Override
  public Stream<ProviderClinic> apply(ClinicProvider t) {
    return Stream.of(mapper.apply(t));
  }

}
