package com.anthem.specialty.provider.datalayer.functional;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

import org.apache.commons.lang3.math.NumberUtils;

public class QueryParamsToObjectProperties implements Function<Map<String, String>, Map<String, Object>> {

  private static final char decimalSeparator = ((DecimalFormat) DecimalFormat.getInstance(Locale.getDefault()))
      .getDecimalFormatSymbols().getDecimalSeparator();

  @Override
  public Map<String, Object> apply(Map<String, String> o) {
    if (null == o)
      throw new IllegalArgumentException("!!! map is null !!!");

    Map<String, Object> r = new HashMap<String, Object>();

    for (Map.Entry<String, String> e : o.entrySet()) {

      Object v = e.getValue();
      if (NumberUtils.isParsable(e.getValue())) {
        if (-1 < e.getValue().indexOf(decimalSeparator)) {
          v = Double.parseDouble(e.getValue());
        } else {
          v = Integer.parseInt(e.getValue());
        }
      }

      r.put(e.getKey(), v);
    }

    return r;
  }

}
