package com.anthem.specialty.provider.datalayer.functional;

import static java.lang.String.format;

import com.anthem.specialty.provider.datalayer.utils.TriFunction;
import com.anthem.specialty.provider.datamodel.dto.Link;

/**
 * creates a link as a URI path. It may contains several id's to be used in the link format.
 * 
 * @author jviegas
 *
 */
public class LinkResolver implements TriFunction<String[], LinkResolver.Type, Boolean, Link> {

  public enum Type {
    clinic("clinic", "/api/clinics/%s"),
    networkgroup("networkgroup", "/api/networkgroups/%s"),
    provider("provider", "/api/providers/%s"),
    network("network", "/api/networks/%s"),
    carrier("carrier", "/api/carriers/%s"),
    w9("w9", "/api/w9/%s"),
    provider_disciplinaryaction("provider.disciplinaryAction", "/api/providers/%s/disciplinaryActions/%s"),
    provider_document("provider.document", "/api/providers/%s/documents/%s"),
    provider_clinic_document("provider.clinic.document", "/api/providers/%s/clinics/%s/documents/%s"),
    provider_clinic("provider.clinic", "/api/providers/%s/clinics/%s"),
    provider_specialty("provider.specialty", "/api/providers/%s/specialties/%s"),
    provider_license("provider.license", "/api/providers/%s/licenses/%s"),
    clinic_address("clinic.address", "/api/clinics/%s/addresses/%s"),
    clinic_language("clinic.language", "/api/clinics/%s/languages/%s"),
    clinic_w9("clinic.w9", "/api/clinics/%s/w9/%s"),
    clinic_phoneContacts("clinic.phoneContact", "/api/clinics/%s/phoneContacts/%s"),
    clinic_credential("clinic.credential", "/api/clinics/%s/credentials/%s"),
    w9_legalAddress("w9.legalAddress", "/api/w9/%s/legalAddresses/%s"),
    network_clinic("network.clinic", "/api/networks/%s/clinics/%s"),
    provider_focus_review("provider.focusReviews", "/api/providers/%s/focusReviews/%s"),
    clinic_focus_review("clinic.focusReviews", "/api/clinics/%s/focusReviews/%s"),
    network_clinic_provider("network.clinic.provider", "/api/networks/%s/clinics/%s/providers/%s"),
    data_owner("dataowner", "/api/metadata/dataowners/%s"),
    carrier_phoneContacts("carrier.phoneContact", "/api/carriers/%s/phoneContacts/%s"),;

    private final String rel;

    private final String format;

    private Type(String rel, String format) {
      this.rel = rel;
      this.format = format;
    }

    public String getRel() {
      return rel;
    }

    public String getFormat() {
      return format;
    }

  }

  public static final String DEFAULT_REL = "self";

  @Override
  public Link apply(String[] ids, LinkResolver.Type u, Boolean self) {
    return LinkResolver.createLink(ids, u, self);
  }

  public static Link createLink(String[] ids, LinkResolver.Type u, Boolean self) {
    return new com.anthem.specialty.provider.datamodel.dto.LinkImpl(self ? DEFAULT_REL : u.getRel(),
        format(u.getFormat(), (Object[]) ids));
  }
}
