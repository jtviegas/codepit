package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.LanguageImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;

public class ProviderLanguageToLanguage implements Function<ProviderLanguage, Language> {

  public ProviderLanguageToLanguage() {
  }

  @Override
  public Language apply(ProviderLanguage n) {

    LanguageImpl o = new LanguageImpl();
    o.setId(n.getId());
    o.setName(n.getLanguage());

    return o;
  }

}
