package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedW9;
import com.anthem.specialty.provider.datamodel.dto.RelatedW9Impl;
import com.anthem.specialty.provider.datamodel.dto.W9RelatedItem;
import com.anthem.specialty.provider.datamodel.dto.W9RelatedItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;

public class ClinicW9ToRelatedW9 implements Function<ClinicW9, RelatedW9> {

  private final LinkResolver linkResolver;

  public ClinicW9ToRelatedW9() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedW9 apply(ClinicW9 t) {
    RelatedW9 o = new RelatedW9Impl();
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));

    W9RelatedItem w9ri = new W9RelatedItemImpl();
    w9ri.setId(t.getId());
    w9ri.setLink(linkResolver.apply(new String[] { t.getClinic().getId().toString(), t.getId().toString() },
        LinkResolver.Type.clinic_w9, true));
    w9ri.setIrsName(t.getW9LegalEntity().getIrsName());
    w9ri.setTin(t.getW9LegalEntity().getTin());

    o.setW9(w9ri);
    o.setId(t.getId());

    return o;
  }

}
