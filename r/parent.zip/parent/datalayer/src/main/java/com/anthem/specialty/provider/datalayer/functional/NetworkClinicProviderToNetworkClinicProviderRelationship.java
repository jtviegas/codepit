package com.anthem.specialty.provider.datalayer.functional;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.CoreDataEntityImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationshipImpl;
import com.anthem.specialty.provider.datamodel.dto.NetworkProviderTermination;
import com.anthem.specialty.provider.datamodel.dto.NetworkProviderTerminationImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;

public class NetworkClinicProviderToNetworkClinicProviderRelationship
    implements Function<NetworkClinicProvider, NetworkClinicProviderRelationship> {

  private final LinkResolver linkResolver;

  public NetworkClinicProviderToNetworkClinicProviderRelationship() {
    linkResolver = new LinkResolver();
  }

  @Override
  public NetworkClinicProviderRelationship apply(NetworkClinicProvider t) {
    NetworkClinicProviderRelationship o = new NetworkClinicProviderRelationshipImpl();

    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));

    o.setFrozenFrom(t.getFrozenFrom());
    o.setHoldCodeApplied(t.getHoldCodeApplied().equals('Y'));
    o.setId(t.getId());
    o.setInDirectory(t.getInDirectory().equals('Y'));
    o.setIsFrozen(t.getIsFrozen().equals('Y'));

    o.setOfficeNumber(t.getOfficeNo());
    o.setProvider(new CoreDataEntityImpl(t.getProvider().getId()));
    LocalDate terminated = null;
    if (null != (terminated = t.getTerminated())) {
      NetworkProviderTermination npt = new NetworkProviderTerminationImpl();
      npt.setFrom(terminated);
      npt.setClauseActiveFrom(t.getTerminationClauseFrom());
      npt.setReceived(t.getTerminationReceipt());
      npt.setTerminationLevelCode(t.getTerminationLevel().getId());
      o.setTerminated(npt);
    }

    o.setLinks(Arrays.asList(
        linkResolver.apply(
            new String[] { t.getNetworkClinic().getNetwork().getId().toString(),
                t.getNetworkClinic().getId().toString(), t.getId().toString() },
            LinkResolver.Type.network_clinic_provider, true),
        linkResolver.apply(new String[] { t.getNetworkClinic().getNetwork().getId().toString() },
            LinkResolver.Type.network, false),
        linkResolver.apply(new String[] { t.getNetworkClinic().getClinic().getId().toString() },
            LinkResolver.Type.clinic, false),
        linkResolver.apply(new String[] { t.getProvider().getId().toString() }, LinkResolver.Type.provider, false)));

    o.setOverrideExceptions(t.getOverrideExceptions().equals('Y'));

    return o;
  }

}
