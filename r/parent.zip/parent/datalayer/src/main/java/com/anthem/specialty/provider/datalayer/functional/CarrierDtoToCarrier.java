package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;

public class CarrierDtoToCarrier implements Function<com.anthem.specialty.provider.datamodel.dto.Carrier, Carrier> {

  private final DataOwnerRepository repository;

  public CarrierDtoToCarrier(final DataOwnerRepository repository) {
    this.repository = repository;
  }

  @Override
  public Carrier apply(com.anthem.specialty.provider.datamodel.dto.Carrier t) {
    Carrier r = new Carrier();

    r.setClearCarrierNo(t.getClearCarrierNo());
    r.setComments(t.getComments());
    r.setContactName(t.getContactName());

    r.setDataOwner(repository.findById(t.getDataOwner().getId()).get());
    r.setDescription(t.getDescription());
    if (null != t.getEffective()) {
      r.setEffectiveFrom(t.getEffective().getFrom());
      r.setEffectiveTo(t.getEffective().getTo());
    }
    r.setManager(t.getManager());

    r.setId(t.getId());

    return r;
  }

}
