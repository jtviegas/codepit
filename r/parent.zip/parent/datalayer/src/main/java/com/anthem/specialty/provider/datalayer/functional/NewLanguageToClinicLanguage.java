package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.dto.NewLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;

public class NewLanguageToClinicLanguage implements BiFunction<Clinic, NewLanguage, ClinicLanguage> {

  @Override
  public ClinicLanguage apply(Clinic t, NewLanguage u) {
    ClinicLanguage o = new ClinicLanguage();

    o.setClinic(t);
    o.setDataOwner(t.getDataOwner());
    o.setLanguage(u.getName());

    return o;
  }

}
