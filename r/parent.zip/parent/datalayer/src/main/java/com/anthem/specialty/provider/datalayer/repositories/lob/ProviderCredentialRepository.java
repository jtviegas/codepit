package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;

public interface ProviderCredentialRepository extends CrudRepository<ProviderCredential, Long> {
  List<ProviderCredential> findByProvider(Provider provider);

  List<ProviderCredential> findByProviderId(Long providerId);

}
