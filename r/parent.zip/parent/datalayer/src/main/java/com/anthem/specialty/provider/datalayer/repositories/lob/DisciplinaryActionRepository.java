package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface DisciplinaryActionRepository extends CrudRepository<DisciplinaryAction, Long> {
  List<DisciplinaryAction> findByProvider(Provider provider);

  List<DisciplinaryAction> findByProviderId(Long providerId);

  Optional<DisciplinaryAction> findByIdAndProviderId(Long id, Long providerId);

  void deleteByIdAndProviderId(Long id, Long providerId);
}
