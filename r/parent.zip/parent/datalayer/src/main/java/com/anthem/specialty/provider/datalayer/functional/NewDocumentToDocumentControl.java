package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewDocument;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class NewDocumentToDocumentControl implements Function<NewDocument, DocumentControl> {

  private final Provider provider;

  private final Clinic clinic;

  public NewDocumentToDocumentControl(Provider provider, Clinic clinic) {
    this.provider = provider;
    this.clinic = clinic;
  }

  @Override
  public DocumentControl apply(NewDocument t) {
    DocumentControl o = new DocumentControl();

    DataOwner dO = null;
    // just to note that clinic might not be present
    if (null != clinic) {
      o.setClinic(clinic);
      dO = clinic.getDataOwner();
    }

    // just to note that provider might not be present
    if (provider != null) {
      o.setProvider(provider);
      if (null == dO)
        dO = provider.getDataOwner();
    }

    o.setDataOwner(dO);
    o.setDcnId(t.getControlNumber());
    o.setDescription(new DocumentTypeDtoToDocumentType().apply(t.getType()));
    o.setSource(t.getSource());

    return o;
  }

}
