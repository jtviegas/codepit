package com.anthem.specialty.provider.datalayer.repositories.core;




import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.NetworkId;

public interface NetworkIdRepository extends CrudRepository<NetworkId, Long> {

	 List<NetworkId> findBySchemaName(String schemaName);
}
