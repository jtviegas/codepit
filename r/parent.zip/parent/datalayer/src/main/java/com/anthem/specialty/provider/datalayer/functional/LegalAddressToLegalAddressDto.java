package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.LegalAddress;

public class LegalAddressToLegalAddressDto
    implements Function<LegalAddress, com.anthem.specialty.provider.datamodel.dto.LegalAddress> {

  private final LinkResolver linkResolver;

  public LegalAddressToLegalAddressDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.LegalAddress apply(LegalAddress t) {
    com.anthem.specialty.provider.datamodel.dto.LegalAddress o = new com.anthem.specialty.provider.datamodel.dto.LegalAddressImpl();

    o.setCity(t.getCity());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setId(t.getId());
    o.setLine1(t.getAddress1());
    o.setLine2(t.getAddress2());
    o.setLine3(t.getAddress3());
    o.setState(t.getState());
    o.setZipCode(t.getZip());

    o.setLinks(
        Arrays.asList(linkResolver.apply(new String[] { t.getW9LegalEntity().getId().toString(), t.getId().toString() },
            LinkResolver.Type.w9_legalAddress, true)));

    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));

    return o;
  }

}
