package com.anthem.specialty.provider.datalayer.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import com.anthem.specialty.provider.datalayer.functional.LargeGroupToLargeGroupDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.repositories.core.BusinessSegmentRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.DentalProcedureRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.DocumentTypeRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.LanguageRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.LargeGroupRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.ProviderRelationshipRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.SpecialtyRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.TenantRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.TerminationLevelRepository;
import com.anthem.specialty.provider.datamodel.schemas.core.BusinessSegment;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.DentalProcedure;
import com.anthem.specialty.provider.datamodel.schemas.core.DocumentType;
import com.anthem.specialty.provider.datamodel.schemas.core.Language;
import com.anthem.specialty.provider.datamodel.schemas.core.LargeGroup;
import com.anthem.specialty.provider.datamodel.schemas.core.LineOfBusiness;
import com.anthem.specialty.provider.datamodel.schemas.core.ProviderRelationship;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;

public class MetadataServiceImpl implements MetadataService {

  private final static Logger logger = LoggerFactory.getLogger(MetadataServiceImpl.class);

  @Autowired
  private DataOwnerRepository dataOwnerRepository;

  @Autowired
  private TenantRepository tenantRepository;

  @Autowired
  private TerminationLevelRepository terminationLevelRepository;

  @Autowired
  private SpecialtyRepository specialtyRepository;

  @Autowired
  private LargeGroupRepository largeGroupRepository;

  @Autowired
  private BusinessSegmentRepository businessSegmentRepository;

  @Autowired
  private DocumentTypeRepository documentTypeRepository;

  @Autowired
  private ProviderRelationshipRepository providerRelationshipRepository;

  @Autowired
  private DentalProcedureRepository dentalProcedureRepository;

  @Autowired
  private LanguageRepository languageRepository;

  @Override
  public DataOwner getDataOwner(Long id) throws NoEntityFoundException {
    logger.trace("[getDataOwner] in", id);
    Optional<DataOwner> o = dataOwnerRepository.findById(id);
    DataOwner r = o.isPresent() ? o.get() : null;
    if (r == null)
      throw new NoEntityFoundException("No data owner " + id);
    logger.trace("[getDataOwner] out", r);
    return r;
  }

  @Override
  public List<DataOwner> getDataOwners() {
    logger.trace("[getDataOwners] in");
    List<DataOwner> o = StreamSupport.stream(dataOwnerRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getDataOwners] out", o);
    return o;
  }

  @Override
  public LineOfBusiness getTenant(Long id) throws NoEntityFoundException {
    logger.trace("[getTenant] in", id);
    Optional<LineOfBusiness> o = tenantRepository.findById(id);
    LineOfBusiness r = o.isPresent() ? o.get() : null;
    if (r == null)
      throw new NoEntityFoundException("No tenant " + id);
    logger.trace("[getTenant] out", r);
    return r;
  }

  @Override
  public List<LineOfBusiness> getTenants() {
    logger.trace("[getTenants] in");
    List<LineOfBusiness> o = StreamSupport.stream(tenantRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getTenants] out", o);
    return o;
  }

  @Override
  public TerminationLevel getTerminationLevel(Long id) {
    logger.trace("[getTerminationLevel] in", id);
    Optional<TerminationLevel> o = terminationLevelRepository.findById(id);
    TerminationLevel r = o.isPresent() ? o.get() : null;
    logger.trace("[getTerminationLevel] out", r);
    return r;
  }

  @Override
  public List<TerminationLevel> getTerminationLevels() {
    logger.trace("[getTerminationLevels] in");
    List<TerminationLevel> o = StreamSupport.stream(terminationLevelRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getTerminationLevels] out", o);
    return o;
  }

  @Override
  public Specialty getSpecialty(String code) {
    logger.trace("[getSpecialty] in", code);
    Optional<Specialty> o = specialtyRepository.findById(code);
    Specialty result = o.isPresent() ? o.get() : null;
    logger.trace("[getSpecialty] out", result);
    return result;
  }

  @Override
  public List<Specialty> getSpecialties() {
    logger.trace("[getSpecialties] in");
    List<Specialty> o = StreamSupport.stream(specialtyRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getSpecialties] out", o);
    return o;
  }

  @Override
  public LargeGroup getLargeGroup(Long id) throws NoEntityFoundException {
    logger.trace("[getLargeGroup] in", id);
    Optional<LargeGroup> o = largeGroupRepository.findById(id);
    if (!o.isPresent())
      throw new NoEntityFoundException("No large group " + id);
    logger.trace("[getLargeGroup] out", o.get());
    return o.get();
  }

  @Override
  public List<LargeGroup> getLargeGroups() {
    logger.trace("[getLargeGroups] in");
    List<LargeGroup> o
        = StreamSupport.stream(largeGroupRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getLargeGroups] out", o);
    return o;
  }

  @Override
  public List<com.anthem.specialty.provider.datamodel.dto.LargeGroup> getLargeGroupDtos() {
    logger.trace("[getLargeGroupDtos] in");
    List<com.anthem.specialty.provider.datamodel.dto.LargeGroup> o
        = StreamSupport.stream(largeGroupRepository.findAll().spliterator(), false)
        .map(new LargeGroupToLargeGroupDto())
        .collect(Collectors.toList());
    logger.trace("[getLargeGroupDtos] out", o);
    return o;
  }

  @Override
  public BusinessSegment getBusinessSegment(Long id) {
    logger.trace("[getBusinessSegment] in", id);
    Optional<BusinessSegment> o = businessSegmentRepository.findById(id);
    BusinessSegment r = o.isPresent() ? o.get() : null;
    logger.trace("[getBusinessSegment] out", r);
    return r;
  }

  @Override
  public List<BusinessSegment> getBusinessSegments() {
    logger.trace("[getBusinessSegments] in");
    List<BusinessSegment> o = StreamSupport.stream(businessSegmentRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getBusinessSegments] out", o);
    return o;
  }

  @Override
  public DocumentType getDocumentType(String code) {
    logger.trace("[getDocumentType] in", code);
    Optional<DocumentType> o = documentTypeRepository.findById(code);
    DocumentType r = o.isPresent() ? o.get() : null;
    logger.trace("[getDocumentType] out", r);
    return r;
  }

  @Override
  public List<DocumentType> getDocumentTypes() {
    logger.trace("[getDocumentTypes] in");
    List<DocumentType> o = StreamSupport.stream(documentTypeRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getDocumentTypes] out", o);
    return o;
  }

  @Override
  public ProviderRelationship getProviderRelationship(String code) {
    logger.trace("[getProviderRelationship] in", code);
    Optional<ProviderRelationship> o = providerRelationshipRepository.findById(code);
    ProviderRelationship r = o.isPresent() ? o.get() : null;
    logger.trace("[getProviderRelationship] out", r);
    return r;
  }

  @Override
  public List<ProviderRelationship> getProviderRelationships() {
    logger.trace("[getProviderRelationships] in");
    List<ProviderRelationship> o = StreamSupport.stream(providerRelationshipRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getProviderRelationships] out", o);
    return o;
  }

  @Override
  public List<DentalProcedure> getDentalProcedures() {
    logger.trace("[getDentalProcedures] in");
    List<DentalProcedure> o = StreamSupport.stream(dentalProcedureRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getDentalProcedures] out", o);
    return o;
  }

  @Override
  public List<Language> getLanguages() {
    logger.trace("[getLanguages] in");
    List<Language> o = StreamSupport.stream(languageRepository.findAll().spliterator(), false)
        .collect(Collectors.toList());
    logger.trace("[getLanguages] out", o);
    return o;
  }

}
