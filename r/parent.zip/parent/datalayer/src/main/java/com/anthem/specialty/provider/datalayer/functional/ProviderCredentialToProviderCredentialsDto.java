package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.ProviderCredentialsImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;

public class ProviderCredentialToProviderCredentialsDto
    implements Function<ProviderCredential, ProviderCredentialsImpl> {

  private final LinkResolver linkResolver;

  public ProviderCredentialToProviderCredentialsDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public ProviderCredentialsImpl apply(ProviderCredential p) {

    ProviderCredentialsImpl o = new ProviderCredentialsImpl();

    o.setCredentialed(p.getCredentialed());
    o.setCredentialingLevel(p.getCredentialingLevel());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(p.getDataOwner()));
    o.setDeaRestricted(p.getDeaRestricted().equals('Y'));
    o.setDeaRestrictedComments(p.getDeaRestrictedComments());
    o.setDisciplinaryAction(p.getDisciplinaryAction().equals('Y'));
    o.setDisciplinaryActionComments(p.getDisciplinaryActionComments());
    o.setFelonyMisdemeanor(p.getFelonyMisdemeanor().equals('Y'));
    o.setFelonyMisdemeanorComments(p.getFelonyMisdemeanorComments());
    o.setHealthProblem(p.getHealthProblem().equals('Y'));
    o.setHealthProblemComments(p.getHealthProblemComments());
    o.setLicenseSuspended(p.getLicenseSuspended());
    o.setLicenseSuspendedComments(p.getLicenseSuspendedComments());
    o.setMalpracticeExper(p.getMalpracticeExper().equals('Y'));
    o.setMalpracticeExperComments(p.getMalpracticeExperComments());
    o.setId(p.getId());
    o.setLinks(Arrays.asList(
        linkResolver.apply(new String[] { p.getProvider().getId().toString() }, LinkResolver.Type.provider, false)));

    return o;
  }

}
