package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.SpecialtyClassification;
import com.anthem.specialty.provider.datamodel.dto.SpecialtyTypeImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;

public class ProviderSpecialtyToProviderSpecialtyDto
    implements Function<ProviderSpecialty, com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty> {

  private final LinkResolver linkResolver;

  public ProviderSpecialtyToProviderSpecialtyDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty apply(ProviderSpecialty p) {

    com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty o = new com.anthem.specialty.provider.datamodel.dto.ProviderSpecialtyImpl();

    o.setCertifiedFrom(p.getCertifiedFrom());
    o.setCertifyingBoardId(p.getCertifyingBoardId());
    o.setComments(p.getComments());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(p.getDataOwner()));
    o.setEligibleFrom(p.getEligibleFrom());
    o.setRenewalDate(p.getRenewalDate());
    List<com.anthem.specialty.provider.datamodel.dto.Link> links = new ArrayList<com.anthem.specialty.provider.datamodel.dto.Link>();
    links.add(
        linkResolver.apply(new String[] { p.getProvider().getId().toString() }, LinkResolver.Type.provider, false));
    o.setLinks(links);

    if (null != p.getSpecialty()) {
      SpecialtyTypeImpl st = new SpecialtyTypeImpl();
      st.setCode(p.getSpecialty().getCode());
      st.setDescription(p.getSpecialty().getDescription());
      if (null != p.getSpecialtyType())
        st.setType(SpecialtyClassification.fromChar(p.getSpecialtyType()));

      links.add(linkResolver.apply(new String[] { p.getProvider().getId().toString(), p.getSpecialty().getCode() },
          LinkResolver.Type.provider_specialty, false));
      o.setSpecialtyCode(st);
    }

    o.setId(p.getId());

    return o;
  }

}
