package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public interface ClinicRepository extends PagingAndSortingRepository<Clinic, Long>, QueryByExampleExecutor<Clinic> {

  List<Clinic> findByStateMedicaidNo(String stateMedicaidNo);

  List<Clinic> findByCommonName(String name);

  Stream<Clinic> findByOrderByIdDesc(Pageable pageable);

  @Query(value = "SELECT c.* FROM CLINIC_ADDRESS ca INNER JOIN clinic c on c.id = ca.clinic_id INNER JOIN clinic_phone_contact cpc ON ca.clinic_id = cpc.clinic_id WHERE ca.type = 'D' AND cpc.type = 'P' AND ( ( ca.ADDRESS1 = ?1 ) or ( UTL_MATCH.edit_distance_similarity(ca.ADDRESS1, ?1)>75 and cpc.DISPLAY = ?2) ) and ( ca.DATA_OWNER_ID = ?3 )", nativeQuery = true)
  List<Clinic> findMatch(String addressLine1, String phoneDisplay, Long dataOwnerId);
}
