package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;

public interface ProviderLicenseRepository extends CrudRepository<ProviderLicense, Long> {

  List<ProviderLicense> findByProvider(Provider provider);

  List<ProviderLicense> findByProviderId(Long providerId);

  Optional<ProviderLicense> findByProviderIdAndLicenseNo(Long providerId, String licenseNo);

  void deleteByProviderIdAndLicenseNo(Long providerId, String licenseNo);

  void deleteByLicenseNo(String licenseNo);

}
