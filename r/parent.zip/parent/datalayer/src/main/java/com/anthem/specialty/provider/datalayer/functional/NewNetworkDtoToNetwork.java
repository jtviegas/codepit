package com.anthem.specialty.provider.datalayer.functional;

import static com.anthem.specialty.provider.datalayer.utils.Validation.yesNo;

import java.util.function.Function;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.dto.NewNetwork;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;

public class NewNetworkDtoToNetwork implements Function<NewNetwork, Network> {

  private DataOwnerRepository doRepository;

  public NewNetworkDtoToNetwork(DataOwnerRepository doRep) {
    doRepository = doRep;
  }

  @Override
  public Network apply(NewNetwork t) {
    Network o = new Network();

    o.setCapitationPayment(yesNo(t.isCapitationPayment()));
    o.setComments(t.getComments());
    o.setCustomerServiceDisplayed(t.isCustomerServiceDisplayed() ? 'Y' : 'N');
    o.setDataOwner(doRepository.findById(t.getDataOwnerId()).get());
    o.setDescription(t.getDescription());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setManager(t.getManager());
    o.setShortDescription(t.getShortDescription());

    return o;
  }

}
