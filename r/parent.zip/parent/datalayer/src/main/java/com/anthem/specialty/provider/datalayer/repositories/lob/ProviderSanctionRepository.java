package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSanction;

public interface ProviderSanctionRepository extends CrudRepository<ProviderSanction, Long> {
  List<ProviderSanction> findByClinic(Clinic clinic);

  List<ProviderSanction> findByProvider(Provider provider);

  List<ProviderSanction> findByProviderId(Long providerId);
}
