package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.PhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;

public class PhoneContactToClinicPhoneContact implements Function<PhoneContact, ClinicPhoneContact> {

  private final Clinic clinic;

  public PhoneContactToClinicPhoneContact(Clinic c) {
    this.clinic = c;
  }

  @Override
  public ClinicPhoneContact apply(PhoneContact u) {
    ClinicPhoneContact o = new ClinicPhoneContact();

    o.setAccessCode(u.getAccessCode());
    o.setAreaCode(u.getAreaCode());
    o.setCityCode(u.getCityCode());
    o.setClinic(this.clinic);
    o.setCountryCode(u.getCountryCode());
    o.setDataOwner(this.clinic.getDataOwner());
    o.setExtension(u.getExtension());
    o.setNumber(u.getNumber());
    o.setType(u.getType().asChar());
    o.setId(u.getId());

    return o;
  }

}
