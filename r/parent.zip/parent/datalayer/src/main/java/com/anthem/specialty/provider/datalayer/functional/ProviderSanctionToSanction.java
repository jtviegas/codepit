package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.Sanction;
import com.anthem.specialty.provider.datamodel.dto.SanctionImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSanction;

public class ProviderSanctionToSanction implements Function<ProviderSanction, Sanction> {

  private final LinkResolver linkResolver;

  public ProviderSanctionToSanction() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public Sanction apply(ProviderSanction p) {

    Sanction o = new SanctionImpl();

    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(p.getDataOwner()));
    if (null != p.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(p.getEffectiveFrom());
      ep.setTo(p.getEffectiveTo());
      o.setEffective(ep);
    }
    o.setId(p.getId());
    List<com.anthem.specialty.provider.datamodel.dto.Link> links = new ArrayList<com.anthem.specialty.provider.datamodel.dto.Link>();
    links.add(
        linkResolver.apply(new String[] { p.getProvider().getId().toString() }, LinkResolver.Type.provider, false));
    o.setLinks(links);
    if (null != p.getClinic()) {
      o.setClinic(new ClinicToRelatedClinic().apply(p.getClinic()));
      links.add(linkResolver.apply(new String[] { p.getClinic().getId().toString() }, LinkResolver.Type.clinic, false));
    }
    o.setSanctionAgency(p.getSanctionAgency());
    o.setSanctionCode(p.getSanctionCode());

    return o;
  }

}
