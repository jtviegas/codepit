package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.OpeningHours;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class ProviderClinicDtoToClinicProvider implements Function<ProviderClinic, ClinicProvider> {

  private final Clinic clinic;

  private final Provider provider;

  public ProviderClinicDtoToClinicProvider(Clinic clinic, Provider provider) {
    this.clinic = clinic;
    this.provider = provider;
  }

  @Override
  public ClinicProvider apply(ProviderClinic t) {

    ClinicProvider o = new ClinicProvider();

    if (null != t.getBci()) {
      o.setBciAccountBilled(t.getBci().getBilled());
      o.setBciTransactionId(t.getBci().getId());
    }
    o.setClinic(this.clinic);
    o.setProvider(this.provider);

    o.setClearLicenseNumber(t.isClearLicenseNumber() ? 'Y' : 'N');
    o.setComments(t.getComments());
    o.setCorporatePayment(t.isCorporatePayment() ? 'Y' : 'N');
    o.setDataOwner(clinic.getDataOwner());
    o.setDeltaPrecertified(t.isDeltaPrecertified() ? 'Y' : 'N');
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }

    for (OpeningHours oh : t.getHours())
      o.addClinicProviderSchedule(
          new ClinicProviderSchedule(oh.getDayOfWeek(), oh.getFrom(), oh.getTo(), clinic.getDataOwner()));

    o.setId(t.getId());
    o.setPayClinicProvider(t.getPayClinicProvider());
    o.setProfessionalReviewUnderway(t.isProfessionalReviewUnderway() ? 'Y' : 'N');
    o.setProviderClaimInReview(t.isProviderClaimInReview() ? 'Y' : 'N');
    o.setProviderCob(t.isProviderCob() ? 'Y' : 'N');
    o.setProviderRelationship(t.getProviderRelationship());
    o.setProviderSpecialistClinic(t.isProviderSpecialistClinic() ? 'Y' : 'N');
    o.setWitholdPayments(t.isWitholdPayments() ? 'Y' : 'N');

    return o;
  }

}
