package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.Optional;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public interface ClinicRepositoryCustom {
	//List<ClinicProvider> getProviders(Clinic clinic);
	Optional<Clinic> findOneByStateMedicaidNo(String stateMedicaidNo);
	
}
