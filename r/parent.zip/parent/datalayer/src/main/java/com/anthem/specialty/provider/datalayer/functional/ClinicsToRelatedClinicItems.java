package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;

public class ClinicsToRelatedClinicItems implements Function<Clinic, Stream<RelatedClinicItem>> {

  private final LinkResolver linkResolver;

  public ClinicsToRelatedClinicItems() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public Stream<RelatedClinicItem> apply(Clinic clinic) {
    RelatedClinicItem result = null;
    if (null == clinic)
      throw new IllegalArgumentException("!!! clinic is null !!!");

    com.anthem.specialty.provider.datamodel.dto.Link link = linkResolver
        .apply(new String[] { clinic.getId().toString() }, LinkResolver.Type.clinic, true);

    result = new RelatedClinicItemImpl();
    result.setId(clinic.getId());
    result.setLink(link);
    result.setCommonName(clinic.getCommonName());

    return Stream.of(result);
  }

}
