package com.anthem.specialty.provider.datalayer.services;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.anthem.specialty.provider.datalayer.exceptions.DataConstraintException;
import com.anthem.specialty.provider.datalayer.exceptions.DataIntegrityException;
import com.anthem.specialty.provider.datalayer.exceptions.DataLayerException;
import com.anthem.specialty.provider.datalayer.exceptions.DataValidationException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.dto.Address;
import com.anthem.specialty.provider.datamodel.dto.AddressType;
import com.anthem.specialty.provider.datamodel.dto.ClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.ClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.ClinicMatch;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrier;
import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.License;
import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewAddress;
import com.anthem.specialty.provider.datamodel.dto.NewCarrier;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierEffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewClinic;
import com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.NewClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewClinicProvider;
import com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.NewDocument;
import com.anthem.specialty.provider.datamodel.dto.NewLanguage;
import com.anthem.specialty.provider.datamodel.dto.NewLegalAddress;
import com.anthem.specialty.provider.datamodel.dto.NewLicense;
import com.anthem.specialty.provider.datamodel.dto.NewNetwork;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.NewProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.NewProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.NewProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty;
import com.anthem.specialty.provider.datamodel.dto.NewSanction;
import com.anthem.specialty.provider.datamodel.dto.NewW9;
import com.anthem.specialty.provider.datamodel.dto.NewW9EffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.PhoneContact;
import com.anthem.specialty.provider.datamodel.dto.PhoneContactType;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.ProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.RelatedProvider;
import com.anthem.specialty.provider.datamodel.dto.RelatedW9;
import com.anthem.specialty.provider.datamodel.dto.Sanction;
import com.anthem.specialty.provider.datamodel.dto.SimpleClinic;
import com.anthem.specialty.provider.datamodel.dto.SimpleProvider;
import com.anthem.specialty.provider.datamodel.dto.W9;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElement;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderVerificationElement;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicOpeningHours;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;
import com.anthem.specialty.provider.datamodel.schemas.lob.LegalAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPlan;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSanction;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialtyHospital;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public interface LobService {

  List<SimpleProvider> getRelatedProviders();

  Page<SimpleProvider> getSimpleProviders(String firstName, String lastName, int start, int size);

  Provider setProvider(Provider provider);

  com.anthem.specialty.provider.datamodel.dto.Provider patchProvider(Long providerId, Map<String, Object> changes)
      throws DataConstraintException, DataValidationException, DataLayerException;

  com.anthem.specialty.provider.datamodel.dto.Provider getProvider(Long id) throws NoEntityFoundException;

  Provider getProvider(Long id, boolean eagerLoad);

  void deleteProvider(Long id) throws NoEntityFoundException;

  ProviderMedicaid setProviderMedicaid(ProviderMedicaid pma);

  ProviderMedicaid getProviderMedicaid(Long id);

  List<ProviderMedicaid> getProviderMedicaidsByProvider(Provider provider);

  List<ProviderCredential> getProviderCredentialsByProvider(Provider provider);

  List<ProviderLicense> getProviderLicensesByProvider(Provider provider);

  List<DisciplinaryAction> getDisciplinaryActionsByProvider(Provider provider);

  List<ProviderLanguage> getProviderLanguagesByProvider(Provider provider);

  List<ProviderSpecialty> getProviderSpecialtiesByProvider(Provider provider);

  List<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty> getProviderSpecialtiesByProvider(Long providerId)
      throws NoEntityFoundException;

  List<ProviderSpecialtyHospital> getProviderSpecialtyHospitalsByProvider(Provider provider);

  W9LegalEntity setW9LegalEntity(W9LegalEntity o);

  W9LegalEntity getW9LegalEntity(Long id) throws NoEntityFoundException;

  void deleteW9LegalEntity(Long id) throws NoEntityFoundException;

  List<LegalAddress> getLegalAddressesByW9LegalEntity(W9LegalEntity w9LegalEntity);

  Network setNetwork(Network o);

  Network getNetwork(Long id) throws NoEntityFoundException;

  void deleteNetwork(Long id) throws NoEntityFoundException;

  List<NetworkPhoneContact> getNetworkPhoneContactsByNetwork(Network o);

  List<NetworkPlan> getNetworkPlansByNetwork(Network o);

  Carrier setCarrier(Carrier o);

  Carrier getCarrier(Long id) throws NoEntityFoundException;

  void deleteCarrier(Long id) throws NoEntityFoundException;

  List<CarrierPhoneContact> getCarrierPhoneContactsByCarrier(Carrier o);

  List<NetworkCarrier> getNetworkCarriersByCarrier(Carrier o);

  List<NetworkCarrier> getNetworkCarriersByNetwork(Network o);

  Clinic setClinic(Clinic o);

  void deleteClinic(Long id) throws NoEntityFoundException;

  List<ClinicAddress> getClinicAddressesByClinic(Clinic o);

  List<ClinicPhoneContact> getClinicPhoneContactsByClinic(Clinic o);

  List<ClinicOpeningHours> getClinicOpeningHoursByClinic(Clinic o);

  List<ClinicCredential> getClinicCredentialsByClinic(Clinic o);

  List<ClinicLanguage> getClinicLanguagesByClinic(Clinic o);

  ProviderSanction setProviderSanction(ProviderSanction o);

  ProviderSanction getProviderSanction(Long id);

  void deleteProviderSanction(Long id) throws NoEntityFoundException;

  List<ProviderSanction> getProviderSanctionsByClinic(Clinic o);

  List<ProviderSanction> getProviderSanctionsByProvider(Provider o);

  DocumentControl setDocumentControl(DocumentControl o);

  DocumentControl getDocumentControl(Long id);

  void deleteDocumentControl(Long id) throws NoEntityFoundException;

  List<DocumentControl> getDocumentControlsByClinic(Clinic o);

  List<DocumentControl> getDocumentControlsByProvider(Provider o);

  NetworkCarrier setNetworkCarrier(NetworkCarrier o);

  NetworkCarrier getNetworkCarrier(Long id);

  void deleteNetworkCarrier(Long id) throws NoEntityFoundException;

  NetworkGroup setNetworkGroup(NetworkGroup o);

  NetworkGroup getNetworkGroup(Long id) throws NoEntityFoundException;

  void deleteNetworkGroup(Long id) throws NoEntityFoundException;

  ClinicProvider setClinicProvider(ClinicProvider o);

  ClinicProvider getClinicProvider(Long id);

  void deleteClinicProvider(Long id) throws NoEntityFoundException;

  List<ClinicProvider> getClinicProvidersByClinic(Clinic o);

  List<ClinicProvider> getClinicProvidersByProvider(Provider o);

  List<ClinicProviderSchedule> getClinicProviderSchedulesByClinicProvider(ClinicProvider o);

  ClinicW9 setClinicW9(ClinicW9 o);

  ClinicW9 getClinicW9(Long id);

  void deleteClinicW9(Long id) throws NoEntityFoundException;

  List<ClinicW9> getClinicW9sByClinic(Clinic o);

  List<ClinicW9> getClinicW9sByW9LegalEntity(W9LegalEntity o);

  NetworkClinic setNetworkClinic(NetworkClinic o);

  NetworkClinic getNetworkClinic(Long id) throws NoEntityFoundException;

  void deleteNetworkClinic(Long id) throws NoEntityFoundException;

  List<NetworkClinic> getNetworkClinicsByClinic(Clinic o);

  List<NetworkClinic> getNetworkClinicsByNetwork(Network o);

  NetworkClinicProvider setNetworkClinicProvider(NetworkClinicProvider o);

  NetworkClinicProvider getNetworkClinicProvider(Long id) throws NoEntityFoundException;

  void deleteNetworkClinicProvider(Long id) throws NoEntityFoundException;

  List<NetworkClinicProvider> getNetworkClinicProvidersByNetworkClinic(NetworkClinic o);

  List<NetworkClinicProvider> getNetworkClinicProvidersByProvider(Provider o);

  FocusReview setFocusReview(FocusReview o);

  FocusReview getFocusReview(Long id);

  void deleteFocusReview(Long id) throws NoEntityFoundException;

  List<FocusReview> getFocusReviewsByNetworkGroup(NetworkGroup o);

  List<FocusReview> getFocusReviewsByProvider(Provider o);

  List<FocusReview> getFocusReviewsByClinic(Clinic o);

  List<ProviderClinic> getClinicsByProvider(Long providerId) throws NoEntityFoundException;

  Clinic getClinic(Long id, boolean eagerLoad);

  com.anthem.specialty.provider.datamodel.dto.Clinic patchClinic(Long clinicId, Map<String, Object> changes)
      throws DataLayerException;

  ClinicProvider patchClinicProvider(Long providerId, Long clinicProviderId, Map<String, Object> properties)
      throws DataLayerException;

  List<Document> getClinicProviderDocuments(Long clinicProviderId) throws NoEntityFoundException;

  Document createClinicProviderDocument(NewDocument o, Long clinicProviderId) throws DataLayerException;

  void deleteClinicProviderDocument(Long clinicProviderId, Long dcnId) throws NoEntityFoundException;

  Set<RelatedNetwork> getProviderRelatedNetworks(Long providerId) throws NoEntityFoundException;

  List<Sanction> getProviderSanctionsByProvider(Long providerId) throws NoEntityFoundException;

  Sanction createProviderSanction(Long providerId, NewSanction newSanction) throws DataLayerException;

  Provider setProvider(NewProvider provider);

  ProviderCredentials createProviderCredential(Long providerId, NewProviderCredentials n) throws DataLayerException;

  List<ProviderCredentials> getProviderCredentialsByProvider(Long providerId) throws NoEntityFoundException;

  ProviderSpecialty createProviderSpecialty(Long providerId, NewProviderSpecialty n) throws DataLayerException;

  void deleteProviderSpecialty(Long providerId, String specialtyCode) throws NoEntityFoundException;

  List<Language> getLanguagesByProvider(Long providerId) throws NoEntityFoundException;

  Language createProviderLanguage(Long providerId, NewLanguage n) throws DataLayerException;

  void deleteProviderLanguage(Long providerId, Long languageId) throws NoEntityFoundException;

  List<Document> getDocumentControlsByProvider(Long providerId) throws NoEntityFoundException;

  void deleteProviderDocument(Long providerId, Long docId) throws NoEntityFoundException;

  List<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction> getDisciplinaryActionsByProvider(Long providerId)
      throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction patchDisciplinaryAction(Long providerId,
      Long disciplinaryActionId, Map<String, Object> changes)
      throws DataValidationException, IllegalArgumentException, NoEntityFoundException;

  void deleteDisciplinaryAction(Long providerId, Long disciplinaryActionId) throws NoEntityFoundException;

  List<License> getLicensesByProvider(Long providerId) throws NoEntityFoundException;

  License createProviderLicense(Long providerId, NewLicense n);

  License patchProviderLicense(Long providerId, String licenseNumber, Map<String, Object> changes)
      throws IllegalArgumentException, DataValidationException, NoEntityFoundException;

  void deleteProviderLicense(Long providerId, String licenseNumber) throws NoEntityFoundException;

  List<Medicaid> getMedicaidsByProvider(Long providerId) throws NoEntityFoundException;

  Medicaid createProviderMedicaid(Long providerId, Medicaid n) throws DataLayerException;

  void deleteProviderMedicaid(Long providerId, String medicaidNumber) throws NoEntityFoundException;

  /* ProviderMedicaid putProviderMedicaid(Long providerId, String medicaidNumber, ProviderMedicaid o); */

  List<ClinicFocusReview> getClinicFocusReviewsByClinicId(Long providerId) throws NoEntityFoundException;

  void deleteProviderFocusReview(Long providerId, Long id) throws NoEntityFoundException;

  ProviderClinic createProviderClinic(Long providerId, NewProviderClinic o) throws DataLayerException;

  ProviderClinic patchProviderClinic(Long providerId, Long providerClinicId, Map<String, Object> changes)
      throws DataLayerException;

  SimpleProvider createNewProvider(NewProvider p);

  ProviderMedicaid putProviderMedicaid(Long providerId, String medicaidNumber, Medicaid o)
      throws NoEntityFoundException;

  Provider findProvider(Long id) throws NoEntityFoundException;

  NetworkGroup findNetworkGroup(Long id) throws NoEntityFoundException;

  Clinic findClinic(Long id) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.ClinicProvider createClinicProvider(NewClinicProvider o, Long clinicId)
      throws NoEntityFoundException;

  SimpleClinic getSimpleClinic(Long id);

  com.anthem.specialty.provider.datamodel.dto.Clinic setClinicAndGetDto(NewClinic o);

  List<SimpleClinic> getClinics(int start, int size);

  com.anthem.specialty.provider.datamodel.dto.Clinic getClinicDto(Long id);

  List<ProviderVerificationElement> getProviderDirectoryAccuracyByLargeGroup(Long largeGroupId);

  List<ProviderVerificationElement> getProviderDirectoryAccuracyByNetwork(Long networkId);

  List<ClinicVerificationElement> getClinicsDirectoryAccuracyByLargeGroup(Long largeGroupId);

  /* List<ClinicVerificationElement> getClinicsDirectoryAccuracyByNetwork(Long networkId); */

  List<SimpleClinic> getClinics(Map<String, String> queryParams, int start, int size);

  List<Address> getAddressesFromClinic(Long clinicId) throws NoEntityFoundException;

  Address getClinicAddress(Long addressId) throws NoEntityFoundException;

  Address postClinicAddress(Long clinicId, NewAddress address) throws DataLayerException;

  Address putClinicAddress(Long clinicId, NewAddress address)
      throws DataConstraintException, DataValidationException, NoEntityFoundException, DataLayerException;

  boolean hasAddress(Long clinicId, AddressType type) throws NoEntityFoundException;

  void deleteClinicAddress(Long clinicId, Long addressId) throws NoEntityFoundException;

  Address patchClinicAddress(Long clinicId, Long addressId, Map<String, Object> changes)
      throws DataConstraintException, DataValidationException, NoEntityFoundException, DataLayerException;

  void deleteClinicW9(Long clinicId, Long id) throws NoEntityFoundException;

  List<RelatedW9> getW9sFromClinic(Long id) throws NoEntityFoundException;

  RelatedW9 postClinicW9(Long clinicId, NewW9EffectiveRelationship o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException;

  W9 setNewW9AndGetDto(NewW9 o);

  W9 getW9(Long id) throws NoEntityFoundException;

  void deleteW9(Long id) throws NoEntityFoundException;

  W9 patchW9(Long id, Map<String, Object> changes) throws DataValidationException, NoEntityFoundException;

  List<W9> getW9s(int start, int size);

  PhoneContact patchClinicPhoneContact(Long clinicId, Long id, Map<String, Object> changes) throws DataLayerException;

  void deleteClinicFocusReview(Long clinicId, Long id) throws NoEntityFoundException;

  ClinicFocusReview patchClinicFocusReview(Long clinicId, Long id, Map<String, Object> properties)
      throws DataLayerException;

  void deleteClinicLanguage(Long clinicId, Long id) throws NoEntityFoundException;

  void deleteClinicPhoneContact(Long clinicId, Long id) throws NoEntityFoundException;

  ClinicCredentials postClinicClinicCredentials(Long clinicId, NewClinicCredentials o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException;

  Language postClinicLanguage(Long clinicId, NewLanguage o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException;

  List<Language> getLanguagesFromClinic(Long id) throws NoEntityFoundException;

  List<ClinicCredentials> getCredentialsFromClinic(Long id) throws NoEntityFoundException;

  List<PhoneContact> getPhoneContactsFromClinic(Long id) throws NoEntityFoundException;

  PhoneContact postClinicPhoneContact(Long clinicId, NewPhoneContact o)
      throws NoEntityFoundException, DataIntegrityException, DataValidationException;

  void deleteW9LegalAddress(Long legalAddressId) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.LegalAddress getW9LegalAddress(Long id) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.LegalAddress putW9LegalAddress(Long w9id,
      com.anthem.specialty.provider.datamodel.dto.LegalAddress o) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.LegalAddress postW9LegalAddress(Long w9id, NewLegalAddress address)
      throws NoEntityFoundException, DataIntegrityException;

  List<com.anthem.specialty.provider.datamodel.dto.LegalAddress> getW9LegalAddresses(Long id)
      throws NoEntityFoundException;

  List<CollectionRelatedCarrier> getNetworkCarriers(Long networkId) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction createProviderDisciplinaryAction(Long providerId,
      NewDisciplinaryAction n) throws DataLayerException;

  Document createProviderDocument(Long providerId, NewDocument n) throws DataLayerException;

  com.anthem.specialty.provider.datamodel.dto.Network setNewNetwork(NewNetwork o);

  com.anthem.specialty.provider.datamodel.dto.Network setNetworkDto(
      com.anthem.specialty.provider.datamodel.dto.Network o);

  List<RelatedNetwork> getNetworks(int start, int size);

  com.anthem.specialty.provider.datamodel.dto.Network patchNetwork(Long id, Map<String, Object> changes)
      throws NoEntityFoundException, DataLayerException;

  com.anthem.specialty.provider.datamodel.dto.Network getNetworkDto(Long id)
      throws NoEntityFoundException, DataLayerException;

  List<RelatedProvider> getNetworkProviders(Long networkId) throws NoEntityFoundException;

  CollectionRelatedCarrier getNetworkCarrier(Long networkId, Long networkCarrierId) throws NoEntityFoundException;

  CollectionRelatedCarrier postNetworkCarrier(Long networkId, NewCarrierEffectiveRelationship o)
      throws NoEntityFoundException, DataValidationException;

  CollectionRelatedCarrier patchNetworkCarrier(Long networkId, Long networkCarrierId, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException;

  List<RelatedClinic> getNetworkClinicsByNetworkId(Long id) throws NoEntityFoundException;

  NetworkClinicRelationship postNetworkClinic(Long networkId, NewNetworkClinicRelationship o)
      throws NoEntityFoundException, DataValidationException;

  NetworkClinicRelationship patchNetworkClinic(Long networkId, Long networkClinicId, Map<String, Object> changes)
      throws DataLayerException;

  NetworkClinicRelationship getNetworkClinic(Long networkId, Long networkClinicId) throws NoEntityFoundException;

  List<RelatedProvider> getRelatedProvidersByNetworkClinicId(Long nwClinicId) throws NoEntityFoundException;

  NetworkClinicProviderRelationship postNetworkClinicProvider(Long networkClinicId,
      NewNetworkClinicProviderRelationship o) throws NoEntityFoundException, DataValidationException;

  NetworkClinicProviderRelationship patchNetworkClinicProvider(Long networkClinicProviderId,
      Map<String, Object> changes) throws DataLayerException;

  NetworkClinicProviderRelationship getNetworkClinicProviderDto(Long id) throws NoEntityFoundException;

  Page<com.anthem.specialty.provider.datamodel.dto.Carrier> getCarriers(int start, int size);

  com.anthem.specialty.provider.datamodel.dto.Carrier setNewCarrier(NewCarrier o) throws DataLayerException;

  void deleteCarriers(List<Long> ids) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.Carrier patchCarrier(Long id, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException;

  List<RelatedNetwork> getNetworksByCarrier(Long carrierId) throws NoEntityFoundException;

  List<com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact> getPhoneContactsFromCarrier(Long id)
      throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact postCarrierPhoneContact(Long carrierId,
      NewCarrierPhoneContact o)
      throws NoEntityFoundException, DataValidationException, DataConstraintException, DataLayerException;

  void deleteCarrierPhoneContact(Long id) throws NoEntityFoundException;

  com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact patchCarrierPhoneContact(Long carrierId,
      Long carrierPhoneContactId, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException;

  List<SimpleClinic> doClinicMatch(ClinicMatch o);

  ClinicCredentials patchClinicCredential(Long clinicId, Long id, Map<String, Object> changes)
      throws DataValidationException, NoEntityFoundException, DataLayerException;

  boolean hasClinicPhoneContact(Long clinicId, PhoneContactType type) throws NoEntityFoundException;

  PhoneContact putClinicPhoneContact(Long clinicId, NewPhoneContact o) throws DataLayerException;

  ClinicFocusReview postClinicFocusReview(Long clinicId, NewClinicFocusReview o)
      throws NoEntityFoundException, DataIntegrityException;

  List<ProviderFocusReview> getProviderFocusReviewsByProviderId(Long id) throws NoEntityFoundException;

  ProviderFocusReview postProviderFocusReview(Long providerId, NewProviderFocusReview o)
      throws NoEntityFoundException, DataIntegrityException;

  ProviderFocusReview patchProviderFocusReview(Long clinicId, Long id, Map<String, Object> changes)
      throws DataLayerException;

  List<com.anthem.specialty.provider.datamodel.dto.NetworkGroup> getNetworkGroups();

}