package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface ProviderRepository extends CrudRepository<Provider, Long>, QueryByExampleExecutor<Provider> {

  List<Provider> findByTin(String tin);

  List<Provider> findByLastName(String lastName);

  List<Provider> findByFirstName(String firstName);

  List<Provider> findByFirstNameAndLastName(String firstName, String lastName);

  List<Provider> findByLastNameAndEffectiveFromNotNull(String lastName);

  List<Provider> findByFirstNameAndEffectiveFromNotNull(String firstName);

  List<Provider> findByFirstNameAndLastNameAndEffectiveFromNotNull(String firstName, String lastName);

  Page<Provider> findByOrderByEffectiveFromDesc(Pageable pageable);

  Page<Provider> findByFirstNameAndEffectiveFromNotNull(String firstName, Pageable pageable);

  Page<Provider> findByLastNameAndEffectiveFromNotNull(String lastName, Pageable pageable);

  Page<Provider> findByFirstNameAndLastNameAndEffectiveFromNotNull(String firstName, String lastName,
      Pageable pageable);

}
