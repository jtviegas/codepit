package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;

public interface NetworkClinicRepository extends CrudRepository<NetworkClinic, Long> {
  List<NetworkClinic> findByOfficeNo(String officeNo);

  List<NetworkClinic> findByNetwork(Network network);

  Stream<NetworkClinic> findByNetworkId(Long nwId);

  Optional<NetworkClinic> findByIdAndNetworkId(Long id, Long networkId);

  List<NetworkClinic> findByNetworkIdAndClinicId(Long networkId, Long clinicId);

  List<NetworkClinic> findByClinic(Clinic clinic);

  void deleteByIdAndNetworkId(Long networkClinicId, Long networkId);
}
