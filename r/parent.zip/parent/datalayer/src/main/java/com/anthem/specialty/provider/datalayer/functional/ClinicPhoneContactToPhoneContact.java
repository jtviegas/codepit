package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.PhoneContact;
import com.anthem.specialty.provider.datamodel.dto.PhoneContactImpl;
import com.anthem.specialty.provider.datamodel.dto.PhoneContactType;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;

public class ClinicPhoneContactToPhoneContact implements Function<ClinicPhoneContact, PhoneContact> {

  private final LinkResolver linkResolver;

  public ClinicPhoneContactToPhoneContact() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public PhoneContact apply(ClinicPhoneContact t) {
    PhoneContact o = new PhoneContactImpl();

    o.setAccessCode(t.getAccessCode());
    o.setAreaCode(t.getAreaCode());
    o.setCityCode(t.getCityCode());
    o.setCountryCode(t.getCountryCode());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setExtension(t.getExtension());
    o.setId(t.getId());
    o.setNumber(t.getNumber());
    o.setType(PhoneContactType.fromChar(t.getType()));
    o.setDisplay(t.getDisplay());

    o.setLinks(Arrays.asList(linkResolver.apply(new String[] { t.getClinic().getId().toString(), o.getId().toString() },
        LinkResolver.Type.clinic_phoneContacts, true)));

    return o;
  }

}
