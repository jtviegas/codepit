package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContactType;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;

public class CarrierPhoneContactToCarrierPhoneContactDto
    implements Function<CarrierPhoneContact, com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact> {

  private final LinkResolver linkResolver;

  public CarrierPhoneContactToCarrierPhoneContactDto() {
    linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact apply(CarrierPhoneContact t) {
    com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact o = new com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContactImpl();

    o.setAccessCode(t.getAccessCode());
    o.setAreaCode(t.getAreaCode());
    o.setCityCode(t.getCityCode());
    o.setCountryCode(t.getCountryCode());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setExtension(t.getExtension());
    o.setId(t.getId());
    o.setNumber(t.getNumber());
    o.setType(CarrierPhoneContactType.fromChar(t.getType()));

    o.setLinks(Arrays.asList(
        linkResolver.apply(new String[] { t.getCarrier().getId().toString() }, LinkResolver.Type.carrier, true),
        linkResolver.apply(new String[] { t.getCarrier().getId().toString(), t.getId().toString() },
            LinkResolver.Type.carrier_phoneContacts, true)));

    return o;
  }

}
