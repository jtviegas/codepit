package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.Gender;
import com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance;
import com.anthem.specialty.provider.datamodel.dto.MalpracticeInsuranceImpl;
import com.anthem.specialty.provider.datamodel.dto.ProviderTermination;
import com.anthem.specialty.provider.datamodel.dto.ProviderTerminationImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class ProviderToProviderDto
    implements Function<Provider, com.anthem.specialty.provider.datamodel.dto.Provider> {

  private final LinkResolver linkResolver;

  public ProviderToProviderDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Provider apply(Provider p) {
    com.anthem.specialty.provider.datamodel.dto.Provider o = new com.anthem.specialty.provider.datamodel.dto.ProviderImpl();

    o.setTin(p.getTin());
    o.setStateProviderNo(p.getStateProviderNo());
    o.setNamePrefix(p.getNamePrefix());
    o.setFirstName(p.getFirstName());
    o.setMiddleName(p.getMiddleName());
    o.setLastName(p.getLastName());
    o.setNameSuffix(p.getNameSuffix());
    o.setGender(Gender.fromChar(p.getGender()));
    o.setBirthDate(p.getBirthDate());
    o.setSchoolOfDentistry(p.getSchoolOfDentistry());
    o.setGraduationYear(p.getGraduationYear());
    o.setPracticeEffectiveFrom(p.getPracticeEffectiveFrom());
    o.setComments(p.getComments());
    if (null != p.getTerminated()) {
      ProviderTermination t = new ProviderTerminationImpl();
      t.setFrom(p.getTerminated());
      if (null != p.getTerminationLevel())
        t.setTerminationLevelCode(p.getTerminationLevel().getId());
      o.setTerminated(t);
    }
    o.setRetired(p.getRetired());
    o.setDeceased(p.getDeceased());

    if (null != p.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(p.getEffectiveFrom());
      if (null != p.getEffectiveTo())
        ep.setTo(p.getEffectiveTo());

      o.setEffective(ep);
    }
    o.setMedicareNo(p.getMedicareNo());
    o.setFirstBnotice(p.getFirstBnotice());
    o.setSecondBnotice(p.getSecondBnotice());
    if ('Y' == p.getMalpracticeInsurance()) {
      MalpracticeInsurance mi = new MalpracticeInsuranceImpl();
      mi.setInsuredLimit(p.getMalpracticeInsuranceLimit());
      mi.setInsurer(p.getMalpracticeInsuranceCompany());
      mi.setPolicyNo(p.getMalpracticePolicyNo());
      mi.setRenewal(p.getMalpracticeInsuranceRenewal());
      o.setMalpracticeInsurance(mi);
    }
    o.setConsentFormSigned(p.getConsentFormSignedAsBoolean());
    o.setConsentSignatureDate(p.getConsentSignatureDate());
    o.setNoDEANumericReason(p.getNoDEANumericReasonAsString());
    o.setSpecialtySchool(p.getSpecialtySchool());
    o.setAnesthesiaCertificateExpiry(p.getAnesthesiaCertificateExpiry());
    o.setEmailAddress(p.getEmailAddress());
    o.setCollaborationAgreement(p.getCollaborationAgreementAsBoolean());
    o.setParaLicenseNumber(p.getParaLicenseNumber());
    o.setParaLicenseState(p.getParaLicenseState());
    o.setSpecialtyGradYear(p.getSpecialtyGradYear());
    o.setFWAComplianceDate(p.getFWAComplianceDate());
    o.setDegree1(p.getDegree1());
    o.setDegree2(p.getDegree2());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(p.getDataOwner()));
    o.setLinks(
        Arrays.asList(linkResolver.apply(new String[] { p.getId().toString() }, LinkResolver.Type.provider, true)));
    o.setId(p.getId());

    return o;
  }

}
