package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;

public class DisciplinaryActionToDisciplinaryActionDto
    implements Function<DisciplinaryAction, com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction> {

  private final LinkResolver linkResolver;

  public DisciplinaryActionToDisciplinaryActionDto() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction apply(DisciplinaryAction p) {
    com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction o = new com.anthem.specialty.provider.datamodel.dto.DisciplinaryActionImpl();

    o.setComments(p.getComments());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(p.getDataOwner()));
    o.setDescription(p.getDescription());
    if (null != p.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(p.getEffectiveFrom());
      if (null != p.getEffectiveTo())
        ep.setTo(p.getEffectiveTo());

      o.setEffective(ep);
    }
    o.setId(p.getId());
    o.setLinks(
        Arrays.asList(linkResolver.apply(new String[] { p.getProvider().getId().toString(), p.getId().toString() },
            LinkResolver.Type.provider_disciplinaryaction, true)));
    o.setOriginatorCode(p.getOriginatorCode());

    return o;
  }

}
