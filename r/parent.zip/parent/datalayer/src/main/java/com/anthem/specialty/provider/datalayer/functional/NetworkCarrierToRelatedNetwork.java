package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetworkImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetworkItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetworkItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;

public class NetworkCarrierToRelatedNetwork implements Function<NetworkCarrier, RelatedNetwork> {

  private final LinkResolver linkResolver;

  public NetworkCarrierToRelatedNetwork() {
    linkResolver = new LinkResolver();
  }

  @Override
  public RelatedNetwork apply(NetworkCarrier t) {
    RelatedNetwork o = new RelatedNetworkImpl();

    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));
    o.setId(t.getId());
    RelatedNetworkItem i = new RelatedNetworkItemImpl();
    o.setNetwork(i);
    i.setId(t.getCarrier().getId());
    i.setName(t.getCarrier().getContactName());

    i.setLink(linkResolver.apply(new String[] { t.getCarrier().getId().toString() }, LinkResolver.Type.carrier, true));

    return o;
  }

}
