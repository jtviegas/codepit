package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;

public interface ClinicCredentialRepository extends CrudRepository<ClinicCredential, Long> {
  List<ClinicCredential> findByDataOwner(DataOwner dataOwner);

  List<ClinicCredential> findByClinic(Clinic clinic);

  List<ClinicCredential> findByClinicId(Long id);
}
