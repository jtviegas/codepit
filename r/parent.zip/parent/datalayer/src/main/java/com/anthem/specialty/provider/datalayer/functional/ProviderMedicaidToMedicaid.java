package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.dto.MedicaidImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;

public class ProviderMedicaidToMedicaid implements Function<ProviderMedicaid, Medicaid> {

  @Override
  public Medicaid apply(ProviderMedicaid t) {
    Medicaid o = new MedicaidImpl();
    o.setNumber(t.getMedicaidNo());
    o.setState(t.getMedicaidState());

    return o;
  }

}
