package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewProviderCredentials;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;

public class NewProviderCredentialToProviderCredential implements Function<NewProviderCredentials, ProviderCredential> {

  private final Provider provider;

  public NewProviderCredentialToProviderCredential(Provider p) {
    this.provider = p;
  }

  @Override
  public ProviderCredential apply(NewProviderCredentials p) {

    ProviderCredential o = new ProviderCredential();

    o.setCredentialed(p.getCredentialed());
    o.setCredentialingLevel(p.getCredentialingLevel());
    o.setDataOwner(provider.getDataOwner());
    o.setDeaRestricted(p.getDeaRestricted() ? 'Y' : 'N');
    o.setDeaRestrictedComments(p.getDeaRestrictedComments());
    o.setDisciplinaryAction(p.getDisciplinaryAction() ? 'Y' : 'N');
    o.setDisciplinaryActionComments(p.getDisciplinaryActionComments());
    o.setFelonyMisdemeanor(p.getFelonyMisdemeanor() ? 'Y' : 'N');
    o.setFelonyMisdemeanorComments(p.getFelonyMisdemeanorComments());
    o.setHealthProblem(p.getHealthProblem() ? 'Y' : 'N');
    o.setHealthProblemComments(p.getHealthProblemComments());
    o.setLicenseSuspended(p.getLicenseSuspended() ? 'Y' : 'N');
    o.setLicenseSuspendedComments(p.getLicenseSuspendedComments());
    o.setMalpracticeExper(p.getMalpracticeExper() ? 'Y' : 'N');
    o.setMalpracticeExperComments(p.getMalpracticeExperComments());
    o.setProvider(provider);

    return o;
  }

}
