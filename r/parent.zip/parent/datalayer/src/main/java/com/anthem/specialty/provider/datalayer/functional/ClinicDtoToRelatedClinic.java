package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Clinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicImpl;

public class ClinicDtoToRelatedClinic implements Function<Clinic, RelatedClinic> {

  @Override
  public RelatedClinic apply(Clinic clinic) {
    RelatedClinicImpl r = new RelatedClinicImpl();
    if (null == clinic)
      throw new IllegalArgumentException("!!! clinic is null !!!");

    r.setClinic(new ClinicDtoToRelatedClinicItem().apply(clinic));
    r.setDataOwner(clinic.getDataOwner());
    r.setEffective(clinic.getEffective());
    r.setId(clinic.getId());

    return r;
  }

}
