package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.TinType;
import com.anthem.specialty.provider.datamodel.dto.W9;
import com.anthem.specialty.provider.datamodel.dto.W9Impl;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public class W9LegalEntityToW9 implements Function<W9LegalEntity, W9> {

  private final LinkResolver linkResolver;


  public W9LegalEntityToW9() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public W9 apply(W9LegalEntity t) {
    W9 o = new W9Impl();

    o.setBackupWithholdingTax(t.getBackupWithholdingTax().equals('Y'));
    o.setByPhone(t.getByPhone());
    o.setCorporatePayment(t.getCorporatePayment().equals('Y'));
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));
    o.setId(t.getId());
    o.setIrsName(t.getIrsName());
    o.setReceived(t.getReceived());
    o.setSubmittedBy(t.getSubmittedBy());
    o.setTaxExempt(t.getTaxExempt().equals('Y'));
    o.setTin(t.getTin());
    o.setType(TinType.fromChar(t.getTinType()));
    o.setDelegatedCreditAgreement(t.getDelegatedCreditAgreement().equals('Y'));
    o.setLinks(Arrays.asList(linkResolver.apply(new String[] { t.getId().toString() }, LinkResolver.Type.w9, true)));

    return o;
  }

}
