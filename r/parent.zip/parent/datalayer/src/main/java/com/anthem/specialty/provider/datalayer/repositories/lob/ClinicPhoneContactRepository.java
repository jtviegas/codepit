package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;

public interface ClinicPhoneContactRepository extends CrudRepository<ClinicPhoneContact, Long> {
  List<ClinicPhoneContact> findByClinic(Clinic clinic);

  List<ClinicPhoneContact> findByClinicId(Long id);

  Optional<ClinicPhoneContact> findByIdAndClinicId(Long id, Long clinicId);

  Optional<ClinicPhoneContact> findByClinicIdAndType(Long clinicId, Character type);
}
