package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;

public class SpecialtyToSpecialtyDto
    implements Function<Specialty, com.anthem.specialty.provider.datamodel.dto.Specialty> {

  @Override
  public com.anthem.specialty.provider.datamodel.dto.Specialty apply(Specialty t) {
    com.anthem.specialty.provider.datamodel.dto.Specialty o = new com.anthem.specialty.provider.datamodel.dto.SpecialtyImpl();

    o.setCode(t.getCode());
    o.setDescription(t.getDescription());

    return o;
  }

}
