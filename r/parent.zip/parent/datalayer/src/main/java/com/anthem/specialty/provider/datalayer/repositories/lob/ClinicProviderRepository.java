package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public interface ClinicProviderRepository extends CrudRepository<ClinicProvider, Long> {

  List<ClinicProvider> findByDataOwner(DataOwner dataOwner);

  List<ClinicProvider> findByClearLicenseNumber(char clearLicenseNumber);

  List<ClinicProvider> findAll();

  List<ClinicProvider> findByProvider(Provider provider);

  List<ClinicProvider> findByClinic(Clinic clinic);

  Optional<ClinicProvider> findByIdAndProviderId(Long id, Long providerId);

  Optional<ClinicProvider> findByClinicIdAndProviderId(Long clinicId, Long providerId);
}
