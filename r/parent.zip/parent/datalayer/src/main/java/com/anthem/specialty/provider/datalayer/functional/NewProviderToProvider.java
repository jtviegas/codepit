package com.anthem.specialty.provider.datalayer.functional;

import static com.anthem.specialty.provider.datalayer.utils.Validation.yesNo;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class NewProviderToProvider implements Function<NewProvider, Provider> {

  private final Function<Long, TerminationLevel> tlF;

  private final Function<Long, DataOwner> doF;

  public NewProviderToProvider(Function<Long, TerminationLevel> tlF, Function<Long, DataOwner> doF) {
    this.tlF = tlF;
    this.doF = doF;
  }

  @Override
  public Provider apply(NewProvider p) {

    Provider o = new Provider();
    o.setTin(p.getTin());
    o.setStateProviderNo(p.getStateProviderNo());
    o.setNamePrefix(p.getNamePrefix());
    o.setFirstName(p.getFirstName());
    o.setMiddleName(p.getMiddleName());
    o.setLastName(p.getLastName());
    o.setNameSuffix(p.getNameSuffix());
    if (null != p.getGender())
      o.setGender(p.getGender().toChar());
    o.setBirthDate(p.getBirthDate());
    o.setSchoolOfDentistry(p.getSchoolOfDentistry());
    o.setGraduationYear(p.getGraduationYear());
    o.setPracticeEffectiveFrom(p.getPracticeEffectiveFrom());
    o.setComments(p.getComments());
    if (null != p.getTerminated()) {
      o.setTerminated(p.getTerminated().getFrom());
      o.setTerminationLevel(tlF.apply(p.getTerminated().getTerminationLevelCode()));
    }

    o.setRetired(p.getRetired());
    o.setDeceased(p.getDeceased());
    if (null != p.getEffective()) {
      o.setEffectiveFrom(p.getEffective().getFrom());
      o.setEffectiveTo(p.getEffective().getTo());
    }
    o.setMedicareNo(p.getMedicareNo());
    o.setFirstBnotice(p.getFirstBnotice());
    o.setSecondBnotice(p.getSecondBnotice());
    if (null != p.getMalpracticeInsurance()) {
      o.setMalpracticeInsurance('Y');
      o.setMalpracticeInsuranceCompany(p.getMalpracticeInsurance().getInsurer());
      o.setMalpracticeInsuranceLimit(p.getMalpracticeInsurance().getInsuredLimit());
      o.setMalpracticeInsuranceRenewal(p.getMalpracticeInsurance().getRenewal());
      o.setMalpracticePolicyNo(p.getMalpracticeInsurance().getPolicyNo());
    } else
      o.setMalpracticeInsurance('N');

    o.setConsentFormSigned(yesNo(p.getConsentFormSigned()));
    o.setConsentSignatureDate(p.getConsentSignatureDate());
    if (null != p.getNoDEANumericReason() && !p.getNoDEANumericReason().isEmpty())
      o.setNoDEANumericReason(p.getNoDEANumericReason().charAt(0));
    o.setSpecialtySchool(p.getSpecialtySchool());
    o.setAnesthesiaCertificateExpiry(p.getAnesthesiaCertificateExpiry());
    o.setEmailAddress(p.getEmailAddress());
    o.setCollaborationAgreement(p.getCollaborationAgreement() ? 'Y' : 'N');
    o.setParaLicenseNumber(p.getParaLicenseNumber());
    o.setParaLicenseState(p.getParaLicenseState());
    o.setSpecialtyGradYear(p.getSpecialtyGradYear());
    o.setFWAComplianceDate(p.getFWAComplianceDate());
    o.setDegree1(p.getDegree1());
    o.setDegree2(p.getDegree2());
    o.setDataOwner(doF.apply(p.getDataOwnerId()));

    return o;

  }

}
