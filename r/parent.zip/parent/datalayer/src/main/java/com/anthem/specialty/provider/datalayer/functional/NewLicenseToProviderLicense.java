package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NewLicense;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;

public class NewLicenseToProviderLicense implements Function<NewLicense, ProviderLicense> {

  private final Provider provider;

  public NewLicenseToProviderLicense(Provider provider) {
    this.provider = provider;
  }

  @Override
  public ProviderLicense apply(NewLicense t) {
    ProviderLicense o = new ProviderLicense();

    o.setProvider(provider);
    o.setDataOwner(provider.getDataOwner());
    if (null != t.getDea()) {
      o.setDeaNumber(t.getDea().getDeaNumber());
      o.setDeaNumberExpires(t.getDea().getExpiration());
      if (null != t.getDea().getMissingBecause() && !t.getDea().getMissingBecause().isEmpty())
        o.setDeaReason(t.getDea().getMissingBecause().charAt(0));
    }

    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }

    o.setIssuingState(t.getIssuingState());
    o.setLicenseNo(t.getLicenseNumber());
    o.setOnHold(t.getOnHold() ? 'Y' : 'N');
    o.setTerminated(t.getTerminated());

    return o;
  }

}
