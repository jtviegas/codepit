package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.RelatedCarrierItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedCarrierItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;

public class CarrierToRelatedCarrierItem implements Function<Carrier, RelatedCarrierItem> {

  private final LinkResolver linkResolver;

  public CarrierToRelatedCarrierItem() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedCarrierItem apply(Carrier t) {
    RelatedCarrierItem o = new RelatedCarrierItemImpl();
    o.setId(t.getId());
    o.setLink(linkResolver.apply(new String[] { t.getId().toString() }, LinkResolver.Type.carrier, true));
    o.setName(t.getContactName());
    return o;
  }

}
