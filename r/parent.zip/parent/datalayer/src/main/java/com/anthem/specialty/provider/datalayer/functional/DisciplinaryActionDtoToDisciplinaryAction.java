package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class DisciplinaryActionDtoToDisciplinaryAction
    implements Function<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction, DisciplinaryAction> {

  private final Provider provider;

  public DisciplinaryActionDtoToDisciplinaryAction(Provider provider) {
    this.provider = provider;
  }

  @Override
  public DisciplinaryAction apply(com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction t) {
    DisciplinaryAction o = new DisciplinaryAction();

    o.setProvider(provider);
    o.setComments(t.getComments());
    o.setDataOwner(provider.getDataOwner());
    o.setDescription(t.getDescription());
    o.setOriginatorCode(t.getOriginatorCode());
    o.setId(t.getId());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    return o;
  }

}
