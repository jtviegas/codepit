package com.anthem.specialty.provider.datalayer.utils;

import java.util.function.BiFunction;

/**
 * 
 * @author jviegas
 *
 * @param <F>
 *          the type of the first argument to the function
 * @param <S>
 *          the type of the second argument to the function
 * @param <T>
 *          the type of the third argument to the function
 * @param <R>
 *          the type of the result of the function
 * 
 * @see BiFunction
 */

@FunctionalInterface
public interface TriFunction<F, S, T, R> {

  /**
   * Applies this function to the given arguments
   * 
   * @param f
   *          the first argument
   * @param s
   *          the second argument
   * @param t
   *          the third argument
   * @return the function result
   */
  R apply(F f, S s, T t);

}
