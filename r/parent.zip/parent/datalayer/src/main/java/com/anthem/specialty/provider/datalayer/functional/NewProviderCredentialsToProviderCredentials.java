package com.anthem.specialty.provider.datalayer.functional;

import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.Link;
import com.anthem.specialty.provider.datamodel.dto.NewProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.ProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.ProviderCredentialsImpl;

public class NewProviderCredentialsToProviderCredentials
    implements Function<NewProviderCredentials, ProviderCredentials> {

  private final DataOwner dOwn;

  private final Long id;

  private final List<Link> links;

  public NewProviderCredentialsToProviderCredentials(List<Link> links, Long id, DataOwner dOwn) {
    this.links = links;
    this.id = id;
    this.dOwn = dOwn;
  }

  @Override
  public ProviderCredentials apply(NewProviderCredentials p) {

    ProviderCredentials o = new ProviderCredentialsImpl();

    o.setCredentialed(p.getCredentialed());
    o.setCredentialingLevel(p.getCredentialingLevel());
    o.setDeaRestricted(p.getDeaRestricted());
    o.setDeaRestrictedComments(p.getDeaRestrictedComments());
    o.setDisciplinaryAction(p.getDisciplinaryAction());
    o.setDisciplinaryActionComments(p.getDisciplinaryActionComments());
    o.setFelonyMisdemeanor(p.getFelonyMisdemeanor());
    o.setFelonyMisdemeanorComments(p.getFelonyMisdemeanorComments());
    o.setHealthProblem(p.getHealthProblem());
    o.setHealthProblemComments(p.getHealthProblemComments());
    o.setLicenseSuspended(p.getLicenseSuspended());
    o.setLicenseSuspendedComments(p.getLicenseSuspendedComments());
    o.setMalpracticeExper(p.getMalpracticeExper());
    o.setMalpracticeExperComments(p.getMalpracticeExperComments());

    o.setDataOwner(dOwn);
    o.setId(id);
    o.setLinks(links);

    return o;
  }

}
