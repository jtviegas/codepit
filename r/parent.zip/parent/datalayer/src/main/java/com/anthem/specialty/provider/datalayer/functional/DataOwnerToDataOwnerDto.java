package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;

public class DataOwnerToDataOwnerDto
    implements Function<DataOwner, com.anthem.specialty.provider.datamodel.dto.DataOwner> {

  @Override
  public com.anthem.specialty.provider.datamodel.dto.DataOwner apply(DataOwner t) {
    com.anthem.specialty.provider.datamodel.dto.DataOwner o = new com.anthem.specialty.provider.datamodel.dto.DataOwnerImpl();

    o.setId(t.getId());
    o.setName(t.getDisplayName());

    return o;
  }

}
