package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.NetworkGroupImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;

public class NetworkGroupToNetworkGroupDto
    implements Function<NetworkGroup, com.anthem.specialty.provider.datamodel.dto.NetworkGroup> {

  private final LinkResolver linkResolver;

  public NetworkGroupToNetworkGroupDto(LinkResolver linkResolver) {
    this.linkResolver = linkResolver;
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.NetworkGroup apply(
      com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup src) {
    com.anthem.specialty.provider.datamodel.dto.NetworkGroup ret = new NetworkGroupImpl();
    ret.setDataOwner(new DataOwnerToDataOwnerDto().apply(src.getDataOwner()));
    ret.setDescription(src.getDescription());
    ret.setId(src.getId());
    ret.setLinks(Arrays
        .asList(linkResolver.apply(new String[] { src.getId().toString() }, LinkResolver.Type.networkgroup, true)));
    return ret;
  }

}
