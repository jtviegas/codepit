package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.LanguageImpl;
import com.anthem.specialty.provider.datamodel.dto.Link;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;

public class ClinicLanguageToLanguage implements Function<ClinicLanguage, Language> {

  public ClinicLanguageToLanguage() {
  }

  @Override
  public Language apply(ClinicLanguage t) {
    Language o = new LanguageImpl();

    o.setId(t.getId());
    // TODO review: no isocode in ClinicLanguage
    // o.setIsoCode(t.);
    o.setName(t.getLanguage());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));

    LinkResolver linkResolver = new LinkResolver();
    List<Link> links = new ArrayList<Link>();
    o.setLinks(links);
    links.add(linkResolver.apply(new String[] { t.getClinic().getId().toString(), o.getId().toString() },
        LinkResolver.Type.clinic_language, true));
    links.add(linkResolver.apply(new String[] { t.getClinic().getId().toString() }, LinkResolver.Type.clinic, false));

    return o;
  }

}
