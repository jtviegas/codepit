package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datalayer.repositories.lob.CarrierRepository;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;

public class CollectionRelatedCarrierToNetworkCarrier
    implements BiFunction<Network, CollectionRelatedCarrier, NetworkCarrier> {

  private final CarrierRepository carrierRep;

  public CollectionRelatedCarrierToNetworkCarrier(CarrierRepository carrierRep) {
    this.carrierRep = carrierRep;
  }

  @Override
  public NetworkCarrier apply(Network n, CollectionRelatedCarrier t) {
    NetworkCarrier o = new NetworkCarrier();
    Carrier carrier = carrierRep.findById(t.getCarrier().getId()).get();
    o.setCarrier(carrier);
    o.setDataOwner(carrier.getDataOwner());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setId(t.getId());
    o.setNetwork(n);

    return o;
  }

}
