package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.stream.Stream;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.Repository;

import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicDirectoryAccuracy;

public interface ClinicDirectoryAccuracyRepository extends Repository<ClinicDirectoryAccuracy, Long> {

  Page<ClinicDirectoryAccuracy> findAll(Pageable pageable);
  /*
   * Stream<ClinicDirectoryAccuracy> findByNetworkId(Long networkId);
   */

  Stream<ClinicDirectoryAccuracy> findByLargeGroupId(Long largeGroupId);

  // Stream<ClinicDirectoryAccuracy> findByLargeGroupIdAndNetworkId(Long largeGroupId, Long networkId, Pageable
  // pageable);

}
