package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.UpdateableAddress;
import com.anthem.specialty.provider.datamodel.dto.UpdateableAddressImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ClinicElementImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.License;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.LicenseImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.NetworkElementImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderElementImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderVerificationElement;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderVerificationElementImpl;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.W9ElementImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderDirectoryAccuracy;

/**
 * ProviderDirectoryAccuracyToMessageStream
 * 
 * Is a stream mapper applies transformation in a provider directory accuracy query row, resolving its elements, keeping
 * track of its references and completing them as the stream of related rows is fed in.
 * 
 * As an example, once a given row denotes a new aggregation/provider directory, it creates a new top level element,
 * DirectoryVerificationElement, returns it inside an Optional, and keeps processing the next lines related to this
 * element, adding the related data to its reference, and in the mean time returning an empty optional, once it receives
 * a row related to a new top level element, releases the previous DirectoryVerificationElement reference and creates a
 * new one, and goes on with the same rationale, until there is no more rows.
 * 
 * @author jviegas
 *
 */
public class ProviderDirectoryAccuracyToMessageStream
    implements Function<ProviderDirectoryAccuracy, Optional<ProviderVerificationElement>> {

  private static final Logger logger = LoggerFactory.getLogger(ProviderDirectoryAccuracyToMessageStream.class);

  private ProviderVerificationElementImpl providerDirectoryPointer;

  private final LinkResolver linkResolver = new LinkResolver();

  private final Function<String, DataOwner> dataOwnerResolver;

  public ProviderDirectoryAccuracyToMessageStream(Function<String, DataOwner> dataOwnerResolver) {
    this.dataOwnerResolver = dataOwnerResolver;
  }

  @Override
  public Optional<ProviderVerificationElement> apply(ProviderDirectoryAccuracy t) {
    logger.trace("[apply] in");
    Optional<ProviderVerificationElement> r = Optional.empty();

    if (null == providerDirectoryPointer
        || (null == t.getLargeGroupId() && (providerDirectoryPointer.getLargeGroupName() != null))
        || (null != t.getLargeGroupId()
            && (!t.getLargeGroupName().equals(providerDirectoryPointer.getLargeGroupName())))) {
      providerDirectoryPointer = new ProviderVerificationElementImpl();
      providerDirectoryPointer.setLargeGroupName(t.getLargeGroupName());
      logger.debug("[apply] new providerDirectoryPointer: {}", providerPointer);
      r = Optional.of(providerDirectoryPointer);
    }
    providerDirectoryPointer.increaseRows();

    // hand over analysis of row to the W9 section
    Optional<W9ElementImpl> newW9 = parseW9(t);
    if (newW9.isPresent())
      providerDirectoryPointer.getW9().add(newW9.get());

    logger.trace("[apply] out");
    // stream over whatever we've realized here
    return r;
  }

  private W9ElementImpl w9Pointer;

  private Optional<W9ElementImpl> parseW9(ProviderDirectoryAccuracy t) {
    logger.trace("[parseW9] in");
    Optional<W9ElementImpl> r = Optional.empty();
    if (null == w9Pointer || (!w9Pointer.getId().equals(t.getW9BusinessId()))) {
      // new W9 in the stream
      w9Pointer = new W9ElementImpl();
      w9Pointer.setDelegatedCreditAgreement(t.getDelegatedCreditAgreement().equals('Y'));
      w9Pointer.setId(t.getW9BusinessId());
      // TODO w9Pointer.setLink(t.get);
      w9Pointer.setName(t.getW9());
      w9Pointer.setTin(t.getTin());
      logger.debug("[parseW9] new w9Pointer: {}", w9Pointer);
      r = Optional.of(w9Pointer);
    }

    // hand over analysis of row to the Clinic section
    Optional<ClinicElementImpl> newClinic = parseClinic(t);
    if (newClinic.isPresent())
      w9Pointer.getClinics().add(newClinic.get());

    logger.trace("[parseW9] out");
    // return whatever we've realized here
    return r;
  }

  private ClinicElementImpl clinicPointer;

  private Optional<ClinicElementImpl> parseClinic(ProviderDirectoryAccuracy t) {
    logger.trace("[parseClinic] in");

    Optional<ClinicElementImpl> r = Optional.empty();
    if (null == clinicPointer || (!clinicPointer.getId().equals(t.getClinicId()))) {
      clinicPointer = new ClinicElementImpl();
      UpdateableAddress address = new UpdateableAddressImpl();
      address.setCity(t.getCity());
      address.setLine1(t.getAddress1());
      address.setState(t.getState());
      address.setzIPCode(t.getZipCode());
      clinicPointer.setAddress(address);

      // TODO clinicPointer.setClinicNpi(clinicNpi);
      // TODO clinicPointer.setCorporateNpi(corporateNpi);

      clinicPointer.setDataOwner(dataOwnerResolver.apply(t.getDataOwner()));
      clinicPointer.setId(t.getClinicId());
      clinicPointer
          .setLink(linkResolver.apply(new String[] { t.getClinicId().toString() }, LinkResolver.Type.clinic, false));
      clinicPointer.setName(t.getClinic());
      clinicPointer.setPrimaryOfficeNumber(t.getPrimaryOfficeNumber());
      logger.debug("[parseClinic] new clinicPointer: {}", clinicPointer);
      r = Optional.of(clinicPointer);
    }

    // hand over analysis of row to the provider section
    Optional<ProviderElementImpl> newProvider = parseProvider(t);
    if (newProvider.isPresent())
      clinicPointer.getProviders().add(newProvider.get());

    logger.trace("[parseClinic] out");
    // return whatever we've realized here
    return r;
  }

  private ProviderElementImpl providerPointer;

  private Optional<ProviderElementImpl> parseProvider(ProviderDirectoryAccuracy t) {
    logger.trace("[parseProvider] in");

    Optional<ProviderElementImpl> r = Optional.empty();
    if (null == providerPointer || (!providerPointer.getId().equals(t.getProviderId()))) {
      // new provider element from row
      providerPointer = new ProviderElementImpl();
      providerPointer.setBoardStatus(t.getBoardCertification());
      providerPointer.setFirstName(t.getFirstName());
      providerPointer.setId(t.getProviderId());
      if (null != t.getLanguages())
        providerPointer.setLanguages(Arrays.asList(t.getLanguages().split(",")).stream().map(s -> s.trim())
            .filter(s -> (0 < s.length())).distinct().collect(Collectors.toList()));

      providerPointer.setLastName(t.getLastName());
      License license = new LicenseImpl();
      license.setIssuingState(t.getIssuingState());
      license.setLicenseNumber(t.getStateLicenseNo());
      providerPointer.setLicense(license);

      providerPointer.setLink(
          linkResolver.apply(new String[] { t.getProviderId().toString() }, LinkResolver.Type.provider, false));
      providerPointer.setMiddleInitial(t.getMiddleName());
      providerPointer.setNamePrefix(t.getNamePrefix());
      providerPointer.setNpi(t.getProviderNpi());
      providerPointer.setProviderRelationship(t.getProviderRelationShip());
      if (null != t.getSpecialties())
        providerPointer.setSpecialty(Arrays.asList(t.getSpecialties().split(",")).stream().map(s -> s.trim())
            .filter(s -> (0 < s.length())).distinct().collect(Collectors.toList()));
      logger.debug("[parseProvider] new providerPointer: {}", providerPointer);
      r = Optional.of(providerPointer);
    }

    // every row should provider a new network info
    providerPointer.getNetworks().add(parseNetwork(t));

    logger.trace("[parseProvider] out");
    // return whatever we've realized here
    return r;
  }

  private NetworkElementImpl parseNetwork(ProviderDirectoryAccuracy t) {
    logger.trace("[parseNetwork] in");
    NetworkElementImpl r = new NetworkElementImpl();
    if (null != t.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(t.getEffectiveFrom());
      r.setEffective(ep);
    }
    r.setFrozenFrom(t.getFrozenFrom());
    r.setInDirectory(t.getInDirectory().equals('Y'));
    r.setId(t.getNetworkId());
    r.setName(t.getNetworkName());
    r.setOfficeNumber(t.getPrimaryOfficeNumber());
    logger.trace("[parseNetwork] new NetworkElement: {}", r);
    logger.trace("[parseNetwork] out");
    return r;
  }

}
