package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public interface W9LegalEntityRepository extends CrudRepository<W9LegalEntity, Long> {

  List<W9LegalEntity> findByTin(Long tin);

  List<W9LegalEntity> findByOrderByIdDesc(Pageable pageable);

}
