package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;

public interface ProviderLanguageRepository extends CrudRepository<ProviderLanguage, Long> {
  List<ProviderLanguage> findByProvider(Provider provider);

  List<ProviderLanguage> findByProviderId(Long providerId);

  // this method does not throw exception
  // void deleteByIdAndProviderId(Long id, Long providerId);
  List<ProviderLanguage> findByIdAndProviderId(Long id, Long providerId);
}
