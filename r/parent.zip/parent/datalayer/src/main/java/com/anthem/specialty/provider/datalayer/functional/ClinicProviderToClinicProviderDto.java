package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Bci;
import com.anthem.specialty.provider.datamodel.dto.BciImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.OpeningHours;
import com.anthem.specialty.provider.datamodel.dto.OpeningHoursImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;

public class ClinicProviderToClinicProviderDto
    implements Function<ClinicProvider, com.anthem.specialty.provider.datamodel.dto.ClinicProvider> {

  private ProviderToRelatedProviderItem mapper;

  public ClinicProviderToClinicProviderDto() {
    this.mapper = new ProviderToRelatedProviderItem();
  }

  @Override
  public com.anthem.specialty.provider.datamodel.dto.ClinicProvider apply(ClinicProvider t) {

    com.anthem.specialty.provider.datamodel.dto.ClinicProvider o = new com.anthem.specialty.provider.datamodel.dto.ClinicProviderImpl();

    if (null != t.getBciAccountBilled() && null != t.getBciTransactionId()) {
      Bci r = new BciImpl();
      r.setBilled(t.getBciAccountBilled());
      r.setId(t.getBciTransactionId());
      o.setBci(r);
    } else if (null != t.getBciAccountBilled() || null != t.getBciTransactionId()) {
      throw new IllegalArgumentException("BCI requires both properties, Id and Billed, to be provided");
    }

    o.setProvider(mapper.apply(t.getProvider()));
    o.setClearLicenseNumber(t.getClearLicenseNumber().equals('Y'));
    o.setComments(t.getComments());
    o.setCorporatePayment(t.getCorporatePayment().equals('Y'));
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setDeltaPrecertified(t.getDeltaPrecertified().equals('Y'));
    if (null != t.getEffectiveFrom()) {
      EffectivePeriod ep = new EffectivePeriodImpl();
      ep.setFrom(t.getEffectiveFrom());
      if (null != t.getEffectiveTo())
        ep.setTo(t.getEffectiveTo());
      o.setEffective(ep);
    }

    List<OpeningHours> openingHours = new ArrayList<OpeningHours>();
    for (ClinicProviderSchedule s : t.getClinicProviderSchedules())
      openingHours.add(new OpeningHoursImpl(s.getDayOfWeek(), s.getFrom(), s.getTo()));

    if (!openingHours.isEmpty())
      o.setHours(openingHours);

    o.setId(t.getId());
    o.setPayClinicProvider(t.getPayClinicProvider());
    o.setProfessionalReviewUnderway(t.getProfessionalReviewUnderway().equals('Y'));
    o.setProviderClaimInReview(t.getProviderClaimInReview().equals('Y'));
    o.setProviderCob(t.getProviderCob().equals('Y'));
    o.setProviderRelationship(t.getProviderRelationship());
    o.setProviderSpecialistClinic(t.getProviderSpecialistClinic().equals('Y'));
    o.setWitholdPayments(t.getWitholdPayments().equals('Y'));

    return o;
  }

}
