package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.DentalProcedure;

public interface DentalProcedureRepository extends CrudRepository<DentalProcedure, Long> {
  List<DentalProcedure>  findByCode(String code);
 
}
