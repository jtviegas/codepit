package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.dto.NewPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;

public class NewPhoneContactToClinicPhoneContact implements BiFunction<Clinic, NewPhoneContact, ClinicPhoneContact> {

  public NewPhoneContactToClinicPhoneContact() {
    // TODO Auto-generated constructor stub
  }

  @Override
  public ClinicPhoneContact apply(Clinic t, NewPhoneContact u) {
    ClinicPhoneContact o = new ClinicPhoneContact();

    o.setAccessCode(u.getAccessCode());
    o.setAreaCode(u.getAreaCode());
    o.setCityCode(u.getCityCode());
    o.setClinic(t);
    o.setCountryCode(u.getCountryCode());
    o.setDataOwner(t.getDataOwner());
    o.setExtension(u.getExtension());
    o.setNumber(u.getNumber());
    o.setType(u.getType().asChar());

    return o;
  }

}
