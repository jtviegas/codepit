package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.schemas.lob.LegalAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;

public class LegalAddressDtoToLegalAddress implements
    BiFunction<W9LegalEntity, com.anthem.specialty.provider.datamodel.dto.LegalAddress, LegalAddress> {

  @Override
  public LegalAddress apply(W9LegalEntity w, com.anthem.specialty.provider.datamodel.dto.LegalAddress t) {
    LegalAddress o = new LegalAddress();

    o.setCity(t.getCity());
    o.setDataOwner(w.getDataOwner());
    o.setId(t.getId());
    o.setAddress1(t.getLine1());
    o.setAddress2(t.getLine2());
    o.setAddress3(t.getLine3());
    o.setState(t.getState());
    o.setZip(t.getZipCode());
    o.setW9LegalEntity(w);
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }

    return o;
  }

}
