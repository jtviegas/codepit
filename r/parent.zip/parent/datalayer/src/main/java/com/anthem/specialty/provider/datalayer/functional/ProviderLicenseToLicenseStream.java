package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;
import java.util.stream.Stream;

import com.anthem.specialty.provider.datamodel.dto.License;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;

public class ProviderLicenseToLicenseStream implements Function<ProviderLicense, Stream<License>> {

  private final ProviderLicenseToLicense mapper;

  public ProviderLicenseToLicenseStream() {
    this.mapper = new ProviderLicenseToLicense();
  }

  @Override
  public Stream<License> apply(ProviderLicense t) {
    License o = mapper.apply(t);
    return Stream.of(o);
  }

}
