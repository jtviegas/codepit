package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;

public interface NetworkCarrierRepository extends CrudRepository<NetworkCarrier, Long> {
  List<NetworkCarrier> findByEffectiveFrom(Date date);

  List<NetworkCarrier> findByCarrier(Carrier carrier);

  Stream<NetworkCarrier> findByCarrierId(Long carrierId);

  List<NetworkCarrier> findByNetwork(Network network);

  List<NetworkCarrier> findByNetworkId(Long networkId);

  List<NetworkCarrier> findByNetworkIdAndCarrierId(Long networkId, Long carrierId);

  Optional<NetworkCarrier> findByIdAndNetworkId(Long id, Long networkId);

  @Query(value = "select network_id from network_carrier where carrier_id=?1", nativeQuery = true)
  List<BigDecimal> findRelatedNetworkIdById(Long carrierId);

  void deleteByIdAndNetworkId(Long id, Long networkId);

}
