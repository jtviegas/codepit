package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.ClinicFocusReview;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;

public class ClinicFocusReviewToFocusReview implements Function<ClinicFocusReview, FocusReview> {

  private final Provider provider;

  private final Clinic clinic;

  private final NetworkGroup group;

  public ClinicFocusReviewToFocusReview(Provider provider, Clinic clinic, NetworkGroup group) {
    this.provider = provider;
    this.clinic = clinic;
    this.group = group;
  }

  @Override
  public FocusReview apply(ClinicFocusReview t) {
    FocusReview o = new FocusReview();

    o.setId(t.getId());
    o.setProvider(provider);
    o.setDataOwner(clinic.getDataOwner());
    o.setClinic(clinic);
    o.setNetworkGroup(group);

    o.setAuditNumber(t.getAuditNumber());
    o.setCommenced(t.getCommenced());
    o.setComments(t.getComments());

    if (null != t.getProcedureCodes()) {
      o.setProcedureCodeRangeStart(t.getProcedureCodes().getRangeStart());
      o.setProcedureCodeRangeEnd(t.getProcedureCodes().getRangeEnd());
    }

    if (null != t.getTerminated()) {
      o.setReason(t.getTerminated().getReason());
      o.setTerminated(t.getTerminated().getFrom());
    }

    return o;
  }

}
