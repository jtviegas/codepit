package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.schemas.core.DocumentType;

public class DocumentTypeToDocumentTypeDto
    implements Function<DocumentType, com.anthem.specialty.provider.datamodel.dto.DocumentType> {

  @Override
  public com.anthem.specialty.provider.datamodel.dto.DocumentType apply(DocumentType t) {

    if (null == t)
      throw new IllegalArgumentException("document type can't be null");

    if (null == t.getCode() || null == t.getDescription())
      throw new IllegalArgumentException("document type properties can't be null");

    com.anthem.specialty.provider.datamodel.dto.DocumentType o = new com.anthem.specialty.provider.datamodel.dto.DocumentTypeImpl();

    o.setCode(t.getCode());
    o.setDescription(t.getDescription());

    return o;
  }

}
