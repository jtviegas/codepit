package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.LineOfBusiness;

public interface TenantRepository extends CrudRepository<LineOfBusiness, Long> {
  List<LineOfBusiness> findBySchemaName(String schemaName);
}
