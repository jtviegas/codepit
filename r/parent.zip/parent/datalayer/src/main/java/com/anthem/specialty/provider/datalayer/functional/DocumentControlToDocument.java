package com.anthem.specialty.provider.datalayer.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.dto.DocumentImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;

public class DocumentControlToDocument implements Function<DocumentControl, Document> {

  private final LinkResolver linkResolver;

  public DocumentControlToDocument() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public Document apply(DocumentControl t) {
    Document o = new DocumentImpl();

    o.setControlNumber(t.getDcnId());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setId(t.getId());

    o.setType(new DocumentTypeToDocumentTypeDto().apply(t.getDescription()));
    o.setSource(t.getSource());

    List<com.anthem.specialty.provider.datamodel.dto.Link> links = new ArrayList<com.anthem.specialty.provider.datamodel.dto.Link>();
    links.add(
        linkResolver.apply(new String[] { t.getProvider().getId().toString() }, LinkResolver.Type.provider, false));
    links.add(linkResolver.apply(new String[] { t.getProvider().getId().toString(), t.getDcnId().toString() },
        LinkResolver.Type.provider_document, true));
    if (null != t.getClinic())
      links.add(linkResolver.apply(new String[] { t.getProvider().getId().toString(), t.getClinic().getId().toString(),
          t.getDcnId().toString() }, LinkResolver.Type.provider_clinic_document, true));

    o.setLinks(links);

    return o;
  }

}
