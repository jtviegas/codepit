package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.LineOfBusiness;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;

public interface TerminationLevelRepository extends CrudRepository<TerminationLevel, Long> {

	 List<TerminationLevel> findByDescription(String description);
}