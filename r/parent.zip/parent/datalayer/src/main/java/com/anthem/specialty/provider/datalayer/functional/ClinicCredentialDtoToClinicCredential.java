package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datamodel.dto.ClinicCredentials;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;

public class ClinicCredentialDtoToClinicCredential implements BiFunction<Clinic, ClinicCredentials, ClinicCredential> {

  @Override
  public ClinicCredential apply(Clinic c, ClinicCredentials t) {
    ClinicCredential o = new ClinicCredential();

    o.setCdcOshaRulesCompliance(t.iscDCAndOSHARulesCompliance() ? 'Y' : 'N');
    o.setClinic(c);
    o.setCprTrained(t.isCprTrained() ? 'Y' : 'N');
    o.setCredentialed(t.getCredentialed());
    o.setDataOwner(c.getDataOwner());
    o.setDeptHealthRulesCompliance(t.isDeptHealthRulesCompliance() ? 'Y' : 'N');
    o.setEmergencyKit(t.isEmergencyKit() ? 'Y' : 'N');
    o.setEmergencyTrained(t.isEmergencyTrained() ? 'Y' : 'N');
    o.setHandicappedParking(t.isHadicappedParking() ? 'Y' : 'N');
    o.setHandicapAccess(t.isHandicapAccess() ? 'Y' : 'N');
    o.setPublicTransport(t.isPublicTransport() ? 'Y' : 'N');
    o.setId(t.getId());

    return o;
  }

}
