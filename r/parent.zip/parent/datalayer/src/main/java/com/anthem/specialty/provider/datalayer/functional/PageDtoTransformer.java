package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import org.springframework.data.domain.Page;

public interface PageDtoTransformer<R, T> extends Function<Page<R>, Page<T>> {

}
