package com.anthem.specialty.provider.datalayer.functional;

import java.util.Arrays;
import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.Address;
import com.anthem.specialty.provider.datamodel.dto.AddressImpl;
import com.anthem.specialty.provider.datamodel.dto.AddressType;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;

public class ClinicAddressToAddress implements Function<ClinicAddress, Address> {

  private final LinkResolver linkResolver;

  public ClinicAddressToAddress() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public Address apply(ClinicAddress t) {

    AddressImpl o = new AddressImpl();
    o.setCity(t.getCity());
    o.setCountry(t.getCountry());
    o.setCounty(t.getCounty());
    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setId(t.getId());
    o.setLatitude(t.getLatitude());
    o.setLine1(t.getAddress1());
    o.setLine2(t.getAddress2());
    o.setLine3(t.getAddress3());
    o.setLinks(Arrays.asList(linkResolver.apply(new String[] { t.getClinic().getId().toString(), t.getId().toString() },
        LinkResolver.Type.clinic_address, true)));
    o.setLongitude(t.getLongitude());
    o.setProvince(t.getProvince());
    o.setState(t.getState());
    o.setType(AddressType.fromChar(t.getType()));
    o.setzIPCode(t.getZipCode());

    return o;
  }

}
