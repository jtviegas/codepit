package com.anthem.specialty.provider.datalayer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datalayer.services.LobServiceImpl;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datalayer.services.MetadataServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@Configuration
public class ServicesConfiguration {

  @Bean
  public LobService providerService() {
    return new LobServiceImpl();
  }

  @Bean
  public MetadataService metadataService() {
    return new MetadataServiceImpl();
  }

  @Bean
  public ObjectMapper jsonMapper() {
    ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule()).registerModule(new Jdk8Module())
        .registerModule(new JavaTimeModule());

    return mapper;
  }

}
