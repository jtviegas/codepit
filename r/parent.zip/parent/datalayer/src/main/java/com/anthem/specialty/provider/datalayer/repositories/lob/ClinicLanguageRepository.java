package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;

public interface ClinicLanguageRepository extends CrudRepository<ClinicLanguage, Long> {
  List<ClinicLanguage> findByClinic(Clinic clinic);

  Optional<ClinicLanguage> findByIdAndClinicId(Long id, Long clinicId);

  List<ClinicLanguage> findByClinicId(Long id);

}
