package com.anthem.specialty.provider.datalayer.repositories.core;
 

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.core.LargeGroup;
 
public interface LargeGroupRepository extends CrudRepository<LargeGroup, Long>  {

  
}
