package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.BiFunction;

import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;

public class NetworkClinicRelationshipToNetworkClinic
    implements BiFunction<Network, NetworkClinicRelationship, NetworkClinic> {

  private final ClinicRepository cRep;

  public NetworkClinicRelationshipToNetworkClinic(ClinicRepository cRep) {
    this.cRep = cRep;
  }

  @Override
  public NetworkClinic apply(Network n, NetworkClinicRelationship t) {
    NetworkClinic o = new NetworkClinic();

    Clinic c = cRep.findById(t.getClinic().getId()).get();
    o.setClinic(c);
    o.setDataOwner(c.getDataOwner());
    if (null != t.getEffective()) {
      o.setEffectiveFrom(t.getEffective().getFrom());
      o.setEffectiveTo(t.getEffective().getTo());
    }
    o.setFrozenFrom(t.getFrozenFrom());
    o.setIsFrozen(t.isIsFrozen() ? 'Y' : 'N');
    o.setOfficeNo(t.getOfficeNumber());
    o.setNetwork(n);
    o.setId(t.getId());

    return o;
  }

}
