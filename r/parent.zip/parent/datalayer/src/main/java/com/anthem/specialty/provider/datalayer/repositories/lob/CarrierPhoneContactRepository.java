package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;

public interface CarrierPhoneContactRepository extends CrudRepository<CarrierPhoneContact, Long> {

  List<CarrierPhoneContact> findByCarrier(Carrier carrier);

  List<CarrierPhoneContact> findByCarrierId(Long carrierId);

}
