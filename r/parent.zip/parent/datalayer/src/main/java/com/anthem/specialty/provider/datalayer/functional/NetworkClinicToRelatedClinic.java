package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinicItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;

public class NetworkClinicToRelatedClinic implements Function<NetworkClinic, RelatedClinic> {

  private final LinkResolver linkResolver;

  public NetworkClinicToRelatedClinic() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedClinic apply(NetworkClinic t) {
    RelatedClinic o = new RelatedClinicImpl();

    RelatedClinicItem i = new RelatedClinicItemImpl();
    o.setClinic(i);
    i.setCommonName(t.getClinic().getCommonName());
    i.setId(t.getClinic().getId());
    i.setLink(linkResolver.apply(new String[] { t.getClinic().getId().toString() }, LinkResolver.Type.clinic, true));

    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    if (null != t.getEffectiveFrom())
      o.setEffective(new EffectivePeriodImpl(t.getEffectiveFrom(), t.getEffectiveTo()));
    o.setId(t.getId());

    return o;
  }

}
