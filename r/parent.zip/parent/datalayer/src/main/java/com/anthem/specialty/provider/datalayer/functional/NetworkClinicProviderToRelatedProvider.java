package com.anthem.specialty.provider.datalayer.functional;

import java.util.function.Function;

import com.anthem.specialty.provider.datamodel.dto.RelatedProvider;
import com.anthem.specialty.provider.datamodel.dto.RelatedProviderImpl;
import com.anthem.specialty.provider.datamodel.dto.RelatedProviderItem;
import com.anthem.specialty.provider.datamodel.dto.RelatedProviderItemImpl;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;

public class NetworkClinicProviderToRelatedProvider implements Function<NetworkClinicProvider, RelatedProvider> {

  private final LinkResolver linkResolver;

  public NetworkClinicProviderToRelatedProvider() {
    this.linkResolver = new LinkResolver();
  }

  @Override
  public RelatedProvider apply(NetworkClinicProvider t) {
    RelatedProvider o = new RelatedProviderImpl();

    o.setDataOwner(new DataOwnerToDataOwnerDto().apply(t.getDataOwner()));
    o.setId(t.getProvider().getId());

    RelatedProviderItem i = new RelatedProviderItemImpl();
    o.setProvider(i);
    i.setId(t.getProvider().getId());

    StringBuilder b = new StringBuilder();
    if (null != t.getProvider().getFirstName() && !t.getProvider().getFirstName().isEmpty())
      b.append(t.getProvider().getFirstName());
    if (null != t.getProvider().getMiddleName() && !t.getProvider().getMiddleName().isEmpty()) {
      b.append(" ");
      b.append(t.getProvider().getFirstName());
    }
    if (null != t.getProvider().getLastName() && !t.getProvider().getLastName().isEmpty()) {
      b.append(" ");
      b.append(t.getProvider().getLastName());
    }
    i.setName(b.toString());
    i.setLink(
        linkResolver.apply(new String[] { t.getProvider().getId().toString() }, LinkResolver.Type.provider, false));

    o.setEffective(t.getProvider().getEffectivePeriod());

    return o;
  }

}
