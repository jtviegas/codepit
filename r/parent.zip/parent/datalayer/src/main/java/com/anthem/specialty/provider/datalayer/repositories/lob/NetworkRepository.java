package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.anthem.specialty.provider.datamodel.schemas.lob.Network;

public interface NetworkRepository extends CrudRepository<Network, Long> {

  List<Network> findByDescription(String description);

  Stream<Network> findByOrderByIdDesc(Pageable pageable);

  Stream<Network> findByIdIn(Collection<Long> ids);

}
