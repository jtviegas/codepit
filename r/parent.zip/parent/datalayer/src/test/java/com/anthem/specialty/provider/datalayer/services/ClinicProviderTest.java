package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicProviderSchedule;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClinicProviderTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    assertNotNull(terminationLevel);

    Provider provider = lobService.setProvider(UtilsPopulate.newNewProvider(dataOwner.getId(), terminationLevel));
    Clinic clinic = lobService.setClinic(UtilsPopulate.newClinic(dataOwner));
    ClinicProviderSchedule cps = UtilsPopulate.newClinicProviderSchedule(dataOwner);

    ClinicProvider o = UtilsPopulate.newClinicProvider(dataOwner,
        metadataService.getProviderRelationships().stream().findAny().get());
    o.setClinic(clinic);
    o.setProvider(provider);
    o.addClinicProviderSchedule(cps);

    o = lobService.setClinicProvider(o);
    assertNotNull(o.getId());
    Assert.assertEquals(o.getProvider().getClinicProviders().stream().findFirst().get(), o);
    Assert.assertEquals(o.getClinic().getClinicProviders().stream().findFirst().get(), o);
    assertNotNull(o.getClinicProviderSchedules().get(0).getId());
    Assert.assertEquals(o.getClinicProviderSchedules().get(0).getClinicProvider(), o);
    Assert.assertEquals(1, lobService.getClinicProvidersByProvider(provider).size());
    Assert.assertEquals(1, lobService.getClinicProvidersByClinic(clinic).size());
    Assert.assertEquals(1, lobService.getClinicProviderSchedulesByClinicProvider(o).size());

    lobService.deleteClinicProvider(o.getId());
    Assert.assertNull(lobService.getClinicProvider(o.getId()));
    Assert.assertNotNull(lobService.getProvider(provider.getId()));
    Assert.assertNotNull(lobService.findClinic(clinic.getId()));
    Assert.assertEquals(0, lobService.getClinicProvidersByProvider(provider).size());
    Assert.assertEquals(0, lobService.getClinicProvidersByClinic(clinic).size());
    Assert.assertEquals(0, lobService.getClinicProviderSchedulesByClinicProvider(o).size());

    Assert.assertEquals(0, lobService.getProvider(provider.getId(), true).getClinicProviders().size());
    lobService.deleteProvider(provider.getId());
    try {
      lobService.getProvider(provider.getId());
      Assert.fail("Delete provider failed");
    } catch (NoEntityFoundException nefe) {
    }
    Assert.assertEquals(0, lobService.findClinic(clinic.getId()).getClinicProviders().size());
    lobService.deleteClinic(clinic.getId());
    try {
      lobService.findClinic(clinic.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
