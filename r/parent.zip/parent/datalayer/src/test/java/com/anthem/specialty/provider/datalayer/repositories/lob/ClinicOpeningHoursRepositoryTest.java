package com.anthem.specialty.provider.datalayer.repositories.lob;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicOpeningHours;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ClinicOpeningHoursRepositoryTest {

  @Autowired
  private ClinicOpeningHoursRepository repository;

  @Autowired
  private MetadataService metadataService;

  @Autowired
  private ClinicRepository clinicRepository;

  @Test
  public void test_00() throws Exception {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    ClinicOpeningHours ca = UtilsPopulate.newClinicOpeningHours(dataOwner);

    Clinic clinic = clinicRepository.save(UtilsPopulate.newClinic(dataOwner));
    ca.setClinic(clinic);

    ca = repository.save(ca);
    Assert.assertTrue(repository.findById(ca.getId()).isPresent());

    clinicRepository.deleteById(clinic.getId());
    Assert.assertFalse(clinicRepository.findById(clinic.getId()).isPresent());

  }

}
