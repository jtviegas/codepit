package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicOpeningHours;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicPhoneContact;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClinicTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);

    Clinic o = UtilsPopulate.newClinic(dataOwner);

    ClinicAddress ca = UtilsPopulate.newClinicAddress(dataOwner);
    o.addClinicAddress(ca);
    ClinicCredential cc = UtilsPopulate.newClinicCredential(dataOwner);
    o.addClinicCredential(cc);
    ClinicLanguage cl = UtilsPopulate.newClinicLanguage(dataOwner);
    o.addClinicLanguage(cl);
    ClinicOpeningHours coh = UtilsPopulate.newClinicOpeningHours(dataOwner);
    o.addClinicOpeningHours(coh);
    ClinicPhoneContact cpc = UtilsPopulate.newClinicPhoneContact(dataOwner);
    o.addClinicPhoneContact(cpc);

    /*
     * NetworkClinic nc = UtilsPopulate.newNetworkClinic(dataOwner); NetworkClinicProvider ncp =
     * UtilsPopulate.newNetworkClinicProvider(dataOwner,
     * metadataService.getTerminationLevels().stream().findAny().get()); DocumentControl dc =
     * UtilsPopulate.newDocumentControl(dataOwner, metadataService.getDocumentTypes().stream().findFirst().get());
     * FocusReview fr = UtilsPopulate.newFocusReview(dataOwner);
     * 
     * ClinicW9 cw = UtilsPopulate.newClinicW9(dataOwner); o.getDocumentControls().add(dc);
     */

    o = lobService.setClinic(o);
    assertNotNull(o.getId());
    assertNotNull(o.getClinicAddresses().get(0).getId());
    Assert.assertEquals(o.getClinicAddresses().get(0).getClinic(), o);
    assertNotNull(o.getClinicPhoneContacts().get(0).getId());
    Assert.assertEquals(o.getClinicPhoneContacts().get(0).getClinic(), o);
    assertNotNull(o.getClinicOpeningHours().get(0).getId());
    Assert.assertEquals(o.getClinicOpeningHours().get(0).getClinic(), o);
    assertNotNull(o.getClinicCredentials().get(0).getId());
    Assert.assertEquals(o.getClinicCredentials().get(0).getClinic(), o);
    assertNotNull(o.getClinicLanguages().get(0).getId());
    Assert.assertEquals(o.getClinicLanguages().get(0).getClinic(), o);
    Assert.assertNotNull(o.getClinicPhoneContacts().get(0).getDisplay());

    lobService.deleteClinic(o.getId());
    try {
      lobService.findClinic(o.getId());
      Assert.fail("Delete clinic failed");
    } catch (NoEntityFoundException e) {
    }
    Assert.assertEquals(0, lobService.getClinicAddressesByClinic(o).size());
    Assert.assertEquals(0, lobService.getClinicPhoneContactsByClinic(o).size());
    Assert.assertEquals(0, lobService.getClinicOpeningHoursByClinic(o).size());
    Assert.assertEquals(0, lobService.getClinicCredentialsByClinic(o).size());
    Assert.assertEquals(0, lobService.getClinicLanguagesByClinic(o).size());

  }

}
