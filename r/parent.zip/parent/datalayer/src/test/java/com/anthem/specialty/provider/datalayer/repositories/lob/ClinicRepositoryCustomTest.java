package com.anthem.specialty.provider.datalayer.repositories.lob;

import static org.junit.Assert.assertNotNull;

import java.util.Optional;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepositoryCustom;
import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ClinicRepositoryCustomTest {

  private static final Logger logger = LoggerFactory.getLogger(ClinicRepositoryCustomTest.class);

  @Autowired
  DataSource dataSource;

  @Autowired
  private ClinicRepository clinicRepository;

  @Autowired
  private ClinicRepositoryCustom clinicRepositoryCustom;

  @Autowired
  private DataOwnerRepository dataOwnerRepository;

  @Before
  public void setUp() throws Exception {
    logger.trace("[setup] in");

    Clinic clinic = new Clinic();
    DataOwner dataOwner = dataOwnerRepository.findById(1L).get();

    UtilsPopulate.createTestClinic(clinic, dataOwner, "123456789");

    clinicRepository.save(clinic);

    logger.trace("[setUp] out");
  }

  @Test
  public void test() {
    logger.trace("[test] in");
    Optional<Clinic> clinic = clinicRepositoryCustom.findOneByStateMedicaidNo("123456789");

    assertNotNull(clinic);
    logger.trace("[test] out");
  }

  @After
  public void tearDown() {

    logger.trace("[tearDown] in");
    Optional<Clinic> clinic = clinicRepositoryCustom.findOneByStateMedicaidNo("123456789");
    if (clinic.isPresent()) {
      clinicRepository.delete(clinic.get());
    }

    logger.trace("[tearDown] out");
  }
}
