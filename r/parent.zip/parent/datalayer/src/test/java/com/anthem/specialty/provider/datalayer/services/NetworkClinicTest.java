package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworkClinicTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);

    Network network = lobService.setNetwork(UtilsPopulate.newNetwork(dataOwner));
    Clinic clinic = lobService.setClinic(UtilsPopulate.newClinic(dataOwner));

    NetworkClinic o = UtilsPopulate.newNetworkClinic(dataOwner);
    o.setClinic(clinic);
    o.setNetwork(network);

    o = lobService.setNetworkClinic(o);
    assertNotNull(o.getId());
    Assert.assertEquals(o.getNetwork().getNetworkClinics().stream().findFirst().get(), o);
    Assert.assertEquals(o.getClinic().getNetworkClinics().stream().findFirst().get(), o);
    Assert.assertEquals(1, lobService.getNetworkClinicsByNetwork(network).size());
    Assert.assertEquals(1, lobService.getNetworkClinicsByClinic(clinic).size());

    lobService.deleteNetworkClinic(o.getId());
    try {
      lobService.getNetworkClinic(o.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }
    Assert.assertNotNull(lobService.getNetwork(network.getId()));
    Assert.assertNotNull(lobService.findClinic(clinic.getId()));
    Assert.assertEquals(0, lobService.getNetworkClinicsByNetwork(network).size());
    Assert.assertEquals(0, lobService.getNetworkClinicsByClinic(clinic).size());
    Assert.assertEquals(0, lobService.getNetwork(network.getId()).getNetworkClinics().size());
    Assert.assertEquals(0, lobService.getClinic(clinic.getId(), true).getNetworkClinics().size());

    lobService.deleteNetwork(network.getId());
    try {
      lobService.getNetwork(network.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    lobService.deleteClinic(clinic.getId());
    try {
      lobService.findClinic(clinic.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
