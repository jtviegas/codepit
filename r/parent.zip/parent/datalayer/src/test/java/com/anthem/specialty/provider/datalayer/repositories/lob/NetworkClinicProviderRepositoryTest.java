package com.anthem.specialty.provider.datalayer.repositories.lob;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.functional.NewProviderToProvider;
import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.TerminationLevelRepository;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NetworkClinicProviderRepositoryTest {

  @Autowired
  private TerminationLevelRepository terminationLevelRepository;

  @Autowired
  private ProviderRepository providerRepository;

  @Autowired
  private DataOwnerRepository dataOwnerRepository;

  @Autowired
  private ClinicRepository clinicRepository;

  @Autowired
  private NetworkRepository networkRepository;

  @Autowired
  private NetworkClinicProviderRepository networkClinicProviderRepository;

  @Autowired
  private NetworkClinicRepository networkClinicRepository;

  @Before
  public void setUp() throws Exception {

    /* create a new clinic and provider and network to hold relationships */
    DataOwner dataOwner = dataOwnerRepository.findById(1L).get();
    TerminationLevel terminationLevel = terminationLevelRepository.findById(1L).get();

    NewProvider np = UtilsPopulate.newNewProvider(dataOwner.getId(), terminationLevel);
    np.setTin("12345677");

    Provider provider = providerRepository.save(new NewProviderToProvider(new Function<Long, TerminationLevel>() {

      @Override
      public TerminationLevel apply(Long t) {
        Optional<TerminationLevel> r = terminationLevelRepository.findById(t);
        if (r.isPresent())
          return r.get();
        return null;
      }
    }, new Function<Long, com.anthem.specialty.provider.datamodel.schemas.core.DataOwner>() {

      @Override
      public com.anthem.specialty.provider.datamodel.schemas.core.DataOwner apply(Long t) {
        Optional<com.anthem.specialty.provider.datamodel.schemas.core.DataOwner> r = dataOwnerRepository.findById(t);
        if (r.isPresent())
          return r.get();
        return null;
      }
    }).apply(np));
    Clinic clinic = new Clinic();
    UtilsPopulate.createTestClinic(clinic, dataOwner, "123456789");
    clinic = clinicRepository.save(clinic);

    /** create network */
    Network network = networkRepository.save(UtilsPopulate.newNetwork(dataOwner));

    NetworkClinic nc = UtilsPopulate.newNetworkClinic(dataOwner);
    nc.setClinic(clinic);
    nc.setNetwork(network);
    nc = networkClinicRepository.save(nc);

    NetworkClinicProvider ncp = UtilsPopulate.newNetworkClinicProvider(dataOwner, terminationLevel);
    ncp.setProvider(provider);
    ncp.setNetworkClinic(nc);
    ncp.setOfficeNo("123");

    networkClinicProviderRepository.save(ncp);

  }

  @Transactional
  @Test
  public void test() {

    List<Provider> providerList = providerRepository.findByTin("12345677");
    Provider provider = providerList.get(0);
    List<Clinic> clinicList = clinicRepository.findByStateMedicaidNo("123456789");
    Clinic clinic = clinicList.get(0);

    List<NetworkClinicProvider> ncpList = networkClinicProviderRepository.findByOfficeNo("123");

/*    int size = provider.getNetworkClinicProviders().size();
    assertEquals(size, 1);
    // size = clinic.getNetworkClinicProviders().size();
    // assertEquals(size, 1);
    size = ncpList.size();
    assertEquals(size, 1);*/

    // NetworkClinicProvider ncp = clinic.getNetworkClinicProviders().iterator().next();
    // assertEquals(ncpList.get(0), ncp);
    // ncp = provider.getNetworkClinicProviders().iterator().next();
    // assertEquals(ncpList.get(0), ncp);

    NetworkClinicProvider ncp = ncpList.get(0);
    List<NetworkClinicProvider> ncpList2 = networkClinicProviderRepository
        .findByNetworkId(ncp.getNetworkClinic().getNetwork().getId());
    assertEquals(ncp, ncpList2.get(0));

    List<Long> ls = networkClinicProviderRepository
        .findIdByNetworkIdAndClinicIdAndProviderId(ncp.getNetworkClinic().getNetwork().getId(),
            ncp.getNetworkClinic().getClinic().getId(), ncp.getProvider().getId())
        .stream().map(o -> o.longValue()).collect(Collectors.toList());

    networkClinicProviderRepository.deleteByIdIn(ls);
    ncpList = networkClinicProviderRepository.findByOfficeNo(ncp.getOfficeNo());
    assertEquals(0, ncpList.size());

  }

  @After
  public void tearDown() {

    List<Provider> providerList = providerRepository.findByTin("12345677");
    List<Clinic> clinicList = clinicRepository.findByStateMedicaidNo("123456789");
    List<NetworkClinicProvider> ncpList = networkClinicProviderRepository.findByOfficeNo("123");
    List<Network> networkList = networkRepository.findByDescription("Network");

    for (NetworkClinicProvider ncp : ncpList) {
      // ncp.removeAssociations();
      ncp.setNetworkClinic(null);
      ncp.setProvider(null);
      networkClinicProviderRepository.delete(ncp);
    }

    for (Provider p : providerList) {
      providerRepository.delete(p);
    }

    for (Clinic c : clinicList) {
      clinicRepository.delete(c);
    }

    for (Network network : networkList) {
      networkRepository.delete(network);
    }

  }

}
