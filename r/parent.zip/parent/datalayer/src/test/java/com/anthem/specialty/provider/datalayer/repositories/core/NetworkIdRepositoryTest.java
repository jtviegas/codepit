package com.anthem.specialty.provider.datalayer.repositories.core;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.NetworkId;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NetworkIdRepositoryTest {

  @Autowired
  private DataOwnerRepository dataOwnerRepository;

  @Autowired
  private NetworkIdRepository networkIdRepository;

  private static final String dummySchemaName = "AnthemXPTOtest";

  @Test(expected = InvalidDataAccessResourceUsageException.class)
  public void test() {

    NetworkId networkId = new NetworkId();
    networkId.setSchemaName(dummySchemaName);
    DataOwner dataOwner = dataOwnerRepository.findById(1L).get();
    networkId.setDataOwner(dataOwner);
    networkId = networkIdRepository.save(networkId);

    List<NetworkId> networkIdList = networkIdRepository.findBySchemaName(dummySchemaName);
    Assert.assertTrue(0 < networkIdList.size());

    networkIdRepository.deleteById(networkId.getId());
    Assert.assertFalse(networkIdRepository.findById(networkId.getId()).isPresent());

  }

}
