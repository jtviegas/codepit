package com.anthem.specialty.provider.datalayer.repositories.lob;

import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicLanguage;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ClinicLanguageRepositoryTest {

  @Autowired
  private ClinicLanguageRepository repository;

  @Autowired
  private MetadataService metadataService;

  @Autowired
  private ClinicRepository clinicRepository;

  @Test
  public void test_00() throws Exception {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();

    ClinicLanguage ca = UtilsPopulate.newClinicLanguage(dataOwner);
    Clinic clinic = clinicRepository.save(UtilsPopulate.newClinic(dataOwner));
    ca.setClinic(clinic);

    ca = repository.save(ca);

    Optional<ClinicLanguage> o = repository.findById(ca.getId());

    Assert.assertTrue(o.isPresent());
    repository.deleteById(o.get().getId());
    o = repository.findById(o.get().getId());
    Assert.assertFalse(o.isPresent());

    clinicRepository.deleteById(clinic.getId());
    Assert.assertFalse(clinicRepository.findById(clinic.getId()).isPresent());

  }

}
