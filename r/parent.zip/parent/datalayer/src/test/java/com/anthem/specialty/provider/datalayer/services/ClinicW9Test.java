package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicW9;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClinicW9Test {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    assertNotNull(terminationLevel);

    W9LegalEntity w9le = lobService.setW9LegalEntity(UtilsPopulate.newW9LegalEntity(dataOwner));
    Clinic clinic = lobService.setClinic(UtilsPopulate.newClinic(dataOwner));
    ClinicW9 o = UtilsPopulate.newClinicW9(dataOwner);
    o.setClinic(clinic);
    o.setW9LegalEntity(w9le);

    o = lobService.setClinicW9(o);
    assertNotNull(o.getId());
    Assert.assertEquals(o.getW9LegalEntity().getClinicW9s().stream().findFirst().get(), o);
    Assert.assertEquals(o.getClinic().getClinicW9s().stream().findFirst().get(), o);
    Assert.assertEquals(1, lobService.getClinicW9sByW9LegalEntity(w9le).size());
    Assert.assertEquals(1, lobService.getClinicW9sByClinic(clinic).size());

    lobService.deleteClinicW9(o.getId());
    Assert.assertNotNull(lobService.getW9LegalEntity(w9le.getId()));
    Assert.assertNotNull(lobService.findClinic(clinic.getId()));
    Assert.assertEquals(0, lobService.getClinicW9sByW9LegalEntity(w9le).size());
    Assert.assertEquals(0, lobService.getClinicW9sByClinic(clinic).size());
    Assert.assertEquals(0, lobService.getW9LegalEntity(w9le.getId()).getClinicW9s().size());
    Assert.assertEquals(0, lobService.findClinic(clinic.getId()).getClinicW9s().size());

    lobService.deleteW9LegalEntity(w9le.getId());
    try {
      lobService.getW9LegalEntity(w9le.getId());
      Assert.fail("Delete legal entity failed");
    } catch (NoEntityFoundException e) {
    }
    lobService.deleteClinic(clinic.getId());
    try {
      lobService.findClinic(clinic.getId());
      Assert.fail("Delete clinic failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
