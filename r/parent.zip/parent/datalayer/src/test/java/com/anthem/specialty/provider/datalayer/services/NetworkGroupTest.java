package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworkGroupTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00_network() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    int dataOwnersCount = metadataService.getDataOwners().size();

    assertNotNull(dataOwner);

    Network n = lobService.setNetwork(UtilsPopulate.newNetwork(dataOwner));
    NetworkGroup o = UtilsPopulate.newNetworkGroup(dataOwner);
    o.addNetwork(n);

    lobService.setNetworkGroup(o);
    assertNotNull(o.getId());
    assertNotNull(o.getNetworks().get(0).getId());
    Assert.assertEquals(o.getNetworks().get(0), n);

    lobService.deleteNetworkGroup(o.getId());

    try {
      lobService.getNetworkGroup(o.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    Assert.assertEquals(dataOwnersCount, metadataService.getDataOwners().size());

    Assert.assertNotNull(lobService.getNetwork(n.getId()));
    lobService.deleteNetwork(n.getId());
    try {
      lobService.getNetwork(n.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }
  }

}
