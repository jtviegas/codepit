package com.anthem.specialty.provider.datalayer.repositories.core;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LargeGroupRepositoryTest {

  @Autowired
  private LargeGroupRepository largeGroupRepository;

  @Test
  public void test_00() throws Exception {

    Assert.assertTrue(0 < largeGroupRepository.count());

  }

}
