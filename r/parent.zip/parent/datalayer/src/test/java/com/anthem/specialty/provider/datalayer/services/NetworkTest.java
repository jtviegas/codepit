package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.BusinessSegment;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkPlan;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworkTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00_network() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    int dataOwnersCount = metadataService.getDataOwners().size();

    assertNotNull(dataOwner);

    Network o = UtilsPopulate.newNetwork(dataOwner);

    int specialtiesCount = metadataService.getSpecialties().size();
    Specialty s = metadataService.getSpecialties().stream().findAny().get();
    o.addSpecialty(s);

    int bsCount = metadataService.getBusinessSegments().size();
    BusinessSegment bs = metadataService.getBusinessSegments().stream().findAny().get();
    o.addBusinessSegment(bs);

    NetworkPhoneContact npc = UtilsPopulate.newNetworkPhoneContact(dataOwner);
    o.addNetworkPhoneContact(npc);

    NetworkPlan np = UtilsPopulate.newNetworkPlan(dataOwner);
    o.addNetworkPlan(np);

    o = lobService.setNetwork(o);

    assertNotNull(o.getId());

    assertNotNull(o.getSpecialties().get(0).getCode());
    Assert.assertEquals(o.getSpecialties().get(0).getNetworks().get(0), o);

    assertNotNull(o.getNetworkPhoneContacts().get(0).getId());
    Assert.assertEquals(o.getNetworkPhoneContacts().get(0).getNetwork(), o);

    assertNotNull(o.getNetworkPlans().get(0).getId());
    Assert.assertEquals(o.getNetworkPlans().get(0).getNetwork(), o);
    Assert.assertEquals(1, lobService.getNetworkPlansByNetwork(o).size());

    assertNotNull(o.getBusinessSegments().get(0).getId());
    Assert.assertEquals(o.getBusinessSegments().get(0).getNetworks().get(0), o);

    lobService.deleteNetwork(o.getId());

    try {
      lobService.getNetwork(o.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    Assert.assertEquals(dataOwnersCount, metadataService.getDataOwners().size());

    s = metadataService.getSpecialty(s.getCode());
    Assert.assertFalse(s.getNetworks().contains(o));
    Assert.assertEquals(specialtiesCount, metadataService.getSpecialties().size());

    Assert.assertTrue(lobService.getNetworkPhoneContactsByNetwork(o).isEmpty());

    Assert.assertTrue(lobService.getNetworkPlansByNetwork(o).isEmpty());

    Assert.assertEquals(bsCount, metadataService.getBusinessSegments().size());

  }

}
