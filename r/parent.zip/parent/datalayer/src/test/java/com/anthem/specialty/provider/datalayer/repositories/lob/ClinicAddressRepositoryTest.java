package com.anthem.specialty.provider.datalayer.repositories.lob;

import static org.junit.Assert.assertNotNull;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.repositories.core.ClinicRepository;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.ClinicAddress;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ClinicAddressRepositoryTest {

  @Autowired
  private ClinicAddressRepository repository;

  @Autowired
  private ClinicRepository clinicRepository;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws Exception {

    long oCount = repository.count();
    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();

    ClinicAddress ca = new ClinicAddress();
    ca.setType('D');
    ca.setAddress1(RandomStringUtils.random(12, true, false));
    ca.setDataOwner(dataOwner);

    Clinic clinic = clinicRepository.save(UtilsPopulate.newClinic(dataOwner));
    Assert.assertEquals(oCount, repository.count());
    clinic.addClinicAddress(ca);
    ca = repository.save(ca);

    Assert.assertEquals(oCount + 1, repository.count());
    assertNotNull(ca.getId());

    ca = new ClinicAddress();
    ca.setType('D');
    ca.setAddress1(RandomStringUtils.random(12, true, false));
    ca.setDataOwner(dataOwner);
    clinic = UtilsPopulate.newClinic(dataOwner);
    clinic.addClinicAddress(ca);
    clinic = clinicRepository.save(clinic);

    Assert.assertEquals(oCount + 2, repository.count());
    assertNotNull(ca.getId());
    assertNotNull(clinic.getClinicAddresses().get(0));

    ca = new ClinicAddress();
    ca.setType('D');
    ca.setAddress1(RandomStringUtils.random(12, true, false));
    ca.setDataOwner(dataOwner);
    clinic = clinicRepository.save(UtilsPopulate.newClinic(dataOwner));
    clinic.addClinicAddress(ca);
    clinic = clinicRepository.save(clinic);

    Assert.assertEquals(oCount + 3, repository.count());
    assertNotNull(clinic.getClinicAddresses().get(0).getId());

    ca = new ClinicAddress();
    ca.setType('G');
    ca.setAddress1(RandomStringUtils.random(12, true, false));
    ca.setDataOwner(dataOwner);
    clinic.addClinicAddress(ca);
    ca = repository.save(ca);

    Assert.assertEquals(oCount + 4, repository.count());
    assertNotNull(clinic.getClinicAddresses().get(0).getId());

    repository.deleteById(clinic.getClinicAddresses().get(0).getId());
    Assert.assertEquals(oCount + 3, repository.count());
    Assert.assertFalse(repository.findById(clinic.getClinicAddresses().get(0).getId()).isPresent());

    clinicRepository.deleteById(clinic.getId());
    Assert.assertFalse(clinicRepository.findById(clinic.getId()).isPresent());

  }

}
