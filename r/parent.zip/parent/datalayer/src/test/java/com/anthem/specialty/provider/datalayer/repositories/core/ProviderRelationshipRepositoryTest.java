package com.anthem.specialty.provider.datalayer.repositories.core;

import static org.junit.Assert.assertTrue;

import java.util.stream.StreamSupport;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProviderRelationshipRepositoryTest {

  @Autowired
  private ProviderRelationshipRepository repository;

  @Test
  public void test() {
    assertTrue(StreamSupport.stream(repository.findAll().spliterator(), false).count() > 0);
  }

}
