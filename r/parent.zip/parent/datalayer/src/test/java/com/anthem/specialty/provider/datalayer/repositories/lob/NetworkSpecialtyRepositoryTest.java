package com.anthem.specialty.provider.datalayer.repositories.lob;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datalayer.repositories.core.SpecialtyRepository;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NetworkSpecialtyRepositoryTest {

  private static final Logger logger = LoggerFactory.getLogger(NetworkSpecialtyRepositoryTest.class);

  @Autowired
  private SpecialtyRepository specialtyRepository;

  @Autowired
  private DataOwnerRepository dataOwnerRepository;

  @Autowired
  private NetworkRepository networkRepository;

  @Before
  public void setUp() throws Exception {

    logger.trace("[setup] in");
    DataOwner dataOwner = dataOwnerRepository.findById(1L).get();

    Network network = new Network();
    network.setDescription("Network Description");
    network.setShortDescription("NetDesc");
    network.setManager("Mr. Manager");
    network.setComments("network comments");
    network.setCapitationPayment('Y');
    network.setCustomerServiceDisplayed('Y');
    LocalDate effectiveFrom = LocalDate.of(2002, Month.JANUARY, 1);
    network.setEffectiveFrom(effectiveFrom);
    network.setDataOwner(dataOwner);

    Optional<Specialty> specialty1 = specialtyRepository.findById("009");
    Optional<Specialty> specialty2 = specialtyRepository.findById("021");
    network.addSpecialty(specialty1.get());
    network.addSpecialty(specialty2.get());

    networkRepository.save(network);

    logger.trace("[setup] out");
  }

  @Transactional
  @Test
  public void test() {
    logger.trace("[test] in");

    List<Network> networkList = networkRepository.findByDescription("Network Description");
    assertNotEquals(networkList.size(), 0);
    assertEquals(networkList.get(0).getSpecialties().size(), 2);

    logger.trace("[test] out");
  }

  @After
  public void tearDown() {

    logger.trace("[tearDown] in");
    List<Network> networkList = networkRepository.findByDescription("Network Description");
    assertNotEquals(networkList.size(), 0);
    networkRepository.delete(networkList.get(0));
    logger.trace("[tearDown] out");
  }

}
