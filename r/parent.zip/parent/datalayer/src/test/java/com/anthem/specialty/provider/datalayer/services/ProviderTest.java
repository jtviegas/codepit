package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderCredential;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLanguage;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderLicense;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderMedicaid;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialty;
import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderSpecialtyHospital;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProviderTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    assertNotNull(terminationLevel);

    NewProvider np = UtilsPopulate.newNewProvider(dataOwner.getId(), terminationLevel);
    Provider provider = lobService.setProvider(np);

    ProviderSpecialty ps = UtilsPopulate.newProviderSpecialty(dataOwner,
        metadataService.getSpecialties().stream().findAny().get());
    provider.addProviderSpecialty(ps);

    /* ProviderSanction psanction = UtilsPopulate.newProviderSanction(dataOwner); */
    ProviderLanguage plang = UtilsPopulate.newProviderLanguage(dataOwner);
    provider.addProviderLanguage(plang);

    ProviderCredential pc = UtilsPopulate.newProviderCredential(dataOwner);
    provider.addProviderCredential(pc);

    ProviderLicense pl = UtilsPopulate.newProviderLicense(dataOwner);
    provider.addProviderLicense(pl);

    ProviderMedicaid pm = UtilsPopulate.newProviderMedicaid(dataOwner);
    provider.addProviderMedicaid(pm);

    DisciplinaryAction da = UtilsPopulate.newDisciplinaryAction(dataOwner);
    provider.addDisciplinaryAction(da);

    ProviderSpecialtyHospital psh = UtilsPopulate.newProviderSpecialtyHospital(dataOwner,
        metadataService.getSpecialties().stream().findAny().get());
    provider.addProviderSpecialtyHospital(psh);

    /*
     * NetworkClinicProvider ncp = UtilsPopulate.newNetworkClinicProvider(dataOwner, terminationLevel); ClinicProvider
     * cp = UtilsPopulate.newClinicProvider(dataOwner,
     * metadataService.getProviderRelationships().stream().findAny().get()); FocusReview fr =
     * UtilsPopulate.newFocusReview(dataOwner); DocumentControl dc = UtilsPopulate.newDocumentControl(dataOwner,
     * metadataService.getDocumentTypes().stream().findAny().get());
     */

    final Provider o = lobService.getProvider(lobService.setProvider(provider).getId(), true);
    Assert.assertNotNull(o.getId());
    Assert.assertNotNull(o.getProviderSpecialties().get(0).getId());
    Assert.assertEquals(o.getProviderSpecialties().get(0).getProvider(), o);
    Assert.assertNotNull(o.getProviderLanguages().get(0).getId());
    Assert.assertEquals(o.getProviderLanguages().get(0).getProvider(), o);
    assertNotNull(o.getProviderCredentials().get(0).getId());
    Assert.assertEquals(o.getProviderCredentials().get(0).getProvider(), o);
    assertNotNull(o.getProviderLicenses().get(0).getId());
    Assert.assertEquals(o.getProviderLicenses().get(0).getProvider(), o);
    assertNotNull(o.getProviderMedicaids().get(0).getId());
    Assert.assertEquals(o.getProviderMedicaids().get(0).getProvider(), o);
    assertNotNull(o.getDisciplinaryActions().get(0).getId());
    Assert.assertEquals(o.getDisciplinaryActions().get(0).getProvider(), o);
    assertNotNull(o.getProviderSpecialtyHospitals().get(0).getId());
    Assert.assertEquals(o.getProviderSpecialtyHospitals().get(0).getProvider(), o);

    /*
     * Optional<SimpleProvider> optionalRelatedProvider = lobService.getRelatedProviders().stream() .filter(p ->
     * p.equals(new ProviderToSimpleProvider().apply(literals, o))).findFirst();
     * Assert.assertTrue(optionalRelatedProvider.isPresent());
     */

    Assert.assertEquals(1, lobService.getProviderSpecialtiesByProvider(o).size());
    Assert.assertEquals(1, lobService.getProviderLanguagesByProvider(o).size());
    Assert.assertEquals(1, lobService.getProviderCredentialsByProvider(o).size());
    Assert.assertEquals(1, lobService.getProviderLicensesByProvider(o).size());
    Assert.assertEquals(1, lobService.getProviderMedicaidsByProvider(o).size());
    Assert.assertEquals(1, lobService.getDisciplinaryActionsByProvider(o).size());
    Assert.assertEquals(1, lobService.getProviderSpecialtyHospitalsByProvider(o).size());

    lobService.deleteProvider(o.getId());
    try {
      lobService.getProvider(o.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }
    Assert.assertEquals(0, lobService.getProviderSpecialtiesByProvider(o).size());
    Assert.assertEquals(0, lobService.getProviderLanguagesByProvider(o).size());
    Assert.assertEquals(0, lobService.getProviderCredentialsByProvider(o).size());
    Assert.assertEquals(0, lobService.getProviderLicensesByProvider(o).size());
    Assert.assertEquals(0, lobService.getProviderMedicaidsByProvider(o).size());
    Assert.assertEquals(0, lobService.getDisciplinaryActionsByProvider(o).size());
    Assert.assertEquals(0, lobService.getProviderSpecialtyHospitalsByProvider(o).size());

  }

  /*
   * 
   * @Test public void test_01() {
   * 
   * DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get(); assertNotNull(dataOwner);
   * TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
   * assertNotNull(terminationLevel);
   * 
   * Provider provider = lobService.setProvider(UtilsPopulate.newProvider(dataOwner, terminationLevel)); Clinic clinic =
   * lobService.setClinic(UtilsPopulate.newClinic(dataOwner));
   * 
   * ProviderSanction o = UtilsPopulate.newProviderSanction(dataOwner); o.setClinic(clinic); o.setProvider(provider);
   * 
   * o = lobService.setProviderSanction(o); assertNotNull(o.getId());
   * Assert.assertEquals(o.getProvider().getProviderSanctions().get(0), o);
   * 
   * lobService.deleteProviderSanction(o.getId()); Assert.assertNull(lobService.getProviderSanction(o.getId()));
   * Assert.assertNotNull(lobService.getProvider(provider.getId()));
   * Assert.assertNotNull(lobService.getClinic(clinic.getId())); Assert.assertEquals(0,
   * lobService.getProviderSanctionsByProvider(provider).size()); Assert.assertEquals(0,
   * lobService.getProviderSanctionsByClinic(clinic).size());
   * 
   * lobService.deleteProvider(provider.getId()); Assert.assertNull(lobService.getProvider(provider.getId()));
   * lobService.deleteClinic(clinic.getId()); Assert.assertNull(lobService.getClinic(clinic.getId()));
   * 
   * }
   * 
   * @Test public void test_02() {
   * 
   * DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get(); assertNotNull(dataOwner);
   * TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
   * assertNotNull(terminationLevel);
   * 
   * Provider provider = lobService.setProvider(UtilsPopulate.newProvider(dataOwner, terminationLevel)); Clinic clinic =
   * lobService.setClinic(UtilsPopulate.newClinic(dataOwner)); DocumentControl o =
   * UtilsPopulate.newDocumentControl(dataOwner, metadataService.getDocumentTypes().stream().findAny().get());
   * 
   * o = lobService.setDocumentControl(o); assertNotNull(o.getId());
   * Assert.assertEquals(o.getProvider().getDocumentControls().stream().findFirst().get(), o);
   * Assert.assertEquals(o.getClinic().getDocumentControls().stream().findFirst().get(), o);
   * 
   * lobService.deleteDocumentControl(o.getId()); Assert.assertNull(lobService.getDocumentControl(o.getId()));
   * Assert.assertNotNull(lobService.getProvider(provider.getId()));
   * Assert.assertNotNull(lobService.getClinic(clinic.getId())); Assert.assertEquals(0,
   * lobService.getDocumentControlsByProvider(provider).size()); Assert.assertEquals(0,
   * lobService.getDocumentControlsByClinic(clinic).size());
   * 
   * Assert.assertEquals(0, lobService.getProvider(provider.getId()).getDocumentControls().size());
   * lobService.deleteProvider(provider.getId()); Assert.assertNull(lobService.getProvider(provider.getId()));
   * Assert.assertEquals(0, lobService.getClinic(clinic.getId()).getDocumentControls().size());
   * lobService.deleteClinic(clinic.getId()); Assert.assertNull(lobService.getClinic(clinic.getId()));
   * 
   * }
   */

}
