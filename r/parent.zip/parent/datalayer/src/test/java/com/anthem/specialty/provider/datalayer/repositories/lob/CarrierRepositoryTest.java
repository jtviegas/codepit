package com.anthem.specialty.provider.datalayer.repositories.lob;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CarrierRepositoryTest {

  @Autowired
  private CarrierRepository carrierRepository;

  @Autowired
  private CarrierPhoneContactRepository carrierPhoneContactRepository;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00_carrierAndPhoneContact() throws Exception {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();

    long cCount = carrierRepository.count();
    /* create carrier */
    Carrier carrier = new Carrier();
    UtilsPopulate.createTestCarrier(carrier, dataOwner, "1234567");
    carrier = carrierRepository.save(carrier);

    /* create carrier phone contact and add to carrier */
    CarrierPhoneContact cpc = new CarrierPhoneContact();
    cpc.setAccessCode("A");
    cpc.setAreaCode("086");
    cpc.setCountryCode("44");
    cpc.setType('P');
    cpc.setNumber("Num");
    cpc.setDataOwner(dataOwner);

    carrier.addCarrierPhoneContact(cpc); // update the cache
    carrier = carrierRepository.save(carrier);

    CarrierPhoneContact savedCpc = carrier.getCarrierPhoneContacts().stream().findFirst().get();
    Assert.assertNotNull(savedCpc);
    Assert.assertEquals(savedCpc.getCarrier(), carrier);

    Carrier readCarrier = carrierRepository.findById(carrier.getId()).get();
    Assert.assertEquals(readCarrier, carrier);

    List<Carrier> carrierList = carrierRepository.findByClearCarrierNo("1234567");
    assertEquals(carrierList.size(), 1);
    assertEquals(carrier, carrierList.get(0));

    carrierRepository.delete(carrier);
    assertEquals(cCount, carrierRepository.count());
    Assert.assertFalse(carrierRepository.findById(carrier.getId()).isPresent());
    Assert.assertFalse(carrierPhoneContactRepository.findById(savedCpc.getId()).isPresent());
  }

}
