package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.FocusReview;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FocusReviewTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    assertNotNull(terminationLevel);

    Network network = lobService.setNetwork(UtilsPopulate.newNetwork(dataOwner));
    NetworkGroup ng = UtilsPopulate.newNetworkGroup(dataOwner);
    ng.addNetwork(network);
    ng = lobService.setNetworkGroup(ng);
    Clinic clinic = lobService.setClinic(UtilsPopulate.newClinic(dataOwner));
    Provider provider = lobService.setProvider(UtilsPopulate.newNewProvider(dataOwner.getId(), terminationLevel));

    FocusReview o = UtilsPopulate.newFocusReview(dataOwner);
    o.setNetworkGroup(ng);
    o.setClinic(clinic);
    o.setProvider(provider);

    o = lobService.setFocusReview(o);
    assertNotNull(o.getId());
    Assert.assertEquals(o.getNetworkGroup().getFocusReviews().stream().findFirst().get(), o);
    Assert.assertEquals(o.getProvider().getFocusReviews().stream().findFirst().get(), o);
    Assert.assertEquals(o.getClinic().getFocusReviews().stream().findFirst().get(), o);

    Assert.assertEquals(1, lobService.getFocusReviewsByNetworkGroup(ng).size());
    Assert.assertEquals(1, lobService.getFocusReviewsByProvider(provider).size());
    Assert.assertEquals(1, lobService.getFocusReviewsByClinic(clinic).size());

    lobService.deleteFocusReview(o.getId());
    Assert.assertNull(lobService.getFocusReview(o.getId()));
    Assert.assertNotNull(lobService.getNetworkGroup(ng.getId()));
    Assert.assertNotNull(lobService.getProvider(provider.getId()));
    Assert.assertNotNull(lobService.findClinic(clinic.getId()));

    Assert.assertEquals(0, lobService.getFocusReviewsByNetworkGroup(ng).size());
    Assert.assertEquals(0, lobService.getFocusReviewsByProvider(provider).size());
    Assert.assertEquals(0, lobService.getFocusReviewsByClinic(clinic).size());

    Assert.assertEquals(0, lobService.getNetworkGroup(ng.getId()).getFocusReviews().size());
    Assert.assertEquals(0, lobService.getProvider(provider.getId(), true).getFocusReviews().size());
    Assert.assertEquals(0, lobService.getClinic(clinic.getId(), true).getFocusReviews().size());

    lobService.deleteNetworkGroup(ng.getId());
    try {
      lobService.getNetworkGroup(ng.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    lobService.deleteProvider(provider.getId());
    try {
      lobService.getProvider(provider.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    lobService.deleteClinic(clinic.getId());
    try {
      lobService.findClinic(clinic.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    lobService.deleteNetwork(network.getId());
    try {
      lobService.getNetwork(network.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
