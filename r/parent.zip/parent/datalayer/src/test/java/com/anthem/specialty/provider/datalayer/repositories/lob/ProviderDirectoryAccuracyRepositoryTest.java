package com.anthem.specialty.provider.datalayer.repositories.lob;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datamodel.schemas.lob.ProviderDirectoryAccuracy;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProviderDirectoryAccuracyRepositoryTest {

  private static final Logger logger = LoggerFactory.getLogger(ProviderDirectoryAccuracyRepositoryTest.class);

  @Autowired
  private ProviderDirectoryAccuracyRepository repository;

  @Test
  public void test() {
    logger.trace("[test] in");
    List<ProviderDirectoryAccuracy> o = repository.findAll(new PageRequest(0, 100)).getContent();

    assertNotNull(o);
    logger.trace("[test] out");
  }

}
