package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.LargeGroup;
import com.anthem.specialty.provider.datamodel.schemas.lob.LegalAddress;
import com.anthem.specialty.provider.datamodel.schemas.lob.W9LegalEntity;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class W9LegalEntityTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);

    W9LegalEntity o = UtilsPopulate.newW9LegalEntity(dataOwner);

    LegalAddress la = UtilsPopulate.newLegalAddress(dataOwner);
    o.addLegalAddress(la);

    LargeGroup lg = metadataService.getLargeGroups().stream().findAny().get();
    o.setLargeGroup(lg);

    o = lobService.setW9LegalEntity(o);
    assertNotNull(o.getId());
    assertNotNull(o.getLegalAddresses().get(0).getId());
    assertEquals(o.getLegalAddresses().get(0).getW9LegalEntity().getId(), o.getId());
    Assert.assertEquals(1, lobService.getLegalAddressesByW9LegalEntity(o).size());
    assertEquals(o.getLargeGroup().getId(), lg.getId());

    lobService.deleteW9LegalEntity(o.getId());
    try {
      lobService.getW9LegalEntity(o.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    Assert.assertEquals(0, lobService.getLegalAddressesByW9LegalEntity(o).size());
    Assert.assertNotNull(metadataService.getLargeGroup(lg.getId()));
  }

}
