package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworkClinicProviderTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    assertNotNull(terminationLevel);

    Network network = lobService.setNetwork(UtilsPopulate.newNetwork(dataOwner));
    Clinic clinic = lobService.setClinic(UtilsPopulate.newClinic(dataOwner));

    NetworkClinic nc = UtilsPopulate.newNetworkClinic(dataOwner);
    nc.setClinic(clinic);
    nc.setNetwork(network);

    NetworkClinic networkClinic = lobService.setNetworkClinic(nc);

    Provider provider = lobService.setProvider(UtilsPopulate.newNewProvider(dataOwner.getId(), terminationLevel));

    NetworkClinicProvider o = UtilsPopulate.newNetworkClinicProvider(dataOwner, terminationLevel);
    o.setNetworkClinic(networkClinic);
    o.setProvider(provider);

    o = lobService.setNetworkClinicProvider(o);
    assertNotNull(o.getId());
    Assert.assertEquals(o.getNetworkClinic().getNetworkClinicProviders().stream().findFirst().get(), o);
    // Assert.assertEquals(o.getProvider().getNetworkClinicProviders().stream().findFirst().get(), o);
    Assert.assertEquals(1, lobService.getNetworkClinicProvidersByNetworkClinic(networkClinic).size());
    Assert.assertEquals(1, lobService.getNetworkClinicProvidersByProvider(provider).size());

    lobService.deleteNetworkClinicProvider(o.getId());
    try {
      lobService.getNetworkClinicProvider(o.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }
    Assert.assertNotNull(lobService.getNetworkClinic(networkClinic.getId()));
    Assert.assertNotNull(lobService.getProvider(provider.getId()));
    Assert.assertEquals(0, lobService.getNetworkClinicProvidersByNetworkClinic(networkClinic).size());
    Assert.assertEquals(0, lobService.getNetworkClinicProvidersByProvider(provider).size());
    Assert.assertEquals(0, lobService.getNetworkClinic(networkClinic.getId()).getNetworkClinicProviders().size());
    // Assert.assertEquals(0, lobService.getProvider(provider.getId(), true).getNetworkClinicProviders().size());

    lobService.deleteNetworkClinic(networkClinic.getId());
    try {
      lobService.getNetworkClinic(networkClinic.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    lobService.deleteProvider(provider.getId());
    try {
      lobService.getProvider(provider.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

    lobService.deleteNetwork(network.getId());
    try {
      lobService.getNetwork(network.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }
    lobService.deleteClinic(clinic.getId());
    try {
      lobService.findClinic(clinic.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
