package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Clinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.DocumentControl;
import com.anthem.specialty.provider.datamodel.schemas.lob.Provider;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DocumentControlTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    assertNotNull(terminationLevel);

    Provider provider = lobService.setProvider(UtilsPopulate.newNewProvider(dataOwner.getId(), terminationLevel));
    Clinic clinic = lobService.setClinic(UtilsPopulate.newClinic(dataOwner));
    DocumentControl o = UtilsPopulate.newDocumentControl(dataOwner,
        metadataService.getDocumentTypes().stream().findAny().get());

    o.setClinic(clinic);
    o.setProvider(provider);

    o = lobService.setDocumentControl(o);
    assertNotNull(o.getId());
    Assert.assertEquals(o.getProvider().getDocumentControls().stream().findFirst().get(), o);
    Assert.assertEquals(o.getClinic().getDocumentControls().stream().findFirst().get(), o);
    Assert.assertEquals(1, lobService.getDocumentControlsByProvider(provider).size());
    Assert.assertEquals(1, lobService.getDocumentControlsByClinic(clinic).size());

    lobService.deleteDocumentControl(o.getId());
    Assert.assertNull(lobService.getDocumentControl(o.getId()));
    Assert.assertNotNull(lobService.getProvider(provider.getId()));
    Assert.assertNotNull(lobService.findClinic(clinic.getId()));
    Assert.assertEquals(0, lobService.getDocumentControlsByProvider(provider).size());
    Assert.assertEquals(0, lobService.getDocumentControlsByClinic(clinic).size());

    Assert.assertEquals(0, lobService.getProvider(provider.getId(), true).getDocumentControls().size());
    lobService.deleteProvider(provider.getId());
    try {
      lobService.getProvider(provider.getId());
      Assert.fail("delete failed");
    } catch (NoEntityFoundException e) {
    }
    Assert.assertEquals(0, lobService.getClinic(clinic.getId(), true).getDocumentControls().size());
    lobService.deleteClinic(clinic.getId());
    try {
      lobService.findClinic(clinic.getId());
      Assert.fail("delete failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
