package com.anthem.specialty.provider.datalayer.services;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.lob.Carrier;
import com.anthem.specialty.provider.datamodel.schemas.lob.CarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkCarrier;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworkCarrierTest {

  @Autowired
  private LobService lobService;

  @Autowired
  private MetadataService metadataService;

  @Test
  public void test_00() throws NoEntityFoundException {

    DataOwner dataOwner = metadataService.getDataOwners().stream().findAny().get();
    assertNotNull(dataOwner);

    Carrier carrier = UtilsPopulate.newCarrier(dataOwner);
    CarrierPhoneContact cpc = UtilsPopulate.newCarrierPhoneContact(dataOwner);
    carrier.addCarrierPhoneContact(cpc);

    carrier = lobService.setCarrier(carrier);

    Network n = lobService.setNetwork(UtilsPopulate.newNetwork(dataOwner));

    NetworkCarrier nc = UtilsPopulate.newNetworkCarrier(dataOwner);
    nc.setNetwork(n);
    nc.setCarrier(carrier);

    nc = lobService.setNetworkCarrier(nc);

    Assert.assertNotNull(nc.getId());
    Assert.assertEquals(1, lobService.getNetworkCarriersByCarrier(carrier).size());
    Assert.assertEquals(1, lobService.getNetworkCarriersByNetwork(n).size());

    carrier = lobService.getCarrier(carrier.getId());
    n = lobService.getNetwork(n.getId());

    Assert.assertEquals(carrier.getNetworkCarriers().stream().findFirst().get(), nc);
    Assert.assertEquals(n.getNetworkCarriers().stream().findFirst().get(), nc);

    lobService.deleteNetworkCarrier(nc.getId());

    Assert.assertEquals(0, lobService.getNetworkCarriersByCarrier(carrier).size());
    Assert.assertEquals(0, lobService.getNetworkCarriersByNetwork(n).size());
    Assert.assertNotNull(lobService.getCarrier(carrier.getId()));
    Assert.assertNotNull(lobService.getNetwork(n.getId()));

    lobService.deleteCarrier(carrier.getId());
    try {
      lobService.getCarrier(carrier.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }
    lobService.deleteNetwork(n.getId());
    try {
      lobService.getNetwork(n.getId());
      Assert.fail("Delete failed");
    } catch (NoEntityFoundException e) {
    }

  }

}
