package com.anthem.specialty.provider.datamodel;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public interface Constant {
  static final SimpleDateFormat DATE_ONLY_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

  static final DateTimeFormatter DATE_ONLY_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  static final SimpleDateFormat YEAR_ONLY_FORMAT = new SimpleDateFormat("yyyy", Locale.getDefault());

  static final String OPENING_HOURS_TIME_PATTERN = "0%d:00";
}
