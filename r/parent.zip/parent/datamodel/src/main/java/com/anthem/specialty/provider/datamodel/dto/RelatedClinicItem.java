package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedClinicItemImpl.class)
public interface RelatedClinicItem extends RelatedItem {

  @JsonProperty("CommonName")
  @ApiModelProperty(required = true)
  @NotNull
  String getCommonName();

  @JsonProperty("CommonName")
  @ApiModelProperty(required = true)
  @NotNull
  void setCommonName(String o);

}
