package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PatientsImpl implements Patients {

  @JsonCreator
  public static Patients create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Patients impl = null;
    impl = mapper.readValue(json, PatientsImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private Boolean acceptsNewPatients = Boolean.TRUE;

  private Boolean acceptsNewMedicaidPatients;

  private Boolean medicaidPatientsConverted;

  private Integer MedicaidMonthlyPatients;

  private Boolean underThrees;

  private Boolean underEighteens;

  private Integer providerMonthlyPatients;

  private Integer hygienistMonthlyPatients;

  private String newMedicaidPatientPolicy;

  public PatientsImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getAcceptsNewPatients()
   */
  @Override
  public Boolean getAcceptsNewPatients() {
    return acceptsNewPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setAcceptsNewPatients(java.lang.Boolean)
   */
  @Override
  public void setAcceptsNewPatients(Boolean acceptsNewPatients) {
    this.acceptsNewPatients = acceptsNewPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getAcceptsNewMedicaidPatients()
   */
  @Override
  public Boolean getAcceptsNewMedicaidPatients() {
    return acceptsNewMedicaidPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setAcceptsNewMedicaidPatients(java.lang.Boolean)
   */
  @Override
  public void setAcceptsNewMedicaidPatients(Boolean acceptsNewMedicaidPatients) {
    this.acceptsNewMedicaidPatients = acceptsNewMedicaidPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getMedicaidPatientsConverted()
   */
  @Override
  public Boolean getMedicaidPatientsConverted() {
    return medicaidPatientsConverted;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setMedicaidPatientsConverted(java.lang.Boolean)
   */
  @Override
  public void setMedicaidPatientsConverted(Boolean medicaidPatientsConverted) {
    this.medicaidPatientsConverted = medicaidPatientsConverted;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getMedicaidMonthlyPatients()
   */
  @Override
  public Integer getMedicaidMonthlyPatients() {
    return MedicaidMonthlyPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setMedicaidMonthlyPatients(java.lang.Integer)
   */
  @Override
  public void setMedicaidMonthlyPatients(Integer medicaidMonthlyPatients) {
    MedicaidMonthlyPatients = medicaidMonthlyPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getUnderThrees()
   */
  @Override
  public Boolean getUnderThrees() {
    return underThrees;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setUnderThrees(java.lang.Boolean)
   */
  @Override
  public void setUnderThrees(Boolean underThrees) {
    this.underThrees = underThrees;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getUnderEighteens()
   */
  @Override
  public Boolean getUnderEighteens() {
    return underEighteens;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setUnderEighteens(java.lang.Boolean)
   */
  @Override
  public void setUnderEighteens(Boolean underEighteens) {
    this.underEighteens = underEighteens;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getProviderMonthlyPatients()
   */
  @Override
  public Integer getProviderMonthlyPatients() {
    return providerMonthlyPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setProviderMonthlyPatients(java.lang.Integer)
   */
  @Override
  public void setProviderMonthlyPatients(Integer providerMonthlyPatients) {
    this.providerMonthlyPatients = providerMonthlyPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getHygienistMonthlyPatients()
   */
  @Override
  public Integer getHygienistMonthlyPatients() {
    return hygienistMonthlyPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setHygienistMonthlyPatients(java.lang.Integer)
   */
  @Override
  public void setHygienistMonthlyPatients(Integer hygienistMonthlyPatients) {
    this.hygienistMonthlyPatients = hygienistMonthlyPatients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#getNewMedicaidPatientPolicy()
   */
  @Override
  public String getNewMedicaidPatientPolicy() {
    return newMedicaidPatientPolicy;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Patients#setNewMedicaidPatientPolicy(java.lang.String)
   */
  @Override
  public void setNewMedicaidPatientPolicy(String newMedicaidPatientPolicy) {
    this.newMedicaidPatientPolicy = newMedicaidPatientPolicy;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((MedicaidMonthlyPatients == null) ? 0 : MedicaidMonthlyPatients.hashCode());
    result = prime * result + ((acceptsNewMedicaidPatients == null) ? 0 : acceptsNewMedicaidPatients.hashCode());
    result = prime * result + ((acceptsNewPatients == null) ? 0 : acceptsNewPatients.hashCode());
    result = prime * result + ((hygienistMonthlyPatients == null) ? 0 : hygienistMonthlyPatients.hashCode());
    result = prime * result + ((medicaidPatientsConverted == null) ? 0 : medicaidPatientsConverted.hashCode());
    result = prime * result + ((newMedicaidPatientPolicy == null) ? 0 : newMedicaidPatientPolicy.hashCode());
    result = prime * result + ((providerMonthlyPatients == null) ? 0 : providerMonthlyPatients.hashCode());
    result = prime * result + ((underEighteens == null) ? 0 : underEighteens.hashCode());
    result = prime * result + ((underThrees == null) ? 0 : underThrees.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    PatientsImpl other = (PatientsImpl) obj;
    if (MedicaidMonthlyPatients == null) {
      if (other.MedicaidMonthlyPatients != null)
        return false;
    } else if (!MedicaidMonthlyPatients.equals(other.MedicaidMonthlyPatients))
      return false;
    if (acceptsNewMedicaidPatients == null) {
      if (other.acceptsNewMedicaidPatients != null)
        return false;
    } else if (!acceptsNewMedicaidPatients.equals(other.acceptsNewMedicaidPatients))
      return false;
    if (acceptsNewPatients == null) {
      if (other.acceptsNewPatients != null)
        return false;
    } else if (!acceptsNewPatients.equals(other.acceptsNewPatients))
      return false;
    if (hygienistMonthlyPatients == null) {
      if (other.hygienistMonthlyPatients != null)
        return false;
    } else if (!hygienistMonthlyPatients.equals(other.hygienistMonthlyPatients))
      return false;
    if (medicaidPatientsConverted == null) {
      if (other.medicaidPatientsConverted != null)
        return false;
    } else if (!medicaidPatientsConverted.equals(other.medicaidPatientsConverted))
      return false;
    if (newMedicaidPatientPolicy == null) {
      if (other.newMedicaidPatientPolicy != null)
        return false;
    } else if (!newMedicaidPatientPolicy.equals(other.newMedicaidPatientPolicy))
      return false;
    if (providerMonthlyPatients == null) {
      if (other.providerMonthlyPatients != null)
        return false;
    } else if (!providerMonthlyPatients.equals(other.providerMonthlyPatients))
      return false;
    if (underEighteens == null) {
      if (other.underEighteens != null)
        return false;
    } else if (!underEighteens.equals(other.underEighteens))
      return false;
    if (underThrees == null) {
      if (other.underThrees != null)
        return false;
    } else if (!underThrees.equals(other.underThrees))
      return false;
    return true;
  }

}
