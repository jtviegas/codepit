package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ClinicMatchImpl.class)
public interface ClinicMatch extends Serializable {

  @JsonProperty("DataOwnerId")
  @ApiModelProperty(required = true)
  @NotNull
  Long getDataOwnerId();

  @JsonProperty("DataOwnerId")
  @ApiModelProperty(required = true)
  void setDataOwnerId(Long id);

  @JsonProperty("Address")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  NewAddress getAddress();

  @JsonProperty("Address")
  @ApiModelProperty(required = true)
  void setAddress(NewAddress address);

  @JsonProperty("Phone")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  NewPhoneContact getPhone();

  @JsonProperty("Phone")
  @ApiModelProperty(required = true)
  void setPhone(NewPhoneContact phone);

}
