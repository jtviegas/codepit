package com.anthem.specialty.provider.datamodel.dto;
// Generated 01-Dec-2017 15:03:23 by Hibernate Tools 5.2.6.Final

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProviderSpecialtyImpl implements ProviderSpecialty {

  @JsonCreator
  public static ProviderSpecialty create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ProviderSpecialty impl = null;
    impl = mapper.readValue(json, ProviderSpecialtyImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private SpecialtyType specialtyCode;

  private String certifyingBoardId;

  private LocalDate eligibleFrom;

  private LocalDate certifiedFrom;

  private LocalDate renewalDate;

  private Integer renewalPeriod;

  private String comments;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public ProviderSpecialtyImpl() {
    links = new ArrayList<Link>();
  }

  @Override
  public SpecialtyType getSpecialtyCode() {
    return specialtyCode;
  }

  @Override
  public void setSpecialtyCode(SpecialtyType specialtyCode) {
    this.specialtyCode = specialtyCode;
  }

  @Override
  public String getCertifyingBoardId() {
    return certifyingBoardId;
  }

  @Override
  public void setCertifyingBoardId(String certifyingBoardId) {
    this.certifyingBoardId = certifyingBoardId;
  }

  @Override
  public LocalDate getEligibleFrom() {
    return eligibleFrom;
  }

  @Override
  public void setEligibleFrom(LocalDate effectiveFrom) {
    this.eligibleFrom = effectiveFrom;
  }

  @Override
  public LocalDate getCertifiedFrom() {
    return certifiedFrom;
  }

  @Override
  public void setCertifiedFrom(LocalDate certifiedFrom) {
    this.certifiedFrom = certifiedFrom;
  }

  @Override
  public LocalDate getRenewalDate() {
    return renewalDate;
  }

  @Override
  public void setRenewalDate(LocalDate renewalDate) {
    this.renewalDate = renewalDate;
  }

  @Override
  public Integer getRenewalPeriod() {
    return renewalPeriod;
  }

  @Override
  public void setRenewalPeriod(Integer renewalPeriod) {
    this.renewalPeriod = renewalPeriod;
  }

  @Override
  public String getComments() {
    return comments;
  }

  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((certifiedFrom == null) ? 0 : certifiedFrom.hashCode());
    result = prime * result + ((certifyingBoardId == null) ? 0 : certifyingBoardId.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((eligibleFrom == null) ? 0 : eligibleFrom.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((renewalDate == null) ? 0 : renewalDate.hashCode());
    result = prime * result + ((renewalPeriod == null) ? 0 : renewalPeriod.hashCode());
    result = prime * result + ((specialtyCode == null) ? 0 : specialtyCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ProviderSpecialtyImpl other = (ProviderSpecialtyImpl) obj;
    if (certifiedFrom == null) {
      if (other.certifiedFrom != null)
        return false;
    } else if (!certifiedFrom.equals(other.certifiedFrom))
      return false;
    if (certifyingBoardId == null) {
      if (other.certifyingBoardId != null)
        return false;
    } else if (!certifyingBoardId.equals(other.certifyingBoardId))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (eligibleFrom == null) {
      if (other.eligibleFrom != null)
        return false;
    } else if (!eligibleFrom.equals(other.eligibleFrom))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (renewalDate == null) {
      if (other.renewalDate != null)
        return false;
    } else if (!renewalDate.equals(other.renewalDate))
      return false;
    if (renewalPeriod == null) {
      if (other.renewalPeriod != null)
        return false;
    } else if (!renewalPeriod.equals(other.renewalPeriod))
      return false;
    if (specialtyCode == null) {
      if (other.specialtyCode != null)
        return false;
    } else if (!specialtyCode.equals(other.specialtyCode))
      return false;
    return true;
  }

}
