package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewW9Impl implements NewW9 {

  @JsonCreator
  public static NewW9 create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewW9 impl = null;
    impl = mapper.readValue(json, NewW9Impl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private Long dataOwnerId;

  private String tin;

  private TinType type;

  private String irsName;

  private String submittedBy;

  private LocalDate received;

  private LocalDate byPhone;

  private EffectivePeriod effective;

  private Boolean corporatePayment = Boolean.FALSE;

  private Boolean backupWithholdingTax = Boolean.FALSE;

  private Boolean taxExempt = Boolean.FALSE;

  private Boolean delegatedCreditAgreement = Boolean.FALSE;

  public NewW9Impl() {
    this.type = TinType.EIN;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getTin()
   */
  @Override
  public String getTin() {
    return tin;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setTin(java.lang.String)
   */
  @Override
  public void setTin(String tin) {
    this.tin = tin;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getType()
   */
  @Override
  public TinType getType() {
    return type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setType(com.anthem.specialty.provider.datamodel.dto.newdtos.
   * TinType)
   */
  @Override
  public void setType(TinType type) {
    this.type = type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getIrsName()
   */
  @Override
  public String getIrsName() {
    return irsName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setIrsName(java.lang.String)
   */
  @Override
  public void setIrsName(String irsName) {
    this.irsName = irsName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getSubmittedBy()
   */
  @Override
  public String getSubmittedBy() {
    return submittedBy;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setSubmittedBy(java.lang.String)
   */
  @Override
  public void setSubmittedBy(String submittedBy) {
    this.submittedBy = submittedBy;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getReceived()
   */
  @Override
  public LocalDate getReceived() {
    return received;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setReceived(java.util.Date)
   */
  @Override
  public void setReceived(LocalDate received) {
    this.received = received;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getByPhone()
   */
  @Override
  public LocalDate getByPhone() {
    return byPhone;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setByPhone(java.util.Date)
   */
  @Override
  public void setByPhone(LocalDate byPhone) {
    this.byPhone = byPhone;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#getEffective()
   */
  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewW9#setEffective(com.anthem.specialty.provider.datamodel.dto.newdtos.
   * EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#isCorporatePayment()
   */
  @Override
  public Boolean isCorporatePayment() {
    return corporatePayment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setCorporatePayment(boolean)
   */
  @Override
  public void setCorporatePayment(Boolean corporatePayment) {
    this.corporatePayment = corporatePayment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#isBackupWithholdingTax()
   */
  @Override
  public Boolean isBackupWithholdingTax() {
    return backupWithholdingTax;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setBackupWithholdingTax(boolean)
   */
  @Override
  public void setBackupWithholdingTax(Boolean backupWithholdingTax) {
    this.backupWithholdingTax = backupWithholdingTax;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#isTaxExempt()
   */
  @Override
  public Boolean isTaxExempt() {
    return taxExempt;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setTaxExempt(boolean)
   */
  @Override
  public void setTaxExempt(Boolean taxExempt) {
    this.taxExempt = taxExempt;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#isDelegatedCreditAgreement()
   */
  @Override
  public Boolean isDelegatedCreditAgreement() {
    return delegatedCreditAgreement;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewW9#setDelegatedCreditAgreement(boolean)
   */
  @Override
  public void setDelegatedCreditAgreement(Boolean delegatedCreditAgreement) {
    this.delegatedCreditAgreement = delegatedCreditAgreement;
  }

  @Override
  public @NotNull Long getDataOwnerId() {
    return dataOwnerId;
  }

  @Override
  public void setDataOwnerId(Long o) {
    this.dataOwnerId = o;
  }

  public void setCorporatePayment(boolean corporatePayment) {
    this.corporatePayment = corporatePayment;
  }

  public void setBackupWithholdingTax(boolean backupWithholdingTax) {
    this.backupWithholdingTax = backupWithholdingTax;
  }

  public void setTaxExempt(boolean taxExempt) {
    this.taxExempt = taxExempt;
  }

  public void setDelegatedCreditAgreement(boolean delegatedCreditAgreement) {
    this.delegatedCreditAgreement = delegatedCreditAgreement;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (backupWithholdingTax ? 1231 : 1237);
    result = prime * result + ((byPhone == null) ? 0 : byPhone.hashCode());
    result = prime * result + (corporatePayment ? 1231 : 1237);
    result = prime * result + ((dataOwnerId == null) ? 0 : dataOwnerId.hashCode());
    result = prime * result + (delegatedCreditAgreement ? 1231 : 1237);
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((irsName == null) ? 0 : irsName.hashCode());
    result = prime * result + ((received == null) ? 0 : received.hashCode());
    result = prime * result + ((submittedBy == null) ? 0 : submittedBy.hashCode());
    result = prime * result + (taxExempt ? 1231 : 1237);
    result = prime * result + ((tin == null) ? 0 : tin.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewW9Impl other = (NewW9Impl) obj;
    if (backupWithholdingTax != other.backupWithholdingTax)
      return false;
    if (byPhone == null) {
      if (other.byPhone != null)
        return false;
    } else if (!byPhone.equals(other.byPhone))
      return false;
    if (corporatePayment != other.corporatePayment)
      return false;
    if (dataOwnerId == null) {
      if (other.dataOwnerId != null)
        return false;
    } else if (!dataOwnerId.equals(other.dataOwnerId))
      return false;
    if (delegatedCreditAgreement != other.delegatedCreditAgreement)
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (irsName == null) {
      if (other.irsName != null)
        return false;
    } else if (!irsName.equals(other.irsName))
      return false;
    if (received == null) {
      if (other.received != null)
        return false;
    } else if (!received.equals(other.received))
      return false;
    if (submittedBy == null) {
      if (other.submittedBy != null)
        return false;
    } else if (!submittedBy.equals(other.submittedBy))
      return false;
    if (taxExempt != other.taxExempt)
      return false;
    if (tin == null) {
      if (other.tin != null)
        return false;
    } else if (!tin.equals(other.tin))
      return false;
    if (type != other.type)
      return false;
    return true;
  }

}
