package com.anthem.specialty.provider.datamodel.dto;

import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ClinicImpl.class)
public interface Clinic extends DataEntity {

  @JsonProperty("StateMedicaidNo")
  @ApiModelProperty(required = false)
  String getStateMedicaidNo();

  @JsonProperty("StateMedicaidNo")
  @ApiModelProperty(required = false)
  void setStateMedicaidNo(String stateMedicaidNo);

  @JsonProperty("CommonName")
  @ApiModelProperty(required = false)
  String getCommonName();

  @JsonProperty("CommonName")
  @ApiModelProperty(required = false)
  void setCommonName(String commonName);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

  @JsonProperty("ContactName")
  @ApiModelProperty(required = false)
  String getContactName();

  @JsonProperty("ContactName")
  @ApiModelProperty(required = false)
  void setContactName(String contactName);

  @JsonProperty("PaymentContactName")
  @ApiModelProperty(required = false)
  String getPaymentName();

  @JsonProperty("PaymentContactName")
  @ApiModelProperty(required = false)
  void setPaymentName(String paymentName);

  @JsonProperty("UcrRegionCode")
  @ApiModelProperty(required = false)
  Character getUcrRegionCode();

  @JsonProperty("UcrRegionCode")
  @ApiModelProperty(required = false)
  void setUcrRegionCode(Character ucrRegionCode);

  @JsonProperty("GeneralInsurance")
  @ApiModelProperty(required = false)
  @Valid
  GeneralInsurance getGeneralInsurance();

  @JsonProperty("GeneralInsurance")
  @ApiModelProperty(required = false)
  void setGeneralInsurance(GeneralInsurance generalInsurance);

  @JsonProperty("Services")
  @ApiModelProperty(required = false)
  Services getServices();

  @JsonProperty("Services")
  @ApiModelProperty(required = false)
  void setServices(Services services);

  @JsonProperty("Staffing")
  @ApiModelProperty(required = false)
  Staffing getStaffing();

  @JsonProperty("Staffing")
  @ApiModelProperty(required = false)
  void setStaffing(Staffing staffing);

  @JsonProperty("ReimburseContinuedEducation")
  @ApiModelProperty(required = false)
  Boolean getReimburseContinuedEducation();

  @JsonProperty("ReimburseContinuedEducation")
  @ApiModelProperty(required = false)
  void setReimburseContinuedEducation(Boolean reimburseContinuedEducation);

  @JsonProperty("PracticeManagementSoftware")
  @ApiModelProperty(required = false)
  String getPracticeManagementSoftware();

  @JsonProperty("PracticeManagementSoftware")
  @ApiModelProperty(required = false)
  void setPracticeManagementSoftware(String practiceManagementSoftware);

  @JsonProperty("ElectronicClaimsSubmissionSupported")
  @ApiModelProperty(required = false)
  Boolean getElectronicClaimsSubmissionSupported();

  @JsonProperty("ElectronicClaimsSubmissionSupported")
  @ApiModelProperty(required = false)
  void setElectronicClaimsSubmissionSupported(Boolean electronicClaimsSubmissionSupported);

  @JsonProperty("AlphabeticalSortBy")
  @ApiModelProperty(required = false)
  String getAlphabeticalSortBy();

  @JsonProperty("AlphabeticalSortBy")
  @ApiModelProperty(required = false)
  void setAlphabeticalSortBy(String alphabeticalSortBy);

  @JsonProperty("MARating")
  @ApiModelProperty(required = false)
  String getMaRating();

  @JsonProperty("MARating")
  @ApiModelProperty(required = false)
  void setMaRating(String maRating);

  @JsonProperty("EmailAddress")
  @ApiModelProperty(required = false)
  String getEmailAddress();

  @JsonProperty("EmailAddress")
  @ApiModelProperty(required = false)
  void setEmailAddress(String emailAddress);

  @JsonProperty("MemberEmailAddress")
  @ApiModelProperty(required = false)
  String getMemberEmailAddress();

  @JsonProperty("MemberEmailAddress")
  @ApiModelProperty(required = false)
  void setMemberEmailAddress(String memberEmailAddress);

  @JsonProperty("WebAddress")
  @ApiModelProperty(required = false)
  String getWebAddress();

  @JsonProperty("WebAddress")
  @ApiModelProperty(required = false)
  void setWebAddress(String webAddress);

  @JsonProperty("EssentialCommunityProvider")
  @ApiModelProperty(required = false)
  @Valid
  EssentialCommunityProvider getEssentialCommunityProvider();

  @JsonProperty("EssentialCommunityProvider")
  @ApiModelProperty(required = false)
  void setEssentialCommunityProvider(EssentialCommunityProvider essentialCommunityProvider);

  @JsonProperty("Patients")
  @ApiModelProperty(required = false)
  Patients getPatients();

  @JsonProperty("Patients")
  @ApiModelProperty(required = false)
  void setPatients(Patients patients);

  @JsonProperty("VisitedNursingHomes")
  @ApiModelProperty(required = false)
  String getVisitedNursingHomes();

  @JsonProperty("VisitedNursingHomes")
  @ApiModelProperty(required = false)
  void setVisitedNursingHomes(String visitedNursingHomes);

  @JsonProperty("EmergencyInstructions")
  @ApiModelProperty(required = false)
  Boolean getEmergencyInstructions();

  @JsonProperty("EmergencyInstructions")
  @ApiModelProperty(required = false)
  void setEmergencyInstructions(Boolean emergencyInstructions);

  @JsonProperty("WheelchairAccessible")
  @ApiModelProperty(required = false)
  Boolean getWheelchairAccessible();

  @JsonProperty("WheelchairAccessible")
  @ApiModelProperty(required = false)
  void setWheelchairAccessible(Boolean wheelchairAccessible);

  @JsonProperty("ProfessionalReviewUnderway")
  @ApiModelProperty(required = false)
  String getProfessionalReviewUnderway();

  @JsonProperty("ProfessionalReviewUnderway")
  @ApiModelProperty(required = false)
  void setProfessionalReviewUnderway(String professionalReviewUnderway);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

  @JsonProperty("Hours")
  @ApiModelProperty(required = false)
  @Valid
  List<OpeningHours> getHours();

  @JsonProperty("Hours")
  @ApiModelProperty(required = false)
  void setHours(List<OpeningHours> hours);

}