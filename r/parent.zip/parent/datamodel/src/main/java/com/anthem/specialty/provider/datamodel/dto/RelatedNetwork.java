package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedNetworkImpl.class)
public interface RelatedNetwork extends Relationship {
  @JsonProperty("Network")
  @ApiModelProperty(required = true)
  @NotNull
  RelatedNetworkItem getNetwork();

  @JsonProperty("Network")
  @ApiModelProperty(required = true)
  @NotNull
  void setNetwork(RelatedNetworkItem o);
}
