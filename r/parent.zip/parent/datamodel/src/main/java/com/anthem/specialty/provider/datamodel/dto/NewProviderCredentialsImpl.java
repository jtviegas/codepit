package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewProviderCredentialsImpl implements NewProviderCredentials {

  @JsonCreator
  public static NewProviderCredentials create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewProviderCredentials impl = null;
    impl = mapper.readValue(json, NewProviderCredentialsImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate credentialed;

  private Boolean licenseSuspended = Boolean.FALSE;

  private String licenseSuspendedComments;

  private Boolean disciplinaryAction = Boolean.FALSE;

  private String disciplinaryActionComments;

  private Boolean healthProblem = Boolean.FALSE;

  private String healthProblemComments;

  private Boolean felonyMisdemeanor = Boolean.FALSE;

  private String felonyMisdemeanorComments;

  private Boolean malpracticeExper = Boolean.FALSE;

  private String malpracticeExperComments;

  private Boolean deaRestricted = Boolean.FALSE;

  private String deaRestrictedComments;

  private String credentialingLevel;

  public NewProviderCredentialsImpl() {
  }

  @Override
  public LocalDate getCredentialed() {
    return credentialed;

  }

  @Override
  public void setCredentialed(LocalDate credentialed) {
    this.credentialed = credentialed;
  }

  @Override
  public Boolean getLicenseSuspended() {
    return licenseSuspended;

  }

  @Override
  public void setLicenseSuspended(Boolean licenseSuspended) {
    this.licenseSuspended = licenseSuspended;
  }

  @Override
  public String getLicenseSuspendedComments() {
    return licenseSuspendedComments;

  }

  @Override
  public void setLicenseSuspendedComments(String licenseSuspendedComments) {
    this.licenseSuspendedComments = licenseSuspendedComments;
  }

  @Override
  public Boolean getDisciplinaryAction() {
    return disciplinaryAction;
  }

  @Override
  public void setDisciplinaryAction(Boolean disciplinaryAction) {
    this.disciplinaryAction = disciplinaryAction;
  }

  @Override
  public String getDisciplinaryActionComments() {
    return disciplinaryActionComments;
  }

  @Override
  public void setDisciplinaryActionComments(String disciplinaryActionComments) {
    this.disciplinaryActionComments = disciplinaryActionComments;
  }

  @Override
  public Boolean getHealthProblem() {
    return healthProblem;

  }

  @Override
  public void setHealthProblem(Boolean healthProblem) {
    this.healthProblem = healthProblem;
  }

  @Override
  public String getHealthProblemComments() {
    return healthProblemComments;

  }

  @Override
  public void setHealthProblemComments(String healthProblemComments) {
    this.healthProblemComments = healthProblemComments;
  }

  @Override
  public Boolean getFelonyMisdemeanor() {
    return felonyMisdemeanor;

  }

  @Override
  public void setFelonyMisdemeanor(Boolean felonyMisdemeanor) {
    this.felonyMisdemeanor = felonyMisdemeanor;
  }

  @Override
  public String getFelonyMisdemeanorComments() {
    return felonyMisdemeanorComments;

  }

  @Override
  public void setFelonyMisdemeanorComments(String felonyMisdemeanorComments) {
    this.felonyMisdemeanorComments = felonyMisdemeanorComments;
  }

  @Override
  public Boolean getMalpracticeExper() {
    return malpracticeExper;

  }

  @Override
  public void setMalpracticeExper(Boolean malpracticeExper) {
    this.malpracticeExper = malpracticeExper;
  }

  @Override
  public String getMalpracticeExperComments() {
    return malpracticeExperComments;

  }

  @Override
  public void setMalpracticeExperComments(String malpracticeExperComments) {
    this.malpracticeExperComments = malpracticeExperComments;
  }

  @Override
  public Boolean getDeaRestricted() {
    return deaRestricted;

  }

  @Override
  public void setDeaRestricted(Boolean deaRestricted) {
    this.deaRestricted = deaRestricted;
  }

  @Override
  public String getDeaRestrictedComments() {
    return deaRestrictedComments;

  }

  @Override
  public void setDeaRestrictedComments(String deaRestrictedComments) {
    this.deaRestrictedComments = deaRestrictedComments;
  }

  @Override
  public String getCredentialingLevel() {
    return credentialingLevel;

  }

  @Override
  public void setCredentialingLevel(String credentialingLevel) {
    this.credentialingLevel = credentialingLevel;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((credentialed == null) ? 0 : credentialed.hashCode());
    result = prime * result + ((credentialingLevel == null) ? 0 : credentialingLevel.hashCode());
    result = prime * result + ((deaRestricted == null) ? 0 : deaRestricted.hashCode());
    result = prime * result + ((deaRestrictedComments == null) ? 0 : deaRestrictedComments.hashCode());
    result = prime * result + ((disciplinaryAction == null) ? 0 : disciplinaryAction.hashCode());
    result = prime * result + ((disciplinaryActionComments == null) ? 0 : disciplinaryActionComments.hashCode());
    result = prime * result + ((felonyMisdemeanor == null) ? 0 : felonyMisdemeanor.hashCode());
    result = prime * result + ((felonyMisdemeanorComments == null) ? 0 : felonyMisdemeanorComments.hashCode());
    result = prime * result + ((healthProblem == null) ? 0 : healthProblem.hashCode());
    result = prime * result + ((healthProblemComments == null) ? 0 : healthProblemComments.hashCode());
    result = prime * result + ((licenseSuspended == null) ? 0 : licenseSuspended.hashCode());
    result = prime * result + ((licenseSuspendedComments == null) ? 0 : licenseSuspendedComments.hashCode());
    result = prime * result + ((malpracticeExper == null) ? 0 : malpracticeExper.hashCode());
    result = prime * result + ((malpracticeExperComments == null) ? 0 : malpracticeExperComments.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewProviderCredentialsImpl other = (NewProviderCredentialsImpl) obj;
    if (credentialed == null) {
      if (other.credentialed != null)
        return false;
    } else if (!credentialed.equals(other.credentialed))
      return false;
    if (credentialingLevel == null) {
      if (other.credentialingLevel != null)
        return false;
    } else if (!credentialingLevel.equals(other.credentialingLevel))
      return false;
    if (deaRestricted == null) {
      if (other.deaRestricted != null)
        return false;
    } else if (!deaRestricted.equals(other.deaRestricted))
      return false;
    if (deaRestrictedComments == null) {
      if (other.deaRestrictedComments != null)
        return false;
    } else if (!deaRestrictedComments.equals(other.deaRestrictedComments))
      return false;
    if (disciplinaryAction == null) {
      if (other.disciplinaryAction != null)
        return false;
    } else if (!disciplinaryAction.equals(other.disciplinaryAction))
      return false;
    if (disciplinaryActionComments == null) {
      if (other.disciplinaryActionComments != null)
        return false;
    } else if (!disciplinaryActionComments.equals(other.disciplinaryActionComments))
      return false;
    if (felonyMisdemeanor == null) {
      if (other.felonyMisdemeanor != null)
        return false;
    } else if (!felonyMisdemeanor.equals(other.felonyMisdemeanor))
      return false;
    if (felonyMisdemeanorComments == null) {
      if (other.felonyMisdemeanorComments != null)
        return false;
    } else if (!felonyMisdemeanorComments.equals(other.felonyMisdemeanorComments))
      return false;
    if (healthProblem == null) {
      if (other.healthProblem != null)
        return false;
    } else if (!healthProblem.equals(other.healthProblem))
      return false;
    if (healthProblemComments == null) {
      if (other.healthProblemComments != null)
        return false;
    } else if (!healthProblemComments.equals(other.healthProblemComments))
      return false;
    if (licenseSuspended == null) {
      if (other.licenseSuspended != null)
        return false;
    } else if (!licenseSuspended.equals(other.licenseSuspended))
      return false;
    if (licenseSuspendedComments == null) {
      if (other.licenseSuspendedComments != null)
        return false;
    } else if (!licenseSuspendedComments.equals(other.licenseSuspendedComments))
      return false;
    if (malpracticeExper == null) {
      if (other.malpracticeExper != null)
        return false;
    } else if (!malpracticeExper.equals(other.malpracticeExper))
      return false;
    if (malpracticeExperComments == null) {
      if (other.malpracticeExperComments != null)
        return false;
    } else if (!malpracticeExperComments.equals(other.malpracticeExperComments))
      return false;
    return true;
  }

}
