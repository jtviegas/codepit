package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PhoneContactImpl implements PhoneContact {

  @JsonCreator
  public static PhoneContact create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    PhoneContact impl = null;
    impl = mapper.readValue(json, PhoneContactImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private PhoneContactType type;

  private String countryCode;

  private String cityCode;

  private String areaCode;

  private String accessCode;

  private String number;

  private String extension;

  private String display;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public PhoneContactImpl() {
    links = new ArrayList<Link>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getType()
   */
  @Override
  public PhoneContactType getType() {
    return type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setType(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.PhoneContactType)
   */
  @Override
  public void setType(PhoneContactType type) {
    this.type = type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getCountryCode()
   */
  @Override
  public String getCountryCode() {
    return countryCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setCountryCode(java.lang.String)
   */
  @Override
  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getCityCode()
   */
  @Override
  public String getCityCode() {
    return cityCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setCityCode(java.lang.String)
   */
  @Override
  public void setCityCode(String cityCode) {
    this.cityCode = cityCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getAreaCode()
   */
  @Override
  public String getAreaCode() {
    return areaCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setAreaCode(java.lang.String)
   */
  @Override
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getAccessCode()
   */
  @Override
  public String getAccessCode() {
    return accessCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setAccessCode(java.lang.String)
   */
  @Override
  public void setAccessCode(String accessCode) {
    this.accessCode = accessCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getNumber()
   */
  @Override
  public String getNumber() {
    return number;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setNumber(java.lang.String)
   */
  @Override
  public void setNumber(String number) {
    this.number = number;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#getExtension()
   */
  @Override
  public String getExtension() {
    return extension;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.PhoneContact#setExtension(java.lang.String)
   */
  @Override
  public void setExtension(String extension) {
    this.extension = extension;
  }

  public String getDisplay() {
    return display;
  }

  public void setDisplay(String display) {
    this.display = display;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((accessCode == null) ? 0 : accessCode.hashCode());
    result = prime * result + ((areaCode == null) ? 0 : areaCode.hashCode());
    result = prime * result + ((cityCode == null) ? 0 : cityCode.hashCode());
    result = prime * result + ((countryCode == null) ? 0 : countryCode.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((display == null) ? 0 : display.hashCode());
    result = prime * result + ((extension == null) ? 0 : extension.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((number == null) ? 0 : number.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    PhoneContactImpl other = (PhoneContactImpl) obj;
    if (accessCode == null) {
      if (other.accessCode != null)
        return false;
    } else if (!accessCode.equals(other.accessCode))
      return false;
    if (areaCode == null) {
      if (other.areaCode != null)
        return false;
    } else if (!areaCode.equals(other.areaCode))
      return false;
    if (cityCode == null) {
      if (other.cityCode != null)
        return false;
    } else if (!cityCode.equals(other.cityCode))
      return false;
    if (countryCode == null) {
      if (other.countryCode != null)
        return false;
    } else if (!countryCode.equals(other.countryCode))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (display == null) {
      if (other.display != null)
        return false;
    } else if (!display.equals(other.display))
      return false;
    if (extension == null) {
      if (other.extension != null)
        return false;
    } else if (!extension.equals(other.extension))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (number == null) {
      if (other.number != null)
        return false;
    } else if (!number.equals(other.number))
      return false;
    if (type != other.type)
      return false;
    return true;
  }

}
