package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author jviegas 'P': PRIMARY 'E': EMERGENCY 'A': AFTER_HOURS 'F': FAX
 */
public enum PhoneContactType {
  P('P'),
  E('E'),
  A('A'),
  F('F'),;

  private Character character;

  private PhoneContactType(Character character) {
    this.character = character;
  }

  @JsonIgnore
  public Character asChar() {
    return character;
  }

  @JsonIgnore
  public static PhoneContactType fromChar(Character c) {
    PhoneContactType r = null;
    for (PhoneContactType p : PhoneContactType.values()) {
      if (p.asChar().equals(c)) {
        r = p;
        break;
      }
    }
    return r;
  }

}
