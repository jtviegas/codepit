package com.anthem.specialty.provider.datamodel.dto;

import java.util.List;

public class NetworkBuilder {

  private final Network o;

  public NetworkBuilder(Long id, DataOwner dataOwner, String description, String shortDescription) {
    o = new NetworkImpl(id, dataOwner, description, shortDescription);
  }

  public Network build() {
    return o;
  }

  public NetworkBuilder withLinks(List<Link> links) {
    o.setLinks(links);
    return this;
  }

  public NetworkBuilder withManager(String manager) {
    o.setManager(manager);
    return this;
  }

  public NetworkBuilder withComments(String comments) {
    o.setComments(comments);
    return this;
  }

  public NetworkBuilder withCapitationPayment(Boolean capitationPayment) {
    o.setCapitationPayment(capitationPayment);
    return this;
  }

  public NetworkBuilder withCustomerServiceDisplayed(Boolean customerServiceDisplayed) {
    o.setCustomerServiceDisplayed(customerServiceDisplayed);
    return this;
  }

  public NetworkBuilder withEffective(EffectivePeriod effective) {
    o.setEffective(effective);
    return this;
  }

}
