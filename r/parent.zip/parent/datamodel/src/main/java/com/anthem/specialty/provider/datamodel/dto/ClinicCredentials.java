package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ClinicCredentialsImpl.class)
public interface ClinicCredentials extends DataEntity {
  @JsonProperty("Credentialed")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  @NotNull
  LocalDate getCredentialed();

  @JsonProperty("Credentialed")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  void setCredentialed(LocalDate credentialed);

  @JsonProperty("HandicapAccess")
  @ApiModelProperty(required = false)
  Boolean isHandicapAccess();

  @JsonProperty("HandicapAccess")
  @ApiModelProperty(required = false)
  void setHandicapAccess(Boolean handicapAccess);

  @JsonProperty("CPRTrained")
  @ApiModelProperty(required = false)
  Boolean isCprTrained();

  @JsonProperty("CPRTrained")
  @ApiModelProperty(required = false)
  void setCprTrained(Boolean cprTrained);

  @JsonProperty("EmergencyTrained")
  @ApiModelProperty(required = false)
  Boolean isEmergencyTrained();

  @JsonProperty("EmergencyTrained")
  @ApiModelProperty(required = false)
  void setEmergencyTrained(Boolean emergencyTrained);

  @JsonProperty("EmergencyKit")
  @ApiModelProperty(required = false)
  Boolean isEmergencyKit();

  @JsonProperty("EmergencyKit")
  @ApiModelProperty(required = false)
  void setEmergencyKit(Boolean emergencyKit);

  @JsonProperty("PublicTransport")
  @ApiModelProperty(required = false)
  Boolean isPublicTransport();

  @JsonProperty("PublicTransport")
  @ApiModelProperty(required = false)
  void setPublicTransport(Boolean publicTransport);

  @JsonProperty("HandicappedParking")
  @ApiModelProperty(required = false)
  Boolean isHadicappedParking();

  @JsonProperty("HandicappedParking")
  @ApiModelProperty(required = false)
  void setHadicappedParking(Boolean hadicappedParking);

  @JsonProperty("CDCAndOSHARulesCompliance")
  @ApiModelProperty(required = false)
  Boolean iscDCAndOSHARulesCompliance();

  @JsonProperty("CDCAndOSHARulesCompliance")
  @ApiModelProperty(required = false)
  void setcDCAndOSHARulesCompliance(Boolean cDCAndOSHARulesCompliance);

  @JsonProperty("DeptHealthRulesCompliance")
  @ApiModelProperty(required = false)
  Boolean isDeptHealthRulesCompliance();

  @JsonProperty("DeptHealthRulesCompliance")
  @ApiModelProperty(required = false)
  void setDeptHealthRulesCompliance(Boolean deptHealthRulesCompliance);

}