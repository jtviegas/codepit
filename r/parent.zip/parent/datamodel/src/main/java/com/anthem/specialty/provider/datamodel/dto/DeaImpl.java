package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DeaImpl implements Dea {

  @JsonCreator
  public static Dea create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Dea impl = null;
    impl = mapper.readValue(json, DeaImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String deaNumber;

  private LocalDate expiration;

  private String missingBecause;

  public DeaImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Dea#getDeaNumber()
   */
  @Override
  public String getDeaNumber() {
    return deaNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Dea#setDeaNumber(java.lang.String)
   */
  @Override
  public void setDeaNumber(String deaNumber) {
    this.deaNumber = deaNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Dea#getExpiration()
   */
  @Override
  public LocalDate getExpiration() {
    return expiration;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Dea#setExpiration(java.util.Date)
   */
  @Override
  public void setExpiration(LocalDate expiration) {
    this.expiration = expiration;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Dea#getMissingBecause()
   */
  @Override
  public String getMissingBecause() {
    return missingBecause;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Dea#setMissingBecause(java.lang.String)
   */
  @Override
  public void setMissingBecause(String missingBecause) {
    this.missingBecause = missingBecause;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((deaNumber == null) ? 0 : deaNumber.hashCode());
    result = prime * result + ((expiration == null) ? 0 : expiration.hashCode());
    result = prime * result + ((missingBecause == null) ? 0 : missingBecause.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    DeaImpl other = (DeaImpl) obj;
    if (deaNumber == null) {
      if (other.deaNumber != null)
        return false;
    } else if (!deaNumber.equals(other.deaNumber))
      return false;
    if (expiration == null) {
      if (other.expiration != null)
        return false;
    } else if (!expiration.equals(other.expiration))
      return false;
    if (missingBecause == null) {
      if (other.missingBecause != null)
        return false;
    } else if (!missingBecause.equals(other.missingBecause))
      return false;
    return true;
  }

}
