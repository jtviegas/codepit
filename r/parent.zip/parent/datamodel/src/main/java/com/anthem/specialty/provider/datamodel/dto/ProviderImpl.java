package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProviderImpl implements Provider {

  @JsonCreator
  public static Provider create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Provider impl = null;
    impl = mapper.readValue(json, ProviderImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String tin;

  private String stateProviderNo;

  private String namePrefix;

  private String firstName;

  private String middleName;

  private String lastName;

  private String nameSuffix;

  private Gender gender;

  private LocalDate birthDate;

  private String schoolOfDentistry;

  private LocalDate graduationYear;

  private LocalDate practiceEffectiveFrom;

  private String comments;

  private ProviderTermination terminated;

  private LocalDate retired;

  private LocalDate deceased;

  private EffectivePeriod effective;

  private String medicareNo;

  private LocalDate firstBnotice;

  private LocalDate secondBnotice;

  private MalpracticeInsurance malpracticeInsurance;

  private Boolean consentFormSigned;

  private LocalDate consentSignatureDate;

  private String noDEANumericReason;

  private String specialtySchool;

  private LocalDate anesthesiaCertificateExpiry;

  private String emailAddress;

  private Boolean collaborationAgreement;

  private String paraLicenseNumber;

  private String paraLicenseState;

  private Integer specialtyGradYear;

  private LocalDate FWAComplianceDate;

  private String degree1;

  private String degree2;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public ProviderImpl() {
    links = new ArrayList<Link>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getTin()
   */
  @Override
  public String getTin() {
    return tin;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setTin(java.lang.String)
   */
  @Override
  public void setTin(String tin) {
    this.tin = tin;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getStateProviderNo()
   */
  @Override
  public String getStateProviderNo() {
    return stateProviderNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setStateProviderNo(java.lang.String)
   */
  @Override
  public void setStateProviderNo(String stateProviderNo) {
    this.stateProviderNo = stateProviderNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getNamePrefix()
   */
  @Override
  public String getNamePrefix() {
    return namePrefix;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setNamePrefix(java.lang.String)
   */
  @Override
  public void setNamePrefix(String namePrefix) {
    this.namePrefix = namePrefix;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getFirstName()
   */
  @Override
  public String getFirstName() {
    return firstName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setFirstName(java.lang.String)
   */
  @Override
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getMiddleName()
   */
  @Override
  public String getMiddleName() {
    return middleName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setMiddleName(java.lang.String)
   */
  @Override
  public void setMiddleName(String middleName) {
    this.middleName = middleName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getLastName()
   */
  @Override
  public String getLastName() {
    return lastName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setLastName(java.lang.String)
   */
  @Override
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getNameSuffix()
   */
  @Override
  public String getNameSuffix() {
    return nameSuffix;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setNameSuffix(java.lang.String)
   */
  @Override
  public void setNameSuffix(String nameSuffix) {
    this.nameSuffix = nameSuffix;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getGender()
   */
  @Override
  public Gender getGender() {
    return gender;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.Provider#setGender(com.anthem.specialty.provider.datamodel.dto.newdtos.
   * Gender)
   */
  @Override
  public void setGender(Gender gender) {
    this.gender = gender;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getBirthDate()
   */
  @Override
  public LocalDate getBirthDate() {
    return birthDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setBirthDate(java.util.Date)
   */
  @Override
  public void setBirthDate(LocalDate birthDate) {
    this.birthDate = birthDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getSchoolOfDentistry()
   */
  @Override
  public String getSchoolOfDentistry() {
    return schoolOfDentistry;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setSchoolOfDentistry(java.lang.String)
   */
  @Override
  public void setSchoolOfDentistry(String schoolOfDentistry) {
    this.schoolOfDentistry = schoolOfDentistry;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getGraduationYear()
   */
  @Override
  public LocalDate getGraduationYear() {
    return graduationYear;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setGraduationYear(java.util.Date)
   */
  @Override
  public void setGraduationYear(LocalDate graduationYear) {
    this.graduationYear = graduationYear;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getPracticeEffectiveFrom()
   */
  @Override
  public LocalDate getPracticeEffectiveFrom() {
    return practiceEffectiveFrom;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setPracticeEffectiveFrom(java.util.Date)
   */
  @Override
  public void setPracticeEffectiveFrom(LocalDate practiceEffectiveFrom) {
    this.practiceEffectiveFrom = practiceEffectiveFrom;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getComments()
   */
  @Override
  public String getComments() {
    return comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setComments(java.lang.String)
   */
  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getRetired()
   */
  @Override
  public LocalDate getRetired() {
    return retired;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setRetired(java.util.Date)
   */
  @Override
  public void setRetired(LocalDate retired) {
    this.retired = retired;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getDeceased()
   */
  @Override
  public LocalDate getDeceased() {
    return deceased;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setDeceased(java.util.Date)
   */
  @Override
  public void setDeceased(LocalDate deceased) {
    this.deceased = deceased;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getMedicareNo()
   */
  @Override
  public String getMedicareNo() {
    return medicareNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setMedicareNo(java.lang.String)
   */
  @Override
  public void setMedicareNo(String medicareNo) {
    this.medicareNo = medicareNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getFirstBnotice()
   */
  @Override
  public LocalDate getFirstBnotice() {
    return firstBnotice;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setFirstBnotice(java.util.Date)
   */
  @Override
  public void setFirstBnotice(LocalDate firstBnotice) {
    this.firstBnotice = firstBnotice;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getSecondBnotice()
   */
  @Override
  public LocalDate getSecondBnotice() {
    return secondBnotice;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setSecondBnotice(java.util.Date)
   */
  @Override
  public void setSecondBnotice(LocalDate secondBnotice) {
    this.secondBnotice = secondBnotice;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getConsentSignatureDate()
   */
  @Override
  public LocalDate getConsentSignatureDate() {
    return consentSignatureDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setConsentSignatureDate(java.util.Date)
   */
  @Override
  public void setConsentSignatureDate(LocalDate consentSignatureDate) {
    this.consentSignatureDate = consentSignatureDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getSpecialtySchool()
   */
  @Override
  public String getSpecialtySchool() {
    return specialtySchool;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setSpecialtySchool(java.lang.String)
   */
  @Override
  public void setSpecialtySchool(String specialtySchool) {
    this.specialtySchool = specialtySchool;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getAnesthesiaCertificateExpiry()
   */
  @Override
  public LocalDate getAnesthesiaCertificateExpiry() {
    return anesthesiaCertificateExpiry;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setAnesthesiaCertificateExpiry(java.util.Date)
   */
  @Override
  public void setAnesthesiaCertificateExpiry(LocalDate anesthesiaCertificateExpiry) {
    this.anesthesiaCertificateExpiry = anesthesiaCertificateExpiry;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getEmailAddress()
   */
  @Override
  public String getEmailAddress() {
    return emailAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setEmailAddress(java.lang.String)
   */
  @Override
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getParaLicenseNumber()
   */
  @Override
  public String getParaLicenseNumber() {
    return paraLicenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setParaLicenseNumber(java.lang.String)
   */
  @Override
  public void setParaLicenseNumber(String paraLicenseNumber) {
    this.paraLicenseNumber = paraLicenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getParaLicenseState()
   */
  @Override
  public String getParaLicenseState() {
    return paraLicenseState;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setParaLicenseState(java.lang.String)
   */
  @Override
  public void setParaLicenseState(String paraLicenseState) {
    this.paraLicenseState = paraLicenseState;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getSpecialtyGradYear()
   */
  @Override
  public Integer getSpecialtyGradYear() {
    return specialtyGradYear;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setSpecialtyGradYear(java.lang.Integer)
   */
  @Override
  public void setSpecialtyGradYear(Integer specialtyGradYear) {
    this.specialtyGradYear = specialtyGradYear;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getFWAComplianceDate()
   */
  @Override
  public LocalDate getFWAComplianceDate() {
    return FWAComplianceDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setFWAComplianceDate(java.util.Date)
   */
  @Override
  public void setFWAComplianceDate(LocalDate FWAComplianceDate) {
    this.FWAComplianceDate = FWAComplianceDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getDegree1()
   */
  @Override
  public String getDegree1() {
    return degree1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setDegree1(java.lang.String)
   */
  @Override
  public void setDegree1(String degree1) {
    this.degree1 = degree1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getDegree2()
   */
  @Override
  public String getDegree2() {
    return degree2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setDegree2(java.lang.String)
   */
  @Override
  public void setDegree2(String degree2) {
    this.degree2 = degree2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getTerminated()
   */
  @Override
  public ProviderTermination getTerminated() {
    return terminated;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.Provider#setTerminated(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.ProviderTermination)
   */
  @Override
  public void setTerminated(ProviderTermination terminated) {
    this.terminated = terminated;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getEffective()
   */
  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setEffective(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getMalpracticeInsurance()
   */
  @Override
  public MalpracticeInsurance getMalpracticeInsurance() {
    return malpracticeInsurance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setMalpracticeInsurance(com.anthem.specialty.provider.
   * datamodel.dto.newdtos.MalpracticeInsurance)
   */
  @Override
  public void setMalpracticeInsurance(MalpracticeInsurance malpracticeInsurance) {
    this.malpracticeInsurance = malpracticeInsurance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getConsentFormSigned()
   */
  @Override
  public Boolean getConsentFormSigned() {
    return consentFormSigned;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setConsentFormSigned(java.lang.Boolean)
   */
  @Override
  public void setConsentFormSigned(Boolean consentFormSigned) {
    this.consentFormSigned = consentFormSigned;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getNoDEANumericReason()
   */
  @Override
  public String getNoDEANumericReason() {
    return noDEANumericReason;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setNoDEANumericReason(java.lang.String)
   */
  @Override
  public void setNoDEANumericReason(String noDEANumericReason) {
    this.noDEANumericReason = noDEANumericReason;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#getCollaborationAgreement()
   */
  @Override
  public Boolean getCollaborationAgreement() {
    return collaborationAgreement;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Provider#setCollaborationAgreement(boolean)
   */
  @Override
  public void setCollaborationAgreement(Boolean collaborationAgreement) {
    this.collaborationAgreement = collaborationAgreement;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((FWAComplianceDate == null) ? 0 : FWAComplianceDate.hashCode());
    result = prime * result + ((anesthesiaCertificateExpiry == null) ? 0 : anesthesiaCertificateExpiry.hashCode());
    result = prime * result + ((birthDate == null) ? 0 : birthDate.hashCode());
    result = prime * result + ((collaborationAgreement == null) ? 0 : collaborationAgreement.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((consentFormSigned == null) ? 0 : consentFormSigned.hashCode());
    result = prime * result + ((consentSignatureDate == null) ? 0 : consentSignatureDate.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((deceased == null) ? 0 : deceased.hashCode());
    result = prime * result + ((degree1 == null) ? 0 : degree1.hashCode());
    result = prime * result + ((degree2 == null) ? 0 : degree2.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
    result = prime * result + ((firstBnotice == null) ? 0 : firstBnotice.hashCode());
    result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
    result = prime * result + ((gender == null) ? 0 : gender.hashCode());
    result = prime * result + ((graduationYear == null) ? 0 : graduationYear.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((malpracticeInsurance == null) ? 0 : malpracticeInsurance.hashCode());
    result = prime * result + ((medicareNo == null) ? 0 : medicareNo.hashCode());
    result = prime * result + ((middleName == null) ? 0 : middleName.hashCode());
    result = prime * result + ((namePrefix == null) ? 0 : namePrefix.hashCode());
    result = prime * result + ((nameSuffix == null) ? 0 : nameSuffix.hashCode());
    result = prime * result + ((noDEANumericReason == null) ? 0 : noDEANumericReason.hashCode());
    result = prime * result + ((paraLicenseNumber == null) ? 0 : paraLicenseNumber.hashCode());
    result = prime * result + ((paraLicenseState == null) ? 0 : paraLicenseState.hashCode());
    result = prime * result + ((practiceEffectiveFrom == null) ? 0 : practiceEffectiveFrom.hashCode());
    result = prime * result + ((retired == null) ? 0 : retired.hashCode());
    result = prime * result + ((schoolOfDentistry == null) ? 0 : schoolOfDentistry.hashCode());
    result = prime * result + ((secondBnotice == null) ? 0 : secondBnotice.hashCode());
    result = prime * result + ((specialtyGradYear == null) ? 0 : specialtyGradYear.hashCode());
    result = prime * result + ((specialtySchool == null) ? 0 : specialtySchool.hashCode());
    result = prime * result + ((stateProviderNo == null) ? 0 : stateProviderNo.hashCode());
    result = prime * result + ((terminated == null) ? 0 : terminated.hashCode());
    result = prime * result + ((tin == null) ? 0 : tin.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ProviderImpl other = (ProviderImpl) obj;
    if (FWAComplianceDate == null) {
      if (other.FWAComplianceDate != null)
        return false;
    } else if (!FWAComplianceDate.equals(other.FWAComplianceDate))
      return false;
    if (anesthesiaCertificateExpiry == null) {
      if (other.anesthesiaCertificateExpiry != null)
        return false;
    } else if (!anesthesiaCertificateExpiry.equals(other.anesthesiaCertificateExpiry))
      return false;
    if (birthDate == null) {
      if (other.birthDate != null)
        return false;
    } else if (!birthDate.equals(other.birthDate))
      return false;
    if (collaborationAgreement == null) {
      if (other.collaborationAgreement != null)
        return false;
    } else if (!collaborationAgreement.equals(other.collaborationAgreement))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (consentFormSigned == null) {
      if (other.consentFormSigned != null)
        return false;
    } else if (!consentFormSigned.equals(other.consentFormSigned))
      return false;
    if (consentSignatureDate == null) {
      if (other.consentSignatureDate != null)
        return false;
    } else if (!consentSignatureDate.equals(other.consentSignatureDate))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (deceased == null) {
      if (other.deceased != null)
        return false;
    } else if (!deceased.equals(other.deceased))
      return false;
    if (degree1 == null) {
      if (other.degree1 != null)
        return false;
    } else if (!degree1.equals(other.degree1))
      return false;
    if (degree2 == null) {
      if (other.degree2 != null)
        return false;
    } else if (!degree2.equals(other.degree2))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (emailAddress == null) {
      if (other.emailAddress != null)
        return false;
    } else if (!emailAddress.equals(other.emailAddress))
      return false;
    if (firstBnotice == null) {
      if (other.firstBnotice != null)
        return false;
    } else if (!firstBnotice.equals(other.firstBnotice))
      return false;
    if (firstName == null) {
      if (other.firstName != null)
        return false;
    } else if (!firstName.equals(other.firstName))
      return false;
    if (gender != other.gender)
      return false;
    if (graduationYear == null) {
      if (other.graduationYear != null)
        return false;
    } else if (!graduationYear.equals(other.graduationYear))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (lastName == null) {
      if (other.lastName != null)
        return false;
    } else if (!lastName.equals(other.lastName))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (malpracticeInsurance == null) {
      if (other.malpracticeInsurance != null)
        return false;
    } else if (!malpracticeInsurance.equals(other.malpracticeInsurance))
      return false;
    if (medicareNo == null) {
      if (other.medicareNo != null)
        return false;
    } else if (!medicareNo.equals(other.medicareNo))
      return false;
    if (middleName == null) {
      if (other.middleName != null)
        return false;
    } else if (!middleName.equals(other.middleName))
      return false;
    if (namePrefix == null) {
      if (other.namePrefix != null)
        return false;
    } else if (!namePrefix.equals(other.namePrefix))
      return false;
    if (nameSuffix == null) {
      if (other.nameSuffix != null)
        return false;
    } else if (!nameSuffix.equals(other.nameSuffix))
      return false;
    if (noDEANumericReason == null) {
      if (other.noDEANumericReason != null)
        return false;
    } else if (!noDEANumericReason.equals(other.noDEANumericReason))
      return false;
    if (paraLicenseNumber == null) {
      if (other.paraLicenseNumber != null)
        return false;
    } else if (!paraLicenseNumber.equals(other.paraLicenseNumber))
      return false;
    if (paraLicenseState == null) {
      if (other.paraLicenseState != null)
        return false;
    } else if (!paraLicenseState.equals(other.paraLicenseState))
      return false;
    if (practiceEffectiveFrom == null) {
      if (other.practiceEffectiveFrom != null)
        return false;
    } else if (!practiceEffectiveFrom.equals(other.practiceEffectiveFrom))
      return false;
    if (retired == null) {
      if (other.retired != null)
        return false;
    } else if (!retired.equals(other.retired))
      return false;
    if (schoolOfDentistry == null) {
      if (other.schoolOfDentistry != null)
        return false;
    } else if (!schoolOfDentistry.equals(other.schoolOfDentistry))
      return false;
    if (secondBnotice == null) {
      if (other.secondBnotice != null)
        return false;
    } else if (!secondBnotice.equals(other.secondBnotice))
      return false;
    if (specialtyGradYear == null) {
      if (other.specialtyGradYear != null)
        return false;
    } else if (!specialtyGradYear.equals(other.specialtyGradYear))
      return false;
    if (specialtySchool == null) {
      if (other.specialtySchool != null)
        return false;
    } else if (!specialtySchool.equals(other.specialtySchool))
      return false;
    if (stateProviderNo == null) {
      if (other.stateProviderNo != null)
        return false;
    } else if (!stateProviderNo.equals(other.stateProviderNo))
      return false;
    if (terminated == null) {
      if (other.terminated != null)
        return false;
    } else if (!terminated.equals(other.terminated))
      return false;
    if (tin == null) {
      if (other.tin != null)
        return false;
    } else if (!tin.equals(other.tin))
      return false;
    return true;
  }

}
