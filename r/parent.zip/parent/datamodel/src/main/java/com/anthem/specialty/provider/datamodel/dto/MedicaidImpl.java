package com.anthem.specialty.provider.datamodel.dto;
// Generated 01-Dec-2017 15:03:23 by Hibernate Tools 5.2.6.Final

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MedicaidImpl implements Medicaid {

  @JsonCreator
  public static Medicaid create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Medicaid impl = null;
    impl = mapper.readValue(json, MedicaidImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String number;

  private String state;

  public MedicaidImpl() {
  }

  @Override
  public String getNumber() {
    return number;

  }

  @Override
  public void setNumber(String number) {
    this.number = number;
  }

  @Override
  public String getState() {
    return state;

  }

  @Override
  public void setState(String state) {
    this.state = state;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((number == null) ? 0 : number.hashCode());
    result = prime * result + ((state == null) ? 0 : state.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MedicaidImpl other = (MedicaidImpl) obj;
    if (number == null) {
      if (other.number != null)
        return false;
    } else if (!number.equals(other.number))
      return false;
    if (state == null) {
      if (other.state != null)
        return false;
    } else if (!state.equals(other.state))
      return false;
    return true;
  }

}
