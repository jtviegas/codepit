package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewProviderClinicImpl implements NewProviderClinic {

  @JsonCreator
  public static NewProviderClinic create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewProviderClinic impl = null;
    impl = mapper.readValue(json, NewProviderClinicImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private List<OpeningHours> hours;

  private String comments;

  private Boolean clearLicenseNumber = Boolean.FALSE;

  private Boolean providerSpecialistClinic = Boolean.FALSE;

  private Character providerRelationship;

  private Character payClinicProvider;

  private Boolean deltaPrecertified = Boolean.FALSE;

  private Boolean corporatePayment = Boolean.FALSE;

  private Boolean witholdPayments = Boolean.FALSE;

  private Boolean providerCob = Boolean.FALSE;

  private Bci bci;

  private Boolean providerClaimInReview = Boolean.FALSE;

  private Boolean professionalReviewUnderway = Boolean.FALSE;

  private EffectivePeriod effective;

  private CoreDataEntity clinic;

  public NewProviderClinicImpl() {
    hours = new ArrayList<OpeningHours>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getHours()
   */
  @Override
  public List<OpeningHours> getHours() {
    return hours;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setHours(java.util.List)
   */
  @Override
  public void setHours(List<OpeningHours> hours) {
    this.hours = hours;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getComments()
   */
  @Override
  public String getComments() {
    return comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setComments(java.lang.String)
   */
  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getProviderRelationship()
   */
  @Override
  public Character getProviderRelationship() {
    return providerRelationship;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setProviderRelationship(java.lang.Character)
   */
  @Override
  public void setProviderRelationship(Character providerRelationship) {
    this.providerRelationship = providerRelationship;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getPayClinicProvider()
   */
  @Override
  public Character getPayClinicProvider() {
    return payClinicProvider;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setPayClinicProvider(java.lang.Character)
   */
  @Override
  public void setPayClinicProvider(Character payClinicProvider) {
    this.payClinicProvider = payClinicProvider;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getClearLicenseNumber()
   */
  @Override
  public Boolean getClearLicenseNumber() {
    return clearLicenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setClearLicenseNumber(java.lang.Boolean)
   */
  @Override
  public void setClearLicenseNumber(Boolean clearLicenseNumber) {
    this.clearLicenseNumber = clearLicenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getProviderSpecialistClinic()
   */
  @Override
  public Boolean getProviderSpecialistClinic() {
    return providerSpecialistClinic;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setProviderSpecialistClinic(java.lang.Boolean)
   */
  @Override
  public void setProviderSpecialistClinic(Boolean providerSpecialistClinic) {
    this.providerSpecialistClinic = providerSpecialistClinic;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getDeltaPrecertified()
   */
  @Override
  public Boolean getDeltaPrecertified() {
    return deltaPrecertified;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setDeltaPrecertified(java.lang.Boolean)
   */
  @Override
  public void setDeltaPrecertified(Boolean deltaPrecertified) {
    this.deltaPrecertified = deltaPrecertified;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getCorporatePayment()
   */
  @Override
  public Boolean getCorporatePayment() {
    return corporatePayment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setCorporatePayment(java.lang.Boolean)
   */
  @Override
  public void setCorporatePayment(Boolean corporatePayment) {
    this.corporatePayment = corporatePayment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getWitholdPayments()
   */
  @Override
  public Boolean getWitholdPayments() {
    return witholdPayments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setWitholdPayments(java.lang.Boolean)
   */
  @Override
  public void setWitholdPayments(Boolean witholdPayments) {
    this.witholdPayments = witholdPayments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getProviderCob()
   */
  @Override
  public Boolean getProviderCob() {
    return providerCob;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setProviderCob(java.lang.Boolean)
   */
  @Override
  public void setProviderCob(Boolean providerCob) {
    this.providerCob = providerCob;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getBci()
   */
  @Override
  public Bci getBci() {
    return bci;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setBci(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.Bci)
   */
  @Override
  public void setBci(Bci bci) {
    this.bci = bci;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getProviderClaimInReview()
   */
  @Override
  public Boolean getProviderClaimInReview() {
    return providerClaimInReview;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setProviderClaimInReview(java.lang.Boolean)
   */
  @Override
  public void setProviderClaimInReview(Boolean providerClaimInReview) {
    this.providerClaimInReview = providerClaimInReview;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#getProfessionalReviewUnderway()
   */
  @Override
  public Boolean getProfessionalReviewUnderway() {
    return professionalReviewUnderway;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderClinic#setProfessionalReviewUnderway(java.lang.Boolean)
   */
  @Override
  public void setProfessionalReviewUnderway(Boolean professionalReviewUnderway) {
    this.professionalReviewUnderway = professionalReviewUnderway;
  }

  @Override
  public @NotNull CoreDataEntity getClinic() {
    return clinic;
  }

  @Override
  public void setClinic(CoreDataEntity clinic) {
    this.clinic = clinic;
  }

  @Override
  public @NotNull EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((bci == null) ? 0 : bci.hashCode());
    result = prime * result + ((clearLicenseNumber == null) ? 0 : clearLicenseNumber.hashCode());
    result = prime * result + ((clinic == null) ? 0 : clinic.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((corporatePayment == null) ? 0 : corporatePayment.hashCode());
    result = prime * result + ((deltaPrecertified == null) ? 0 : deltaPrecertified.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((hours == null) ? 0 : hours.hashCode());
    result = prime * result + ((payClinicProvider == null) ? 0 : payClinicProvider.hashCode());
    result = prime * result + ((professionalReviewUnderway == null) ? 0 : professionalReviewUnderway.hashCode());
    result = prime * result + ((providerClaimInReview == null) ? 0 : providerClaimInReview.hashCode());
    result = prime * result + ((providerCob == null) ? 0 : providerCob.hashCode());
    result = prime * result + ((providerRelationship == null) ? 0 : providerRelationship.hashCode());
    result = prime * result + ((providerSpecialistClinic == null) ? 0 : providerSpecialistClinic.hashCode());
    result = prime * result + ((witholdPayments == null) ? 0 : witholdPayments.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewProviderClinicImpl other = (NewProviderClinicImpl) obj;
    if (bci == null) {
      if (other.bci != null)
        return false;
    } else if (!bci.equals(other.bci))
      return false;
    if (clearLicenseNumber == null) {
      if (other.clearLicenseNumber != null)
        return false;
    } else if (!clearLicenseNumber.equals(other.clearLicenseNumber))
      return false;
    if (clinic == null) {
      if (other.clinic != null)
        return false;
    } else if (!clinic.equals(other.clinic))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (corporatePayment == null) {
      if (other.corporatePayment != null)
        return false;
    } else if (!corporatePayment.equals(other.corporatePayment))
      return false;
    if (deltaPrecertified == null) {
      if (other.deltaPrecertified != null)
        return false;
    } else if (!deltaPrecertified.equals(other.deltaPrecertified))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (hours == null) {
      if (other.hours != null)
        return false;
    } else if (!hours.equals(other.hours))
      return false;
    if (payClinicProvider == null) {
      if (other.payClinicProvider != null)
        return false;
    } else if (!payClinicProvider.equals(other.payClinicProvider))
      return false;
    if (professionalReviewUnderway == null) {
      if (other.professionalReviewUnderway != null)
        return false;
    } else if (!professionalReviewUnderway.equals(other.professionalReviewUnderway))
      return false;
    if (providerClaimInReview == null) {
      if (other.providerClaimInReview != null)
        return false;
    } else if (!providerClaimInReview.equals(other.providerClaimInReview))
      return false;
    if (providerCob == null) {
      if (other.providerCob != null)
        return false;
    } else if (!providerCob.equals(other.providerCob))
      return false;
    if (providerRelationship == null) {
      if (other.providerRelationship != null)
        return false;
    } else if (!providerRelationship.equals(other.providerRelationship))
      return false;
    if (providerSpecialistClinic == null) {
      if (other.providerSpecialistClinic != null)
        return false;
    } else if (!providerSpecialistClinic.equals(other.providerSpecialistClinic))
      return false;
    if (witholdPayments == null) {
      if (other.witholdPayments != null)
        return false;
    } else if (!witholdPayments.equals(other.witholdPayments))
      return false;
    return true;
  }

}
