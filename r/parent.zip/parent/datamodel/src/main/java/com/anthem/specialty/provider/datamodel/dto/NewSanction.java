package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewSanctionImpl.class)
public interface NewSanction extends Serializable {
  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  RelatedClinic getClinic();

  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  void setClinic(RelatedClinic clinic);

  @JsonProperty("SanctionAgency")
  @ApiModelProperty(required = true)
  @NotNull
  String getSanctionAgency();

  @JsonProperty("SanctionAgency")
  @ApiModelProperty(required = true)
  void setSanctionAgency(String sanctionAgency);

  @JsonProperty("SanctionCode")
  @ApiModelProperty(required = true)
  @NotNull
  String getSanctionCode();

  @JsonProperty("SanctionCode")
  @ApiModelProperty(required = true)
  void setSanctionCode(String sanctionCode);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

}