package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ProviderRelationshipImpl implements ProviderRelationship {

  private static final long serialVersionUID = 1L;

  private CoreDataEntity provider;

  public ProviderRelationshipImpl() {
  }

  @Override
  public @Valid CoreDataEntity getProvider() {
    return provider;
  }

  @Override
  public void setProvider(CoreDataEntity provider) {
    this.provider = provider;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((provider == null) ? 0 : provider.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ProviderRelationshipImpl other = (ProviderRelationshipImpl) obj;
    if (provider == null) {
      if (other.provider != null)
        return false;
    } else if (!provider.equals(other.provider))
      return false;
    return true;
  }

}
