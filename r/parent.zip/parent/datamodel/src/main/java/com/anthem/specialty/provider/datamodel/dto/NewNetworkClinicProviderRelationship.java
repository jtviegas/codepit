package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewNetworkClinicProviderRelationshipImpl.class)
public interface NewNetworkClinicProviderRelationship extends NewProviderEffectiveRelationship {

  @JsonProperty("IsFrozen")
  @ApiModelProperty(required = false)
  Boolean isIsFrozen();

  @JsonProperty("IsFrozen")
  @ApiModelProperty(required = false)
  void setIsFrozen(Boolean isFrozen);

  @JsonProperty("FrozenFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getFrozenFrom();

  @JsonProperty("FrozenFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setFrozenFrom(LocalDate frozenFrom);

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  String getOfficeNumber();

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  void setOfficeNumber(String officeNumber);

  @JsonProperty("InDirectory")
  @ApiModelProperty(required = false)
  Boolean isInDirectory();

  @JsonProperty("InDirectory")
  @ApiModelProperty(required = false)
  void setInDirectory(Boolean inDirectory);

  @JsonProperty("HoldCodeApplied")
  @ApiModelProperty(required = false)
  Boolean isHoldCodeApplied();

  @JsonProperty("HoldCodeApplied")
  @ApiModelProperty(required = false)
  void setHoldCodeApplied(Boolean holdCodeApplied);

  @JsonProperty("Terminated")
  @ApiModelProperty(required = false)
  @Valid
  NetworkProviderTermination getTerminated();

  @JsonProperty("Terminated")
  @ApiModelProperty(required = false)
  void setTerminated(NetworkProviderTermination terminated);

  @JsonProperty("OverrideExceptions")
  @ApiModelProperty(required = true)
  Boolean isOverrideExceptions();

  @JsonProperty("OverrideExceptions")
  @ApiModelProperty(required = true)
  void setOverrideExceptions(Boolean o);

}
