package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class HttpStatusResponseImpl implements HttpStatusResponse {

  private static final long serialVersionUID = 1L;

  private Integer code;

  private String info;

  @JsonCreator
  public static HttpStatusResponse create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    HttpStatusResponse impl = null;
    impl = mapper.readValue(json, HttpStatusResponse.class);
    return impl;
  }

  public HttpStatusResponseImpl() {
  }

  public HttpStatusResponseImpl(Integer code, String info) {
    this.code = code;
    this.info = info;
  }

  @Override
  public void setCode(Integer code) {
    if (code < 100 || code > 599)
      throw new IllegalArgumentException("Invalid HTTP status code " + code);
    this.code = code;
  }

  @Override
  public Integer getCode() {
    return this.code;
  }

  @Override
  public void setInfo(String info) {
    this.info = info;
  }

  @Override
  public String getInfo() {
    return this.info;
  }

}
