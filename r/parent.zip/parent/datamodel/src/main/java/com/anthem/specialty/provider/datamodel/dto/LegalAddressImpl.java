package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LegalAddressImpl implements LegalAddress {

  @JsonCreator
  public static LegalAddress create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    LegalAddress impl = null;
    impl = mapper.readValue(json, LegalAddressImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String line1;

  private String line2;

  private String line3;

  private String city;

  private String state;

  private String zipCode;

  private EffectivePeriod effective;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public LegalAddressImpl() {
    links = new ArrayList<Link>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getLine1()
   */
  @Override
  public String getLine1() {
    return line1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#setLine1(java.lang.String)
   */
  @Override
  public void setLine1(String line1) {
    this.line1 = line1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getLine2()
   */
  @Override
  public String getLine2() {
    return line2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#setLine2(java.lang.String)
   */
  @Override
  public void setLine2(String line2) {
    this.line2 = line2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getLine3()
   */
  @Override
  public String getLine3() {
    return line3;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#setLine3(java.lang.String)
   */
  @Override
  public void setLine3(String line3) {
    this.line3 = line3;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getCity()
   */
  @Override
  public String getCity() {
    return city;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#setCity(java.lang.String)
   */
  @Override
  public void setCity(String city) {
    this.city = city;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getState()
   */
  @Override
  public String getState() {
    return state;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#setState(java.lang.String)
   */
  @Override
  public void setState(String state) {
    this.state = state;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getZipCode()
   */
  @Override
  public String getZipCode() {
    return zipCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#setZipCode(java.lang.String)
   */
  @Override
  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.LegalAddress#getEffective()
   */
  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.LegalAddress#setEffective(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((city == null) ? 0 : city.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((line1 == null) ? 0 : line1.hashCode());
    result = prime * result + ((line2 == null) ? 0 : line2.hashCode());
    result = prime * result + ((line3 == null) ? 0 : line3.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((state == null) ? 0 : state.hashCode());
    result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    LegalAddressImpl other = (LegalAddressImpl) obj;
    if (city == null) {
      if (other.city != null)
        return false;
    } else if (!city.equals(other.city))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (line1 == null) {
      if (other.line1 != null)
        return false;
    } else if (!line1.equals(other.line1))
      return false;
    if (line2 == null) {
      if (other.line2 != null)
        return false;
    } else if (!line2.equals(other.line2))
      return false;
    if (line3 == null) {
      if (other.line3 != null)
        return false;
    } else if (!line3.equals(other.line3))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (state == null) {
      if (other.state != null)
        return false;
    } else if (!state.equals(other.state))
      return false;
    if (zipCode == null) {
      if (other.zipCode != null)
        return false;
    } else if (!zipCode.equals(other.zipCode))
      return false;
    return true;
  }

}
