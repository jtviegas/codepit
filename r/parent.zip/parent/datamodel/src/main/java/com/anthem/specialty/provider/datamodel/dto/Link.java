package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = LinkImpl.class)
public interface Link extends Serializable {

  @JsonProperty("rel")
  @ApiModelProperty(required = true)
  @NotNull
  String getRel();

  @JsonProperty("rel")
  @ApiModelProperty(required = true)
  @NotNull
  void setRel(String rel);

  @JsonProperty("href")
  @ApiModelProperty(required = true)
  @NotNull
  String getHref();

  @JsonProperty("href")
  @ApiModelProperty(required = true)
  @NotNull
  void setHref(String href);
}
