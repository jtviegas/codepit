package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewSanctionImpl implements NewSanction {

  @JsonCreator
  public static NewSanction create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewSanction impl = null;
    impl = mapper.readValue(json, NewSanctionImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private RelatedClinic clinic;

  private String sanctionAgency;

  private String sanctionCode;

  private EffectivePeriod effective;

  public NewSanctionImpl() {
  }

  @Override
  public RelatedClinic getClinic() {
    return clinic;
  }

  @Override
  public void setClinic(RelatedClinic clinic) {
    this.clinic = clinic;
  }

  @Override
  public String getSanctionAgency() {
    return sanctionAgency;
  }

  @Override
  public void setSanctionAgency(String sanctionAgency) {
    this.sanctionAgency = sanctionAgency;
  }

  @Override
  public String getSanctionCode() {
    return sanctionCode;
  }

  @Override
  public void setSanctionCode(String sanctionCode) {
    this.sanctionCode = sanctionCode;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((clinic == null) ? 0 : clinic.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((sanctionAgency == null) ? 0 : sanctionAgency.hashCode());
    result = prime * result + ((sanctionCode == null) ? 0 : sanctionCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewSanctionImpl other = (NewSanctionImpl) obj;
    if (clinic == null) {
      if (other.clinic != null)
        return false;
    } else if (!clinic.equals(other.clinic))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (sanctionAgency == null) {
      if (other.sanctionAgency != null)
        return false;
    } else if (!sanctionAgency.equals(other.sanctionAgency))
      return false;
    if (sanctionCode == null) {
      if (other.sanctionCode != null)
        return false;
    } else if (!sanctionCode.equals(other.sanctionCode))
      return false;
    return true;
  }

}
