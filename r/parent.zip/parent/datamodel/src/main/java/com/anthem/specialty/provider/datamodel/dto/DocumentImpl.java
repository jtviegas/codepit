package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DocumentImpl implements Document {

  @JsonCreator
  public static Document create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Document impl = null;
    impl = mapper.readValue(json, DocumentImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private Long controlNumber;

  private DocumentType type;

  private Character source;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public DocumentImpl() {
    links = new ArrayList<Link>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Document#getControlNumber()
   */
  @Override
  public @NotNull Long getControlNumber() {
    return controlNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Document#setControlNumber(java.lang.Long)
   */
  @Override
  public void setControlNumber(Long controlNumber) {
    this.controlNumber = controlNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Document#getType()
   */
  @Override
  public @NotNull DocumentType getType() {
    return type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.Document#setType(com.anthem.specialty.provider.datamodel.dto.newdtos.
   * DocumentType)
   */
  @Override
  public void setType(DocumentType type) {
    this.type = type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Document#getSource()
   */
  @Override
  public Character getSource() {
    return source;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.Document#setSource(java.lang.Character)
   */
  @Override
  public void setSource(Character source) {
    this.source = source;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((controlNumber == null) ? 0 : controlNumber.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((source == null) ? 0 : source.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    DocumentImpl other = (DocumentImpl) obj;
    if (controlNumber == null) {
      if (other.controlNumber != null)
        return false;
    } else if (!controlNumber.equals(other.controlNumber))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (source == null) {
      if (other.source != null)
        return false;
    } else if (!source.equals(other.source))
      return false;
    if (type == null) {
      if (other.type != null)
        return false;
    } else if (!type.equals(other.type))
      return false;
    return true;
  }

}
