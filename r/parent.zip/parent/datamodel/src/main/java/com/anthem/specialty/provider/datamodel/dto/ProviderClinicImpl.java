package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProviderClinicImpl implements ProviderClinic {

  @JsonCreator
  public static ProviderClinic create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ProviderClinic impl = null;
    impl = mapper.readValue(json, ProviderClinicImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private List<OpeningHours> hours;

  private String comments;

  private Boolean clearLicenseNumber;

  private Boolean providerSpecialistClinic;

  private Character providerRelationship;

  private Character payClinicProvider;

  private Boolean deltaPrecertified;

  private Boolean corporatePayment;

  private Boolean witholdPayments;

  private Boolean providerCob;

  private Bci bci;

  private Boolean providerClaimInReview;

  private Boolean professionalReviewUnderway;

  private RelatedClinicItem clinic;

  private Long id;

  private DataOwner dataOwner;

  private EffectivePeriod effective;

  public ProviderClinicImpl() {
    hours = new ArrayList<OpeningHours>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#getHours()
   */
  @Override
  public List<OpeningHours> getHours() {
    return hours;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setHours(java.util.List)
   */
  @Override
  public void setHours(List<OpeningHours> hours) {
    this.hours = hours;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#getComments()
   */
  @Override
  public String getComments() {
    return comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setComments(java.lang.String)
   */
  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#getProviderRelationship()
   */
  @Override
  public Character getProviderRelationship() {
    return providerRelationship;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setProviderRelationship(java.lang.Character)
   */
  @Override
  public void setProviderRelationship(Character providerRelationship) {
    this.providerRelationship = providerRelationship;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#getPayClinicProvider()
   */
  @Override
  public Character getPayClinicProvider() {
    return payClinicProvider;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setPayClinicProvider(java.lang.Character)
   */
  @Override
  public void setPayClinicProvider(Character payClinicProvider) {
    this.payClinicProvider = payClinicProvider;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isClearLicenseNumber()
   */
  @Override
  public Boolean isClearLicenseNumber() {
    return clearLicenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setClearLicenseNumber(java.lang.Boolean)
   */
  @Override
  public void setClearLicenseNumber(Boolean clearLicenseNumber) {
    this.clearLicenseNumber = clearLicenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isProviderSpecialistClinic()
   */
  @Override
  public Boolean isProviderSpecialistClinic() {
    return providerSpecialistClinic;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setProviderSpecialistClinic(java.lang.Boolean)
   */
  @Override
  public void setProviderSpecialistClinic(Boolean providerSpecialistClinic) {
    this.providerSpecialistClinic = providerSpecialistClinic;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isDeltaPrecertified()
   */
  @Override
  public Boolean isDeltaPrecertified() {
    return deltaPrecertified;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setDeltaPrecertified(java.lang.Boolean)
   */
  @Override
  public void setDeltaPrecertified(Boolean deltaPrecertified) {
    this.deltaPrecertified = deltaPrecertified;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isCorporatePayment()
   */
  @Override
  public Boolean isCorporatePayment() {
    return corporatePayment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setCorporatePayment(java.lang.Boolean)
   */
  @Override
  public void setCorporatePayment(Boolean corporatePayment) {
    this.corporatePayment = corporatePayment;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isWitholdPayments()
   */
  @Override
  public Boolean isWitholdPayments() {
    return witholdPayments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setWitholdPayments(java.lang.Boolean)
   */
  @Override
  public void setWitholdPayments(Boolean witholdPayments) {
    this.witholdPayments = witholdPayments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isProviderCob()
   */
  @Override
  public Boolean isProviderCob() {
    return providerCob;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setProviderCob(java.lang.Boolean)
   */
  @Override
  public void setProviderCob(Boolean providerCob) {
    this.providerCob = providerCob;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#getBci()
   */
  @Override
  public Bci getBci() {
    return bci;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setBci(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.Bci)
   */
  @Override
  public void setBci(Bci bci) {
    this.bci = bci;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isProviderClaimInReview()
   */
  @Override
  public Boolean isProviderClaimInReview() {
    return providerClaimInReview;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setProviderClaimInReview(java.lang.Boolean)
   */
  @Override
  public void setProviderClaimInReview(Boolean providerClaimInReview) {
    this.providerClaimInReview = providerClaimInReview;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#isProfessionalReviewUnderway()
   */
  @Override
  public Boolean isProfessionalReviewUnderway() {
    return professionalReviewUnderway;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderClinic#setProfessionalReviewUnderway(java.lang.Boolean)
   */
  @Override
  public void setProfessionalReviewUnderway(Boolean professionalReviewUnderway) {
    this.professionalReviewUnderway = professionalReviewUnderway;
  }

  @Override
  public @NotNull RelatedClinicItem getClinic() {
    return clinic;
  }

  @Override
  public void setClinic(RelatedClinicItem o) {
    this.clinic = o;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner o) {
    this.dataOwner = o;
  }

  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((bci == null) ? 0 : bci.hashCode());
    result = prime * result + ((clearLicenseNumber == null) ? 0 : clearLicenseNumber.hashCode());
    result = prime * result + ((clinic == null) ? 0 : clinic.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((corporatePayment == null) ? 0 : corporatePayment.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((deltaPrecertified == null) ? 0 : deltaPrecertified.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((hours == null) ? 0 : hours.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((payClinicProvider == null) ? 0 : payClinicProvider.hashCode());
    result = prime * result + ((professionalReviewUnderway == null) ? 0 : professionalReviewUnderway.hashCode());
    result = prime * result + ((providerClaimInReview == null) ? 0 : providerClaimInReview.hashCode());
    result = prime * result + ((providerCob == null) ? 0 : providerCob.hashCode());
    result = prime * result + ((providerRelationship == null) ? 0 : providerRelationship.hashCode());
    result = prime * result + ((providerSpecialistClinic == null) ? 0 : providerSpecialistClinic.hashCode());
    result = prime * result + ((witholdPayments == null) ? 0 : witholdPayments.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ProviderClinicImpl other = (ProviderClinicImpl) obj;
    if (bci == null) {
      if (other.bci != null)
        return false;
    } else if (!bci.equals(other.bci))
      return false;
    if (clearLicenseNumber == null) {
      if (other.clearLicenseNumber != null)
        return false;
    } else if (!clearLicenseNumber.equals(other.clearLicenseNumber))
      return false;
    if (clinic == null) {
      if (other.clinic != null)
        return false;
    } else if (!clinic.equals(other.clinic))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (corporatePayment == null) {
      if (other.corporatePayment != null)
        return false;
    } else if (!corporatePayment.equals(other.corporatePayment))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (deltaPrecertified == null) {
      if (other.deltaPrecertified != null)
        return false;
    } else if (!deltaPrecertified.equals(other.deltaPrecertified))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (hours == null) {
      if (other.hours != null)
        return false;
    } else if (!hours.equals(other.hours))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (payClinicProvider == null) {
      if (other.payClinicProvider != null)
        return false;
    } else if (!payClinicProvider.equals(other.payClinicProvider))
      return false;
    if (professionalReviewUnderway == null) {
      if (other.professionalReviewUnderway != null)
        return false;
    } else if (!professionalReviewUnderway.equals(other.professionalReviewUnderway))
      return false;
    if (providerClaimInReview == null) {
      if (other.providerClaimInReview != null)
        return false;
    } else if (!providerClaimInReview.equals(other.providerClaimInReview))
      return false;
    if (providerCob == null) {
      if (other.providerCob != null)
        return false;
    } else if (!providerCob.equals(other.providerCob))
      return false;
    if (providerRelationship == null) {
      if (other.providerRelationship != null)
        return false;
    } else if (!providerRelationship.equals(other.providerRelationship))
      return false;
    if (providerSpecialistClinic == null) {
      if (other.providerSpecialistClinic != null)
        return false;
    } else if (!providerSpecialistClinic.equals(other.providerSpecialistClinic))
      return false;
    if (witholdPayments == null) {
      if (other.witholdPayments != null)
        return false;
    } else if (!witholdPayments.equals(other.witholdPayments))
      return false;
    return true;
  }

}
