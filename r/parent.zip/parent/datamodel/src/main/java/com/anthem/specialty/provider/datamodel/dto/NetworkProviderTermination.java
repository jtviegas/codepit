package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NetworkProviderTerminationImpl.class)
public interface NetworkProviderTermination extends ProviderTermination {

  @JsonProperty("Received")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getReceived();

  @JsonProperty("Received")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setReceived(LocalDate received);

  @JsonProperty("ClauseActiveFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getClauseActiveFrom();

  @JsonProperty("ClauseActiveFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setClauseActiveFrom(LocalDate activeFrom);

}