package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

public interface Linkable extends Serializable {

}
