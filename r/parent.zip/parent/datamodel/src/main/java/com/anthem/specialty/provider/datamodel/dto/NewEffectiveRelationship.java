package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewEffectiveRelationshipImpl.class)
public interface NewEffectiveRelationship extends Serializable {

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  void setEffective(EffectivePeriod effective);

}
