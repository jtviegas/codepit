package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ServicesImpl.class)
public interface Services extends Serializable {

  @JsonProperty("DiagnosticService")
  @ApiModelProperty(required = false)
  Boolean getDiagnosticService();

  @JsonProperty("DiagnosticService")
  @ApiModelProperty(required = false)
  void setDiagnosticService(Boolean diagnosticService);

  @JsonProperty("PreventiveService")
  @ApiModelProperty(required = false)
  Boolean getPreventiveService();

  @JsonProperty("PreventiveService")
  @ApiModelProperty(required = false)
  void setPreventiveService(Boolean preventiveService);

  @JsonProperty("RestorativeService")
  @ApiModelProperty(required = false)
  Boolean getRestorativeService();

  @JsonProperty("RestorativeService")
  @ApiModelProperty(required = false)
  void setRestorativeService(Boolean restorativeService);

  @JsonProperty("PeriodonticService")
  @ApiModelProperty(required = false)
  Boolean getPeriodonticService();

  @JsonProperty("PeriodonticService")
  @ApiModelProperty(required = false)
  void setPeriodonticService(Boolean periodonticService);

  @JsonProperty("PedodonticService")
  @ApiModelProperty(required = false)
  Boolean getPedodonticService();

  @JsonProperty("PedodonticService")
  @ApiModelProperty(required = false)
  void setPedodonticService(Boolean pedodonticService);

  @JsonProperty("EndodonticService")
  @ApiModelProperty(required = false)
  Boolean getEndodonticService();

  @JsonProperty("EndodonticService")
  @ApiModelProperty(required = false)
  void setEndodonticService(Boolean endodonticService);

  @JsonProperty("OrthodonticService")
  @ApiModelProperty(required = false)
  Boolean getOrthodonticService();

  @JsonProperty("OrthodonticService")
  @ApiModelProperty(required = false)
  void setOrthodonticService(Boolean orthodonticService);

  @JsonProperty("OralSurgeryService")
  @ApiModelProperty(required = false)
  Boolean getOralSurgeryService();

  @JsonProperty("OralSurgeryService")
  @ApiModelProperty(required = false)
  void setOralSurgeryService(Boolean oralSurgeryService);

  @JsonProperty("ProsthodonticService")
  @ApiModelProperty(required = false)
  Boolean getProsthodonticService();

  @JsonProperty("ProsthodonticService")
  @ApiModelProperty(required = false)
  void setProsthodonticService(Boolean prosthodonticService);

  @JsonProperty("TmjService")
  @ApiModelProperty(required = false)
  Boolean getTmjService();

  @JsonProperty("TmjService")
  @ApiModelProperty(required = false)
  void setTmjService(Boolean tmjService);

  @JsonProperty("Vision")
  @ApiModelProperty(required = false)
  VisionService getVision();

  @JsonProperty("Vision")
  @ApiModelProperty(required = false)
  void setVision(VisionService vision);

  @JsonProperty("Hearing")
  @ApiModelProperty(required = false)
  HearingService getHearing();

  @JsonProperty("Hearing")
  @ApiModelProperty(required = false)
  void setHearing(HearingService hearing);

  @JsonProperty("IntensiveTherapyUnit")
  @ApiModelProperty(required = false)
  IntensiveTherapyUnitService getIntensiveTherapyUnit();

  @JsonProperty("IntensiveTherapyUnit")
  @ApiModelProperty(required = false)
  void setIntensiveTherapyUnit(IntensiveTherapyUnitService intensiveTherapyUnit);

  @JsonProperty("MobilityServices")
  @ApiModelProperty(required = false)
  Boolean getMobilityServices();

  @JsonProperty("MobilityServices")
  @ApiModelProperty(required = false)
  void setMobilityServices(Boolean mobilityServices);

  @JsonProperty("HIVServices")
  @ApiModelProperty(required = false)
  Boolean getHivServices();

  @JsonProperty("HIVServices")
  @ApiModelProperty(required = false)
  void setHivServices(Boolean hivServices);

  @JsonProperty("DevelopmentallyDisabledServices")
  @ApiModelProperty(required = false)
  Boolean getDevelopmentallyDisabledServices();

  @JsonProperty("DevelopmentallyDisabledServices")
  @ApiModelProperty(required = false)
  void setDevelopmentallyDisabledServices(Boolean developmentallyDisabledServices);

  @JsonProperty("NursingHomeVisits")
  @ApiModelProperty(required = false)
  Boolean getNursingHomeVisits();

  @JsonProperty("NursingHomeVisits")
  @ApiModelProperty(required = false)
  void setNursingHomeVisits(Boolean nursingHomeVisits);

  @JsonProperty("ChildDisabilitySupported")
  @ApiModelProperty(required = false)
  Boolean getChildDisabilitySupported();

  @JsonProperty("ChildDisabilitySupported")
  @ApiModelProperty(required = false)
  void setChildDisabilitySupported(Boolean childDisabilitySupported);

  @JsonProperty("AdultDisabilitySupported")
  @ApiModelProperty(required = false)
  Boolean getAdultDisabilitySupported();

  @JsonProperty("AdultDisabilitySupported")
  @ApiModelProperty(required = false)
  void setAdultDisabilitySupported(Boolean adultDisabilitySupported);

  @JsonProperty("SpecialAccommodations")
  @ApiModelProperty(required = false)
  String getSpecialAccommodations();

  @JsonProperty("SpecialAccommodations")
  @ApiModelProperty(required = false)
  void setSpecialAccommodations(String specialAccommodations);

}