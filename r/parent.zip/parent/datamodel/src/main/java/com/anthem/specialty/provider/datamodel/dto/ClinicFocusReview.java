package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = ClinicFocusReviewImpl.class)
public interface ClinicFocusReview extends NewClinicFocusReview, DataEntity {

}
