package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NetworkProviderTerminationImpl implements NetworkProviderTermination {

  @JsonCreator
  public static NetworkProviderTermination create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NetworkProviderTermination impl = null;
    impl = mapper.readValue(json, NetworkProviderTerminationImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate from;

  private Long terminationLevelCode;

  private LocalDate received;

  private LocalDate clauseActiveFrom;

  public NetworkProviderTerminationImpl() {
  }

  @Override
  public @NotNull LocalDate getFrom() {
    return from;
  }

  @Override
  public void setFrom(LocalDate from) {
    this.from = from;
  }

  @Override
  public @NotNull Long getTerminationLevelCode() {
    return terminationLevelCode;
  }

  @Override
  public void setTerminationLevelCode(Long terminationLevelCode) {
    this.terminationLevelCode = terminationLevelCode;
  }

  @Override
  public LocalDate getReceived() {
    return received;
  }

  @Override
  public void setReceived(LocalDate received) {
    this.received = received;
  }

  @Override
  public LocalDate getClauseActiveFrom() {
    return clauseActiveFrom;
  }

  @Override
  public void setClauseActiveFrom(LocalDate activeFrom) {
    this.clauseActiveFrom = activeFrom;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((clauseActiveFrom == null) ? 0 : clauseActiveFrom.hashCode());
    result = prime * result + ((from == null) ? 0 : from.hashCode());
    result = prime * result + ((received == null) ? 0 : received.hashCode());
    result = prime * result + ((terminationLevelCode == null) ? 0 : terminationLevelCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NetworkProviderTerminationImpl other = (NetworkProviderTerminationImpl) obj;
    if (clauseActiveFrom == null) {
      if (other.clauseActiveFrom != null)
        return false;
    } else if (!clauseActiveFrom.equals(other.clauseActiveFrom))
      return false;
    if (from == null) {
      if (other.from != null)
        return false;
    } else if (!from.equals(other.from))
      return false;
    if (received == null) {
      if (other.received != null)
        return false;
    } else if (!received.equals(other.received))
      return false;
    if (terminationLevelCode == null) {
      if (other.terminationLevelCode != null)
        return false;
    } else if (!terminationLevelCode.equals(other.terminationLevelCode))
      return false;
    return true;
  }

}
