package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class HttpStatusResponseWithMatchesImpl extends HttpStatusResponseImpl implements HttpStatusResponseWithMatches {

  private static final long serialVersionUID = 1L;

  private List<SimpleClinic> matches;

  @JsonCreator
  public static HttpStatusResponseWithMatchesImpl create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    HttpStatusResponseWithMatchesImpl impl = null;
    impl = mapper.readValue(json, HttpStatusResponseWithMatchesImpl.class);
    return impl;
  }

  public HttpStatusResponseWithMatchesImpl() {
  };

  public HttpStatusResponseWithMatchesImpl(Integer code, String info, List<SimpleClinic> matches) {
    super(code, info);
    this.matches = matches;
  }

  @Override
  public void setMatches(List<SimpleClinic> matches) {
    this.matches = matches;
  }

  @Override
  public @NotNull @Valid List<SimpleClinic> getMatches() {
    return matches;
  }

}
