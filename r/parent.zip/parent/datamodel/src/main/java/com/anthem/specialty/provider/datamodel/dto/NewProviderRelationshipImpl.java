package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewProviderRelationshipImpl implements NewProviderRelationship {

  @JsonCreator
  public static NewProviderRelationship create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewProviderRelationship impl = null;
    impl = mapper.readValue(json, NewProviderRelationshipImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private CoreDataEntity provider;

  public NewProviderRelationshipImpl() {
  }

  public @NotNull CoreDataEntity getProvider() {
    return provider;
  }

  public void setProvider(CoreDataEntity provider) {
    this.provider = provider;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((provider == null) ? 0 : provider.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewProviderRelationshipImpl other = (NewProviderRelationshipImpl) obj;
    if (provider == null) {
      if (other.provider != null)
        return false;
    } else if (!provider.equals(other.provider))
      return false;
    return true;
  }

}
