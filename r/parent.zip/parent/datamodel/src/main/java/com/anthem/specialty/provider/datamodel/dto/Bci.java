
package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = BciImpl.class)
public interface Bci extends Serializable {

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  @NotNull
  String getId();

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  void setId(String id);

  @JsonProperty("Billed")
  @ApiModelProperty(required = true)
  @NotNull
  String getBilled();

  @JsonProperty("Billed")
  @ApiModelProperty(required = true)
  void setBilled(String billed);

}
