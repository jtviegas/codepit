package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewLegalAddressImpl implements NewLegalAddress {

  @JsonCreator
  public static NewLegalAddress create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewLegalAddress impl = null;
    impl = mapper.readValue(json, NewLegalAddressImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String line1;

  private String line2;

  private String line3;

  private String city;

  private String state;

  private String zipCode;

  private EffectivePeriod effective;

  public NewLegalAddressImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getLine1()
   */
  @Override
  public String getLine1() {
    return line1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setLine1(java.lang.String)
   */
  @Override
  public void setLine1(String line1) {
    this.line1 = line1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getLine2()
   */
  @Override
  public String getLine2() {
    return line2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setLine2(java.lang.String)
   */
  @Override
  public void setLine2(String line2) {
    this.line2 = line2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getLine3()
   */
  @Override
  public String getLine3() {
    return line3;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setLine3(java.lang.String)
   */
  @Override
  public void setLine3(String line3) {
    this.line3 = line3;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getCity()
   */
  @Override
  public String getCity() {
    return city;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setCity(java.lang.String)
   */
  @Override
  public void setCity(String city) {
    this.city = city;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getState()
   */
  @Override
  public String getState() {
    return state;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setState(java.lang.String)
   */
  @Override
  public void setState(String state) {
    this.state = state;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getZipCode()
   */
  @Override
  public String getZipCode() {
    return zipCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setZipCode(java.lang.String)
   */
  @Override
  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#getEffective()
   */
  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewLegalAddress#setEffective(com.anthem.specialty.provider.datamodel.
   * dto.newdtos.EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((city == null) ? 0 : city.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((line1 == null) ? 0 : line1.hashCode());
    result = prime * result + ((line2 == null) ? 0 : line2.hashCode());
    result = prime * result + ((line3 == null) ? 0 : line3.hashCode());
    result = prime * result + ((state == null) ? 0 : state.hashCode());
    result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewLegalAddressImpl other = (NewLegalAddressImpl) obj;
    if (city == null) {
      if (other.city != null)
        return false;
    } else if (!city.equals(other.city))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (line1 == null) {
      if (other.line1 != null)
        return false;
    } else if (!line1.equals(other.line1))
      return false;
    if (line2 == null) {
      if (other.line2 != null)
        return false;
    } else if (!line2.equals(other.line2))
      return false;
    if (line3 == null) {
      if (other.line3 != null)
        return false;
    } else if (!line3.equals(other.line3))
      return false;
    if (state == null) {
      if (other.state != null)
        return false;
    } else if (!state.equals(other.state))
      return false;
    if (zipCode == null) {
      if (other.zipCode != null)
        return false;
    } else if (!zipCode.equals(other.zipCode))
      return false;
    return true;
  }

}
