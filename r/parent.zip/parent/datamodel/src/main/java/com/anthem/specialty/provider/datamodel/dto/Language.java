package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = LanguageImpl.class)
public interface Language extends DataEntity {
  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  String getName();

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  void setName(String name);

  @JsonProperty("ISOCode")
  @ApiModelProperty(required = false)
  String getIsoCode();

  @JsonProperty("ISOCode")
  @ApiModelProperty(required = false)
  void setIsoCode(String isoCode);

}