package com.anthem.specialty.provider.datamodel.dto;
// Generated 01-Dec-2017 15:03:23 by Hibernate Tools 5.2.6.Final

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LicenseImpl implements License {

  @JsonCreator
  public static License create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    License impl = null;
    impl = mapper.readValue(json, LicenseImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String licenseNumber;

  private String issuingState;

  private EffectivePeriod effective;

  private LocalDate terminated;

  private Boolean onHold;

  private Dea dea;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public LicenseImpl() {
    links = new ArrayList<Link>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#getLicenseNumber()
   */
  @Override
  public String getLicenseNumber() {
    return licenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#setLicenseNumber(java.lang.String)
   */
  @Override
  public void setLicenseNumber(String licenseNumber) {
    this.licenseNumber = licenseNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#getIssuingState()
   */
  @Override
  public String getIssuingState() {
    return issuingState;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#setIssuingState(java.lang.String)
   */
  @Override
  public void setIssuingState(String issuingState) {
    this.issuingState = issuingState;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#getEffective()
   */
  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#setEffective(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#getTerminated()
   */
  @Override
  public LocalDate getTerminated() {
    return terminated;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#setTerminated(java.util.Date)
   */
  @Override
  public void setTerminated(LocalDate terminated) {
    this.terminated = terminated;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#getOnHold()
   */
  @Override
  public Boolean getOnHold() {
    return onHold;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#setOnHold(java.lang.Boolean)
   */
  @Override
  public void setOnHold(Boolean onHold) {
    this.onHold = onHold;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.License#getDea()
   */
  @Override
  public Dea getDea() {
    return dea;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.License#setDea(com.anthem.specialty.provider.datamodel.dto.newdtos.Dea)
   */
  @Override
  public void setDea(Dea dea) {
    this.dea = dea;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((dea == null) ? 0 : dea.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((issuingState == null) ? 0 : issuingState.hashCode());
    result = prime * result + ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((onHold == null) ? 0 : onHold.hashCode());
    result = prime * result + ((terminated == null) ? 0 : terminated.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    LicenseImpl other = (LicenseImpl) obj;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (dea == null) {
      if (other.dea != null)
        return false;
    } else if (!dea.equals(other.dea))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (issuingState == null) {
      if (other.issuingState != null)
        return false;
    } else if (!issuingState.equals(other.issuingState))
      return false;
    if (licenseNumber == null) {
      if (other.licenseNumber != null)
        return false;
    } else if (!licenseNumber.equals(other.licenseNumber))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (onHold == null) {
      if (other.onHold != null)
        return false;
    } else if (!onHold.equals(other.onHold))
      return false;
    if (terminated == null) {
      if (other.terminated != null)
        return false;
    } else if (!terminated.equals(other.terminated))
      return false;
    return true;
  }

}
