package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewPhoneContactImpl implements NewPhoneContact {

  @JsonCreator
  public static NewPhoneContact create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewPhoneContact impl = null;
    impl = mapper.readValue(json, NewPhoneContactImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private PhoneContactType type;

  private String countryCode;

  private String cityCode;

  private String areaCode;

  private String accessCode;

  private String number;

  private String extension;

  public NewPhoneContactImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getType()
   */
  @Override
  public PhoneContactType getType() {
    return type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setType(com.anthem.specialty.provider.datamodel.dto.
   * PhoneContactType)
   */
  @Override
  public void setType(PhoneContactType type) {
    this.type = type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getCountryCode()
   */
  @Override
  public String getCountryCode() {
    return countryCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setCountryCode(java.lang.String)
   */
  @Override
  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getCityCode()
   */
  @Override
  public String getCityCode() {
    return cityCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setCityCode(java.lang.String)
   */
  @Override
  public void setCityCode(String cityCode) {
    this.cityCode = cityCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getAreaCode()
   */
  @Override
  public String getAreaCode() {
    return areaCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setAreaCode(java.lang.String)
   */
  @Override
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getAccessCode()
   */
  @Override
  public String getAccessCode() {
    return accessCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setAccessCode(java.lang.String)
   */
  @Override
  public void setAccessCode(String accessCode) {
    this.accessCode = accessCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getNumber()
   */
  @Override
  public String getNumber() {
    return number;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setNumber(java.lang.String)
   */
  @Override
  public void setNumber(String number) {
    this.number = number;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#getExtension()
   */
  @Override
  public String getExtension() {
    return extension;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewPhoneContact#setExtension(java.lang.String)
   */
  @Override
  public void setExtension(String extension) {
    this.extension = extension;
  }

  @Override
  public String toString() {
    String r = Stream.of(countryCode, areaCode, cityCode, number).filter(o -> (null != o && (!o.isEmpty())))
        .collect(Collectors.joining(""));
    return r;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((accessCode == null) ? 0 : accessCode.hashCode());
    result = prime * result + ((areaCode == null) ? 0 : areaCode.hashCode());
    result = prime * result + ((cityCode == null) ? 0 : cityCode.hashCode());
    result = prime * result + ((countryCode == null) ? 0 : countryCode.hashCode());
    result = prime * result + ((extension == null) ? 0 : extension.hashCode());
    result = prime * result + ((number == null) ? 0 : number.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewPhoneContactImpl other = (NewPhoneContactImpl) obj;
    if (accessCode == null) {
      if (other.accessCode != null)
        return false;
    } else if (!accessCode.equals(other.accessCode))
      return false;
    if (areaCode == null) {
      if (other.areaCode != null)
        return false;
    } else if (!areaCode.equals(other.areaCode))
      return false;
    if (cityCode == null) {
      if (other.cityCode != null)
        return false;
    } else if (!cityCode.equals(other.cityCode))
      return false;
    if (countryCode == null) {
      if (other.countryCode != null)
        return false;
    } else if (!countryCode.equals(other.countryCode))
      return false;
    if (extension == null) {
      if (other.extension != null)
        return false;
    } else if (!extension.equals(other.extension))
      return false;
    if (number == null) {
      if (other.number != null)
        return false;
    } else if (!number.equals(other.number))
      return false;
    if (type != other.type)
      return false;
    return true;
  }

}
