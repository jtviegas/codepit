package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NetworkGroupImpl.class)
public interface NetworkGroup extends DataEntity {

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  public void setDescription(String description);

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  public String getDescription();
}
