package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewProviderRelationshipImpl.class)
public interface NewProviderRelationship extends Serializable {
  @JsonProperty("Provider")
  @ApiModelProperty(required = true)
  @Valid
  CoreDataEntity getProvider();

  @JsonProperty("Provider")
  @ApiModelProperty(required = true)
  void setProvider(CoreDataEntity provider);
}
