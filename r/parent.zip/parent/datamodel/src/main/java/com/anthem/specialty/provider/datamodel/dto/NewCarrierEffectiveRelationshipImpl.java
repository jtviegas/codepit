package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewCarrierEffectiveRelationshipImpl implements NewCarrierEffectiveRelationship {

  @JsonCreator
  public static NewCarrierEffectiveRelationship create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewCarrierEffectiveRelationship impl = null;
    impl = mapper.readValue(json, NewCarrierEffectiveRelationshipImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String officeNumber;

  private CoreDataEntity carrier;

  private EffectivePeriod effective;

  public NewCarrierEffectiveRelationshipImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewCarrierRelationship#getOfficeNumber()
   */
  @Override
  public String getOfficeNumber() {
    return officeNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewCarrierRelationship#setOfficeNumber(java.lang.String)
   */
  @Override
  public void setOfficeNumber(String officeNumber) {
    this.officeNumber = officeNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewCarrierRelationship#getCarrier()
   */
  @Override
  public CoreDataEntity getCarrier() {
    return carrier;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewCarrierRelationship#setCarrier(com.anthem.specialty.provider.
   * datamodel.dto.newdtos.CoreDataEntity)
   */
  @Override
  public void setCarrier(CoreDataEntity carrier) {
    this.carrier = carrier;
  }

  @Override
  public @NotNull EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((carrier == null) ? 0 : carrier.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((officeNumber == null) ? 0 : officeNumber.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewCarrierEffectiveRelationshipImpl other = (NewCarrierEffectiveRelationshipImpl) obj;
    if (carrier == null) {
      if (other.carrier != null)
        return false;
    } else if (!carrier.equals(other.carrier))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (officeNumber == null) {
      if (other.officeNumber != null)
        return false;
    } else if (!officeNumber.equals(other.officeNumber))
      return false;
    return true;
  }

}
