package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LinkImpl implements Link {

  @JsonCreator
  public static Link create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Link impl = null;
    impl = mapper.readValue(json, LinkImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String rel;

  private String href;

  public LinkImpl() {
  }

  public LinkImpl(String href) {
    this.href = href;
  }

  public LinkImpl(String rel, String href) {
    this.rel = rel;
    this.href = href;
  }

  public void setRel(String rel) {
    this.rel = rel;
  }

  public String getRel() {
    return rel;
  }

  public void setHref(String href) {
    this.href = href;
  }

  public String getHref() {
    return href;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((href == null) ? 0 : href.hashCode());
    result = prime * result + ((rel == null) ? 0 : rel.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    LinkImpl other = (LinkImpl) obj;
    if (href == null) {
      if (other.href != null)
        return false;
    } else if (!href.equals(other.href))
      return false;
    if (rel == null) {
      if (other.rel != null)
        return false;
    } else if (!rel.equals(other.rel))
      return false;
    return true;
  }

}
