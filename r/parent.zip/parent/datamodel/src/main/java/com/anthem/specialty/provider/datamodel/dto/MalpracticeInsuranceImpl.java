package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MalpracticeInsuranceImpl implements MalpracticeInsurance {

  @JsonCreator
  public static MalpracticeInsurance create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    MalpracticeInsurance impl = null;
    impl = mapper.readValue(json, MalpracticeInsuranceImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String insurer;

  private Character insuredLimit;

  private LocalDate renewal;

  private String policyNo;

  public MalpracticeInsuranceImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#getInsurer()
   */
  @Override
  public String getInsurer() {
    return insurer;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#setInsurer(java.lang.String)
   */
  @Override
  public void setInsurer(String insurer) {
    this.insurer = insurer;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#getInsuredLimit()
   */
  @Override
  public Character getInsuredLimit() {
    return insuredLimit;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#setInsuredLimit(java.lang.Character)
   */
  @Override
  public void setInsuredLimit(Character insuredLimit) {
    this.insuredLimit = insuredLimit;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#getRenewal()
   */
  @Override
  public LocalDate getRenewal() {
    return renewal;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#setRenewal(java.util.Date)
   */
  @Override
  public void setRenewal(LocalDate renewal) {
    this.renewal = renewal;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#getPolicyNo()
   */
  @Override
  public String getPolicyNo() {
    return policyNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.MalpracticeInsurance#setPolicyNo(java.lang.String)
   */
  @Override
  public void setPolicyNo(String policyNo) {
    this.policyNo = policyNo;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((insuredLimit == null) ? 0 : insuredLimit.hashCode());
    result = prime * result + ((insurer == null) ? 0 : insurer.hashCode());
    result = prime * result + ((policyNo == null) ? 0 : policyNo.hashCode());
    result = prime * result + ((renewal == null) ? 0 : renewal.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MalpracticeInsuranceImpl other = (MalpracticeInsuranceImpl) obj;
    if (insuredLimit == null) {
      if (other.insuredLimit != null)
        return false;
    } else if (!insuredLimit.equals(other.insuredLimit))
      return false;
    if (insurer == null) {
      if (other.insurer != null)
        return false;
    } else if (!insurer.equals(other.insurer))
      return false;
    if (policyNo == null) {
      if (other.policyNo != null)
        return false;
    } else if (!policyNo.equals(other.policyNo))
      return false;
    if (renewal == null) {
      if (other.renewal != null)
        return false;
    } else if (!renewal.equals(other.renewal))
      return false;
    return true;
  }

}
