package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewProviderSpecialtyImpl.class)
public interface NewProviderSpecialty extends Serializable {
  @JsonProperty("Specialty")
  @ApiModelProperty(required = false)
  SpecialtyType getSpecialtyCode();

  @JsonProperty("Specialty")
  @ApiModelProperty(required = false)
  void setSpecialtyCode(SpecialtyType specialtyCode);

  @JsonProperty("CertifyingBoard")
  @ApiModelProperty(required = false)
  String getCertifyingBoardId();

  @JsonProperty("CertifyingBoard")
  @ApiModelProperty(required = false)
  void setCertifyingBoardId(String certifyingBoardId);

  @JsonProperty("EligibleFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getEligibleFrom();

  @JsonProperty("EligibleFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setEligibleFrom(LocalDate effectiveFrom);

  @JsonProperty("CertifiedFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getCertifiedFrom();

  @JsonProperty("CertifiedFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setCertifiedFrom(LocalDate certifiedFrom);

  @JsonProperty("Renewal")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getRenewalDate();

  @JsonProperty("Renewal")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setRenewalDate(LocalDate renewalDate);

  @JsonProperty("RenewalPeriod")
  @ApiModelProperty(required = false)
  Integer getRenewalPeriod();

  @JsonProperty("RenewalPeriod")
  @ApiModelProperty(required = false)
  void setRenewalPeriod(Integer renewalPeriod);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

}