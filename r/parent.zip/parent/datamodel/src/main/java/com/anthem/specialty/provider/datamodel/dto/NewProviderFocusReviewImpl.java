package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewProviderFocusReviewImpl implements NewProviderFocusReview {

  @JsonCreator
  public static NewProviderFocusReview create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewProviderFocusReview impl = null;
    impl = mapper.readValue(json, NewProviderFocusReviewImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private CoreDataEntity clinic;

  private CoreDataEntity networkGroup;

  private Integer auditNumber;

  private ProcedureCodes procedureCodes;

  private LocalDate commenced;

  private FocusReviewTermination terminated;

  private String comments;

  private List<Link> links;

  public NewProviderFocusReviewImpl() {
    links = new ArrayList<Link>();
  }

  @Override
  public CoreDataEntity getClinic() {
    return clinic;
  }

  @Override
  public void setClinic(CoreDataEntity clinic) {
    this.clinic = clinic;
  }

  @Override
  public @NotNull CoreDataEntity getNetworkGroup() {
    return networkGroup;
  }

  @Override
  public void setNetworkGroup(CoreDataEntity networkGroup) {
    this.networkGroup = networkGroup;
  }

  @Override
  public Integer getAuditNumber() {
    return auditNumber;
  }

  @Override
  public void setAuditNumber(Integer auditNumber) {
    this.auditNumber = auditNumber;
  }

  @Override
  public @NotNull ProcedureCodes getProcedureCodes() {
    return procedureCodes;
  }

  @Override
  public void setProcedureCodes(ProcedureCodes procedureCodes) {
    this.procedureCodes = procedureCodes;
  }

  @Override
  public @NotNull LocalDate getCommenced() {
    return commenced;
  }

  @Override
  public void setCommenced(LocalDate commenced) {
    this.commenced = commenced;
  }

  @Override
  public FocusReviewTermination getTerminated() {
    return terminated;
  }

  @Override
  public void setTerminated(FocusReviewTermination terminated) {
    this.terminated = terminated;
  }

  @Override
  public String getComments() {
    return comments;
  }

  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  @Override
  public @NotNull List<Link> getLinks() {
    return links;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((auditNumber == null) ? 0 : auditNumber.hashCode());
    result = prime * result + ((clinic == null) ? 0 : clinic.hashCode());
    result = prime * result + ((commenced == null) ? 0 : commenced.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((networkGroup == null) ? 0 : networkGroup.hashCode());
    result = prime * result + ((procedureCodes == null) ? 0 : procedureCodes.hashCode());
    result = prime * result + ((terminated == null) ? 0 : terminated.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewProviderFocusReviewImpl other = (NewProviderFocusReviewImpl) obj;
    if (auditNumber == null) {
      if (other.auditNumber != null)
        return false;
    } else if (!auditNumber.equals(other.auditNumber))
      return false;
    if (clinic == null) {
      if (other.clinic != null)
        return false;
    } else if (!clinic.equals(other.clinic))
      return false;
    if (commenced == null) {
      if (other.commenced != null)
        return false;
    } else if (!commenced.equals(other.commenced))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (networkGroup == null) {
      if (other.networkGroup != null)
        return false;
    } else if (!networkGroup.equals(other.networkGroup))
      return false;
    if (procedureCodes == null) {
      if (other.procedureCodes != null)
        return false;
    } else if (!procedureCodes.equals(other.procedureCodes))
      return false;
    if (terminated == null) {
      if (other.terminated != null)
        return false;
    } else if (!terminated.equals(other.terminated))
      return false;
    return true;
  }

}
