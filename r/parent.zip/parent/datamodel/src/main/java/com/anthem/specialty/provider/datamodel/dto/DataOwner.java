package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = DataOwnerImpl.class)
public interface DataOwner extends Serializable {

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  @NotNull
  Long getId();

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  @NotNull
  void setId(Long id);

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  String getName();

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  void setName(String name);
}
