package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ServicesImpl implements Services {

  @JsonCreator
  public static Services create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Services module = null;
    module = mapper.readValue(json, ServicesImpl.class);
    return module;
  }

  private static final long serialVersionUID = 1L;

  private Boolean diagnosticService = Boolean.FALSE;

  private Boolean preventiveService = Boolean.FALSE;

  private Boolean restorativeService = Boolean.FALSE;

  private Boolean periodonticService = Boolean.FALSE;

  private Boolean pedodonticService = Boolean.FALSE;

  private Boolean endodonticService = Boolean.FALSE;

  private Boolean orthodonticService = Boolean.FALSE;

  private Boolean oralSurgeryService = Boolean.FALSE;

  private Boolean prosthodonticService = Boolean.FALSE;

  private Boolean tmjService = Boolean.FALSE;

  private VisionService vision;

  private HearingService hearing;

  private IntensiveTherapyUnitService intensiveTherapyUnit;

  private Boolean mobilityServices = Boolean.FALSE;

  private Boolean hivServices = Boolean.FALSE;

  private Boolean developmentallyDisabledServices = Boolean.FALSE;

  private Boolean nursingHomeVisits = Boolean.FALSE;

  private Boolean childDisabilitySupported = Boolean.FALSE;

  private Boolean adultDisabilitySupported = Boolean.FALSE;

  private String specialAccommodations;

  public ServicesImpl() {
  }

  @Override
  public Boolean getDiagnosticService() {
    return diagnosticService;
  }

  @Override
  public void setDiagnosticService(Boolean diagnosticService) {
    this.diagnosticService = diagnosticService;
  }

  @Override
  public Boolean getPreventiveService() {
    return preventiveService;
  }

  @Override
  public void setPreventiveService(Boolean preventiveService) {
    this.preventiveService = preventiveService;
  }

  @Override
  public Boolean getRestorativeService() {
    return restorativeService;
  }

  @Override
  public void setRestorativeService(Boolean restorativeService) {
    this.restorativeService = restorativeService;
  }

  @Override
  public Boolean getPeriodonticService() {
    return periodonticService;
  }

  @Override
  public void setPeriodonticService(Boolean periodonticService) {
    this.periodonticService = periodonticService;
  }

  @Override
  public Boolean getPedodonticService() {
    return pedodonticService;
  }

  @Override
  public void setPedodonticService(Boolean pedodonticService) {
    this.pedodonticService = pedodonticService;
  }

  @Override
  public Boolean getEndodonticService() {
    return endodonticService;
  }

  @Override
  public void setEndodonticService(Boolean endodonticService) {
    this.endodonticService = endodonticService;
  }

  @Override
  public Boolean getOrthodonticService() {
    return orthodonticService;
  }

  @Override
  public void setOrthodonticService(Boolean orthodonticService) {
    this.orthodonticService = orthodonticService;
  }

  @Override
  public Boolean getOralSurgeryService() {
    return oralSurgeryService;
  }

  @Override
  public void setOralSurgeryService(Boolean oralSurgeryService) {
    this.oralSurgeryService = oralSurgeryService;
  }

  @Override
  public Boolean getProsthodonticService() {
    return prosthodonticService;
  }

  @Override
  public void setProsthodonticService(Boolean prosthodonticService) {
    this.prosthodonticService = prosthodonticService;
  }

  @Override
  public Boolean getTmjService() {
    return tmjService;
  }

  @Override
  public void setTmjService(Boolean tmjService) {
    this.tmjService = tmjService;
  }

  @Override
  public VisionService getVision() {
    return vision;
  }

  @Override
  public void setVision(VisionService vision) {
    this.vision = vision;
  }

  @Override
  public HearingService getHearing() {
    return hearing;
  }

  @Override
  public void setHearing(HearingService hearing) {
    this.hearing = hearing;
  }

  @Override
  public IntensiveTherapyUnitService getIntensiveTherapyUnit() {
    return intensiveTherapyUnit;
  }

  @Override
  public void setIntensiveTherapyUnit(IntensiveTherapyUnitService intensiveTherapyUnit) {
    this.intensiveTherapyUnit = intensiveTherapyUnit;
  }

  @Override
  public Boolean getMobilityServices() {
    return mobilityServices;
  }

  @Override
  public void setMobilityServices(Boolean mobilityServices) {
    this.mobilityServices = mobilityServices;
  }

  @Override
  public Boolean getHivServices() {
    return hivServices;
  }

  @Override
  public void setHivServices(Boolean hivServices) {
    this.hivServices = hivServices;
  }

  @Override
  public Boolean getDevelopmentallyDisabledServices() {
    return developmentallyDisabledServices;
  }

  @Override
  public void setDevelopmentallyDisabledServices(Boolean developmentallyDisabledServices) {
    this.developmentallyDisabledServices = developmentallyDisabledServices;
  }

  @Override
  public Boolean getNursingHomeVisits() {
    return nursingHomeVisits;
  }

  @Override
  public void setNursingHomeVisits(Boolean nursingHomeVisits) {
    this.nursingHomeVisits = nursingHomeVisits;
  }

  @Override
  public Boolean getChildDisabilitySupported() {
    return childDisabilitySupported;
  }

  @Override
  public void setChildDisabilitySupported(Boolean childDisabilitySupported) {
    this.childDisabilitySupported = childDisabilitySupported;
  }

  @Override
  public Boolean getAdultDisabilitySupported() {
    return adultDisabilitySupported;
  }

  @Override
  public void setAdultDisabilitySupported(Boolean adultDisabilitySupported) {
    this.adultDisabilitySupported = adultDisabilitySupported;
  }

  @Override
  public String getSpecialAccommodations() {
    return specialAccommodations;
  }

  @Override
  public void setSpecialAccommodations(String specialAccommodations) {
    this.specialAccommodations = specialAccommodations;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((adultDisabilitySupported == null) ? 0 : adultDisabilitySupported.hashCode());
    result = prime * result + ((childDisabilitySupported == null) ? 0 : childDisabilitySupported.hashCode());
    result = prime * result
        + ((developmentallyDisabledServices == null) ? 0 : developmentallyDisabledServices.hashCode());
    result = prime * result + ((diagnosticService == null) ? 0 : diagnosticService.hashCode());
    result = prime * result + ((endodonticService == null) ? 0 : endodonticService.hashCode());
    result = prime * result + ((hearing == null) ? 0 : hearing.hashCode());
    result = prime * result + ((hivServices == null) ? 0 : hivServices.hashCode());
    result = prime * result + ((intensiveTherapyUnit == null) ? 0 : intensiveTherapyUnit.hashCode());
    result = prime * result + ((mobilityServices == null) ? 0 : mobilityServices.hashCode());
    result = prime * result + ((nursingHomeVisits == null) ? 0 : nursingHomeVisits.hashCode());
    result = prime * result + ((oralSurgeryService == null) ? 0 : oralSurgeryService.hashCode());
    result = prime * result + ((orthodonticService == null) ? 0 : orthodonticService.hashCode());
    result = prime * result + ((pedodonticService == null) ? 0 : pedodonticService.hashCode());
    result = prime * result + ((periodonticService == null) ? 0 : periodonticService.hashCode());
    result = prime * result + ((preventiveService == null) ? 0 : preventiveService.hashCode());
    result = prime * result + ((prosthodonticService == null) ? 0 : prosthodonticService.hashCode());
    result = prime * result + ((restorativeService == null) ? 0 : restorativeService.hashCode());
    result = prime * result + ((specialAccommodations == null) ? 0 : specialAccommodations.hashCode());
    result = prime * result + ((tmjService == null) ? 0 : tmjService.hashCode());
    result = prime * result + ((vision == null) ? 0 : vision.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ServicesImpl other = (ServicesImpl) obj;
    if (adultDisabilitySupported == null) {
      if (other.adultDisabilitySupported != null)
        return false;
    } else if (!adultDisabilitySupported.equals(other.adultDisabilitySupported))
      return false;
    if (childDisabilitySupported == null) {
      if (other.childDisabilitySupported != null)
        return false;
    } else if (!childDisabilitySupported.equals(other.childDisabilitySupported))
      return false;
    if (developmentallyDisabledServices == null) {
      if (other.developmentallyDisabledServices != null)
        return false;
    } else if (!developmentallyDisabledServices.equals(other.developmentallyDisabledServices))
      return false;
    if (diagnosticService == null) {
      if (other.diagnosticService != null)
        return false;
    } else if (!diagnosticService.equals(other.diagnosticService))
      return false;
    if (endodonticService == null) {
      if (other.endodonticService != null)
        return false;
    } else if (!endodonticService.equals(other.endodonticService))
      return false;
    if (hearing == null) {
      if (other.hearing != null)
        return false;
    } else if (!hearing.equals(other.hearing))
      return false;
    if (hivServices == null) {
      if (other.hivServices != null)
        return false;
    } else if (!hivServices.equals(other.hivServices))
      return false;
    if (intensiveTherapyUnit == null) {
      if (other.intensiveTherapyUnit != null)
        return false;
    } else if (!intensiveTherapyUnit.equals(other.intensiveTherapyUnit))
      return false;
    if (mobilityServices == null) {
      if (other.mobilityServices != null)
        return false;
    } else if (!mobilityServices.equals(other.mobilityServices))
      return false;
    if (nursingHomeVisits == null) {
      if (other.nursingHomeVisits != null)
        return false;
    } else if (!nursingHomeVisits.equals(other.nursingHomeVisits))
      return false;
    if (oralSurgeryService == null) {
      if (other.oralSurgeryService != null)
        return false;
    } else if (!oralSurgeryService.equals(other.oralSurgeryService))
      return false;
    if (orthodonticService == null) {
      if (other.orthodonticService != null)
        return false;
    } else if (!orthodonticService.equals(other.orthodonticService))
      return false;
    if (pedodonticService == null) {
      if (other.pedodonticService != null)
        return false;
    } else if (!pedodonticService.equals(other.pedodonticService))
      return false;
    if (periodonticService == null) {
      if (other.periodonticService != null)
        return false;
    } else if (!periodonticService.equals(other.periodonticService))
      return false;
    if (preventiveService == null) {
      if (other.preventiveService != null)
        return false;
    } else if (!preventiveService.equals(other.preventiveService))
      return false;
    if (prosthodonticService == null) {
      if (other.prosthodonticService != null)
        return false;
    } else if (!prosthodonticService.equals(other.prosthodonticService))
      return false;
    if (restorativeService == null) {
      if (other.restorativeService != null)
        return false;
    } else if (!restorativeService.equals(other.restorativeService))
      return false;
    if (specialAccommodations == null) {
      if (other.specialAccommodations != null)
        return false;
    } else if (!specialAccommodations.equals(other.specialAccommodations))
      return false;
    if (tmjService == null) {
      if (other.tmjService != null)
        return false;
    } else if (!tmjService.equals(other.tmjService))
      return false;
    if (vision == null) {
      if (other.vision != null)
        return false;
    } else if (!vision.equals(other.vision))
      return false;
    return true;
  }

}
