package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DocumentTypeImpl implements DocumentType {

  @JsonCreator
  public static DocumentType create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    DocumentType impl = null;
    impl = mapper.readValue(json, DocumentTypeImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String code;

  private String description;

  public DocumentTypeImpl() {
  }

  public DocumentTypeImpl(String code, String description) {
    this.code = code;
    this.description = description;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.DocumentType#getCode()
   */
  @Override
  public String getCode() {
    return code;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.DocumentType#setCode(java.lang.String)
   */
  @Override
  public void setCode(String code) {
    this.code = code;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.DocumentType#getDescription()
   */
  @Override
  public String getDescription() {
    return description;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.DocumentType#setDescription(java.lang.String)
   */
  @Override
  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((code == null) ? 0 : code.hashCode());
    result = prime * result + ((description == null) ? 0 : description.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    DocumentTypeImpl other = (DocumentTypeImpl) obj;
    if (code == null) {
      if (other.code != null)
        return false;
    } else if (!code.equals(other.code))
      return false;
    if (description == null) {
      if (other.description != null)
        return false;
    } else if (!description.equals(other.description))
      return false;
    return true;
  }

}
