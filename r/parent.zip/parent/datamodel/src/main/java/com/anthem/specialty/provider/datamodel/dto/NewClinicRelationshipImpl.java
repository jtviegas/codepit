package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewClinicRelationshipImpl implements NewClinicRelationship {

  @JsonCreator
  public static NewClinicRelationship create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewClinicRelationship impl = null;
    impl = mapper.readValue(json, NewClinicRelationshipImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private CoreDataEntity clinic;

  public NewClinicRelationshipImpl() {
  }

  public @NotNull CoreDataEntity getClinic() {
    return clinic;
  }

  public void setClinic(CoreDataEntity clinic) {
    this.clinic = clinic;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((clinic == null) ? 0 : clinic.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewClinicRelationshipImpl other = (NewClinicRelationshipImpl) obj;
    if (clinic == null) {
      if (other.clinic != null)
        return false;
    } else if (!clinic.equals(other.clinic))
      return false;
    return true;
  }

}
