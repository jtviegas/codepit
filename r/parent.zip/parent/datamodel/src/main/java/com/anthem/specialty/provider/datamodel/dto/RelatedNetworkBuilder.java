package com.anthem.specialty.provider.datamodel.dto;

public class RelatedNetworkBuilder {

  private final RelatedNetwork o;

  public RelatedNetworkBuilder(Long id, DataOwner dataOwner, RelatedNetworkItem network) {
    o = new RelatedNetworkImpl(id, dataOwner, network);
  }

  public RelatedNetwork build() {
    return o;
  }

  public RelatedNetworkBuilder withEffective(EffectivePeriod effective) {
    o.setEffective(effective);
    return this;
  }

}
