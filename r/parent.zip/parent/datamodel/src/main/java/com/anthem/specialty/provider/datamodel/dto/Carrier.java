package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = CarrierImpl.class)
public interface Carrier extends DataEntity {

  @JsonProperty("ClearCarrierNo")
  @ApiModelProperty(required = true)
  @NotNull
  String getClearCarrierNo();

  @JsonProperty("ClearCarrierNo")
  @ApiModelProperty(required = true)
  void setClearCarrierNo(String clearCarrierNo);

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  String getDescription();

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  void setDescription(String description);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

  @JsonProperty("ContactName")
  @ApiModelProperty(required = false)
  String getContactName();

  @JsonProperty("ContactName")
  @ApiModelProperty(required = false)
  void setContactName(String contactName);

  @JsonProperty("Manager")
  @ApiModelProperty(required = false)
  String getManager();

  @JsonProperty("Manager")
  @ApiModelProperty(required = false)
  void setManager(String manager);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

}