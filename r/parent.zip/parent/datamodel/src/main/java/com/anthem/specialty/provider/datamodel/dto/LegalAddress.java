package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = LegalAddressImpl.class)
public interface LegalAddress extends DataEntity {
  @JsonProperty("Line1")
  @ApiModelProperty(required = true)
  @NotNull
  String getLine1();

  @JsonProperty("Line1")
  @ApiModelProperty(required = true)
  void setLine1(String line1);

  @JsonProperty("Line2")
  @ApiModelProperty(required = false)
  String getLine2();

  @JsonProperty("Line2")
  @ApiModelProperty(required = false)
  void setLine2(String line2);

  @JsonProperty("Line3")
  @ApiModelProperty(required = false)
  String getLine3();

  @JsonProperty("Line3")
  @ApiModelProperty(required = false)
  void setLine3(String line3);

  @JsonProperty("City")
  @ApiModelProperty(required = false)
  String getCity();

  @JsonProperty("City")
  @ApiModelProperty(required = false)
  void setCity(String city);

  @JsonProperty("State")
  @ApiModelProperty(required = false)
  String getState();

  @JsonProperty("State")
  @ApiModelProperty(required = false)
  void setState(String state);

  @JsonProperty("ZIPCode")
  @ApiModelProperty(required = false)
  String getZipCode();

  @JsonProperty("ZIPCode")
  @ApiModelProperty(required = false)
  void setZipCode(String zipCode);

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  void setEffective(EffectivePeriod effective);

}