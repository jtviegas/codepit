package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public interface NewFocusReview extends MultiLinkable {

  @JsonProperty("NetworkGroup")
  @ApiModelProperty(required = true)
  @NotNull
  CoreDataEntity getNetworkGroup();

  @JsonProperty("NetworkGroup")
  @ApiModelProperty(required = true)
  void setNetworkGroup(CoreDataEntity networkGroup);

  @JsonProperty("AuditNumber")
  @ApiModelProperty(required = false)
  Integer getAuditNumber();

  @JsonProperty("AuditNumber")
  @ApiModelProperty(required = false)
  void setAuditNumber(Integer auditNumber);

  @JsonProperty("ProcedureCodes")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  ProcedureCodes getProcedureCodes();

  @JsonProperty("ProcedureCodes")
  @ApiModelProperty(required = true)
  void setProcedureCodes(ProcedureCodes procedureCodes);

  @JsonProperty("Commenced")
  @ApiModelProperty(required = true)
  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  LocalDate getCommenced();

  @JsonProperty("Commenced")
  @ApiModelProperty(required = true)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  void setCommenced(LocalDate commenced);

  @JsonProperty("Terminated")
  @ApiModelProperty(required = false)
  @Valid
  FocusReviewTermination getTerminated();

  @JsonProperty("Terminated")
  @ApiModelProperty(required = false)
  void setTerminated(FocusReviewTermination terminated);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

  @JsonProperty("Links")
  @ApiModelProperty(required = true)
  @NotNull
  List<Link> getLinks();

  @JsonProperty("Links")
  @ApiModelProperty(required = true)
  void setLinks(List<Link> links);

}