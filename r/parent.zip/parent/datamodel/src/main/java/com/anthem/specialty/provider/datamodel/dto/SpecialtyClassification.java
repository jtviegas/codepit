package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public enum SpecialtyClassification {
  Primary(new Character('P')),
  Secondary(new Character('S'));

  private Character c;

  private SpecialtyClassification(Character c) {
    this.c = c;
  }

  @JsonIgnore
  public Character asChar() {
    return this.c;
  }

  @JsonIgnore
  public static SpecialtyClassification fromChar(Character c) {
    SpecialtyClassification r = null;
    for (SpecialtyClassification o : SpecialtyClassification.values()) {
      if (o.asChar().equals(c)) {
        r = o;
        break;
      }
    }
    return r;
  }
}
