package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedProviderImpl.class)
public interface RelatedProvider extends Relationship {

  @JsonProperty("Provider")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  RelatedProviderItem getProvider();

  @JsonProperty("Provider")
  @ApiModelProperty(required = true)
  @NotNull
  void setProvider(RelatedProviderItem o);

}
