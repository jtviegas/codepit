package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = NewNetworkClinicRelationshipImpl.class)
public interface NewNetworkClinicRelationship extends NewClinicEffectiveRelationship, UpdatableNetworkClinicRelationship {

}
