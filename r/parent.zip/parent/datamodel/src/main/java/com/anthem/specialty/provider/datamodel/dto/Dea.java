package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = DeaImpl.class)
public interface Dea extends Serializable {

  @JsonProperty("DEANumber")
  @ApiModelProperty(required = true)
  @NotNull
  String getDeaNumber();

  @JsonProperty("DEANumber")
  @ApiModelProperty(required = true)
  void setDeaNumber(String deaNumber);

  @JsonProperty("Expiration")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  @NotNull
  LocalDate getExpiration();

  @JsonProperty("Expiration")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  void setExpiration(LocalDate expiration);

  @JsonProperty("MissingBecause")
  @ApiModelProperty(required = true)
  @NotNull
  String getMissingBecause();

  @JsonProperty("MissingBecause")
  @ApiModelProperty(required = true)
  void setMissingBecause(String missingBecause);

}
