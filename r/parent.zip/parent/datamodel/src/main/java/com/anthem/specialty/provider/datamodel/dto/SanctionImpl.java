package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SanctionImpl implements Sanction {

  @JsonCreator
  public static Sanction create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Sanction impl = null;
    impl = mapper.readValue(json, SanctionImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private RelatedClinic clinic;

  private String sanctionAgency;

  private String sanctionCode;

  private EffectivePeriod effective;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public SanctionImpl() {
    links = new ArrayList<Link>();
  }

  @Override
  public RelatedClinic getClinic() {
    return clinic;
  }

  @Override
  public void setClinic(RelatedClinic clinic) {
    this.clinic = clinic;
  }

  @Override
  public String getSanctionAgency() {
    return sanctionAgency;
  }

  @Override
  public void setSanctionAgency(String sanctionAgency) {
    this.sanctionAgency = sanctionAgency;
  }

  @Override
  public String getSanctionCode() {
    return sanctionCode;
  }

  @Override
  public void setSanctionCode(String sanctionCode) {
    this.sanctionCode = sanctionCode;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((clinic == null) ? 0 : clinic.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((sanctionAgency == null) ? 0 : sanctionAgency.hashCode());
    result = prime * result + ((sanctionCode == null) ? 0 : sanctionCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    SanctionImpl other = (SanctionImpl) obj;
    if (clinic == null) {
      if (other.clinic != null)
        return false;
    } else if (!clinic.equals(other.clinic))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (sanctionAgency == null) {
      if (other.sanctionAgency != null)
        return false;
    } else if (!sanctionAgency.equals(other.sanctionAgency))
      return false;
    if (sanctionCode == null) {
      if (other.sanctionCode != null)
        return false;
    } else if (!sanctionCode.equals(other.sanctionCode))
      return false;
    return true;
  }

}
