package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = NetworkClinicRelationshipImpl.class)
public interface NetworkClinicRelationship extends NewNetworkClinicRelationship, DataEntity {

}
