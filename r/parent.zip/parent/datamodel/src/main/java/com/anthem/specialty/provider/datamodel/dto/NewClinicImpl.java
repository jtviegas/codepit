package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewClinicImpl implements NewClinic {

  @JsonCreator
  public static NewClinic create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewClinic impl = null;
    impl = mapper.readValue(json, NewClinicImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String stateMedicaidNo;

  private String commonName;

  private String comments;

  private String contactName;

  private String paymentName;

  private Character ucrRegionCode;

  @Valid
  private GeneralInsurance generalInsurance;

  private Services services;

  private Staffing staffing;

  private Boolean reimburseContinuedEducation;

  private String practiceManagementSoftware;

  private Boolean electronicClaimsSubmissionSupported;

  private String alphabeticalSortBy;

  private String maRating;

  private String emailAddress;

  private String memberEmailAddress;

  private String webAddress;

  @Valid
  private EssentialCommunityProvider essentialCommunityProvider;

  private Patients patients;

  private String visitedNursingHomes;

  private Boolean emergencyInstructions;

  private Boolean wheelchairAccessible;

  private String professionalReviewUnderway;

  @Valid
  private EffectivePeriod effective;

  @Valid
  private List<OpeningHours> hours;

  private Long dataOwnerId;

  public NewClinicImpl() {
    hours = new ArrayList<OpeningHours>();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getStateMedicaidNo()
   */
  @Override
  public String getStateMedicaidNo() {
    return stateMedicaidNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setStateMedicaidNo(java.lang.String)
   */
  @Override
  public void setStateMedicaidNo(String stateMedicaidNo) {
    this.stateMedicaidNo = stateMedicaidNo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getCommonName()
   */
  @Override
  public String getCommonName() {
    return commonName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setCommonName(java.lang.String)
   */
  @Override
  public void setCommonName(String commonName) {
    this.commonName = commonName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getComments()
   */
  @Override
  public String getComments() {
    return comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setComments(java.lang.String)
   */
  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getContactName()
   */
  @Override
  public String getContactName() {
    return contactName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setContactName(java.lang.String)
   */
  @Override
  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getPaymentName()
   */
  @Override
  public String getPaymentName() {
    return paymentName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setPaymentName(java.lang.String)
   */
  @Override
  public void setPaymentName(String paymentName) {
    this.paymentName = paymentName;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getUcrRegionCode()
   */
  @Override
  public Character getUcrRegionCode() {
    return ucrRegionCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setUcrRegionCode(java.lang.Character)
   */
  @Override
  public void setUcrRegionCode(Character ucrRegionCode) {
    this.ucrRegionCode = ucrRegionCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getGeneralInsurance()
   */
  @Override
  public GeneralInsurance getGeneralInsurance() {
    return generalInsurance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewClinic#setGeneralInsurance(com.anthem.specialty.provider.datamodel.
   * dto.newdtos.GeneralInsurance)
   */
  @Override
  public void setGeneralInsurance(GeneralInsurance generalInsurance) {
    this.generalInsurance = generalInsurance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getServices()
   */
  @Override
  public Services getServices() {
    return services;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setServices(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.Services)
   */
  @Override
  public void setServices(Services services) {
    this.services = services;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getStaffing()
   */
  @Override
  public Staffing getStaffing() {
    return staffing;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setStaffing(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.Staffing)
   */
  @Override
  public void setStaffing(Staffing staffing) {
    this.staffing = staffing;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getReimburseContinuedEducation()
   */
  @Override
  public Boolean getReimburseContinuedEducation() {
    return reimburseContinuedEducation;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setReimburseContinuedEducation(java.lang.Boolean)
   */
  @Override
  public void setReimburseContinuedEducation(Boolean reimburseContinuedEducation) {
    this.reimburseContinuedEducation = reimburseContinuedEducation;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getPracticeManagementSoftware()
   */
  @Override
  public String getPracticeManagementSoftware() {
    return practiceManagementSoftware;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setPracticeManagementSoftware(java.lang.String)
   */
  @Override
  public void setPracticeManagementSoftware(String practiceManagementSoftware) {
    this.practiceManagementSoftware = practiceManagementSoftware;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getElectronicClaimsSubmissionSupported()
   */
  @Override
  public Boolean getElectronicClaimsSubmissionSupported() {
    return electronicClaimsSubmissionSupported;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewClinic#setElectronicClaimsSubmissionSupported(java.lang.Boolean)
   */
  @Override
  public void setElectronicClaimsSubmissionSupported(Boolean electronicClaimsSubmissionSupported) {
    this.electronicClaimsSubmissionSupported = electronicClaimsSubmissionSupported;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getAlphabeticalSortBy()
   */
  @Override
  public String getAlphabeticalSortBy() {
    return alphabeticalSortBy;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setAlphabeticalSortBy(java.lang.String)
   */
  @Override
  public void setAlphabeticalSortBy(String alphabeticalSortBy) {
    this.alphabeticalSortBy = alphabeticalSortBy;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getMaRating()
   */
  @Override
  public String getMaRating() {
    return maRating;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setMaRating(java.lang.String)
   */
  @Override
  public void setMaRating(String maRating) {
    this.maRating = maRating;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getEmailAddress()
   */
  @Override
  public String getEmailAddress() {
    return emailAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setEmailAddress(java.lang.String)
   */
  @Override
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getMemberEmailAddress()
   */
  @Override
  public String getMemberEmailAddress() {
    return memberEmailAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setMemberEmailAddress(java.lang.String)
   */
  @Override
  public void setMemberEmailAddress(String memberEmailAddress) {
    this.memberEmailAddress = memberEmailAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getWebAddress()
   */
  @Override
  public String getWebAddress() {
    return webAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setWebAddress(java.lang.String)
   */
  @Override
  public void setWebAddress(String webAddress) {
    this.webAddress = webAddress;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getEssentialCommunityProvider()
   */
  @Override
  public EssentialCommunityProvider getEssentialCommunityProvider() {
    return essentialCommunityProvider;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewClinic#setEssentialCommunityProvider(com.anthem.specialty.provider.
   * datamodel.dto.newdtos.EssentialCommunityProvider)
   */
  @Override
  public void setEssentialCommunityProvider(EssentialCommunityProvider essentialCommunityProvider) {
    this.essentialCommunityProvider = essentialCommunityProvider;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getPatients()
   */
  @Override
  public Patients getPatients() {
    return patients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setPatients(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.Patients)
   */
  @Override
  public void setPatients(Patients patients) {
    this.patients = patients;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getVisitedNursingHomes()
   */
  @Override
  public String getVisitedNursingHomes() {
    return visitedNursingHomes;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setVisitedNursingHomes(java.lang.String)
   */
  @Override
  public void setVisitedNursingHomes(String visitedNursingHomes) {
    this.visitedNursingHomes = visitedNursingHomes;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getEmergencyInstructions()
   */
  @Override
  public Boolean getEmergencyInstructions() {
    return emergencyInstructions;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setEmergencyInstructions(java.lang.Boolean)
   */
  @Override
  public void setEmergencyInstructions(Boolean emergencyInstructions) {
    this.emergencyInstructions = emergencyInstructions;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getWheelchairAccessible()
   */
  @Override
  public Boolean getWheelchairAccessible() {
    return wheelchairAccessible;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setWheelchairAccessible(java.lang.Boolean)
   */
  @Override
  public void setWheelchairAccessible(Boolean wheelchairAccessible) {
    this.wheelchairAccessible = wheelchairAccessible;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getProfessionalReviewUnderway()
   */
  @Override
  public String getProfessionalReviewUnderway() {
    return professionalReviewUnderway;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setProfessionalReviewUnderway(java.lang.String)
   */
  @Override
  public void setProfessionalReviewUnderway(String professionalReviewUnderway) {
    this.professionalReviewUnderway = professionalReviewUnderway;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getEffective()
   */
  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewClinic#setEffective(com.anthem.specialty.provider.datamodel.dto.
   * newdtos.EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#getHours()
   */
  @Override
  public List<OpeningHours> getHours() {
    return hours;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinic#setHours(java.util.List)
   */
  @Override
  public void setHours(List<OpeningHours> hours) {
    this.hours = hours;
  }

  @Override
  public @NotNull Long getDataOwnerId() {
    return dataOwnerId;
  }

  @Override
  public void setDataOwnerId(Long o) {
    this.dataOwnerId = o;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((alphabeticalSortBy == null) ? 0 : alphabeticalSortBy.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((commonName == null) ? 0 : commonName.hashCode());
    result = prime * result + ((contactName == null) ? 0 : contactName.hashCode());
    result = prime * result + ((dataOwnerId == null) ? 0 : dataOwnerId.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result
        + ((electronicClaimsSubmissionSupported == null) ? 0 : electronicClaimsSubmissionSupported.hashCode());
    result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
    result = prime * result + ((emergencyInstructions == null) ? 0 : emergencyInstructions.hashCode());
    result = prime * result + ((essentialCommunityProvider == null) ? 0 : essentialCommunityProvider.hashCode());
    result = prime * result + ((generalInsurance == null) ? 0 : generalInsurance.hashCode());
    result = prime * result + ((hours == null) ? 0 : hours.hashCode());
    result = prime * result + ((maRating == null) ? 0 : maRating.hashCode());
    result = prime * result + ((memberEmailAddress == null) ? 0 : memberEmailAddress.hashCode());
    result = prime * result + ((patients == null) ? 0 : patients.hashCode());
    result = prime * result + ((paymentName == null) ? 0 : paymentName.hashCode());
    result = prime * result + ((practiceManagementSoftware == null) ? 0 : practiceManagementSoftware.hashCode());
    result = prime * result + ((professionalReviewUnderway == null) ? 0 : professionalReviewUnderway.hashCode());
    result = prime * result + ((reimburseContinuedEducation == null) ? 0 : reimburseContinuedEducation.hashCode());
    result = prime * result + ((services == null) ? 0 : services.hashCode());
    result = prime * result + ((staffing == null) ? 0 : staffing.hashCode());
    result = prime * result + ((stateMedicaidNo == null) ? 0 : stateMedicaidNo.hashCode());
    result = prime * result + ((ucrRegionCode == null) ? 0 : ucrRegionCode.hashCode());
    result = prime * result + ((visitedNursingHomes == null) ? 0 : visitedNursingHomes.hashCode());
    result = prime * result + ((webAddress == null) ? 0 : webAddress.hashCode());
    result = prime * result + ((wheelchairAccessible == null) ? 0 : wheelchairAccessible.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewClinicImpl other = (NewClinicImpl) obj;
    if (alphabeticalSortBy == null) {
      if (other.alphabeticalSortBy != null)
        return false;
    } else if (!alphabeticalSortBy.equals(other.alphabeticalSortBy))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (commonName == null) {
      if (other.commonName != null)
        return false;
    } else if (!commonName.equals(other.commonName))
      return false;
    if (contactName == null) {
      if (other.contactName != null)
        return false;
    } else if (!contactName.equals(other.contactName))
      return false;
    if (dataOwnerId == null) {
      if (other.dataOwnerId != null)
        return false;
    } else if (!dataOwnerId.equals(other.dataOwnerId))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (electronicClaimsSubmissionSupported == null) {
      if (other.electronicClaimsSubmissionSupported != null)
        return false;
    } else if (!electronicClaimsSubmissionSupported.equals(other.electronicClaimsSubmissionSupported))
      return false;
    if (emailAddress == null) {
      if (other.emailAddress != null)
        return false;
    } else if (!emailAddress.equals(other.emailAddress))
      return false;
    if (emergencyInstructions == null) {
      if (other.emergencyInstructions != null)
        return false;
    } else if (!emergencyInstructions.equals(other.emergencyInstructions))
      return false;
    if (essentialCommunityProvider == null) {
      if (other.essentialCommunityProvider != null)
        return false;
    } else if (!essentialCommunityProvider.equals(other.essentialCommunityProvider))
      return false;
    if (generalInsurance == null) {
      if (other.generalInsurance != null)
        return false;
    } else if (!generalInsurance.equals(other.generalInsurance))
      return false;
    if (hours == null) {
      if (other.hours != null)
        return false;
    } else if (!hours.equals(other.hours))
      return false;
    if (maRating == null) {
      if (other.maRating != null)
        return false;
    } else if (!maRating.equals(other.maRating))
      return false;
    if (memberEmailAddress == null) {
      if (other.memberEmailAddress != null)
        return false;
    } else if (!memberEmailAddress.equals(other.memberEmailAddress))
      return false;
    if (patients == null) {
      if (other.patients != null)
        return false;
    } else if (!patients.equals(other.patients))
      return false;
    if (paymentName == null) {
      if (other.paymentName != null)
        return false;
    } else if (!paymentName.equals(other.paymentName))
      return false;
    if (practiceManagementSoftware == null) {
      if (other.practiceManagementSoftware != null)
        return false;
    } else if (!practiceManagementSoftware.equals(other.practiceManagementSoftware))
      return false;
    if (professionalReviewUnderway == null) {
      if (other.professionalReviewUnderway != null)
        return false;
    } else if (!professionalReviewUnderway.equals(other.professionalReviewUnderway))
      return false;
    if (reimburseContinuedEducation == null) {
      if (other.reimburseContinuedEducation != null)
        return false;
    } else if (!reimburseContinuedEducation.equals(other.reimburseContinuedEducation))
      return false;
    if (services == null) {
      if (other.services != null)
        return false;
    } else if (!services.equals(other.services))
      return false;
    if (staffing == null) {
      if (other.staffing != null)
        return false;
    } else if (!staffing.equals(other.staffing))
      return false;
    if (stateMedicaidNo == null) {
      if (other.stateMedicaidNo != null)
        return false;
    } else if (!stateMedicaidNo.equals(other.stateMedicaidNo))
      return false;
    if (ucrRegionCode == null) {
      if (other.ucrRegionCode != null)
        return false;
    } else if (!ucrRegionCode.equals(other.ucrRegionCode))
      return false;
    if (visitedNursingHomes == null) {
      if (other.visitedNursingHomes != null)
        return false;
    } else if (!visitedNursingHomes.equals(other.visitedNursingHomes))
      return false;
    if (webAddress == null) {
      if (other.webAddress != null)
        return false;
    } else if (!webAddress.equals(other.webAddress))
      return false;
    if (wheelchairAccessible == null) {
      if (other.wheelchairAccessible != null)
        return false;
    } else if (!wheelchairAccessible.equals(other.wheelchairAccessible))
      return false;
    return true;
  }

}
