package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedCarrierImpl.class)
public interface RelatedCarrier extends Relationship {

  @JsonProperty("Carrier")
  @ApiModelProperty(required = true)
  @NotNull
  RelatedCarrierItem getCarrier();

  @JsonProperty("Carrier")
  @ApiModelProperty(required = true)
  @NotNull
  void setCarrier(RelatedCarrierItem o);

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  String getOfficeNumber();

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  void setOfficeNumber(String o);

}
