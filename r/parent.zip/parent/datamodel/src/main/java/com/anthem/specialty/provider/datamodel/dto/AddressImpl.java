package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AddressImpl implements Address {

  @JsonCreator
  public static Address create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Address impl = null;
    impl = mapper.readValue(json, AddressImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  private AddressType type;

  private String line1;

  private String line2;

  private String line3;

  private String city;

  private String state;

  private String zIPCode;

  private String county;

  private String country;

  private String province;

  private Long latitude;

  private Long longitude;

  public AddressImpl() {
    links = new ArrayList<Link>();
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public AddressType getType() {
    return type;
  }

  @Override
  public void setType(AddressType type) {
    this.type = type;
  }

  @Override
  public String getLine1() {
    return line1;
  }

  @Override
  public void setLine1(String line1) {
    this.line1 = line1;
  }

  @Override
  public String getLine2() {
    return line2;
  }

  @Override
  public void setLine2(String line2) {
    this.line2 = line2;
  }

  @Override
  public String getLine3() {
    return line3;
  }

  @Override
  public void setLine3(String line3) {
    this.line3 = line3;
  }

  @Override
  public String getCity() {
    return city;
  }

  @Override
  public void setCity(String city) {
    this.city = city;
  }

  @Override
  public String getState() {
    return state;
  }

  @Override
  public void setState(String state) {
    this.state = state;
  }

  @Override
  public String getzIPCode() {
    return zIPCode;
  }

  @Override
  public void setzIPCode(String zIPCode) {
    this.zIPCode = zIPCode;
  }

  @Override
  public String getCounty() {
    return county;
  }

  @Override
  public void setCounty(String county) {
    this.county = county;
  }

  @Override
  public String getCountry() {
    return country;
  }

  @Override
  public void setCountry(String country) {
    this.country = country;
  }

  @Override
  public String getProvince() {
    return province;
  }

  @Override
  public void setProvince(String province) {
    this.province = province;
  }

  @Override
  public Long getLatitude() {
    return latitude;
  }

  @Override
  public void setLatitude(Long latitude) {
    this.latitude = latitude;
  }

  @Override
  public Long getLongitude() {
    return longitude;
  }

  @Override
  public void setLongitude(Long longitude) {
    this.longitude = longitude;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((city == null) ? 0 : city.hashCode());
    result = prime * result + ((country == null) ? 0 : country.hashCode());
    result = prime * result + ((county == null) ? 0 : county.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
    result = prime * result + ((line1 == null) ? 0 : line1.hashCode());
    result = prime * result + ((line2 == null) ? 0 : line2.hashCode());
    result = prime * result + ((line3 == null) ? 0 : line3.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((longitude == null) ? 0 : longitude.hashCode());
    result = prime * result + ((province == null) ? 0 : province.hashCode());
    result = prime * result + ((state == null) ? 0 : state.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    result = prime * result + ((zIPCode == null) ? 0 : zIPCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    AddressImpl other = (AddressImpl) obj;
    if (city == null) {
      if (other.city != null)
        return false;
    } else if (!city.equals(other.city))
      return false;
    if (country == null) {
      if (other.country != null)
        return false;
    } else if (!country.equals(other.country))
      return false;
    if (county == null) {
      if (other.county != null)
        return false;
    } else if (!county.equals(other.county))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (latitude == null) {
      if (other.latitude != null)
        return false;
    } else if (!latitude.equals(other.latitude))
      return false;
    if (line1 == null) {
      if (other.line1 != null)
        return false;
    } else if (!line1.equals(other.line1))
      return false;
    if (line2 == null) {
      if (other.line2 != null)
        return false;
    } else if (!line2.equals(other.line2))
      return false;
    if (line3 == null) {
      if (other.line3 != null)
        return false;
    } else if (!line3.equals(other.line3))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (longitude == null) {
      if (other.longitude != null)
        return false;
    } else if (!longitude.equals(other.longitude))
      return false;
    if (province == null) {
      if (other.province != null)
        return false;
    } else if (!province.equals(other.province))
      return false;
    if (state == null) {
      if (other.state != null)
        return false;
    } else if (!state.equals(other.state))
      return false;
    if (type != other.type)
      return false;
    if (zIPCode == null) {
      if (other.zIPCode != null)
        return false;
    } else if (!zIPCode.equals(other.zIPCode))
      return false;
    return true;
  }

}
