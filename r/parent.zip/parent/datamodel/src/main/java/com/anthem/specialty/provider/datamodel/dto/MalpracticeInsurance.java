package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = MalpracticeInsuranceImpl.class)
public interface MalpracticeInsurance extends Serializable {
  @JsonProperty("Insurer")
  @ApiModelProperty(required = false)
  String getInsurer();

  @JsonProperty("Insurer")
  @ApiModelProperty(required = false)
  void setInsurer(String insurer);

  @JsonProperty("InsuredLimit")
  @ApiModelProperty(required = false)
  Character getInsuredLimit();

  @JsonProperty("InsuredLimit")
  @ApiModelProperty(required = false)
  void setInsuredLimit(Character insuredLimit);

  @JsonProperty("Renewal")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getRenewal();

  @JsonProperty("Renewal")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setRenewal(LocalDate renewal);

  @JsonProperty("PolicyNo")
  @ApiModelProperty(required = false)
  String getPolicyNo();

  @JsonProperty("PolicyNo")
  @ApiModelProperty(required = false)
  void setPolicyNo(String policyNo);

}