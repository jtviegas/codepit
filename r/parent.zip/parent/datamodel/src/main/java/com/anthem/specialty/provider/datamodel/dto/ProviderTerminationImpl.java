package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProviderTerminationImpl implements ProviderTermination {

  @JsonCreator
  public static ProviderTermination create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ProviderTermination impl = null;
    impl = mapper.readValue(json, ProviderTerminationImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate from;

  private Long terminationLevelCode;

  public ProviderTerminationImpl() {
  }

  public ProviderTerminationImpl(LocalDate from, long terminationLevelCode) {
    this.from = from;
    this.terminationLevelCode = terminationLevelCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderTermination#getFrom()
   */
  @Override
  public LocalDate getFrom() {
    return from;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderTermination#setFrom(java.util.Date)
   */
  @Override
  public void setFrom(LocalDate from) {
    this.from = from;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderTermination#getTerminationLevelCode()
   */
  @Override
  public Long getTerminationLevelCode() {
    return terminationLevelCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProviderTermination#setTerminationLevelCode(java.lang.Integer)
   */
  @Override
  public void setTerminationLevelCode(Long terminationLevelCode) {
    this.terminationLevelCode = terminationLevelCode;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((from == null) ? 0 : from.hashCode());
    result = prime * result + ((terminationLevelCode == null) ? 0 : terminationLevelCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ProviderTerminationImpl other = (ProviderTerminationImpl) obj;
    if (from == null) {
      if (other.from != null)
        return false;
    } else if (!from.equals(other.from))
      return false;
    if (terminationLevelCode == null) {
      if (other.terminationLevelCode != null)
        return false;
    } else if (!terminationLevelCode.equals(other.terminationLevelCode))
      return false;
    return true;
  }

}
