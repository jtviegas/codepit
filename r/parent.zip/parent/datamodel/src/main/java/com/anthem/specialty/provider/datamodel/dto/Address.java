package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = AddressImpl.class)
public interface Address extends DataEntity { // CHECKME: extends UpdatableAddress?

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  AddressType getType();

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  void setType(AddressType type);

  @JsonProperty("Line1")
  @ApiModelProperty(required = true)
  String getLine1();

  @JsonProperty("Line1")
  @ApiModelProperty(required = true)
  void setLine1(String line1);

  @JsonProperty("Line2")
  @ApiModelProperty(required = false)
  String getLine2();

  @JsonProperty("Line2")
  @ApiModelProperty(required = false)
  void setLine2(String line2);

  @JsonProperty("Line3")
  @ApiModelProperty(required = false)
  String getLine3();

  @JsonProperty("Line3")
  @ApiModelProperty(required = false)
  void setLine3(String line3);

  @JsonProperty("City")
  @ApiModelProperty(required = false)
  String getCity();

  @JsonProperty("City")
  @ApiModelProperty(required = false)
  void setCity(String city);

  @JsonProperty("State")
  @ApiModelProperty(required = false)
  String getState();

  @JsonProperty("State")
  @ApiModelProperty(required = false)
  void setState(String state);

  @JsonProperty("ZIPCode")
  @ApiModelProperty(required = false)
  String getzIPCode();

  @JsonProperty("ZIPCode")
  @ApiModelProperty(required = false)
  void setzIPCode(String zIPCode);

  @JsonProperty("County")
  @ApiModelProperty(required = false)
  String getCounty();

  @JsonProperty("County")
  @ApiModelProperty(required = false)
  void setCounty(String county);

  @JsonProperty("Country")
  @ApiModelProperty(required = false)
  String getCountry();

  @JsonProperty("Country")
  @ApiModelProperty(required = false)
  void setCountry(String country);

  @JsonProperty("Province")
  @ApiModelProperty(required = false)
  String getProvince();

  @JsonProperty("Province")
  @ApiModelProperty(required = false)
  void setProvince(String province);

  @JsonProperty("Latitude")
  @ApiModelProperty(required = false)
  Long getLatitude();

  @JsonProperty("Latitude")
  @ApiModelProperty(required = false)
  void setLatitude(Long latitude);

  @JsonProperty("Longitude")
  @ApiModelProperty(required = false)
  Long getLongitude();

  @JsonProperty("Longitude")
  @ApiModelProperty(required = false)
  void setLongitude(Long longitude);

}