package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = DocumentImpl.class)
public interface Document extends DataEntity {
  @JsonProperty("ControlNumber")
  @ApiModelProperty(required = true)
  @NotNull
  Long getControlNumber();

  @JsonProperty("ControlNumber")
  @ApiModelProperty(required = true)
  void setControlNumber(Long controlNumber);

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  DocumentType getType();

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  void setType(DocumentType type);

  @JsonProperty("Source")
  @ApiModelProperty(required = false)
  Character getSource();

  @JsonProperty("Source")
  @ApiModelProperty(required = false)
  void setSource(Character source);

}