package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class NewEffectiveRelationshipImpl implements NewEffectiveRelationship {

  private static final long serialVersionUID = 1L;

  @NotNull
  private EffectivePeriod effective;

  public NewEffectiveRelationshipImpl() {
  }

  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewEffectiveRelationshipImpl other = (NewEffectiveRelationshipImpl) obj;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    return true;
  }

}
