package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = SimpleProviderImpl.class)
public interface SimpleProvider extends DataEntity {
  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  void setName(String name);

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  String getName();

}