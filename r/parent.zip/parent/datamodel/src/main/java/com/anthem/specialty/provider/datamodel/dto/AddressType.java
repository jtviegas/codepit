package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 'Directory', 'GeoCoding', 'Mailing', 'Billing' and 'Payment'
 * 
 * @author jviegas
 *
 */
public enum AddressType {
  D,
  G,
  M,
  B,
  P;

  @JsonIgnore
  public static AddressType fromChar(char c) {
    AddressType r = null;
    for (AddressType g : values()) {
      if (g.toString().charAt(0) == c) {
        r = g;
        break;
      }
    }
    return r;
  }

  @JsonIgnore
  public char toChar() {
    return this.toString().charAt(0);
  }

}
