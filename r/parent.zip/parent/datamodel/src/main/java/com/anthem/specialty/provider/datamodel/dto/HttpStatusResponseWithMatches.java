package com.anthem.specialty.provider.datamodel.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = HttpStatusResponseWithMatchesImpl.class)
public interface HttpStatusResponseWithMatches extends HttpStatusResponse {

  @JsonProperty("matches")
  public void setMatches(List<SimpleClinic> matches);

  @JsonProperty("matches")
  @NotNull
  @Valid
  @ApiModelProperty(required = true)
  public List<SimpleClinic> getMatches();
}
