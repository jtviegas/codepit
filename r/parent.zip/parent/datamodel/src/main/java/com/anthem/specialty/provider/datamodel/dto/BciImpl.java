package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BciImpl implements Bci {

  @JsonCreator
  public static Bci create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Bci impl = null;
    impl = mapper.readValue(json, BciImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String id;

  private String billed;

  public BciImpl() {
  }

  @Override
  public String getId() {
    return id;
  }

  @Override
  public void setId(String id) {
    this.id = id;
  }

  @Override
  public String getBilled() {
    return billed;
  }

  @Override
  public void setBilled(String billed) {
    this.billed = billed;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((billed == null) ? 0 : billed.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    BciImpl other = (BciImpl) obj;
    if (billed == null) {
      if (other.billed != null)
        return false;
    } else if (!billed.equals(other.billed))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    return true;
  }

}
