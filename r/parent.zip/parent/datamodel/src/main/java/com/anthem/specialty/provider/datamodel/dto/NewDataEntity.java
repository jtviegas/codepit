package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewDataEntityImpl.class)
public interface NewDataEntity extends Serializable {

  @JsonCreator
  public static NewDataEntity create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewDataEntity module = null;
    module = mapper.readValue(json, NewDataEntityImpl.class);
    return module;
  }

  @JsonProperty("DataOwnerId")
  @ApiModelProperty(required = true)
  Long getDataOwnerId();

  @JsonProperty("DataOwnerId")
  @ApiModelProperty(required = true)
  void setDataOwnerId(Long o);
}
