package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewAddressImpl implements NewAddress {

  @JsonCreator
  public static NewAddress create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewAddress impl = null;
    impl = mapper.readValue(json, NewAddressImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private AddressType type;

  private String line1;

  private String line2;

  private String line3;

  private String city;

  private String state;

  private String zipCode;

  private String county;

  private String country;

  private String province;

  private Long latitude;

  private Long longitude;

  public NewAddressImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getType()
   */
  @Override
  public AddressType getType() {
    return type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewAddress#setType(com.anthem.specialty.provider.datamodel.dto.newdtos.
   * AddressType)
   */
  @Override
  public void setType(AddressType type) {
    this.type = type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getLine1()
   */
  @Override
  public String getLine1() {
    return line1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setLine1(java.lang.String)
   */
  @Override
  public void setLine1(String line1) {
    this.line1 = line1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getLine2()
   */
  @Override
  public String getLine2() {
    return line2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setLine2(java.lang.String)
   */
  @Override
  public void setLine2(String line2) {
    this.line2 = line2;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getLine3()
   */
  @Override
  public String getLine3() {
    return line3;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setLine3(java.lang.String)
   */
  @Override
  public void setLine3(String line3) {
    this.line3 = line3;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getCity()
   */
  @Override
  public String getCity() {
    return city;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setCity(java.lang.String)
   */
  @Override
  public void setCity(String city) {
    this.city = city;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getState()
   */
  @Override
  public String getState() {
    return state;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setState(java.lang.String)
   */
  @Override
  public void setState(String state) {
    this.state = state;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getZipCode()
   */
  @Override
  public String getZipCode() {
    return zipCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setZipCode(java.lang.String)
   */
  @Override
  public void setZipCode(String zIPCode) {
    this.zipCode = zIPCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getCounty()
   */
  @Override
  public String getCounty() {
    return county;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setCounty(java.lang.String)
   */
  @Override
  public void setCounty(String county) {
    this.county = county;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getCountry()
   */
  @Override
  public String getCountry() {
    return country;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setCountry(java.lang.String)
   */
  @Override
  public void setCountry(String country) {
    this.country = country;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getProvince()
   */
  @Override
  public String getProvince() {
    return province;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setProvince(java.lang.String)
   */
  @Override
  public void setProvince(String province) {
    this.province = province;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getLatitude()
   */
  @Override
  public Long getLatitude() {
    return latitude;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setLatitude(java.lang.Long)
   */
  @Override
  public void setLatitude(Long latitude) {
    this.latitude = latitude;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#getLongitude()
   */
  @Override
  public Long getLongitude() {
    return longitude;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewAddress#setLongitude(java.lang.Long)
   */
  @Override
  public void setLongitude(Long longitude) {
    this.longitude = longitude;
  }

  @Override
  public String toString() {
    String r = Stream.of(line1, line2, line3, city, state, zipCode, county, country, province)
        .filter(o -> (null != o && (!o.isEmpty()))).collect(Collectors.joining(" "));
    return r;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((city == null) ? 0 : city.hashCode());
    result = prime * result + ((country == null) ? 0 : country.hashCode());
    result = prime * result + ((county == null) ? 0 : county.hashCode());
    result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
    result = prime * result + ((line1 == null) ? 0 : line1.hashCode());
    result = prime * result + ((line2 == null) ? 0 : line2.hashCode());
    result = prime * result + ((line3 == null) ? 0 : line3.hashCode());
    result = prime * result + ((longitude == null) ? 0 : longitude.hashCode());
    result = prime * result + ((province == null) ? 0 : province.hashCode());
    result = prime * result + ((state == null) ? 0 : state.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewAddressImpl other = (NewAddressImpl) obj;
    if (city == null) {
      if (other.city != null)
        return false;
    } else if (!city.equals(other.city))
      return false;
    if (country == null) {
      if (other.country != null)
        return false;
    } else if (!country.equals(other.country))
      return false;
    if (county == null) {
      if (other.county != null)
        return false;
    } else if (!county.equals(other.county))
      return false;
    if (latitude == null) {
      if (other.latitude != null)
        return false;
    } else if (!latitude.equals(other.latitude))
      return false;
    if (line1 == null) {
      if (other.line1 != null)
        return false;
    } else if (!line1.equals(other.line1))
      return false;
    if (line2 == null) {
      if (other.line2 != null)
        return false;
    } else if (!line2.equals(other.line2))
      return false;
    if (line3 == null) {
      if (other.line3 != null)
        return false;
    } else if (!line3.equals(other.line3))
      return false;
    if (longitude == null) {
      if (other.longitude != null)
        return false;
    } else if (!longitude.equals(other.longitude))
      return false;
    if (province == null) {
      if (other.province != null)
        return false;
    } else if (!province.equals(other.province))
      return false;
    if (state == null) {
      if (other.state != null)
        return false;
    } else if (!state.equals(other.state))
      return false;
    if (type != other.type)
      return false;
    if (zipCode == null) {
      if (other.zipCode != null)
        return false;
    } else if (!zipCode.equals(other.zipCode))
      return false;
    return true;
  }

}
