package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = SanctionImpl.class)
public interface Sanction extends DataEntity {

  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  RelatedClinic getClinic();

  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  void setClinic(RelatedClinic clinic);

  @JsonProperty("SanctionAgency")
  @ApiModelProperty(required = false)
  String getSanctionAgency();

  @JsonProperty("SanctionAgency")
  @ApiModelProperty(required = false)
  void setSanctionAgency(String sanctionAgency);

  @JsonProperty("SanctionCode")
  @ApiModelProperty(required = false)
  String getSanctionCode();

  @JsonProperty("SanctionCode")
  @ApiModelProperty(required = false)
  void setSanctionCode(String sanctionCode);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

}