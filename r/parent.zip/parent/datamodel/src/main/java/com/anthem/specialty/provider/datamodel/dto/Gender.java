package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public enum Gender {
  M,
  F;

  @JsonIgnore
  public static Gender fromChar(char c) {
    Gender r = null;
    for (Gender g : values()) {
      if (g.toString().charAt(0) == c) {
        r = g;
        break;
      }
    }
    return r;
  }

  @JsonIgnore
  public char toChar() {
    return this.toString().charAt(0);
  }

}
