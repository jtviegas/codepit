package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ProviderImpl.class)
public interface Provider extends DataEntity {
  @JsonProperty("Tin")
  @ApiModelProperty(required = false)
  String getTin();

  @JsonProperty("Tin")
  @ApiModelProperty(required = false)
  void setTin(String tin);

  @JsonProperty("StateProviderNo")
  @ApiModelProperty(required = false)
  String getStateProviderNo();

  @JsonProperty("StateProviderNo")
  @ApiModelProperty(required = false)
  void setStateProviderNo(String stateProviderNo);

  @JsonProperty("NamePrefix")
  @ApiModelProperty(required = false)
  String getNamePrefix();

  @JsonProperty("NamePrefix")
  @ApiModelProperty(required = false)
  void setNamePrefix(String namePrefix);

  @JsonProperty("FirstName")
  @ApiModelProperty(required = false)
  String getFirstName();

  @JsonProperty("FirstName")
  @ApiModelProperty(required = false)
  void setFirstName(String firstName);

  @JsonProperty("MiddleName")
  @ApiModelProperty(required = false)
  String getMiddleName();

  @JsonProperty("MiddleName")
  @ApiModelProperty(required = false)
  void setMiddleName(String middleName);

  @JsonProperty("LastName")
  @ApiModelProperty(required = false)
  String getLastName();

  @JsonProperty("LastName")
  @ApiModelProperty(required = false)
  void setLastName(String lastName);

  @JsonProperty("NameSuffix")
  @ApiModelProperty(required = false)
  String getNameSuffix();

  @JsonProperty("NameSuffix")
  @ApiModelProperty(required = false)
  void setNameSuffix(String nameSuffix);

  @JsonProperty("Gender")
  @ApiModelProperty(required = false)
  Gender getGender();

  @JsonProperty("Gender")
  @ApiModelProperty(required = false)
  void setGender(Gender gender);

  @JsonProperty("BirthDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getBirthDate();

  @JsonProperty("BirthDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setBirthDate(LocalDate birthDate);

  @JsonProperty("SchoolOfDentistry")
  @ApiModelProperty(required = false)
  String getSchoolOfDentistry();

  @JsonProperty("SchoolOfDentistry")
  @ApiModelProperty(required = false)
  void setSchoolOfDentistry(String schoolOfDentistry);

  @JsonProperty("GraduationYear")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getGraduationYear();

  @JsonProperty("GraduationYear")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setGraduationYear(LocalDate graduationYear);

  @JsonProperty("PracticeEffectiveFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getPracticeEffectiveFrom();

  @JsonProperty("PracticeEffectiveFrom")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setPracticeEffectiveFrom(LocalDate practiceEffectiveFrom);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

  @JsonProperty("Retired")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getRetired();

  @JsonProperty("Retired")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setRetired(LocalDate retired);

  @JsonProperty("Deceased")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getDeceased();

  @JsonProperty("Deceased")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setDeceased(LocalDate deceased);

  @JsonProperty("MedicareNo")
  @ApiModelProperty(required = false)
  String getMedicareNo();

  @JsonProperty("MedicareNo")
  @ApiModelProperty(required = false)
  void setMedicareNo(String medicareNo);

  @JsonProperty("FirstBNotice")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getFirstBnotice();

  @JsonProperty("FirstBNotice")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setFirstBnotice(LocalDate firstBnotice);

  @JsonProperty("SecondBNotice")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getSecondBnotice();

  @JsonProperty("SecondBNotice")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setSecondBnotice(LocalDate secondBnotice);

  @JsonProperty("ConsentSignatureDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getConsentSignatureDate();

  @JsonProperty("ConsentSignatureDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setConsentSignatureDate(LocalDate consentSignatureDate);

  @JsonProperty("SpecialtySchool")
  @ApiModelProperty(required = false)
  String getSpecialtySchool();

  @JsonProperty("SpecialtySchool")
  @ApiModelProperty(required = false)
  void setSpecialtySchool(String specialtySchool);

  @JsonProperty("AnesthesialCertificateExpiry")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getAnesthesiaCertificateExpiry();

  @JsonProperty("AnesthesialCertificateExpiry")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setAnesthesiaCertificateExpiry(LocalDate anesthesiaCertificateExpiry);

  @JsonProperty("EmailAddress")
  @ApiModelProperty(required = false)
  String getEmailAddress();

  @JsonProperty("EmailAddress")
  @ApiModelProperty(required = false)
  void setEmailAddress(String emailAddress);

  @JsonProperty("ParaLicenseNumber")
  @ApiModelProperty(required = false)
  String getParaLicenseNumber();

  @JsonProperty("ParaLicenseNumber")
  @ApiModelProperty(required = false)
  void setParaLicenseNumber(String paraLicenseNumber);

  @JsonProperty("ParaLicenseState")
  @ApiModelProperty(required = false)
  String getParaLicenseState();

  @JsonProperty("ParaLicenseState")
  @ApiModelProperty(required = false)
  void setParaLicenseState(String paraLicenseState);

  @JsonProperty("SpecialtyGradYear")
  @ApiModelProperty(required = false)
  Integer getSpecialtyGradYear();

  @JsonProperty("SpecialtyGradYear")
  @ApiModelProperty(required = false)
  void setSpecialtyGradYear(Integer specialtyGradYear);

  @JsonProperty("FWAComplianceDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getFWAComplianceDate();

  @JsonProperty("FWAComplianceDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setFWAComplianceDate(LocalDate FWAComplianceDate);

  @JsonProperty("Degree1")
  @ApiModelProperty(required = false)
  String getDegree1();

  @JsonProperty("Degree1")
  @ApiModelProperty(required = false)
  void setDegree1(String degree1);

  @JsonProperty("Degree2")
  @ApiModelProperty(required = false)
  String getDegree2();

  @JsonProperty("Degree2")
  @ApiModelProperty(required = false)
  void setDegree2(String degree2);

  @JsonProperty("Terminated")
  @ApiModelProperty(required = false)
  @Valid
  ProviderTermination getTerminated();

  @JsonProperty("Terminated")
  @ApiModelProperty(required = false)
  void setTerminated(ProviderTermination terminated);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

  @JsonProperty("MalpracticeInsurance")
  @ApiModelProperty(required = false)
  MalpracticeInsurance getMalpracticeInsurance();

  @JsonProperty("MalpracticeInsurance")
  @ApiModelProperty(required = false)
  void setMalpracticeInsurance(MalpracticeInsurance malpracticeInsurance);

  @JsonProperty("ConsentFormSigned")
  @JsonFormat(shape = Shape.BOOLEAN)
  @ApiModelProperty(required = false)
  Boolean getConsentFormSigned();

  @JsonProperty("ConsentFormSigned")
  @JsonFormat(shape = Shape.BOOLEAN)
  @ApiModelProperty(required = false)
  void setConsentFormSigned(Boolean consentFormSigned);

  @JsonProperty("NoDeaNumberReason")
  @ApiModelProperty(required = false)
  String getNoDEANumericReason();

  @JsonProperty("NoDeaNumberReason")
  @ApiModelProperty(required = false)
  void setNoDEANumericReason(String noDEANumericReason);

  @JsonProperty("CollaborationAgreement")
  @ApiModelProperty(required = false)
  Boolean getCollaborationAgreement();

  @JsonProperty("CollaborationAgreement")
  @ApiModelProperty(required = false)
  void setCollaborationAgreement(Boolean collaborationAgreement);

}