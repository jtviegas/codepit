package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = StaffingImpl.class)
public interface Staffing extends Serializable {

  @JsonProperty("ProviderCount")
  @ApiModelProperty(required = true)
  Integer getProviderCount();

  @JsonProperty("ProviderCount")
  @ApiModelProperty(required = true)
  void setProviderCount(Integer providerCount);

  @JsonProperty("HygienistCount")
  @ApiModelProperty(required = true)
  Integer getHygienistCount();

  @JsonProperty("HygienistCount")
  @ApiModelProperty(required = true)
  void setHygienistCount(Integer hygienistCount);

  @JsonProperty("AssistantCount")
  @ApiModelProperty(required = true)
  Integer getAssistantCount();

  @JsonProperty("AssistantCount")
  @ApiModelProperty(required = true)
  void setAssistantCount(Integer assistantCount);

  @JsonProperty("SpecialistCount")
  @ApiModelProperty(required = true)
  Integer getSpecialistCount();

  @JsonProperty("SpecialistCount")
  @ApiModelProperty(required = true)
  void setSpecialistCount(Integer specialistCount);

  @JsonProperty("CollaborativeHygienistCount")
  @ApiModelProperty(required = true)
  Integer getCollaborativeHygienistCount();

  @JsonProperty("CollaborativeHygienistCount")
  @ApiModelProperty(required = true)
  void setCollaborativeHygienistCount(Integer collaborativeHygienistCount);

  @JsonProperty("DentalTherapistCount")
  @ApiModelProperty(required = true)
  Integer getDentalTherapistCount();

  @JsonProperty("DentalTherapistCount")
  @ApiModelProperty(required = true)
  void setDentalTherapistCount(Integer dentalTherapistCount);

  @JsonProperty("AdvancedDentalTherapistCount")
  @ApiModelProperty(required = true)
  Integer getAdvancedDentalTherapistCount();

  @JsonProperty("AdvancedDentalTherapistCount")
  @ApiModelProperty(required = true)
  void setAdvancedDentalTherapistCount(Integer advancedDentalTherapistCount);

  @JsonProperty("AdvancedDentalHygienistCount")
  @ApiModelProperty(required = true)
  Integer getAdvancedDentalHygienistCount();

  @JsonProperty("AdvancedDentalHygienistCount")
  @ApiModelProperty(required = true)
  void setAdvancedDentalHygienistCount(Integer advancedDentalHygienistCount);

}