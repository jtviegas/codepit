package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewClinicCredentialsImpl implements NewClinicCredentials {

  @JsonCreator
  public static NewClinicCredentials create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewClinicCredentials impl = null;
    impl = mapper.readValue(json, NewClinicCredentialsImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate credentialed;

  private Boolean handicapAccess = Boolean.FALSE;

  private Boolean cprTrained = Boolean.FALSE;

  private Boolean emergencyTrained = Boolean.FALSE;

  private Boolean emergencyKit = Boolean.FALSE;

  private Boolean publicTransport = Boolean.FALSE;

  private Boolean handicappedParking = Boolean.FALSE;

  private Boolean cDCAndOSHARulesCompliance = Boolean.FALSE;

  private Boolean deptHealthRulesCompliance = Boolean.FALSE;

  public NewClinicCredentialsImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#getCredentialed()
   */
  @Override
  public LocalDate getCredentialed() {
    return credentialed;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setCredentialed(java.util.Date)
   */
  @Override
  public void setCredentialed(LocalDate credentialed) {
    this.credentialed = credentialed;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isHandicapAccess()
   */
  @Override
  public Boolean isHandicapAccess() {
    return handicapAccess;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setHandicapAccess(Boolean)
   */
  @Override
  public void setHandicapAccess(Boolean handicapAccess) {
    this.handicapAccess = handicapAccess;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isCprTrained()
   */
  @Override
  public Boolean isCprTrained() {
    return cprTrained;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setCprTrained(Boolean)
   */
  @Override
  public void setCprTrained(Boolean cprTrained) {
    this.cprTrained = cprTrained;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isEmergencyTrained()
   */
  @Override
  public Boolean isEmergencyTrained() {
    return emergencyTrained;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setEmergencyTrained(Boolean)
   */
  @Override
  public void setEmergencyTrained(Boolean emergencyTrained) {
    this.emergencyTrained = emergencyTrained;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isEmergencyKit()
   */
  @Override
  public Boolean isEmergencyKit() {
    return emergencyKit;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setEmergencyKit(Boolean)
   */
  @Override
  public void setEmergencyKit(Boolean emergencyKit) {
    this.emergencyKit = emergencyKit;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isPublicTransport()
   */
  @Override
  public Boolean isPublicTransport() {
    return publicTransport;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setPublicTransport(Boolean)
   */
  @Override
  public void setPublicTransport(Boolean publicTransport) {
    this.publicTransport = publicTransport;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isHandicappedParking()
   */
  @Override
  public Boolean isHandicappedParking() {
    return handicappedParking;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setHandicappedParking(Boolean)
   */
  @Override
  public void setHandicappedParking(Boolean handicappedParking) {
    this.handicappedParking = handicappedParking;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#iscDCAndOSHARulesCompliance()
   */
  @Override
  public Boolean isCDCAndOSHARulesCompliance() {
    return cDCAndOSHARulesCompliance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setcDCAndOSHARulesCompliance(Boolean)
   */
  @Override
  public void setCDCAndOSHARulesCompliance(Boolean cDCAndOSHARulesCompliance) {
    this.cDCAndOSHARulesCompliance = cDCAndOSHARulesCompliance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#isDeptHealthRulesCompliance()
   */
  @Override
  public Boolean isDeptHealthRulesCompliance() {
    return deptHealthRulesCompliance;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewClinicCredentials#setDeptHealthRulesCompliance(Boolean)
   */
  @Override
  public void setDeptHealthRulesCompliance(Boolean deptHealthRulesCompliance) {
    this.deptHealthRulesCompliance = deptHealthRulesCompliance;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (cDCAndOSHARulesCompliance ? 1231 : 1237);
    result = prime * result + (cprTrained ? 1231 : 1237);
    result = prime * result + ((credentialed == null) ? 0 : credentialed.hashCode());
    result = prime * result + (deptHealthRulesCompliance ? 1231 : 1237);
    result = prime * result + (emergencyKit ? 1231 : 1237);
    result = prime * result + (emergencyTrained ? 1231 : 1237);
    result = prime * result + (handicappedParking ? 1231 : 1237);
    result = prime * result + (handicapAccess ? 1231 : 1237);
    result = prime * result + (publicTransport ? 1231 : 1237);
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewClinicCredentialsImpl other = (NewClinicCredentialsImpl) obj;
    if (cDCAndOSHARulesCompliance != other.cDCAndOSHARulesCompliance)
      return false;
    if (cprTrained != other.cprTrained)
      return false;
    if (credentialed == null) {
      if (other.credentialed != null)
        return false;
    } else if (!credentialed.equals(other.credentialed))
      return false;
    if (deptHealthRulesCompliance != other.deptHealthRulesCompliance)
      return false;
    if (emergencyKit != other.emergencyKit)
      return false;
    if (emergencyTrained != other.emergencyTrained)
      return false;
    if (handicappedParking != other.handicappedParking)
      return false;
    if (handicapAccess != other.handicapAccess)
      return false;
    if (publicTransport != other.publicTransport)
      return false;
    return true;
  }

}
