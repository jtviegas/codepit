package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelationshipImpl.class)
public interface Relationship extends Identifiable {

  @JsonProperty("DataOwner")
  @ApiModelProperty(required = true)
  @NotNull
  DataOwner getDataOwner();

  @JsonProperty("DataOwner")
  @ApiModelProperty(required = true)
  void setDataOwner(DataOwner o);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

}
