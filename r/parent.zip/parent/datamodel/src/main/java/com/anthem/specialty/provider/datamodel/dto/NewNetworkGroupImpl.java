package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewNetworkGroupImpl implements NewNetworkGroup {
  @JsonCreator
  public static NewNetwork create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewNetwork impl = null;
    impl = mapper.readValue(json, NewNetworkImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  @NotNull
  private Long dataOwnerId;

  @NotNull
  private String description;

  @Override
  public Long getDataOwnerId() {
    return dataOwnerId;
  }

  @Override
  public void setDataOwnerId(Long o) {
    this.dataOwnerId = o;
  }

  @Override
  public String getDescription() {
    return description;
  }

  @Override
  public void setDescription(String description) {
    this.description = description;
  }

}
