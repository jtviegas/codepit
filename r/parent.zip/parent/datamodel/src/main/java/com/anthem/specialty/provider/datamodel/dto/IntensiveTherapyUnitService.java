package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = IntensiveTherapyUnitServiceImpl.class)
public interface IntensiveTherapyUnitService extends Serializable {

  @JsonProperty("ITUClinicType")
  @ApiModelProperty(required = false)
  String getType();

  @JsonProperty("ITUClinicType")
  @ApiModelProperty(required = false)
  void setType(String type);

}