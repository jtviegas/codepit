package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ClinicMatchImpl implements ClinicMatch {

  private static final long serialVersionUID = 1L;

  @JsonCreator
  public static ClinicMatch create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ClinicMatch impl = null;
    impl = mapper.readValue(json, ClinicMatchImpl.class);
    return impl;
  }

  private Long dataOwnerId;

  private NewAddress address;

  private NewPhoneContact phone;

  public ClinicMatchImpl() {
  }

  @Override
  public @NotNull Long getDataOwnerId() {
    return dataOwnerId;
  }

  @Override
  public void setDataOwnerId(Long id) {
    this.dataOwnerId = id;
  }

  @Override
  public @NotNull NewAddress getAddress() {
    return address;
  }

  @Override
  public void setAddress(NewAddress address) {
    this.address = address;
  }

  @Override
  public @NotNull NewPhoneContact getPhone() {
    return phone;
  }

  @Override
  public void setPhone(NewPhoneContact phone) {
    this.phone = phone;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((address == null) ? 0 : address.hashCode());
    result = prime * result + ((dataOwnerId == null) ? 0 : dataOwnerId.hashCode());
    result = prime * result + ((phone == null) ? 0 : phone.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ClinicMatchImpl other = (ClinicMatchImpl) obj;
    if (address == null) {
      if (other.address != null)
        return false;
    } else if (!address.equals(other.address))
      return false;
    if (dataOwnerId == null) {
      if (other.dataOwnerId != null)
        return false;
    } else if (!dataOwnerId.equals(other.dataOwnerId))
      return false;
    if (phone == null) {
      if (other.phone != null)
        return false;
    } else if (!phone.equals(other.phone))
      return false;
    return true;
  }

}
