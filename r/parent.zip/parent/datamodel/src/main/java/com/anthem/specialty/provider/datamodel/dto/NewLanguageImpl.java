package com.anthem.specialty.provider.datamodel.dto;
// Generated 01-Dec-2017 15:03:23 by Hibernate Tools 5.2.6.Final

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewLanguageImpl implements NewLanguage {

  @JsonCreator
  public static NewLanguage create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewLanguage impl = null;
    impl = mapper.readValue(json, NewLanguageImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String name;

  private String isoCode;

  public NewLanguageImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLanguage#getName()
   */
  @Override
  public String getName() {
    return name;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLanguage#setName(java.lang.String)
   */
  @Override
  public void setName(String name) {
    this.name = name;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLanguage#getIsoCode()
   */
  @Override
  public String getIsoCode() {
    return isoCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewLanguage#setIsoCode(java.lang.String)
   */
  @Override
  public void setIsoCode(String isoCode) {
    this.isoCode = isoCode;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((isoCode == null) ? 0 : isoCode.hashCode());
    result = prime * result + ((name == null) ? 0 : name.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewLanguageImpl other = (NewLanguageImpl) obj;
    if (isoCode == null) {
      if (other.isoCode != null)
        return false;
    } else if (!isoCode.equals(other.isoCode))
      return false;
    if (name == null) {
      if (other.name != null)
        return false;
    } else if (!name.equals(other.name))
      return false;
    return true;
  }

}
