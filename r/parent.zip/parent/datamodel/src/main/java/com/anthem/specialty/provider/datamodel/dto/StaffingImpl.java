package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class StaffingImpl implements Staffing {

  @JsonCreator
  public static Staffing create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    Staffing module = null;
    module = mapper.readValue(json, StaffingImpl.class);
    return module;
  }

  private static final long serialVersionUID = 1L;

  private Integer providerCount;

  private Integer hygienistCount;

  private Integer assistantCount;

  private Integer specialistCount;

  private Integer collaborativeHygienistCount;

  private Integer dentalTherapistCount;

  private Integer advancedDentalTherapistCount;

  private Integer advancedDentalHygienistCount;

  public StaffingImpl() {
  }

  @Override
  public Integer getProviderCount() {
    return providerCount;
  }

  @Override
  public void setProviderCount(Integer providerCount) {
    this.providerCount = providerCount;
  }

  @Override
  public Integer getHygienistCount() {
    return hygienistCount;
  }

  @Override
  public void setHygienistCount(Integer hygienistCount) {
    this.hygienistCount = hygienistCount;
  }

  @Override
  public Integer getAssistantCount() {
    return assistantCount;
  }

  @Override
  public void setAssistantCount(Integer assistantCount) {
    this.assistantCount = assistantCount;
  }

  @Override
  public Integer getSpecialistCount() {
    return specialistCount;
  }

  @Override
  public void setSpecialistCount(Integer specialistCount) {
    this.specialistCount = specialistCount;
  }

  @Override
  public Integer getCollaborativeHygienistCount() {
    return collaborativeHygienistCount;
  }

  @Override
  public void setCollaborativeHygienistCount(Integer collaborativeHygienistCount) {
    this.collaborativeHygienistCount = collaborativeHygienistCount;
  }

  @Override
  public Integer getDentalTherapistCount() {
    return dentalTherapistCount;
  }

  @Override
  public void setDentalTherapistCount(Integer dentalTherapistCount) {
    this.dentalTherapistCount = dentalTherapistCount;
  }

  @Override
  public Integer getAdvancedDentalTherapistCount() {
    return advancedDentalTherapistCount;
  }

  @Override
  public void setAdvancedDentalTherapistCount(Integer advancedDentalTherapistCount) {
    this.advancedDentalTherapistCount = advancedDentalTherapistCount;
  }

  @Override
  public Integer getAdvancedDentalHygienistCount() {
    return advancedDentalHygienistCount;
  }

  @Override
  public void setAdvancedDentalHygienistCount(Integer advancedDentalHygienistCount) {
    this.advancedDentalHygienistCount = advancedDentalHygienistCount;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((advancedDentalHygienistCount == null) ? 0 : advancedDentalHygienistCount.hashCode());
    result = prime * result + ((advancedDentalTherapistCount == null) ? 0 : advancedDentalTherapistCount.hashCode());
    result = prime * result + ((assistantCount == null) ? 0 : assistantCount.hashCode());
    result = prime * result + ((collaborativeHygienistCount == null) ? 0 : collaborativeHygienistCount.hashCode());
    result = prime * result + ((dentalTherapistCount == null) ? 0 : dentalTherapistCount.hashCode());
    result = prime * result + ((hygienistCount == null) ? 0 : hygienistCount.hashCode());
    result = prime * result + ((providerCount == null) ? 0 : providerCount.hashCode());
    result = prime * result + ((specialistCount == null) ? 0 : specialistCount.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    StaffingImpl other = (StaffingImpl) obj;
    if (advancedDentalHygienistCount == null) {
      if (other.advancedDentalHygienistCount != null)
        return false;
    } else if (!advancedDentalHygienistCount.equals(other.advancedDentalHygienistCount))
      return false;
    if (advancedDentalTherapistCount == null) {
      if (other.advancedDentalTherapistCount != null)
        return false;
    } else if (!advancedDentalTherapistCount.equals(other.advancedDentalTherapistCount))
      return false;
    if (assistantCount == null) {
      if (other.assistantCount != null)
        return false;
    } else if (!assistantCount.equals(other.assistantCount))
      return false;
    if (collaborativeHygienistCount == null) {
      if (other.collaborativeHygienistCount != null)
        return false;
    } else if (!collaborativeHygienistCount.equals(other.collaborativeHygienistCount))
      return false;
    if (dentalTherapistCount == null) {
      if (other.dentalTherapistCount != null)
        return false;
    } else if (!dentalTherapistCount.equals(other.dentalTherapistCount))
      return false;
    if (hygienistCount == null) {
      if (other.hygienistCount != null)
        return false;
    } else if (!hygienistCount.equals(other.hygienistCount))
      return false;
    if (providerCount == null) {
      if (other.providerCount != null)
        return false;
    } else if (!providerCount.equals(other.providerCount))
      return false;
    if (specialistCount == null) {
      if (other.specialistCount != null)
        return false;
    } else if (!specialistCount.equals(other.specialistCount))
      return false;
    return true;
  }

}
