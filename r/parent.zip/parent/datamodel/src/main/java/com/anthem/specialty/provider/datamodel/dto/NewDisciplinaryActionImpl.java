package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewDisciplinaryActionImpl implements NewDisciplinaryAction {

  @JsonCreator
  public static NewDisciplinaryAction create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewDisciplinaryAction impl = null;
    impl = mapper.readValue(json, NewDisciplinaryActionImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String originatorCode;

  private String description;

  private String comments;

  private EffectivePeriod effective;

  public NewDisciplinaryActionImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#getOriginatorCode()
   */
  @Override
  public @NotNull String getOriginatorCode() {
    return originatorCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#setOriginatorCode(java.lang.String)
   */
  @Override
  public void setOriginatorCode(String originatorCode) {
    this.originatorCode = originatorCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#getDescription()
   */
  @Override
  public @NotNull String getDescription() {
    return description;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#setDescription(java.lang.String)
   */
  @Override
  public void setDescription(String description) {
    this.description = description;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#getComments()
   */
  @Override
  public String getComments() {
    return comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#setComments(java.lang.String)
   */
  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#getEffective()
   */
  @Override
  public @NotNull EffectivePeriod getEffective() {
    return effective;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction#setEffective(com.anthem.specialty.provider.
   * datamodel.dto.newdtos.EffectivePeriod)
   */
  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((description == null) ? 0 : description.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((originatorCode == null) ? 0 : originatorCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewDisciplinaryActionImpl other = (NewDisciplinaryActionImpl) obj;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (description == null) {
      if (other.description != null)
        return false;
    } else if (!description.equals(other.description))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (originatorCode == null) {
      if (other.originatorCode != null)
        return false;
    } else if (!originatorCode.equals(other.originatorCode))
      return false;
    return true;
  }

}
