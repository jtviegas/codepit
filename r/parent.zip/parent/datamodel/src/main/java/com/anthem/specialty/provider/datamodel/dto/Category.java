package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = CategoryImpl.class)
public interface Category extends Serializable {

  @JsonProperty("Code")
  @ApiModelProperty(required = true)
  @NotNull
  String getCode();

  @JsonProperty("Code")
  @ApiModelProperty(required = true)
  void setCode(String code);

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  String getDescription();

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  void setDescription(String description);

}