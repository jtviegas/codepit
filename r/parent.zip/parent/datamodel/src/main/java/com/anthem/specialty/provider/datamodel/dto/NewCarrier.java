package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewCarrierImpl.class)
public interface NewCarrier extends NewDataEntity {

  @JsonProperty("ClearCarrierNo")
  @ApiModelProperty(required = true)
  String getClearCarrierNo();

  @JsonProperty("ClearCarrierNo")
  @ApiModelProperty(required = true)
  void setClearCarrierNo(String o);

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  String getDescription();

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  void setDescription(String description);

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  void setEffective(EffectivePeriod effective);

  @JsonProperty("ContactName")
  @ApiModelProperty(required = false)
  String getContactName();

  @JsonProperty("ContactName")
  @ApiModelProperty(required = false)
  void setContactName(String o);

  @JsonProperty("Manager")
  @ApiModelProperty(required = false)
  String getManager();

  @JsonProperty("Manager")
  @ApiModelProperty(required = false)
  void setManager(String o);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String o);

}
