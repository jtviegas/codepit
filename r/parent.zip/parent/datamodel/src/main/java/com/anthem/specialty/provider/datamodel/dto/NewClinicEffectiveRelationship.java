package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewClinicEffectiveRelationshipImpl.class)
public interface NewClinicEffectiveRelationship extends NewEffectiveRelationship {
  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  @Valid
  CoreDataEntity getClinic();

  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  void setClinic(CoreDataEntity clinic);
}
