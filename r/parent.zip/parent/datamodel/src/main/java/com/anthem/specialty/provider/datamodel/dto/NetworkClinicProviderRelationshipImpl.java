package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NetworkClinicProviderRelationshipImpl implements NetworkClinicProviderRelationship {

  @JsonCreator
  public static NetworkClinicProviderRelationship create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NetworkClinicProviderRelationship impl = null;
    impl = mapper.readValue(json, NetworkClinicProviderRelationshipImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  private Boolean isFrozen;

  private LocalDate frozenFrom;

  private String officeNumber;

  private EffectivePeriod effective;

  private Boolean inDirectory = Boolean.TRUE;

  private Boolean holdCodeApplied = Boolean.TRUE;

  private NetworkProviderTermination terminated;

  private CoreDataEntity provider;

  private Boolean overrideExceptions = Boolean.FALSE;

  public NetworkClinicProviderRelationshipImpl() {
    this.links = new ArrayList<Link>();
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public Boolean isIsFrozen() {
    return isFrozen;
  }

  @Override
  public void setIsFrozen(Boolean frozen) {
    this.isFrozen = frozen;
  }

  @Override
  public LocalDate getFrozenFrom() {
    return frozenFrom;
  }

  @Override
  public void setFrozenFrom(LocalDate frozenFrom) {
    this.frozenFrom = frozenFrom;
  }

  @Override
  public String getOfficeNumber() {
    return officeNumber;
  }

  @Override
  public void setOfficeNumber(String officeNumber) {
    this.officeNumber = officeNumber;
  }

  @Override
  public EffectivePeriod getEffective() {
    return effective;
  }

  @Override
  public void setEffective(EffectivePeriod effective) {
    this.effective = effective;
  }

  @Override
  public Boolean isInDirectory() {
    return inDirectory;
  }

  @Override
  public void setInDirectory(Boolean inDirectory) {
    this.inDirectory = inDirectory;
  }

  @Override
  public Boolean isHoldCodeApplied() {
    return holdCodeApplied;
  }

  @Override
  public void setHoldCodeApplied(Boolean holdCodeApplied) {
    this.holdCodeApplied = holdCodeApplied;
  }

  @Override
  public NetworkProviderTermination getTerminated() {
    return terminated;
  }

  @Override
  public void setTerminated(NetworkProviderTermination terminated) {
    this.terminated = terminated;
  }

  @Override
  public @NotNull CoreDataEntity getProvider() {
    return provider;
  }

  @Override
  public void setProvider(CoreDataEntity provider) {
    this.provider = provider;
  }

  @Override
  public Boolean isOverrideExceptions() {
    return overrideExceptions;
  }

  @Override
  public void setOverrideExceptions(Boolean o) {
    overrideExceptions = o;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((effective == null) ? 0 : effective.hashCode());
    result = prime * result + ((frozenFrom == null) ? 0 : frozenFrom.hashCode());
    result = prime * result + ((holdCodeApplied == null) ? 0 : holdCodeApplied.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((inDirectory == null) ? 0 : inDirectory.hashCode());
    result = prime * result + ((isFrozen == null) ? 0 : isFrozen.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((officeNumber == null) ? 0 : officeNumber.hashCode());
    result = prime * result + ((overrideExceptions == null) ? 0 : overrideExceptions.hashCode());
    result = prime * result + ((provider == null) ? 0 : provider.hashCode());
    result = prime * result + ((terminated == null) ? 0 : terminated.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NetworkClinicProviderRelationshipImpl other = (NetworkClinicProviderRelationshipImpl) obj;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (effective == null) {
      if (other.effective != null)
        return false;
    } else if (!effective.equals(other.effective))
      return false;
    if (frozenFrom == null) {
      if (other.frozenFrom != null)
        return false;
    } else if (!frozenFrom.equals(other.frozenFrom))
      return false;
    if (holdCodeApplied == null) {
      if (other.holdCodeApplied != null)
        return false;
    } else if (!holdCodeApplied.equals(other.holdCodeApplied))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (inDirectory == null) {
      if (other.inDirectory != null)
        return false;
    } else if (!inDirectory.equals(other.inDirectory))
      return false;
    if (isFrozen == null) {
      if (other.isFrozen != null)
        return false;
    } else if (!isFrozen.equals(other.isFrozen))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (officeNumber == null) {
      if (other.officeNumber != null)
        return false;
    } else if (!officeNumber.equals(other.officeNumber))
      return false;
    if (overrideExceptions == null) {
      if (other.overrideExceptions != null)
        return false;
    } else if (!overrideExceptions.equals(other.overrideExceptions))
      return false;
    if (provider == null) {
      if (other.provider != null)
        return false;
    } else if (!provider.equals(other.provider))
      return false;
    if (terminated == null) {
      if (other.terminated != null)
        return false;
    } else if (!terminated.equals(other.terminated))
      return false;
    return true;
  }

}
