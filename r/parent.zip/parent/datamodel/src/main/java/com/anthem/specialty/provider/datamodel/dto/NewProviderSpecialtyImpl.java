package com.anthem.specialty.provider.datamodel.dto;
// Generated 01-Dec-2017 15:03:23 by Hibernate Tools 5.2.6.Final

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewProviderSpecialtyImpl implements NewProviderSpecialty {

  @JsonCreator
  public static NewProviderSpecialty create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewProviderSpecialty impl = null;
    impl = mapper.readValue(json, NewProviderSpecialtyImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private SpecialtyType specialtyCode;

  private String certifyingBoardId;

  private LocalDate eligibleFrom;

  private LocalDate certifiedFrom;

  private LocalDate renewalDate;

  private Integer renewalPeriod;

  private String comments;

  public NewProviderSpecialtyImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getSpecialtyCode()
   */
  @Override
  public SpecialtyType getSpecialtyCode() {
    return specialtyCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setSpecialtyCode(com.anthem.specialty.provider.
   * datamodel.dto.SpecialtyType)
   */
  @Override
  public void setSpecialtyCode(SpecialtyType specialtyCode) {
    this.specialtyCode = specialtyCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getCertifyingBoardId()
   */
  @Override
  public String getCertifyingBoardId() {
    return certifyingBoardId;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setCertifyingBoardId(java.lang.String)
   */
  @Override
  public void setCertifyingBoardId(String certifyingBoardId) {
    this.certifyingBoardId = certifyingBoardId;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getEligibleFrom()
   */
  @Override
  public LocalDate getEligibleFrom() {
    return eligibleFrom;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setEligibleFrom(java.util.Date)
   */
  @Override
  public void setEligibleFrom(LocalDate effectiveFrom) {
    this.eligibleFrom = effectiveFrom;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getCertifiedFrom()
   */
  @Override
  public LocalDate getCertifiedFrom() {
    return certifiedFrom;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setCertifiedFrom(java.util.Date)
   */
  @Override
  public void setCertifiedFrom(LocalDate certifiedFrom) {
    this.certifiedFrom = certifiedFrom;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getRenewalDate()
   */
  @Override
  public LocalDate getRenewalDate() {
    return renewalDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setRenewalDate(java.util.Date)
   */
  @Override
  public void setRenewalDate(LocalDate renewalDate) {
    this.renewalDate = renewalDate;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getRenewalPeriod()
   */
  @Override
  public Integer getRenewalPeriod() {
    return renewalPeriod;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setRenewalPeriod(java.lang.Integer)
   */
  @Override
  public void setRenewalPeriod(Integer renewalPeriod) {
    this.renewalPeriod = renewalPeriod;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#getComments()
   */
  @Override
  public String getComments() {
    return comments;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty#setComments(java.lang.String)
   */
  @Override
  public void setComments(String comments) {
    this.comments = comments;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((certifiedFrom == null) ? 0 : certifiedFrom.hashCode());
    result = prime * result + ((certifyingBoardId == null) ? 0 : certifyingBoardId.hashCode());
    result = prime * result + ((comments == null) ? 0 : comments.hashCode());
    result = prime * result + ((eligibleFrom == null) ? 0 : eligibleFrom.hashCode());
    result = prime * result + ((renewalDate == null) ? 0 : renewalDate.hashCode());
    result = prime * result + ((renewalPeriod == null) ? 0 : renewalPeriod.hashCode());
    result = prime * result + ((specialtyCode == null) ? 0 : specialtyCode.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewProviderSpecialtyImpl other = (NewProviderSpecialtyImpl) obj;
    if (certifiedFrom == null) {
      if (other.certifiedFrom != null)
        return false;
    } else if (!certifiedFrom.equals(other.certifiedFrom))
      return false;
    if (certifyingBoardId == null) {
      if (other.certifyingBoardId != null)
        return false;
    } else if (!certifyingBoardId.equals(other.certifyingBoardId))
      return false;
    if (comments == null) {
      if (other.comments != null)
        return false;
    } else if (!comments.equals(other.comments))
      return false;
    if (eligibleFrom == null) {
      if (other.eligibleFrom != null)
        return false;
    } else if (!eligibleFrom.equals(other.eligibleFrom))
      return false;
    if (renewalDate == null) {
      if (other.renewalDate != null)
        return false;
    } else if (!renewalDate.equals(other.renewalDate))
      return false;
    if (renewalPeriod == null) {
      if (other.renewalPeriod != null)
        return false;
    } else if (!renewalPeriod.equals(other.renewalPeriod))
      return false;
    if (specialtyCode == null) {
      if (other.specialtyCode != null)
        return false;
    } else if (!specialtyCode.equals(other.specialtyCode))
      return false;
    return true;
  }

}
