package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewW9Impl.class)
public interface NewW9 extends NewDataEntity {

  @JsonProperty("Tin")
  @ApiModelProperty(required = true)
  @NotNull
  String getTin();

  @JsonProperty("Tin")
  @ApiModelProperty(required = true)
  void setTin(String tin);

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  @NotNull
  TinType getType();

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  void setType(TinType type);

  @JsonProperty("IRSName")
  @ApiModelProperty(required = true)
  @NotNull
  String getIrsName();

  @JsonProperty("IRSName")
  @ApiModelProperty(required = true)
  void setIrsName(String irsName);

  @JsonProperty("SubmittedBy")
  @ApiModelProperty(required = false)
  String getSubmittedBy();

  @JsonProperty("SubmittedBy")
  @ApiModelProperty(required = false)
  void setSubmittedBy(String submittedBy);

  @JsonProperty("Received")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getReceived();

  @JsonProperty("Received")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setReceived(LocalDate received);

  @JsonProperty("ByPhone")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getByPhone();

  @JsonProperty("ByPhone")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setByPhone(LocalDate byPhone);

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  void setEffective(EffectivePeriod effective);

  @JsonProperty("CorporatePayment")
  @ApiModelProperty(required = true)
  @NotNull
  Boolean isCorporatePayment();

  @JsonProperty("CorporatePayment")
  @ApiModelProperty(required = true)
  void setCorporatePayment(Boolean corporatePayment);

  @JsonProperty("BackupWithholdingTax")
  @ApiModelProperty(required = true)
  @NotNull
  Boolean isBackupWithholdingTax();

  @JsonProperty("BackupWithholdingTax")
  @ApiModelProperty(required = true)
  void setBackupWithholdingTax(Boolean backupWithholdingTax);

  @JsonProperty("TaxExempt")
  @ApiModelProperty(required = false)
  Boolean isTaxExempt();

  @JsonProperty("TaxExempt")
  @ApiModelProperty(required = false)
  void setTaxExempt(Boolean taxExempt);

  @JsonProperty("DelegatedCreditAgreement")
  @ApiModelProperty(required = false)
  Boolean isDelegatedCreditAgreement();

  @JsonProperty("DelegatedCreditAgreement")
  @ApiModelProperty(required = false)
  void setDelegatedCreditAgreement(Boolean delegatedCreditAgreement);

}