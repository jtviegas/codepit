package com.anthem.specialty.provider.datamodel.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = CollectionRelatedCarrierImpl.class)
public interface CollectionRelatedCarrier extends RelatedCarrier {
  @JsonProperty("Networks")
  @ApiModelProperty(required = false)
  List<RelatedNetwork> getNetworks();

  @JsonProperty("Networks")
  @ApiModelProperty(required = false)
  void setNetworks(List<RelatedNetwork> o);
}
