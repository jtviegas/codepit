package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = HttpStatusResponseImpl.class)
public interface HttpStatusResponse extends Serializable {

  @JsonProperty("code")
  public void setCode(Integer code);

  @JsonProperty("code")
  @NotNull
  @Valid
  @ApiModelProperty(required = true)
  public Integer getCode();

  @JsonProperty("info")
  public void setInfo(String info);

  @JsonProperty("info")
  @NotNull
  @Valid
  @ApiModelProperty(required = true)
  public String getInfo();

}
