package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedCarrierItemImpl.class)
public interface RelatedCarrierItem extends RelatedItem {

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  String getName();

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  void setName(String name);

}
