package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedItemImpl.class)
public interface RelatedItem extends SingleLinkable {

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  @NotNull
  Long getId();

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  @NotNull
  void setId(Long id);

  @JsonProperty("Link")
  @ApiModelProperty(required = true)
  @NotNull
  void setLink(Link o);

}
