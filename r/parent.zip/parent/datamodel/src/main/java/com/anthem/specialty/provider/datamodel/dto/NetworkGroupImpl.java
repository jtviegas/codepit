package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NetworkGroupImpl implements NetworkGroup {
  private static final long serialVersionUID = 1L;

  private String description;

  private Long id;

  private DataOwner dataOwner;

  private List<Link> links;

  @JsonCreator
  public static NetworkGroup create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NetworkGroupImpl impl = null;
    impl = mapper.readValue(json, NetworkGroupImpl.class);
    return impl;
  }

  @Override
  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public @NotNull String getDescription() {
    return description;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

}
