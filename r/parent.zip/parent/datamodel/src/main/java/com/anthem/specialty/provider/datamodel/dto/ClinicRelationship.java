package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ClinicRelationshipImpl.class)
public interface ClinicRelationship extends Serializable {
  @JsonProperty("Clinic")
  @ApiModelProperty(required = false)
  @Valid
  CoreDataEntity getClinic();

  @JsonProperty("Clinic")
  @ApiModelProperty(required = false)
  void setClinic(CoreDataEntity clinic);
}
