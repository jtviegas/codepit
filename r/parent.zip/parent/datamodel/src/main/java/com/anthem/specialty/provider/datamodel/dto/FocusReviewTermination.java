package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = FocusReviewTerminationImpl.class)
public interface FocusReviewTermination extends Serializable {

  @JsonProperty("From")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  LocalDate getFrom();

  @JsonProperty("From")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  void setFrom(LocalDate from);

  @JsonProperty("Reason")
  @ApiModelProperty(required = true)
  String getReason();

  @JsonProperty("Reason")
  @ApiModelProperty(required = true)
  void setReason(String reason);

}