package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = NewNetworkProviderRelationshipImpl.class)
public interface NewNetworkProviderRelationship extends NewProviderEffectiveRelationship, UpdatableNetworkProviderRelationship {

}
