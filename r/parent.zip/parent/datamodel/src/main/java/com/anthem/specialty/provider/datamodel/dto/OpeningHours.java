package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = OpeningHoursImpl.class)
public interface OpeningHours extends Serializable {

  @JsonProperty("DayOfWeek")
  @ApiModelProperty(required = true)
  @NotNull
  String getDayOfWeek();

  @JsonProperty("DayOfWeek")
  @ApiModelProperty(required = true)
  void setDayOfWeek(String dayOfWeek);

  @JsonProperty("OpeningTime")
  @ApiModelProperty(required = true)
  @NotNull
  String getFrom();

  @JsonProperty("OpeningTime")
  @ApiModelProperty(required = true)
  void setFrom(String from);

  @JsonProperty("ClosingTime")
  @ApiModelProperty(required = true)
  @NotNull
  String getTo();

  @JsonProperty("ClosingTime")
  @ApiModelProperty(required = true)
  void setTo(String to);

}