package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewProviderEffectiveRelationshipImpl.class)
public interface NewProviderEffectiveRelationship extends NewEffectiveRelationship {
  @JsonProperty("Provider")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  CoreDataEntity getProvider();

  @JsonProperty("Provider")
  @ApiModelProperty(required = true)
  void setProvider(CoreDataEntity provider);

}