package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = SpecialtyTypeImpl.class)
public interface SpecialtyType extends Specialty {

  @JsonProperty("Type")
  @ApiModelProperty(required = false)
  SpecialtyClassification getType();

  @JsonProperty("Type")
  @ApiModelProperty(required = false)
  void setType(SpecialtyClassification type);

}