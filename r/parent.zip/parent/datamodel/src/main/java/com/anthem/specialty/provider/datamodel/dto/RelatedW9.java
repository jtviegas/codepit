package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedW9Impl.class)
public interface RelatedW9 extends Relationship {

  @JsonProperty("W9")
  @ApiModelProperty(required = true)
  @NotNull
  W9RelatedItem getW9();

  @JsonProperty("W9")
  @ApiModelProperty(required = true)
  void setW9(W9RelatedItem w9);

}