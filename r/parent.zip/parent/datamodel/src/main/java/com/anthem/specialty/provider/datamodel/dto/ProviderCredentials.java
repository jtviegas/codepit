package com.anthem.specialty.provider.datamodel.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ProviderCredentialsImpl.class)
public interface ProviderCredentials extends DataEntity {

  @JsonProperty("Credentialed")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getCredentialed();

  @JsonProperty("Credentialed")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setCredentialed(LocalDate credentialed);

  @JsonProperty("LicenseSuspended")
  @ApiModelProperty(required = false)
  Boolean getLicenseSuspended();

  @JsonProperty("LicenseSuspended")
  @ApiModelProperty(required = false)
  void setLicenseSuspended(Boolean licenseSuspended);

  void setLicenseSuspended(Character licenseSuspended);

  @JsonProperty("LicenseSuspendedComments")
  @ApiModelProperty(required = false)
  String getLicenseSuspendedComments();

  @JsonProperty("LicenseSuspendedComments")
  @ApiModelProperty(required = false)
  void setLicenseSuspendedComments(String licenseSuspendedComments);

  @JsonProperty("DisciplinaryAction")
  @ApiModelProperty(required = false)
  Boolean getDisciplinaryAction();

  @JsonProperty("DisciplinaryAction")
  @ApiModelProperty(required = false)
  void setDisciplinaryAction(Boolean disciplinaryAction);

  @JsonProperty("DisciplinaryActionComments")
  @ApiModelProperty(required = false)
  String getDisciplinaryActionComments();

  @JsonProperty("DisciplinaryActionComments")
  @ApiModelProperty(required = false)
  void setDisciplinaryActionComments(String disciplinaryActionComments);

  @JsonProperty("HealthProblem")
  @ApiModelProperty(required = false)
  Boolean getHealthProblem();

  @JsonProperty("HealthProblem")
  @ApiModelProperty(required = false)
  void setHealthProblem(Boolean healthProblem);

  @JsonProperty("HealthProblemComments")
  @ApiModelProperty(required = false)
  String getHealthProblemComments();

  @JsonProperty("HealthProblemComments")
  @ApiModelProperty(required = false)
  void setHealthProblemComments(String healthProblemComments);

  @JsonProperty("FelonyMisdemeanor")
  @ApiModelProperty(required = false)
  Boolean getFelonyMisdemeanor();

  @JsonProperty("FelonyMisdemeanor")
  @ApiModelProperty(required = false)
  void setFelonyMisdemeanor(Boolean felonyMisdemeanor);

  @JsonProperty("FelonyMisdemeanorComments")
  @ApiModelProperty(required = false)
  String getFelonyMisdemeanorComments();

  @JsonProperty("FelonyMisdemeanorComments")
  @ApiModelProperty(required = false)
  void setFelonyMisdemeanorComments(String felonyMisdemeanorComments);

  @JsonProperty("MalpracticeExper")
  @ApiModelProperty(required = false)
  Boolean getMalpracticeExper();

  @JsonProperty("MalpracticeExper")
  @ApiModelProperty(required = false)
  void setMalpracticeExper(Boolean malpracticeExper);

  @JsonProperty("MalpracticeExperComments")
  @ApiModelProperty(required = false)
  String getMalpracticeExperComments();

  @JsonProperty("MalpracticeExperComments")
  @ApiModelProperty(required = false)
  void setMalpracticeExperComments(String malpracticeExperComments);

  @JsonProperty("DEARestricted")
  @ApiModelProperty(required = false)
  Boolean getDeaRestricted();

  @JsonProperty("DEARestricted")
  @ApiModelProperty(required = false)
  void setDeaRestricted(Boolean deaRestricted);

  @JsonProperty("DEARestrictedComments")
  @ApiModelProperty(required = false)
  String getDeaRestrictedComments();

  @JsonProperty("DEARestrictedComments")
  @ApiModelProperty(required = false)
  void setDeaRestrictedComments(String deaRestrictedComments);

  @JsonProperty("CredentialingLevel")
  @ApiModelProperty(required = false)
  String getCredentialingLevel();

  @JsonProperty("CredentialingLevel")
  @ApiModelProperty(required = false)
  void setCredentialingLevel(String credentialingLevel);

}