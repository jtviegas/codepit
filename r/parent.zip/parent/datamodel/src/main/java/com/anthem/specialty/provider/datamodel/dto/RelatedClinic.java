package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedClinicImpl.class)
public interface RelatedClinic extends Relationship {

  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  @NotNull
  RelatedClinicItem getClinic();

  @JsonProperty("Clinic")
  @ApiModelProperty(required = true)
  void setClinic(RelatedClinicItem o);

}
