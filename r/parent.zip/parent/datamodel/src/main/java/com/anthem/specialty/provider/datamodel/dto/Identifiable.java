package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public interface Identifiable extends Serializable {

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  @NotNull
  Long getId();

  @JsonProperty("Id")
  @ApiModelProperty(required = true)
  void setId(Long id);

}