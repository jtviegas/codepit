package com.anthem.specialty.provider.datamodel.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = MultiLinkableImpl.class)
public interface MultiLinkable extends Linkable {
  @JsonProperty("Links")
  @ApiModelProperty(required = false)
  List<Link> getLinks();

  @JsonProperty("Links")
  @ApiModelProperty(required = false)
  void setLinks(List<Link> o);
}
