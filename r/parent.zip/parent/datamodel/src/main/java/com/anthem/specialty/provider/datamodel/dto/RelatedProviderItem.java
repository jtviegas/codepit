package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = RelatedProviderItemImpl.class)
public interface RelatedProviderItem extends RelatedItem {

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  String getName();

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  void setName(String name);

}
