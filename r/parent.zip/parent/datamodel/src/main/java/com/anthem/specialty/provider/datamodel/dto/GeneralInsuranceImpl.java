package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GeneralInsuranceImpl implements GeneralInsurance {

  @JsonCreator
  public static GeneralInsurance create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    GeneralInsurance module = null;
    module = mapper.readValue(json, GeneralInsuranceImpl.class);
    return module;
  }

  private static final long serialVersionUID = 1L;

  private String insurer;

  private Character limit;

  private LocalDate renewal;

  private String policy;

  public GeneralInsuranceImpl() {
  }

  @Override
  public String getInsurer() {
    return insurer;
  }

  @Override
  public void setInsurer(String insurer) {
    this.insurer = insurer;
  }

  @Override
  public Character getLimit() {
    return limit;
  }

  @Override
  public void setLimit(Character limit) {
    this.limit = limit;
  }

  @Override
  public LocalDate getRenewal() {
    return renewal;
  }

  @Override
  public void setRenewal(LocalDate renewal) {
    this.renewal = renewal;
  }

  @Override
  public String getPolicy() {
    return policy;
  }

  @Override
  public void setPolicy(String policy) {
    this.policy = policy;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((insurer == null) ? 0 : insurer.hashCode());
    result = prime * result + ((limit == null) ? 0 : limit.hashCode());
    result = prime * result + ((policy == null) ? 0 : policy.hashCode());
    result = prime * result + ((renewal == null) ? 0 : renewal.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    GeneralInsuranceImpl other = (GeneralInsuranceImpl) obj;
    if (insurer == null) {
      if (other.insurer != null)
        return false;
    } else if (!insurer.equals(other.insurer))
      return false;
    if (limit == null) {
      if (other.limit != null)
        return false;
    } else if (!limit.equals(other.limit))
      return false;
    if (policy == null) {
      if (other.policy != null)
        return false;
    } else if (!policy.equals(other.policy))
      return false;
    if (renewal == null) {
      if (other.renewal != null)
        return false;
    } else if (!renewal.equals(other.renewal))
      return false;
    return true;
  }

}
