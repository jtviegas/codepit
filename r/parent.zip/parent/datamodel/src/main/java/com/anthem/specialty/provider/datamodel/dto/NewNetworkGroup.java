package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewNetworkGroupImpl.class)
public interface NewNetworkGroup extends NewDataEntity {
  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  String getDescription();

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  void setDescription(String description);
}
