package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EffectivePeriodImpl implements EffectivePeriod {

  @JsonCreator
  public static EffectivePeriod create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    EffectivePeriod impl = null;
    impl = mapper.readValue(json, EffectivePeriodImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate from;

  private LocalDate to;

  public EffectivePeriodImpl() {
  }

  public EffectivePeriodImpl(LocalDate from, LocalDate to) {
    if (null == from)
      throw new IllegalArgumentException("!!! must provide 'from' parameter !!!");
    this.from = from;
    this.to = to;
  }

  @Override
  public LocalDate getTo() {
    return to;
  }

  @Override
  public LocalDate getFrom() {
    return from;
  }

  @Override
  public void setFrom(LocalDate from) {
    this.from = from;
  }

  @Override
  public void setTo(LocalDate to) {
    this.to = to;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((from == null) ? 0 : from.hashCode());
    result = prime * result + ((to == null) ? 0 : to.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    EffectivePeriodImpl other = (EffectivePeriodImpl) obj;
    if (from == null) {
      if (other.from != null)
        return false;
    } else if (!from.equals(other.from))
      return false;
    if (to == null) {
      if (other.to != null)
        return false;
    } else if (!to.equals(other.to))
      return false;
    return true;
  }

}
