package com.anthem.specialty.provider.datamodel.dto;

public class NewNetworkBuilder {

  private final NewNetwork o;

  public NewNetworkBuilder(Long dataOwnerId, String description, String shortDescription) {
    o = new NewNetworkImpl(dataOwnerId, description, shortDescription);
  }

  public NewNetwork build() {
    return o;
  }

  public NewNetworkBuilder withManager(String manager) {
    o.setManager(manager);
    return this;
  }

  public NewNetworkBuilder withComments(String comments) {
    o.setComments(comments);
    return this;
  }

  public NewNetworkBuilder withCapitationPayment(Boolean capitationPayment) {
    o.setCapitationPayment(capitationPayment);
    return this;
  }

  public NewNetworkBuilder withCustomerServiceDisplayed(Boolean customerServiceDisplayed) {
    o.setCustomerServiceDisplayed(customerServiceDisplayed);
    return this;
  }

  public NewNetworkBuilder withEffective(EffectivePeriod effective) {
    o.setEffective(effective);
    return this;
  }

}
