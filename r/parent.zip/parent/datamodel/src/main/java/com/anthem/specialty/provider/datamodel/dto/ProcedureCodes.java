package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ProcedureCodesImpl.class)
public interface ProcedureCodes extends Serializable {
  @JsonProperty("RangeStart")
  @ApiModelProperty(required = true)
  @NotNull
  String getRangeStart();

  @JsonProperty("RangeStart")
  @ApiModelProperty(required = true)
  void setRangeStart(String rangeStart);

  @JsonProperty("RangeEnd")
  @ApiModelProperty(required = true)
  @NotNull
  String getRangeEnd();

  @JsonProperty("RangeEnd")
  @ApiModelProperty(required = true)
  void setRangeEnd(String rangeEnd);

}