package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = EffectivePeriodImpl.class)
public interface EffectivePeriod extends Serializable {

  @JsonProperty("To")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getTo();

  @JsonProperty("From")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  @NotNull
  LocalDate getFrom();

  @JsonProperty("From")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  void setFrom(LocalDate from);

  @JsonProperty("To")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setTo(LocalDate to);

}