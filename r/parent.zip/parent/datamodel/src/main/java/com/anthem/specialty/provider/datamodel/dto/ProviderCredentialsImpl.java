package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProviderCredentialsImpl implements ProviderCredentials {

  @JsonCreator
  public static ProviderCredentials create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ProviderCredentialsImpl impl = null;
    impl = mapper.readValue(json, ProviderCredentialsImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate credentialed;

  private Boolean licenseSuspended;

  private String licenseSuspendedComments;

  private Boolean disciplinaryAction;

  private String disciplinaryActionComments;

  private Boolean healthProblem;

  private String healthProblemComments;

  private Boolean felonyMisdemeanor;

  private String felonyMisdemeanorComments;

  private Boolean malpracticeExper;

  private String malpracticeExperComments;

  private Boolean deaRestricted;

  private String deaRestrictedComments;

  private String credentialingLevel;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public ProviderCredentialsImpl() {
    links = new ArrayList<Link>();
  }

  @Override
  public LocalDate getCredentialed() {
    return credentialed;

  }

  @Override
  public void setCredentialed(LocalDate credentialed) {
    this.credentialed = credentialed;
  }

  @Override
  public Boolean getLicenseSuspended() {
    return licenseSuspended;

  }

  @Override
  public void setLicenseSuspended(Boolean licenseSuspended) {
    this.licenseSuspended = licenseSuspended;
  }

  @Override
  public String getLicenseSuspendedComments() {
    return licenseSuspendedComments;

  }

  @Override
  public void setLicenseSuspendedComments(String licenseSuspendedComments) {
    this.licenseSuspendedComments = licenseSuspendedComments;
  }

  @Override
  public Boolean getDisciplinaryAction() {
    return disciplinaryAction;
  }

  @Override
  public void setDisciplinaryAction(Boolean disciplinaryAction) {
    this.disciplinaryAction = disciplinaryAction;
  }

  @Override
  public String getDisciplinaryActionComments() {
    return disciplinaryActionComments;
  }

  @Override
  public void setDisciplinaryActionComments(String disciplinaryActionComments) {
    this.disciplinaryActionComments = disciplinaryActionComments;
  }

  @Override
  public Boolean getHealthProblem() {
    return healthProblem;

  }

  @Override
  public void setHealthProblem(Boolean healthProblem) {
    this.healthProblem = healthProblem;
  }

  @Override
  public String getHealthProblemComments() {
    return healthProblemComments;

  }

  @Override
  public void setHealthProblemComments(String healthProblemComments) {
    this.healthProblemComments = healthProblemComments;
  }

  @Override
  public Boolean getFelonyMisdemeanor() {
    return felonyMisdemeanor;

  }

  @Override
  public void setFelonyMisdemeanor(Boolean felonyMisdemeanor) {
    this.felonyMisdemeanor = felonyMisdemeanor;
  }

  @Override
  public String getFelonyMisdemeanorComments() {
    return felonyMisdemeanorComments;

  }

  @Override
  public void setFelonyMisdemeanorComments(String felonyMisdemeanorComments) {
    this.felonyMisdemeanorComments = felonyMisdemeanorComments;
  }

  @Override
  public Boolean getMalpracticeExper() {
    return malpracticeExper;

  }

  @Override
  public void setMalpracticeExper(Boolean malpracticeExper) {
    this.malpracticeExper = malpracticeExper;
  }

  @Override
  public String getMalpracticeExperComments() {
    return malpracticeExperComments;

  }

  @Override
  public void setMalpracticeExperComments(String malpracticeExperComments) {
    this.malpracticeExperComments = malpracticeExperComments;
  }

  @Override
  public Boolean getDeaRestricted() {
    return deaRestricted;

  }

  @Override
  public void setDeaRestricted(Boolean deaRestricted) {
    this.deaRestricted = deaRestricted;
  }

  @Override
  public String getDeaRestrictedComments() {
    return deaRestrictedComments;

  }

  @Override
  public void setDeaRestrictedComments(String deaRestrictedComments) {
    this.deaRestrictedComments = deaRestrictedComments;
  }

  @Override
  public String getCredentialingLevel() {
    return credentialingLevel;

  }

  @Override
  public void setCredentialingLevel(String credentialingLevel) {
    this.credentialingLevel = credentialingLevel;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public void setLicenseSuspended(Character licenseSuspended) {
    // TODO Auto-generated method stub

  }

}
