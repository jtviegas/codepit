package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = NetworkClinicProviderRelationshipImpl.class)
public interface NetworkClinicProviderRelationship extends DataEntity, NewNetworkClinicProviderRelationship {

}
