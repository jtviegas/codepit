package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewDisciplinaryActionImpl.class)
public interface NewDisciplinaryAction extends Serializable {

  @JsonProperty("OriginatorCode")
  @ApiModelProperty(required = true)
  @NotNull
  String getOriginatorCode();

  @JsonProperty("OriginatorCode")
  @ApiModelProperty(required = true)
  void setOriginatorCode(String originatorCode);

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  String getDescription();

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  void setDescription(String description);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = true)
  void setEffective(EffectivePeriod effective);

}