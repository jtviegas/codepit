package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewDocumentImpl implements NewDocument {

  @JsonCreator
  public static NewDocument create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    NewDocument impl = null;
    impl = mapper.readValue(json, NewDocumentImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private Long controlNumber;

  private DocumentType type;

  private Character source;

  public NewDocumentImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDocument#getControlNumber()
   */
  @Override
  public @NotNull Long getControlNumber() {
    return controlNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDocument#setControlNumber(java.lang.Long)
   */
  @Override
  public void setControlNumber(Long controlNumber) {
    this.controlNumber = controlNumber;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDocument#getType()
   */
  @Override
  public @NotNull DocumentType getType() {
    return type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.anthem.specialty.provider.datamodel.dto.NewDocument#setType(com.anthem.specialty.provider.datamodel.dto.newdtos
   * .DocumentType)
   */
  @Override
  public void setType(DocumentType type) {
    this.type = type;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDocument#getSource()
   */
  @Override
  public Character getSource() {
    return source;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.NewDocument#setSource(java.lang.Character)
   */
  @Override
  public void setSource(Character source) {
    this.source = source;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((controlNumber == null) ? 0 : controlNumber.hashCode());
    result = prime * result + ((source == null) ? 0 : source.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    NewDocumentImpl other = (NewDocumentImpl) obj;
    if (controlNumber == null) {
      if (other.controlNumber != null)
        return false;
    } else if (!controlNumber.equals(other.controlNumber))
      return false;
    if (source == null) {
      if (other.source != null)
        return false;
    } else if (!source.equals(other.source))
      return false;
    if (type == null) {
      if (other.type != null)
        return false;
    } else if (!type.equals(other.type))
      return false;
    return true;
  }

}
