package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewW9EffectiveRelationshipImpl.class)
public interface NewW9EffectiveRelationship extends NewEffectiveRelationship {

  @JsonProperty("W9")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  CoreDataEntity getW9();

  @JsonProperty("W9")
  @ApiModelProperty(required = true)
  void setW9(CoreDataEntity w9);

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  Integer getOfficeNumber();

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  void setOfficeNumber(Integer officeNumber);

}