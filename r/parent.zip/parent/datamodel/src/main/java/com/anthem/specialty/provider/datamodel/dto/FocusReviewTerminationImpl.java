package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FocusReviewTerminationImpl implements FocusReviewTermination {

  @JsonCreator
  public static FocusReviewTermination create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    FocusReviewTermination impl = null;
    impl = mapper.readValue(json, FocusReviewTerminationImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  @NotNull
  private LocalDate from;

  @NotNull
  private String reason;

  public FocusReviewTerminationImpl() {
  }

  public FocusReviewTerminationImpl(LocalDate from, String reason) {
    this.from = from;
    this.reason = reason;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.FocusReviewTermination#getFrom()
   */
  @Override
  public LocalDate getFrom() {
    return from;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.FocusReviewTermination#setFrom(java.util.Date)
   */
  @Override
  public void setFrom(LocalDate from) {
    this.from = from;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.FocusReviewTermination#getReason()
   */
  @Override
  public String getReason() {
    return reason;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.FocusReviewTermination#setReason(java.lang.String)
   */
  @Override
  public void setReason(String reason) {
    this.reason = reason;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((from == null) ? 0 : from.hashCode());
    result = prime * result + ((reason == null) ? 0 : reason.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    FocusReviewTerminationImpl other = (FocusReviewTerminationImpl) obj;
    if (from == null) {
      if (other.from != null)
        return false;
    } else if (!from.equals(other.from))
      return false;
    if (reason == null) {
      if (other.reason != null)
        return false;
    } else if (!reason.equals(other.reason))
      return false;
    return true;
  }

}
