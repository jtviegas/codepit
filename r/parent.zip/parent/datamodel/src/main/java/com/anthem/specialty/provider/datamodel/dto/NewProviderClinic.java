package com.anthem.specialty.provider.datamodel.dto;

import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewProviderClinicImpl.class)
public interface NewProviderClinic extends NewClinicEffectiveRelationship {
  @JsonProperty("Hours")
  @ApiModelProperty(required = false)
  @Valid
  List<OpeningHours> getHours();

  @JsonProperty("Hours")
  @ApiModelProperty(required = false)
  void setHours(List<OpeningHours> hours);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

  @JsonProperty("ProviderRelationship")
  @ApiModelProperty(required = false, allowableValues = "A,O,P", value = "A means Associate, O means Owner and P means Partner")
  Character getProviderRelationship();

  @JsonProperty("ProviderRelationship")
  @ApiModelProperty(required = false, allowableValues = "A,O,P", value = "A means Associate, O means Owner and P means Partner")
  void setProviderRelationship(Character providerRelationship);

  @JsonProperty("PayClinicOrProvider")
  @ApiModelProperty(required = false, allowableValues = "P,C", value = "P means make the payment to the provider directly, C the default, means to pay the clinic instead")
  Character getPayClinicProvider();

  @JsonProperty("PayClinicOrProvider")
  @ApiModelProperty(required = false, allowableValues = "P,C", value = "P means make the payment to the provider directly, C the default, means to pay the clinic instead")
  void setPayClinicProvider(Character payClinicProvider);

  @JsonProperty("ClearLicenseNumber")
  @ApiModelProperty(required = false)
  Boolean getClearLicenseNumber();

  @JsonProperty("ClearLicenseNumber")
  @ApiModelProperty(required = false)
  void setClearLicenseNumber(Boolean clearLicenseNumber);

  @JsonProperty("ProviderSpecialistClinic")
  @ApiModelProperty(required = false)
  Boolean getProviderSpecialistClinic();

  @JsonProperty("ProviderSpecialistClinic")
  @ApiModelProperty(required = false)
  void setProviderSpecialistClinic(Boolean providerSpecialistClinic);

  @JsonProperty("DeltaPrecertified")
  @ApiModelProperty(required = false)
  Boolean getDeltaPrecertified();

  @JsonProperty("DeltaPrecertified")
  @ApiModelProperty(required = false)
  void setDeltaPrecertified(Boolean deltaPrecertified);

  @JsonProperty("CorporatePayment")
  @ApiModelProperty(required = false)
  Boolean getCorporatePayment();

  @JsonProperty("CorporatePayment")
  @ApiModelProperty(required = false)
  void setCorporatePayment(Boolean corporatePayment);

  @JsonProperty("WitholdPayments")
  @ApiModelProperty(required = false)
  Boolean getWitholdPayments();

  @JsonProperty("WitholdPayments")
  @ApiModelProperty(required = false)
  void setWitholdPayments(Boolean witholdPayments);

  @JsonProperty("ProviderCOB")
  @ApiModelProperty(required = false)
  Boolean getProviderCob();

  @JsonProperty("ProviderCOB")
  @ApiModelProperty(required = false)
  void setProviderCob(Boolean providerCob);

  @JsonProperty("BCI")
  @ApiModelProperty(required = false)
  @Valid
  Bci getBci();

  @JsonProperty("BCI")
  @ApiModelProperty(required = false)
  void setBci(Bci bci);

  @JsonProperty("ProviderClaimInReview")
  @ApiModelProperty(required = false)
  Boolean getProviderClaimInReview();

  @JsonProperty("ProviderClaimInReview")
  @ApiModelProperty(required = false)
  void setProviderClaimInReview(Boolean providerClaimInReview);

  @JsonProperty("ProfessionalReviewUnderway")
  @ApiModelProperty(required = false)
  Boolean getProfessionalReviewUnderway();

  @JsonProperty("ProfessionalReviewUnderway")
  @ApiModelProperty(required = false)
  void setProfessionalReviewUnderway(Boolean professionalReviewUnderway);

}