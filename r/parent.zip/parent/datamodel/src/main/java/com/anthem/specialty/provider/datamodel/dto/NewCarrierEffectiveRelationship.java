package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewCarrierEffectiveRelationshipImpl.class)
public interface NewCarrierEffectiveRelationship extends NewEffectiveRelationship {
  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  String getOfficeNumber();

  @JsonProperty("OfficeNumber")
  @ApiModelProperty(required = false)
  void setOfficeNumber(String officeNumber);

  @JsonProperty("Carrier")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  CoreDataEntity getCarrier();

  @JsonProperty("Carrier")
  @ApiModelProperty(required = true)
  void setCarrier(CoreDataEntity carrier);

}