package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = PatientsImpl.class)
public interface Patients extends Serializable {

  @JsonProperty("AcceptsNewPatients")
  @ApiModelProperty(required = false)
  Boolean getAcceptsNewPatients();

  @JsonProperty("AcceptsNewPatients")
  @ApiModelProperty(required = false)
  void setAcceptsNewPatients(Boolean acceptsNewPatients);

  @JsonProperty("AcceptsNewMedicaidPatients")
  @ApiModelProperty(required = false)
  Boolean getAcceptsNewMedicaidPatients();

  @JsonProperty("AcceptsNewMedicaidPatients")
  @ApiModelProperty(required = false)
  void setAcceptsNewMedicaidPatients(Boolean acceptsNewMedicaidPatients);

  @JsonProperty("MedicaidPatientsConverted")
  @ApiModelProperty(required = false)
  Boolean getMedicaidPatientsConverted();

  @JsonProperty("MedicaidPatientsConverted")
  @ApiModelProperty(required = false)
  void setMedicaidPatientsConverted(Boolean medicaidPatientsConverted);

  @JsonProperty("MedicaidMonthlyPatients")
  @ApiModelProperty(required = false)
  Integer getMedicaidMonthlyPatients();

  @JsonProperty("MedicaidMonthlyPatients")
  @ApiModelProperty(required = false)
  void setMedicaidMonthlyPatients(Integer medicaidMonthlyPatients);

  @JsonProperty("UnderThrees")
  @ApiModelProperty(required = false)
  Boolean getUnderThrees();

  @JsonProperty("UnderThrees")
  @ApiModelProperty(required = false)
  void setUnderThrees(Boolean underThrees);

  @JsonProperty("UnderEighteens")
  @ApiModelProperty(required = false)
  Boolean getUnderEighteens();

  @JsonProperty("UnderEighteens")
  @ApiModelProperty(required = false)
  void setUnderEighteens(Boolean underEighteens);

  @JsonProperty("ProviderMonthlyPatients")
  @ApiModelProperty(required = false)
  Integer getProviderMonthlyPatients();

  @JsonProperty("ProviderMonthlyPatients")
  @ApiModelProperty(required = false)
  void setProviderMonthlyPatients(Integer providerMonthlyPatients);

  @JsonProperty("HygienistMonthlyPatients")
  @ApiModelProperty(required = false)
  Integer getHygienistMonthlyPatients();

  @JsonProperty("HygienistMonthlyPatients")
  @ApiModelProperty(required = false)
  void setHygienistMonthlyPatients(Integer hygienistMonthlyPatients);

  @JsonProperty("NewMedicaidPatientPolicy")
  @ApiModelProperty(required = false)
  String getNewMedicaidPatientPolicy();

  @JsonProperty("NewMedicaidPatientPolicy")
  @ApiModelProperty(required = false)
  void setNewMedicaidPatientPolicy(String newMedicaidPatientPolicy);

}