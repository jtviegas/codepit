package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

@JsonDeserialize(as = LargeGroupImpl.class)
public interface LargeGroup extends Identifiable {

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  @NotNull
  String getName();

  @JsonProperty("Name")
  @ApiModelProperty(required = true)
  void setName(String name);
}
