package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = DataEntityImpl.class)
public interface DataEntity extends CoreDataEntity, MultiLinkable {
  @JsonProperty("DataOwner")
  @ApiModelProperty(required = true)
  @NotNull
  DataOwner getDataOwner();

  @JsonProperty("DataOwner")
  @ApiModelProperty(required = true)
  void setDataOwner(DataOwner dataOwner);

}
