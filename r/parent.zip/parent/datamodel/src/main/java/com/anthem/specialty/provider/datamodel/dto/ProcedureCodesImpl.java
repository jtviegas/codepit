package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProcedureCodesImpl implements ProcedureCodes {

  @JsonCreator
  public static ProcedureCodes create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ProcedureCodes impl = null;
    impl = mapper.readValue(json, ProcedureCodesImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String rangeStart;

  private String rangeEnd;

  public ProcedureCodesImpl() {
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProcedureCodes#getRangeStart()
   */
  @Override
  public String getRangeStart() {
    return rangeStart;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProcedureCodes#setRangeStart(java.lang.String)
   */
  @Override
  public void setRangeStart(String rangeStart) {
    this.rangeStart = rangeStart;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProcedureCodes#getRangeEnd()
   */
  @Override
  public String getRangeEnd() {
    return rangeEnd;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.anthem.specialty.provider.datamodel.dto.ProcedureCodes#setRangeEnd(java.lang.String)
   */
  @Override
  public void setRangeEnd(String rangeEnd) {
    this.rangeEnd = rangeEnd;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((rangeEnd == null) ? 0 : rangeEnd.hashCode());
    result = prime * result + ((rangeStart == null) ? 0 : rangeStart.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ProcedureCodesImpl other = (ProcedureCodesImpl) obj;
    if (rangeEnd == null) {
      if (other.rangeEnd != null)
        return false;
    } else if (!rangeEnd.equals(other.rangeEnd))
      return false;
    if (rangeStart == null) {
      if (other.rangeStart != null)
        return false;
    } else if (!rangeStart.equals(other.rangeStart))
      return false;
    return true;
  }

}
