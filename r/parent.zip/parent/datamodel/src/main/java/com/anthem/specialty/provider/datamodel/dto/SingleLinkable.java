package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public interface SingleLinkable extends Linkable {
  @JsonProperty("Link")
  @ApiModelProperty(required = true)
  @NotNull
  Link getLink();
}
