package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = ProviderTerminationImpl.class)
public interface ProviderTermination extends Serializable {
  @JsonProperty("From")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  @NotNull
  LocalDate getFrom();

  @JsonProperty("From")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = true)
  void setFrom(LocalDate from);

  @JsonProperty("TerminationLevelCode")
  @ApiModelProperty(required = true)
  @NotNull
  Long getTerminationLevelCode();

  @JsonProperty("TerminationLevelCode")
  @ApiModelProperty(required = true)
  void setTerminationLevelCode(Long terminationLevelCode);

}