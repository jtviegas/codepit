package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public enum CarrierPhoneContactType {
  P('P'),
  S('S'),
  M('M'),
  One('1'),
  Two('2'),;

  private Character character;

  private CarrierPhoneContactType(Character character) {
    this.character = character;
  }

  @JsonIgnore
  public Character asChar() {
    return character;
  }

  @JsonIgnore
  public static CarrierPhoneContactType fromChar(Character c) {
    CarrierPhoneContactType r = null;
    for (CarrierPhoneContactType p : CarrierPhoneContactType.values()) {
      if (p.asChar().equals(c)) {
        r = p;
        break;
      }
    }
    return r;
  }

}
