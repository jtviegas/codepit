package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewLicenseImpl.class)
public interface NewLicense extends Serializable {

  @JsonProperty("LicenseNumber")
  @ApiModelProperty(required = false)
  String getLicenseNumber();

  @JsonProperty("LicenseNumber")
  @ApiModelProperty(required = false)
  void setLicenseNumber(String licenseNumber);

  @JsonProperty("IssuingState")
  @ApiModelProperty(required = false)
  String getIssuingState();

  @JsonProperty("IssuingState")
  @ApiModelProperty(required = false)
  void setIssuingState(String issuingState);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

  @JsonProperty("Terminated")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getTerminated();

  @JsonProperty("Terminated")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setTerminated(LocalDate terminated);

  @JsonProperty("OnHold")
  @ApiModelProperty(required = false)
  Boolean getOnHold();

  @JsonProperty("OnHold")
  @ApiModelProperty(required = false)
  void setOnHold(Boolean onHold);

  @JsonProperty("DEA")
  @ApiModelProperty(required = false)
  @Valid
  Dea getDea();

  @JsonProperty("DEA")
  @ApiModelProperty(required = false)
  void setDea(Dea dea);

}