package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = NewClinicFocusReviewImpl.class)
public interface NewClinicFocusReview extends NewProviderRelationship, NewFocusReview {

}