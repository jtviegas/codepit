package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ClinicCredentialsImpl implements ClinicCredentials {

  @JsonCreator
  public static ClinicCredentials create(String json) throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    ClinicCredentials impl = null;
    impl = mapper.readValue(json, ClinicCredentialsImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private LocalDate credentialed;

  private Boolean handicapAccess = Boolean.FALSE;

  private Boolean cprTrained = Boolean.FALSE;

  private Boolean emergencyTrained = Boolean.FALSE;

  private Boolean emergencyKit = Boolean.FALSE;

  private Boolean publicTransport = Boolean.FALSE;

  private Boolean hadicappedParking = Boolean.FALSE;

  private Boolean cDCAndOSHARulesCompliance = Boolean.FALSE;

  private Boolean deptHealthRulesCompliance = Boolean.FALSE;

  private DataOwner dataOwner;

  private List<Link> links;

  private Long id;

  public ClinicCredentialsImpl() {
    links = new ArrayList<Link>();
  }

  @Override
  public LocalDate getCredentialed() {
    return credentialed;
  }

  @Override
  public void setCredentialed(LocalDate credentialed) {
    this.credentialed = credentialed;
  }

  @Override
  public Boolean isHandicapAccess() {
    return handicapAccess;
  }

  @Override
  public void setHandicapAccess(Boolean handicapAccess) {
    this.handicapAccess = handicapAccess;
  }

  @Override
  public Boolean isCprTrained() {
    return cprTrained;
  }

  @Override
  public void setCprTrained(Boolean cprTrained) {
    this.cprTrained = cprTrained;
  }

  @Override
  public Boolean isEmergencyTrained() {
    return emergencyTrained;
  }

  @Override
  public void setEmergencyTrained(Boolean emergencyTrained) {
    this.emergencyTrained = emergencyTrained;
  }

  @Override
  public Boolean isEmergencyKit() {
    return emergencyKit;
  }

  @Override
  public void setEmergencyKit(Boolean emergencyKit) {
    this.emergencyKit = emergencyKit;
  }

  @Override
  public Boolean isPublicTransport() {
    return publicTransport;
  }

  @Override
  public void setPublicTransport(Boolean publicTransport) {
    this.publicTransport = publicTransport;
  }

  @Override
  public Boolean isHadicappedParking() {
    return hadicappedParking;
  }

  @Override
  public void setHadicappedParking(Boolean hadicappedParking) {
    this.hadicappedParking = hadicappedParking;
  }

  @Override
  public Boolean iscDCAndOSHARulesCompliance() {
    return cDCAndOSHARulesCompliance;
  }

  @Override
  public void setcDCAndOSHARulesCompliance(Boolean cDCAndOSHARulesCompliance) {
    this.cDCAndOSHARulesCompliance = cDCAndOSHARulesCompliance;
  }

  @Override
  public Boolean isDeptHealthRulesCompliance() {
    return deptHealthRulesCompliance;
  }

  @Override
  public void setDeptHealthRulesCompliance(Boolean deptHealthRulesCompliance) {
    this.deptHealthRulesCompliance = deptHealthRulesCompliance;
  }

  @Override
  public @NotNull DataOwner getDataOwner() {
    return dataOwner;
  }

  @Override
  public void setDataOwner(DataOwner dataOwner) {
    this.dataOwner = dataOwner;
  }

  @Override
  public void setLinks(List<Link> links) {
    this.links = links;
  }

  @Override
  public @NotNull Long getId() {
    return id;
  }

  @Override
  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public List<Link> getLinks() {
    return links;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((cDCAndOSHARulesCompliance == null) ? 0 : cDCAndOSHARulesCompliance.hashCode());
    result = prime * result + ((cprTrained == null) ? 0 : cprTrained.hashCode());
    result = prime * result + ((credentialed == null) ? 0 : credentialed.hashCode());
    result = prime * result + ((dataOwner == null) ? 0 : dataOwner.hashCode());
    result = prime * result + ((deptHealthRulesCompliance == null) ? 0 : deptHealthRulesCompliance.hashCode());
    result = prime * result + ((emergencyKit == null) ? 0 : emergencyKit.hashCode());
    result = prime * result + ((emergencyTrained == null) ? 0 : emergencyTrained.hashCode());
    result = prime * result + ((hadicappedParking == null) ? 0 : hadicappedParking.hashCode());
    result = prime * result + ((handicapAccess == null) ? 0 : handicapAccess.hashCode());
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    result = prime * result + ((links == null) ? 0 : links.hashCode());
    result = prime * result + ((publicTransport == null) ? 0 : publicTransport.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ClinicCredentialsImpl other = (ClinicCredentialsImpl) obj;
    if (cDCAndOSHARulesCompliance == null) {
      if (other.cDCAndOSHARulesCompliance != null)
        return false;
    } else if (!cDCAndOSHARulesCompliance.equals(other.cDCAndOSHARulesCompliance))
      return false;
    if (cprTrained == null) {
      if (other.cprTrained != null)
        return false;
    } else if (!cprTrained.equals(other.cprTrained))
      return false;
    if (credentialed == null) {
      if (other.credentialed != null)
        return false;
    } else if (!credentialed.equals(other.credentialed))
      return false;
    if (dataOwner == null) {
      if (other.dataOwner != null)
        return false;
    } else if (!dataOwner.equals(other.dataOwner))
      return false;
    if (deptHealthRulesCompliance == null) {
      if (other.deptHealthRulesCompliance != null)
        return false;
    } else if (!deptHealthRulesCompliance.equals(other.deptHealthRulesCompliance))
      return false;
    if (emergencyKit == null) {
      if (other.emergencyKit != null)
        return false;
    } else if (!emergencyKit.equals(other.emergencyKit))
      return false;
    if (emergencyTrained == null) {
      if (other.emergencyTrained != null)
        return false;
    } else if (!emergencyTrained.equals(other.emergencyTrained))
      return false;
    if (hadicappedParking == null) {
      if (other.hadicappedParking != null)
        return false;
    } else if (!hadicappedParking.equals(other.hadicappedParking))
      return false;
    if (handicapAccess == null) {
      if (other.handicapAccess != null)
        return false;
    } else if (!handicapAccess.equals(other.handicapAccess))
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (links == null) {
      if (other.links != null)
        return false;
    } else if (!links.equals(other.links))
      return false;
    if (publicTransport == null) {
      if (other.publicTransport != null)
        return false;
    } else if (!publicTransport.equals(other.publicTransport))
      return false;
    return true;
  }

}
