package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = ProviderFocusReviewImpl.class)
public interface ProviderFocusReview extends NewProviderFocusReview, DataEntity {

}
