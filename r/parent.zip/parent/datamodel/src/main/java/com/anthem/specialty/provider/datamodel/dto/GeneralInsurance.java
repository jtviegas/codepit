package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = GeneralInsuranceImpl.class)
public interface GeneralInsurance extends Serializable {

  @JsonProperty("Insurer")
  @ApiModelProperty(required = true)
  @NotNull
  String getInsurer();

  @JsonProperty("Insurer")
  @ApiModelProperty(required = true)
  void setInsurer(String insurer);

  @JsonProperty("Limit")
  @ApiModelProperty(required = false)
  Character getLimit();

  @JsonProperty("Limit")
  @ApiModelProperty(required = false)
  void setLimit(Character limit);

  @JsonProperty("RenewalDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  LocalDate getRenewal();

  @JsonProperty("RenewalDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  @ApiModelProperty(required = false)
  void setRenewal(LocalDate renewal);

  @JsonProperty("Policy")
  @ApiModelProperty(required = false)
  String getPolicy();

  @JsonProperty("Policy")
  @ApiModelProperty(required = false)
  void setPolicy(String policy);

}