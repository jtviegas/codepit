package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = NewProviderFocusReviewImpl.class)
public interface NewProviderFocusReview extends NewClinicRelationship, NewFocusReview {

}