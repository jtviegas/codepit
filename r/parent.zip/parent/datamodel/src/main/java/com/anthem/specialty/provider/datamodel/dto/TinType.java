package com.anthem.specialty.provider.datamodel.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public enum TinType {
  EIN('E'),
  SSN('S'),;

  private Character character;

  private TinType(Character character) {
    this.character = character;
  }

  @JsonIgnore
  public Character asChar() {
    return this.character;
  }

  @JsonIgnore
  public static TinType fromChar(Character c) {
    TinType r = null;
    for (TinType w : TinType.values()) {
      if (w.asChar().equals(c)) {
        r = w;
        break;
      }
    }
    return r;
  }
}
