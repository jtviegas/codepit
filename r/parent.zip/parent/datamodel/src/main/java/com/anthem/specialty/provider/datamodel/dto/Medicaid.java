package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = MedicaidImpl.class)
public interface Medicaid {

  @JsonProperty("Number")
  @ApiModelProperty(required = true)
  @NotNull
  String getNumber();

  @JsonProperty("Number")
  @ApiModelProperty(required = true)
  void setNumber(String number);

  @JsonProperty("State")
  @ApiModelProperty(required = true)
  @NotNull
  String getState();

  @JsonProperty("State")
  @ApiModelProperty(required = true)
  void setState(String state);

}