package com.anthem.specialty.provider.datamodel.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NetworkImpl.class)
public interface Network extends DataEntity {

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  String getDescription();

  @JsonProperty("Description")
  @ApiModelProperty(required = true)
  @NotNull
  void setDescription(String description);

  @JsonProperty("ShortDescription")
  @ApiModelProperty(required = true)
  @NotNull
  String getShortDescription();

  @JsonProperty("ShortDescription")
  @ApiModelProperty(required = true)
  @NotNull
  void setShortDescription(String description);

  @JsonProperty("Manager")
  @ApiModelProperty(required = false)
  String getManager();

  @JsonProperty("Manager")
  @ApiModelProperty(required = false)
  void setManager(String manager);

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  String getComments();

  @JsonProperty("Comments")
  @ApiModelProperty(required = false)
  void setComments(String comments);

  @JsonProperty("CapitationPayment")
  @ApiModelProperty(required = false)
  Boolean isCapitationPayment();

  @JsonProperty("CapitationPayment")
  @ApiModelProperty(required = false)
  void setCapitationPayment(Boolean capitationPayment);

  @JsonProperty("CustomerServiceDisplayed")
  @ApiModelProperty(required = false)
  Boolean isCustomerServiceDisplayed();

  @JsonProperty("CustomerServiceDisplayed")
  @ApiModelProperty(required = false)
  void setCustomerServiceDisplayed(Boolean customerServiceDisplayed);

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  @Valid
  EffectivePeriod getEffective();

  @JsonProperty("Effective")
  @ApiModelProperty(required = false)
  void setEffective(EffectivePeriod effective);

}
