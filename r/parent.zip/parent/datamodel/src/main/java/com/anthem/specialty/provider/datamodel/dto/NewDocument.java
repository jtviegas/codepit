package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewDocumentImpl.class)
public interface NewDocument extends Serializable {
  @JsonProperty("ControlNumber")
  @ApiModelProperty(required = true)
  @NotNull
  Long getControlNumber();

  @JsonProperty("ControlNumber")
  @ApiModelProperty(required = true)
  void setControlNumber(Long controlNumber);

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  @NotNull
  @Valid
  DocumentType getType();

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  void setType(DocumentType type);

  @JsonProperty("Source")
  @ApiModelProperty(required = false)
  Character getSource();

  @JsonProperty("Source")
  @ApiModelProperty(required = false)
  void setSource(Character source);

}