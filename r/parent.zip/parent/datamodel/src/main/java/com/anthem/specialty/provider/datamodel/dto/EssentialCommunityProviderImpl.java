package com.anthem.specialty.provider.datamodel.dto;

import java.io.IOException;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EssentialCommunityProviderImpl implements EssentialCommunityProvider {

  @JsonCreator
  public static EssentialCommunityProvider create(String json)
      throws JsonParseException, JsonMappingException, IOException {
    final ObjectMapper mapper = new ObjectMapper();
    EssentialCommunityProvider impl = null;
    impl = mapper.readValue(json, EssentialCommunityProviderImpl.class);
    return impl;
  }

  private static final long serialVersionUID = 1L;

  private String ecpType;

  public EssentialCommunityProviderImpl() {
  }

  @Override
  public String getEcpType() {
    return ecpType;
  }

  @Override
  public void setEcpType(String ecpType) {
    this.ecpType = ecpType;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((ecpType == null) ? 0 : ecpType.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    EssentialCommunityProviderImpl other = (EssentialCommunityProviderImpl) obj;
    if (ecpType == null) {
      if (other.ecpType != null)
        return false;
    } else if (!ecpType.equals(other.ecpType))
      return false;
    return true;
  }

}
