package com.anthem.specialty.provider.datamodel.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModelProperty;

@JsonDeserialize(as = NewCarrierPhoneContactImpl.class)
public interface NewCarrierPhoneContact extends Serializable {

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  @NotNull
  CarrierPhoneContactType getType();

  @JsonProperty("Type")
  @ApiModelProperty(required = true)
  void setType(CarrierPhoneContactType type);

  @JsonProperty("CountryCode")
  @ApiModelProperty(required = false)
  String getCountryCode();

  @JsonProperty("CountryCode")
  @ApiModelProperty(required = false)
  void setCountryCode(String countryCode);

  @JsonProperty("CityCode")
  @ApiModelProperty(required = false)
  String getCityCode();

  @JsonProperty("CityCode")
  @ApiModelProperty(required = false)
  void setCityCode(String cityCode);

  @JsonProperty("AreaCode")
  @ApiModelProperty(required = false)
  String getAreaCode();

  @JsonProperty("AreaCode")
  @ApiModelProperty(required = false)
  void setAreaCode(String areaCode);

  @JsonProperty("AccessCode")
  @ApiModelProperty(required = false)
  String getAccessCode();

  @JsonProperty("AccessCode")
  @ApiModelProperty(required = false)
  void setAccessCode(String accessCode);

  @JsonProperty("Number")
  @ApiModelProperty(required = false)
  String getNumber();

  @JsonProperty("Number")
  @ApiModelProperty(required = false)
  void setNumber(String number);

  @JsonProperty("Extension")
  @ApiModelProperty(required = false)
  String getExtension();

  @JsonProperty("Extension")
  @ApiModelProperty(required = false)
  void setExtension(String extension);

}
