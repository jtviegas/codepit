#!/bin/sh
pid=`ps -ef | grep api-*-SNAPSHOT.jar | awk '{print $2}'`
echo "going to kill pid: $pid"
kill -9 $pid
echo "result: $?\ngoing to spawn new jvm..."
nohup /usr/java8/bin/java -jar  -Xms512m -Xmx1024m -Xss1024m api-0.0.1-SNAPSHOT.jar &
sleep 6
pid=`ps -ef | grep api-*-SNAPSHOT.jar | awk '{print $2}'`
echo "started new pid: $pid"
