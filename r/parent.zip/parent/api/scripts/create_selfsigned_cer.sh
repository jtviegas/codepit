#!/bin/sh

#...create JKS keystore
keytool -keystore selfsigned.jks -genkeypair -alias selfsigned -dname 'CN=va33tuvwbs020.wellpoint.com,O=Wellpoint,L=Tampa,ST=FL,C=US' -keyalg RSA -validity 365 -keysize 2048
#...to convert JKS keystore into PKCS#12 keystore,
keytool -importkeystore -srckeystore selfsigned.jks -destkeystore selfsigned.p12 -srcstoretype jks -deststoretype pkcs12
#...then into PEM file
keytool -exportcert -alias selfsigned -keypass passw0rd -keystore selfsigned.jks -rfc -file selfsigned.pem
#...to compare the certificate
keytool -keystore selfsigned.jks -exportcert -alias selfsigned | openssl x509 -inform der -text

