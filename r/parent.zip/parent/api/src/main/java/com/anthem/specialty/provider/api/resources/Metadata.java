package com.anthem.specialty.provider.api.resources;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.DataOwnerToDataOwnerDto;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.LinkImpl;
import com.anthem.specialty.provider.datamodel.schemas.core.BusinessSegment;
import com.anthem.specialty.provider.datamodel.schemas.core.DentalProcedure;
import com.anthem.specialty.provider.datamodel.schemas.core.Language;
import com.anthem.specialty.provider.datamodel.schemas.core.LargeGroup;
import com.anthem.specialty.provider.datamodel.schemas.core.LineOfBusiness;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/metadata")
@Api(tags = { "metadata" }, value = "root URI for metadata related functionality.")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class),
    @ApiResponse(code = 200, message = "successful operation") })
public class Metadata {
  private static final Logger logger = LoggerFactory.getLogger(Metadata.class);

  @Autowired
  private RequestMappingHandlerMapping requestMappingHandlerMapping;

  @Autowired
  private MetadataService metadataService;

  @RequestMapping(method = RequestMethod.GET)

  @ApiOperation(value = "returns a static set of links to all supported sub-resource types", notes = "", response = LinkImpl.class, responseContainer = "Set")
  public ResponseEntity<Set<LinkImpl>> get(HttpServletRequest request) {
    logger.trace("[get] in");

    Set<LinkImpl> result = requestMappingHandlerMapping.getHandlerMethods().keySet().stream()
        .flatMap(p -> p.getPatternsCondition().getPatterns().stream()).filter(s -> s.startsWith("/api/metadata"))
        .map(p -> new LinkImpl(p.replaceAll("/api/", "").replaceAll("/", "."), p)).collect(Collectors.toSet());

    logger.trace("[get] out", result);
    return new ResponseEntity<Set<LinkImpl>>(result, HttpStatus.OK);
  }

  @RequestMapping(value = "/terminationLevels", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get termination levels", notes = "", response = TerminationLevel.class, responseContainer = "List")
  public ResponseEntity<List<TerminationLevel>> getTerminationLevels() {
    logger.trace("[getTerminationLevels] in");
    logger.trace("[getTerminationLevels] out");
    return new ResponseEntity<List<TerminationLevel>>(metadataService.getTerminationLevels(), HttpStatus.OK);
  }

  @RequestMapping(value = "/dataOwners/{data-owner-id}", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get a data owner using its id", notes = "", response = DataOwner.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 422, message = "validation failure", response = void.class) })
  public ResponseEntity<DataOwner> getDataOwner(@PathVariable("data-owner-id") Long dataOwnerId) throws ApiException {
    logger.trace("[getDataOwner] in");
    DataOwner r;
    try {
      r = new DataOwnerToDataOwnerDto().apply(metadataService.getDataOwner(dataOwnerId));
    } catch (NoEntityFoundException e) {
      throw new ApiException(e);
    }
    logger.trace("[getDataOwner] out", r);
    return new ResponseEntity<DataOwner>(r, HttpStatus.OK);
  }

  @RequestMapping(value = "/dataOwners", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get data owners", notes = "", response = DataOwner.class, responseContainer = "List")
  public ResponseEntity<List<DataOwner>> getDataOwners() {
    logger.trace("[getDataOwners] in");
    logger.trace("[getDataOwners] out");
    List<DataOwner> ret = metadataService.getDataOwners().stream().map(new DataOwnerToDataOwnerDto())
        .collect(Collectors.toList());
    return new ResponseEntity<List<DataOwner>>(ret, HttpStatus.OK);
  }

  @RequestMapping(value = "/tenants/{tenant-id}", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get a tenant using its id", notes = "", response = LineOfBusiness.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<LineOfBusiness> getTenant(@ApiParam @PathVariable("tenant-id") Long tenantId)
      throws ApiException {
    logger.trace("[getTenant] in");
    LineOfBusiness r;
    try {
      r = metadataService.getTenant(tenantId);
    } catch (Exception e) {
      throw new ApiException(e);
    }
    logger.trace("[getTenant] out", r);
    return new ResponseEntity<LineOfBusiness>(r, HttpStatus.OK);
  }

  @RequestMapping(value = "/tenants", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get tenants", notes = "", response = LineOfBusiness.class, responseContainer = "List")
  public ResponseEntity<List<LineOfBusiness>> getTenants() {
    logger.trace("[getTenants] in");
    logger.trace("[getTenants] out");
    return new ResponseEntity<List<LineOfBusiness>>(metadataService.getTenants(), HttpStatus.OK);
  }

  @RequestMapping(value = "/specialties", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get specialties", notes = "", response = Specialty.class, responseContainer = "List")
  public ResponseEntity<List<Specialty>> getSpecialties() {
    logger.trace("[getSpecialties] in");
    logger.trace("[getSpecialties] out");
    return new ResponseEntity<List<Specialty>>(metadataService.getSpecialties(), HttpStatus.OK);
  }

  @RequestMapping(value = "/procedureCodes", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get procedure codes", notes = "", response = DentalProcedure.class, responseContainer = "List")
  public ResponseEntity<List<DentalProcedure>> getDentalProcedures() {
    logger.trace("[getDentalProcedures] in");
    logger.trace("[getDentalProcedures] out");
    return new ResponseEntity<List<DentalProcedure>>(metadataService.getDentalProcedures(), HttpStatus.OK);
  }

  @RequestMapping(value = "/languages", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get languages", notes = "", response = Language.class, responseContainer = "List")
  public ResponseEntity<List<Language>> getLanguages() {
    logger.trace("[getLanguages] in");
    logger.trace("[getLanguages] out");
    return new ResponseEntity<List<Language>>(metadataService.getLanguages(), HttpStatus.OK);
  }

  @RequestMapping(value = "/businessSegments", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get business segments", notes = "", response = BusinessSegment.class, responseContainer = "List")
  public ResponseEntity<List<BusinessSegment>> getBusinessSegments() {
    logger.trace("[getBusinessSegments] in");
    logger.trace("[getBusinessSegments] out");
    return new ResponseEntity<List<BusinessSegment>>(metadataService.getBusinessSegments(), HttpStatus.OK);
  }

  @RequestMapping(value = "/largeGroups", method = RequestMethod.GET)
  @ApiOperation(value = "Used to get large groups", notes = "", response = LargeGroup.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = LargeGroup.class, responseContainer = "List"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.LargeGroup>> getLargeGroups() throws ApiException {
    logger.trace("[getLargeGroups] in");
    try {
      List<com.anthem.specialty.provider.datamodel.dto.LargeGroup> r = metadataService.getLargeGroupDtos();
      return new ResponseEntity<>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getLargeGroups] out");
    }
  }
}
