package com.anthem.specialty.provider.api.resources;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class TenantInterceptor extends HandlerInterceptorAdapter {

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

    String tenant = null;
    if (null != (tenant = request.getHeader("tenant")))
      request.setAttribute("TENANT_IDENTIFIER", tenant);

    return true;
  }

}
