package com.anthem.specialty.provider.api.resources;

import static java.lang.String.format;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.NotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.api.util.HeaderMapBuilder;
import com.anthem.specialty.provider.datalayer.exceptions.DataIntegrityException;
import com.anthem.specialty.provider.datalayer.exceptions.DataValidationException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.LinkLocationResolver;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.LegalAddress;
import com.anthem.specialty.provider.datamodel.dto.NewLegalAddress;
import com.anthem.specialty.provider.datamodel.dto.NewW9;
import com.anthem.specialty.provider.datamodel.dto.W9;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/w9")
@Api(tags = { "w9" }, value = "root URI for W9 related operations on Provider businesses.")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class) })
public class W9s {
  private static final Logger logger = LoggerFactory.getLogger(W9s.class);

  private final LobService lobService;

  private final Config config;

  private final LinkLocationResolver locationResolver;

  public W9s(@Autowired LobService lobService, @Autowired Config config) {
    this.locationResolver = new LinkLocationResolver();
    this.lobService = lobService;
    this.config = config;
  }

  @RequestMapping(value = "/{w9-id}/legalAddresses/{legal-address-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the w9 legal address record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteW9LegalAddress(@ApiParam @PathVariable("w9-id") Long w9id,
      @ApiParam @PathVariable("legal-address-id") Long id) throws ApiException {
    logger.trace("[deleteW9LegalAddress] in", w9id, id);
    try {
      lobService.deleteW9LegalAddress(id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteW9LegalAddress] out");
    }
  }

  @RequestMapping(value = "/{w9-id}/legalAddresses/{legal-address-id}", method = RequestMethod.GET)
  @ApiOperation(value = "returns the details for this specific w9 legal address.", notes = "", response = LegalAddress.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = LegalAddress.class) })
  public ResponseEntity<LegalAddress> getW9LegalAddress(@ApiParam @PathVariable("w9-id") Long w9id,
      @ApiParam @PathVariable("legal-address-id") Long id) throws ApiException {
    logger.trace("[getW9LegalAddress] in", w9id, id);
    LegalAddress r = null;
    try {
      r = lobService.getW9LegalAddress(id);
      return new ResponseEntity<LegalAddress>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getW9LegalAddress] out", r);
    }
  }

  @RequestMapping(value = "/{w9-id}/legalAddresses/{legal-address-id}", method = RequestMethod.PUT)
  @ApiOperation(value = "Used to update the w9 legal address", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation, updated address", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class) })
  public ResponseEntity<Void> putW9LegalAddress(@ApiParam @PathVariable("w9-id") Long w9id,
      @ApiParam @PathVariable("legal-address-id") Long id,
      @ApiParam(value = "the w9 legal address to be updated", required = true) @RequestBody @Valid LegalAddress address)
      throws ApiException {
    logger.trace("[putW9LegalAddress] in", w9id, id, address);
    try {

      if (address.getId() == null)
        throw new IllegalArgumentException("Address id cannot be null");
      if (!address.getId().equals(id))
        throw new IllegalArgumentException("legal address id does not match");

      LegalAddress r = lobService.putW9LegalAddress(w9id, address);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.OK);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[putW9LegalAddress] out");
    }

  }

  @RequestMapping(value = "/{w9-id}/legalAddresses", method = RequestMethod.POST)
  @ApiOperation(value = "creates a new instance of a legal address for a W9 business entity.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postW9LegalAddress(@ApiParam @PathVariable("w9-id") Long w9id,
      @ApiParam(value = "the new w9 legal address to be persisted", required = true) @RequestBody @Valid NewLegalAddress address)
      throws ApiException {
    logger.trace("[postW9LegalAddress] in", address);
    try {
      LegalAddress r = lobService.postW9LegalAddress(w9id, address);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (DataIntegrityException uv) {
      throw new ApiException(uv, HttpStatus.CONFLICT);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postW9LegalAddress] out");
    }

  }

  @RequestMapping(value = "/{w9-id}/legalAddresses", method = RequestMethod.GET)
  @ApiOperation(value = "Returns a a list of all of the addresses associated with this W9 business.", notes = "", response = LegalAddress.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = LegalAddress.class, responseContainer = "List"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<List<LegalAddress>> getW9LegalAddresses(@ApiParam @PathVariable("w9-id") Long id)
      throws ApiException {
    logger.trace("[getW9LegalAddresses] in", id);
    List<LegalAddress> r = null;
    try {
      r = lobService.getW9LegalAddresses(id);
      return new ResponseEntity<List<LegalAddress>>(r, HttpStatus.OK);
    } catch (NotFoundException nf) {
      throw new ApiException(nf, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getW9LegalAddresses] out", r);
    }
  }

  @RequestMapping(value = "/{w9-id}", method = RequestMethod.GET)
  @ApiOperation(value = "Uniquely identifies the w9 instance", notes = "", response = W9.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = W9.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<W9> getW9(@ApiParam @PathVariable("w9-id") Long id) throws ApiException {
    logger.trace("[getW9] in", id);
    W9 r = null;
    try {
      if (null == (r = lobService.getW9(id)))
        throw new NotFoundException(format("no W9 found for id: %s", id.toString()));

      return new ResponseEntity<W9>(r, HttpStatus.OK);
    } catch (NotFoundException nf) {
      throw new ApiException(nf, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getW9] out", r);
    }
  }

  @RequestMapping(value = "/{w9-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the w9 record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteW9(@ApiParam @PathVariable("w9-id") Long id) throws ApiException {
    logger.trace("[deleteW9] in", id);
    try {
      lobService.deleteW9(id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteW9] out");
    }
  }

  @RequestMapping(value = "/{w9-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a w9", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchW9(
      @ApiParam(value = "Uniquely identifies this W9 business instance instance.", required = true) @PathVariable("w9-id") Long w9Id,
      @ApiParam(value = "the W9 properties to patch the existent instance", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchW9] in", w9Id, changes);
    try {
      lobService.patchW9(w9Id, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchW9] out");
    }
  }

  @RequestMapping(method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new W9 Business instance", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postW9(
      @ApiParam(value = "new W9 Business instance", required = true) @RequestBody @Valid NewW9 o) throws ApiException {
    logger.trace("[postW9] in", o);
    try {
      W9 r = lobService.setNewW9AndGetDto(o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

      // TODO
      /*
       * } catch (DataValidationException dve) { throw new ApiException(dve, HttpStatus.UNPROCESSABLE_ENTITY);
       * 
       * } catch (UniquenessViolationException uv) { throw new ApiException(uv, HttpStatus.CONFLICT);
       */
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postW9] out");
    }

  }

  @RequestMapping(method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for matching w9's", notes = "", response = W9.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = W9.class, responseContainer = "List") })
  public ResponseEntity<List<W9>> getW9s(
      @ApiParam(value = "optional query param: startRow", required = false) @RequestParam(required = false, defaultValue = "0") Integer startRow,
      @ApiParam(value = "optional query param: numRows", required = false) @RequestParam(required = false, defaultValue = "0") Integer numRows)
      throws ApiException {
    logger.trace("[getW9s] in");
    List<W9> result = null;
    try {

      int start = 0 <= startRow ? startRow : 0;
      int size = numRows <= 0 ? (int) config.getQuery().get("maxrows") : numRows;
      result = lobService.getW9s(start, size);

      return new ResponseEntity<List<W9>>(result, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getW9s] out", result);
    }
  }

}
