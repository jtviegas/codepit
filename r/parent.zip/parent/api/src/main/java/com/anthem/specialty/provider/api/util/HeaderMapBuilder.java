package com.anthem.specialty.provider.api.util;

import java.util.Optional;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

public class HeaderMapBuilder {

  private final MultiValueMap<String, String> header;

  public HeaderMapBuilder() {
    header = new LinkedMultiValueMap<String, String>();
  }

  public HeaderMapBuilder with(String key, String value) {
    header.add(key, value);
    return this;
  }

  public HeaderMapBuilder withProbably(String key, Optional<String> value) {
    if (value.isPresent())
      header.add(key, value.get());
    return this;
  }

  public MultiValueMap<String, String> build() {
    return header;
  }

  public static HeaderMapBuilder create() {
    return new HeaderMapBuilder();
  }

}
