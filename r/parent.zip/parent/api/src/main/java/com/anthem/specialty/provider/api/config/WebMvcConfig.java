package com.anthem.specialty.provider.api.config;

import com.anthem.specialty.provider.api.filter.HttpMethodOverrideHeaderFilter;
import com.anthem.specialty.provider.api.resources.TenantInterceptor;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.Filter;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer{

  @Autowired
  private ApplicationContext context;

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(new TenantInterceptor());
  }

  @Bean
  public FilterRegistrationBean registerMethodOverrideFilter() {
    FilterRegistrationBean registration = new FilterRegistrationBean();
    registration.setFilter(httpMethodOverrideFilter());
    // registration.addUrlPatterns("/*");
    // registration.addInitParameter("paramName", "paramValue");
    registration.setName("methodOverrideFilter");
    registration.setOrder(1);
    return registration;
  }

  private Filter httpMethodOverrideFilter() {
    return new HttpMethodOverrideHeaderFilter();
  }

  @Bean
  MeterRegistryCustomizer<MeterRegistry> metricsCommonTags() {
    final String hostname = null != context.getEnvironment().getProperty("HOSTNAME")
        ? context.getEnvironment().getProperty("HOSTNAME")
        : context.getEnvironment().getProperty("COMPUTERNAME");

    return registry -> registry.config().commonTags("host", null != hostname ? hostname : "localhost");
  }

}
