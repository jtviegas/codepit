package com.anthem.specialty.provider.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.config.TenantProperties;
import com.anthem.specialty.provider.datalayer.ServicesConfiguration;

@Import({ ServicesConfiguration.class })
@EnableJpaRepositories(basePackages = "com.anthem.specialty.provider.datalayer.repositories", entityManagerFactoryRef = "entityManagerFactory")
@EntityScan("com.anthem.specialty.provider.datamodel.schemas")
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@EnableConfigurationProperties({ TenantProperties.class, Config.class })
@EnableTransactionManagement
public class Bootstrap extends org.springframework.boot.web.servlet.support.SpringBootServletInitializer {

  public static void main(String[] args) {
    SpringApplication.run(Bootstrap.class, args);
  }

}