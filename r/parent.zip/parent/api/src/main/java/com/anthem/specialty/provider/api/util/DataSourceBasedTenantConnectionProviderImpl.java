package com.anthem.specialty.provider.api.util;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DataSourceBasedTenantConnectionProviderImpl
    extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {

  private static final long serialVersionUID = 1L;

  @Autowired
  private DataSource dataSource1;

  @Autowired
  private DataSource dataSource2;

  @Autowired
  private DataSource dataSource3;

  @Autowired
  private DataSource dataSource4;

  @Autowired
  private DataSource dataSource5;

  private Map<String, DataSource> map;

  private static final String DEFAULT_TENANT_ID = "anthem";

  @PostConstruct
  public void load() {
    map = new HashMap<>();
    map.put("anthem", dataSource1);
    map.put("wellmark", dataSource2);
    map.put("horizon", dataSource3);
    map.put("dentemax", dataSource4);
    map.put("fees", dataSource5);
  }

  @Override
  protected DataSource selectAnyDataSource() {
    return map.get(DEFAULT_TENANT_ID);
  }

  @Override
  protected DataSource selectDataSource(String tenantIdentifier) {
    return map.get(tenantIdentifier);
  }

}
