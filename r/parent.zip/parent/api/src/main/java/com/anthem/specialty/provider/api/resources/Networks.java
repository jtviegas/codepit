package com.anthem.specialty.provider.api.resources;

import static java.lang.String.format;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.NotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.api.util.HeaderMapBuilder;
import com.anthem.specialty.provider.datalayer.exceptions.DataValidationException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.LinkLocationResolver;
import com.anthem.specialty.provider.datalayer.functional.LinkResolver;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrier;
import com.anthem.specialty.provider.datamodel.dto.Network;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierEffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewNetwork;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.RelatedProvider;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/networks")
@Api(tags = { "networks" }, value = "API root for network related functions.")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class) })
public class Networks {
  private static final Logger logger = LoggerFactory.getLogger(Networks.class);

  private final LobService lobService;

  private final Config config;

  private final LinkLocationResolver locationResolver;

  public Networks(@Autowired LobService lobService, @Autowired Config config) {
    this.locationResolver = new LinkLocationResolver();
    this.lobService = lobService;
    this.config = config;
  }

  @RequestMapping(value = "/{network-id}/providers", method = RequestMethod.GET)
  @ApiOperation(value = "Returns a a list of all of the providers associated with this network.", notes = "", response = RelatedProvider.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedProvider.class, responseContainer = "List"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<List<RelatedProvider>> getNetworkProviders(@ApiParam @PathVariable("network-id") Long networkId)
      throws ApiException {
    logger.trace("[getNetworkProviders] in", networkId);
    List<RelatedProvider> r = null;
    try {
      r = lobService.getNetworkProviders(networkId);
      return new ResponseEntity<List<RelatedProvider>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkProviders] out", r);
    }
  }

  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}/providers/{provider-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the network clinic provider record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteNetworkClinicProvider(@ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id", required = true) @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the network clinic provider relationship id", required = true) @PathVariable("provider-id") Long id)
      throws ApiException {
    logger.trace("[deleteNetworkClinicProvider] in", networkId, clinicId, id);
    try {
      lobService.deleteNetworkClinicProvider(id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteNetworkClinicProvider] out");
    }
  }

  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}/providers/{provider-id}", method = RequestMethod.GET)
  @ApiOperation(value = "returns the details for this specific network clinic provider.", notes = "", response = NetworkClinicProviderRelationship.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = NetworkClinicProviderRelationship.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<NetworkClinicProviderRelationship> getNetworkClinicProvider(
      @ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id") @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the network clinic provider relationship id") @PathVariable("provider-id") Long id)
      throws ApiException {
    logger.trace("[getNetworkClinicProvider] in", networkId, clinicId, id);
    NetworkClinicProviderRelationship r = null;
    try {
      r = lobService.getNetworkClinicProviderDto(id);
      return new ResponseEntity<NetworkClinicProviderRelationship>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkClinicProvider] out", r);
    }
  }

  // FIXME: switch from map to object parameter
  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}/providers/{provider-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a network clinic provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchNetworkClinicProvider(
      @ApiParam(required = true) @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id", required = true) @PathVariable("clinic-id") Long networkClinicId,
      @ApiParam(value = "the network clinic provider relationship id", required = true) @PathVariable("provider-id") Long id,
      @ApiParam(required = true) @RequestBody Map<String, Object> changes) throws ApiException {
    logger.trace("[patchNetworkClinicProvider] in", networkId, networkClinicId, id, changes);
    try {
      lobService.patchNetworkClinicProvider(id, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchNetworkClinicProvider] out");
    }
  }

  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}/providers", method = RequestMethod.POST)
  @ApiOperation(value = "creates a new instance of a provider for this network clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postNetworkClinicProvider(@ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id") @PathVariable("clinic-id") Long networkClinicId,
      @ApiParam(value = " the new provider relationship instance.", required = true) @RequestBody @Valid NewNetworkClinicProviderRelationship o)
      throws ApiException {
    logger.trace("[postNetworkClinicProvider] in", networkId, o);
    try {
      NetworkClinicProviderRelationship r = lobService.postNetworkClinicProvider(networkClinicId, o);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postNetworkClinicProvider] out");
    }

  }

  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}/providers", method = RequestMethod.GET)
  @ApiOperation(value = "Returns a a list of all of the providers associated with this network clinic.", notes = "", response = RelatedProvider.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedProvider.class, responseContainer = "List"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<List<RelatedProvider>> getNetworkClinicProviders(
      @ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id") @PathVariable("clinic-id") Long networkClinicId)
      throws ApiException {
    logger.trace("[getNetworkClinicProviders] in", networkId, networkClinicId);
    List<RelatedProvider> r = null;
    try {
      r = lobService.getRelatedProvidersByNetworkClinicId(networkClinicId);
      return new ResponseEntity<List<RelatedProvider>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkClinicProviders] out", r);
    }
  }

  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}", method = RequestMethod.GET)
  @ApiOperation(value = "returns the details for this specific network clinic.", notes = "", response = NetworkClinicRelationship.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = NetworkClinicRelationship.class) })
  public ResponseEntity<NetworkClinicRelationship> getNetworkClinic(
      @ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id") @PathVariable("clinic-id") Long id) throws ApiException {
    logger.trace("[getNetworkClinic] in", networkId, id);
    NetworkClinicRelationship r = null;
    try {
      r = lobService.getNetworkClinic(networkId, id);
      return new ResponseEntity<NetworkClinicRelationship>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkClinic] out", r);
    }
  }

  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the network carrier record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteNetworkClinic(@ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id", required = true) @PathVariable("clinic-id") Long clinicId)
      throws ApiException {
    logger.trace("[deleteNetworkClinic] in", networkId, clinicId);
    try {
      lobService.deleteNetworkClinic(clinicId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteNetworkClinic] out");
    }
  }

  // FIXME
  @RequestMapping(value = "/{network-id}/clinics/{clinic-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a network clinic", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchNetworkClinic(@ApiParam(required = true) @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network clinic relationship id", required = true) @PathVariable("clinic-id") Long clinicId,
      @ApiParam(required = true) @RequestBody Map<String, Object> changes) throws ApiException {
    logger.trace("[patchNetworkClinic] in", networkId, clinicId, changes);
    try {
      lobService.patchNetworkClinic(networkId, clinicId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchNetworkClinic] out");
    }
  }

  @RequestMapping(value = "/{network-id}/clinics", method = RequestMethod.POST)
  @ApiOperation(value = "creates a new instance of a clinic for a network entity.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postNetworkClinic(@ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = " creates a new instance of a clinic for a network.", required = true) @RequestBody @Valid NewNetworkClinicRelationship o)
      throws ApiException {
    logger.trace("[postNetworkClinic] in", networkId, o);
    try {
      NetworkClinicRelationship r = lobService.postNetworkClinic(networkId, o);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postNetworkClinic] out");
    }

  }

  @RequestMapping(value = "/{network-id}/clinics", method = RequestMethod.GET)
  @ApiOperation(value = "Returns a a list of all of the clinics associated with this network.", notes = "", response = RelatedClinic.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedClinic.class, responseContainer = "List"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<List<RelatedClinic>> getNetworkClinics(@ApiParam @PathVariable("network-id") Long id)
      throws ApiException {
    logger.trace("[getNetworkClinics] in", id);
    List<RelatedClinic> r = null;
    try {
      r = lobService.getNetworkClinicsByNetworkId(id);
      return new ResponseEntity<List<RelatedClinic>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkClinics] out", r);
    }
  }

  @RequestMapping(value = "/{network-id}/carriers/{carrier-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the network carrier record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteNetworkCarrier(@ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam @PathVariable("carrier-id") Long nwCarrierId) throws ApiException {
    logger.trace("[deleteNetworkCarrier] in", networkId, nwCarrierId);
    try {
      lobService.deleteNetworkCarrier(nwCarrierId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteNetworkCarrier] out");
    }
  }

  // FIXME
  @RequestMapping(value = "/{network-id}/carriers/{carrier-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a network carrier", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchNetworkCarrier(
      @ApiParam(value = "Uniquely identifies this W9 business instance instance.", required = true) @PathVariable("network-id") Long networkId,
      @ApiParam @PathVariable("carrier-id") Long networkCarrierId,
      @ApiParam(value = "the W9 properties to patch the existent instance", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchNetworkCarrier] in", networkId, networkCarrierId, changes);
    try {
      lobService.patchNetworkCarrier(networkId, networkCarrierId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchNetworkCarrier] out");
    }
  }

  @RequestMapping(value = "/{network-id}/carriers/{carrier-id}", method = RequestMethod.GET)
  @ApiOperation(value = "returns the details for this specific network carrier.", notes = "", response = CollectionRelatedCarrier.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = CollectionRelatedCarrier.class) })
  public ResponseEntity<CollectionRelatedCarrier> getNetworkCarrier(
      @ApiParam @PathVariable("network-id") Long networkId, @ApiParam @PathVariable("carrier-id") Long networkCarrierId)
      throws ApiException {
    logger.trace("[getNetworkCarrier] in", networkId, networkCarrierId);
    CollectionRelatedCarrier r = null;
    try {
      if (null == (r = lobService.getNetworkCarrier(networkId, networkCarrierId)))
        throw new ApiException(format("no carrier found for network id: %s  carrier id: %s", networkId.toString(),
            networkCarrierId.toString()), HttpStatus.BAD_REQUEST);

      return new ResponseEntity<CollectionRelatedCarrier>(r, HttpStatus.OK);
    } catch (ApiException ae) {
      throw ae;
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkCarrier] out", r);
    }
  }

  @RequestMapping(value = "/{network-id}/carriers", method = RequestMethod.POST)
  @ApiOperation(value = "creates a new instance of a carrier for a network entity.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postNetworkCarrier(@ApiParam @PathVariable("network-id") Long networkId,
      @ApiParam(value = " creates a new instance of a carrier for a network.", required = true) @RequestBody @Valid NewCarrierEffectiveRelationship o)
      throws ApiException {
    logger.trace("[postNetworkCarrier] in", networkId, o);
    try {
      CollectionRelatedCarrier r = lobService.postNetworkCarrier(networkId, o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .with("Location",
              LinkResolver.createLink(new String[] { r.getId().toString() }, LinkResolver.Type.carrier, true).getHref())
          .build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postNetworkCarrier] out");
    }

  }

  @RequestMapping(value = "/{network-id}/carriers", method = RequestMethod.GET)
  @ApiOperation(value = "Returns a a list of all of the carriers associated with this network.", notes = "", response = CollectionRelatedCarrier.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = CollectionRelatedCarrier.class, responseContainer = "List"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<List<CollectionRelatedCarrier>> getNetworkCarriers(
      @ApiParam @PathVariable("network-id") Long id) throws ApiException {
    logger.trace("[getNetworkCarriers] in", id);
    List<CollectionRelatedCarrier> r = null;
    try {
      r = lobService.getNetworkCarriers(id);

      return new ResponseEntity<List<CollectionRelatedCarrier>>(r, HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (NotFoundException nf) {
      throw new ApiException(nf, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworkCarriers] out", r);
    }
  }

  @RequestMapping(value = "/{network-id}", method = RequestMethod.GET)
  @ApiOperation(value = "Uniquely identifies the network instance", notes = "", response = Network.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Network.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Network> getNetwork(@ApiParam @PathVariable("network-id") Long id) throws ApiException {
    logger.trace("[getNetwork] in", id);
    Network r = null;
    try {
      if (null == (r = lobService.getNetworkDto(id)))
        throw new NotFoundException(format("no network found for id: %s", id.toString()));

      return new ResponseEntity<Network>(r, HttpStatus.OK);
    } catch (NotFoundException nf) {
      throw new ApiException(nf, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetwork] out", r);
    }
  }

  // FIXME
  @RequestMapping(value = "/{network-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a network", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchNetwork(
      @ApiParam(value = " Uniquely identifies the network instance.", required = true) @PathVariable("network-id") Long networkId,
      @ApiParam(value = "the network properties to patch the existent instance", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchNetwork] in", networkId, changes);
    try {
      lobService.patchNetwork(networkId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchNetwork] out");
    }
  }

  @RequestMapping(method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new network", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postNetwork(
      @ApiParam(value = "new network instance", required = true) @RequestBody @Valid NewNetwork o) throws ApiException {
    logger.trace("[postNetwork] in", o);
    try {
      Network r = lobService.setNewNetwork(o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

      // TODO
      /*
       * } catch (DataValidationException dve) { throw new ApiException(dve, HttpStatus.UNPROCESSABLE_ENTITY);
       * 
       * } catch (UniquenessViolationException uv) { throw new ApiException(uv, HttpStatus.CONFLICT);
       */
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postNetwork] out");
    }

  }

  @RequestMapping(method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for matching networks", notes = "", response = RelatedNetwork.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedNetwork.class, responseContainer = "List") })
  public ResponseEntity<List<RelatedNetwork>> getNetworks(
      @ApiParam(value = "optional query param: startRow", required = false) @RequestParam(required = false, defaultValue = "0") Integer startRow,
      @ApiParam(value = "optional query param: numRows", required = false) @RequestParam(required = false, defaultValue = "0") Integer numRows)
      throws ApiException {
    logger.trace("[getNetworks] in");
    List<RelatedNetwork> result = null;
    try {

      int start = 0 <= startRow ? startRow : 0;
      int size = numRows <= 0 ? (int) config.getQuery().get("maxrows") : numRows;
      result = lobService.getNetworks(start, size);

      return new ResponseEntity<List<RelatedNetwork>>(result, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getNetworks] out", result);
    }
  }

}
