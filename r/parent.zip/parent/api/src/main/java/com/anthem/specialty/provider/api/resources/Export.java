package com.anthem.specialty.provider.api.resources;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElement;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderVerificationElement;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/export")
@Api(tags = { "export" }, value = "API root for export related functions")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class),
    @ApiResponse(code = 200, message = "successful operation") })
public class Export {
  private static final Logger logger = LoggerFactory.getLogger(Export.class);

  private final LobService lobService;

  private final MetadataService metadataService;

  public Export(@Autowired LobService lobService, @Autowired MetadataService metadataService) {
    this.lobService = lobService;
    this.metadataService = metadataService;
  }

  @RequestMapping(value = "/directoryVerification/providers", method = RequestMethod.GET)
  @ApiOperation(value = "Used to retrieve providers directory verification", notes = "", response = ProviderVerificationElement.class, responseContainer = "List")
  public ResponseEntity<List<ProviderVerificationElement>> getProviders(
      @ApiParam(value = "Uniquely identifies a set of networks to apply directory verification to.  Mutually exclusive with networkId.", required = false) @RequestParam(name = "largeGroupId", required = false) Long largeGroupId,
      @ApiParam(value = "Uniquely identifies a network to apply directory verification to.  Mutually exclusive with largeGroupId.", required = false) @RequestParam(name = "networkId", required = false) Long networkId)
      throws ApiException {
    logger.trace("[getProviders] in");
    List<ProviderVerificationElement> result = null;
    try {
      if (null != largeGroupId && null != networkId)
        throw new IllegalArgumentException("largeGroupId and networkId are mutually exclusive");
      if (null == largeGroupId && null == networkId)
        throw new IllegalArgumentException("have to provide either largeGroupId or networkId");

      if (null != largeGroupId)
        result = lobService.getProviderDirectoryAccuracyByLargeGroup(largeGroupId);
      else
        result = lobService.getProviderDirectoryAccuracyByNetwork(networkId);

      return new ResponseEntity<List<ProviderVerificationElement>>(result, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviders] out", result);
    }
  }

  @RequestMapping(value = "/directoryVerification/clinics", method = RequestMethod.GET)
  @ApiOperation(value = "Used to retrieve clinics directory verification", notes = "", response = ClinicVerificationElement.class, responseContainer = "List")
  public ResponseEntity<List<ClinicVerificationElement>> getClinics(
      @ApiParam(value = "Uniquely identifies a set of clinics to apply directory verification to..", required = true) @RequestParam(name = "largeGroupId", required = true) Long largeGroupId)
      throws ApiException {
    logger.trace("[getClinics] in");
    List<ClinicVerificationElement> result = null;
    try {
      if (null == largeGroupId)
        throw new IllegalArgumentException("largeGroupId is mandatory");

      metadataService.getLargeGroup(largeGroupId); // validation
      result = lobService.getClinicsDirectoryAccuracyByLargeGroup(largeGroupId);

      return new ResponseEntity<List<ClinicVerificationElement>>(result, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinics] out", result);
    }
  }

}
