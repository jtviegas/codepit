package com.anthem.specialty.provider.api.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("app")
public class Config {

  private Map<String, Object> query = new HashMap<String, Object>();

  public Map<String, Object> getQuery() {
    return query;
  }

}
