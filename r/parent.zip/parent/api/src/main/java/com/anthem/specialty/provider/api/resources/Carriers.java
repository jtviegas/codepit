package com.anthem.specialty.provider.api.resources;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.api.util.HeaderMapBuilder;
import com.anthem.specialty.provider.datalayer.exceptions.DataConstraintException;
import com.anthem.specialty.provider.datalayer.exceptions.DataValidationException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.LinkLocationResolver;
import com.anthem.specialty.provider.datalayer.functional.LinkResolver;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.Carrier;
import com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewCarrier;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/carriers")
@Api(tags = { "carriers" }, value = "API root for carrier related functions.")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class) })
public class Carriers {
  private static final Logger logger = LoggerFactory.getLogger(Carriers.class);

  private final LobService lobService;

  private final Config config;

  private final LinkLocationResolver locationResolver;

  public Carriers(@Autowired LobService lobService, @Autowired Config config) {
    this.locationResolver = new LinkLocationResolver();
    this.lobService = lobService;
    this.config = config;
  }

  @RequestMapping(value = "/{carrier-id}/phoneContacts/{phone-contact-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a carrier phone contact", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchCarrierPhoneContact(@ApiParam @PathVariable("carrier-id") Long carrierId,
      @ApiParam @PathVariable("phone-contact-id") Long carrierPhoneContactId,
      @ApiParam(required = true) @RequestBody Map<String, Object> changes) throws ApiException {
    // registry.
    logger.trace("[patchCarrierPhoneContact] in", carrierId, carrierPhoneContactId, changes);
    try {

      lobService.patchCarrierPhoneContact(carrierId, carrierPhoneContactId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchCarrierPhoneContact] out");
    }
  }

  @RequestMapping(value = "/{carrier-id}/phoneContacts/{phone-contact-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the carrier phone contact record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteCarrierPhoneContact(@ApiParam @PathVariable("carrier-id") Long carrierId,
      @ApiParam @PathVariable("phone-contact-id") Long carrierPhoneContactId) throws ApiException {
    logger.trace("[deleteCarrierPhoneContact] in", carrierId, carrierPhoneContactId);
    try {
      lobService.deleteCarrierPhoneContact(carrierPhoneContactId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteCarrierPhoneContact] out");
    }
  }

  @RequestMapping(value = "/{carrier-id}/phoneContacts", method = RequestMethod.POST)
  @ApiOperation(value = "creates a new instance of a phone contact for a carrier entity.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postCarrierPhoneContact(
      @ApiParam(value = "the carrier id", required = true) @PathVariable("carrier-id") Long id,
      @ApiParam(value = "  new instance of a phone contact for a carrier.", required = true) @RequestBody @Valid NewCarrierPhoneContact o)
      throws ApiException {
    logger.trace("[postCarrierPhoneContact] in", id, o);
    try {
      CarrierPhoneContact r = lobService.postCarrierPhoneContact(id, o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .with("Location",
              LinkResolver.createLink(new String[] { r.getId().toString() }, LinkResolver.Type.carrier, true).getHref())
          .build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (DataConstraintException ne) {
      throw new ApiException(ne, HttpStatus.CONFLICT);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postCarrierPhoneContact] out");
    }

  }

  @RequestMapping(value = "/{carrier-id}/phoneContacts", method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for carrier phone contacts", notes = "", response = CarrierPhoneContact.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = CarrierPhoneContact.class, responseContainer = "List") })
  public ResponseEntity<List<CarrierPhoneContact>> getCarrierPhoneContacts(
      @ApiParam(value = "the carrier id", required = true) @PathVariable("carrier-id") Long id) throws ApiException {
    logger.trace("[getCarrierPhoneContacts] in");
    List<CarrierPhoneContact> r = null;
    try {
      r = lobService.getPhoneContactsFromCarrier(id);
      return new ResponseEntity<List<CarrierPhoneContact>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getCarrierPhoneContacts] out");
    }
  }

  @RequestMapping(value = "/{carrier-id}/networks", method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for carrier networks", notes = "", response = RelatedNetwork.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedNetwork.class, responseContainer = "List") })
  public ResponseEntity<List<RelatedNetwork>> getCarrierNetworks(
      @ApiParam(value = "the carrier id", required = true) @PathVariable("carrier-id") Long id) throws ApiException {
    logger.trace("[getCarrierNetworks] in");
    List<RelatedNetwork> r = null;
    try {
      r = lobService.getNetworksByCarrier(id);
      return new ResponseEntity<List<RelatedNetwork>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getCarrierNetworks] out");
    }
  }

  @RequestMapping(value = "/{carrier-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a carrier record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchCarrier(
      @ApiParam(value = "the carrier id", required = true) @PathVariable("carrier-id") Long id,
      @ApiParam(required = true) @RequestBody Map<String, Object> changes) throws ApiException {
    logger.trace("[patchCarrier] in", id, changes);
    try {
      lobService.patchCarrier(id, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchCarrier] out");
    }
  }

  @RequestMapping(value = "/{carrier-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the carrier record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteCarrier(@ApiParam @PathVariable("carrier-id") Long carrierId) throws ApiException {
    logger.trace("[deleteCarrier] in", carrierId);
    try {
      lobService.deleteCarrier(carrierId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteCarrier] out");
    }
  }

  @RequestMapping(method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new carrier", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postCarrier(
      @ApiParam(value = "new carrier instance", required = true) @RequestBody @Valid NewCarrier o) throws ApiException {
    logger.trace("[postCarrier] in", o);
    try {
      Carrier r = lobService.setNewCarrier(o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postCarrier] out");
    }

  }

  @RequestMapping(method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for matching carriers", notes = "", response = Carrier.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Carrier.class, responseContainer = "List") })
  public ResponseEntity<List<Carrier>> getCarriers(
      @ApiParam(value = "optional query param: startRow", required = false) @RequestParam(required = false, defaultValue = "0") Integer startRow,
      @ApiParam(value = "optional query param: numRows", required = false) @RequestParam(required = false, defaultValue = "0") Integer numRows)
      throws ApiException {
    logger.trace("[getCarriers] in");
    try {
      int start = 0 <= startRow ? startRow : 0;
      int size = numRows <= 0 ? (int) config.getQuery().get("maxrows") : numRows;
      Page<com.anthem.specialty.provider.datamodel.dto.Carrier> page = lobService.getCarriers(start, size);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .with("X-Total-Count", Long.toString(page.getTotalElements())).build();

      return new ResponseEntity<List<Carrier>>(page.getContent(), header, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getCarriers] out");
    }
  }

}
