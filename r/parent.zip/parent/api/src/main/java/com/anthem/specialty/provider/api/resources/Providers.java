package com.anthem.specialty.provider.api.resources;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.api.util.HeaderMapBuilder;
import com.anthem.specialty.provider.datalayer.functional.LinkLocationResolver;
import com.anthem.specialty.provider.datalayer.functional.LinkResolver;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.License;
import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.NewDocument;
import com.anthem.specialty.provider.datamodel.dto.NewLanguageImpl;
import com.anthem.specialty.provider.datamodel.dto.NewLicense;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.NewProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.NewProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.NewProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty;
import com.anthem.specialty.provider.datamodel.dto.NewSanction;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.ProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.Sanction;
import com.anthem.specialty.provider.datamodel.dto.SimpleProvider;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/providers")
@Api(tags = { "providers" }, value = "API root for provider related functions") // , authorizations = {// //
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class) })
public class Providers {
  private static final Logger logger = LoggerFactory.getLogger(Providers.class);

  private final LobService lobService;

  private final Config config;

  private final LinkLocationResolver dataEntityLocationResolver;

  public Providers(@Autowired LobService lobService, @Autowired Config config) {
    this.dataEntityLocationResolver = new LinkLocationResolver();
    this.lobService = lobService;
    this.config = config;
  }

  @RequestMapping(value = "/{provider-id}/clinics/{clinic-id}/documents/{document-control-number}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Used to delete a clinic provider document", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicProviderDocument(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("clinic-id") Long clinicProviderId,
      @ApiParam @PathVariable("document-control-number") Long docControlNumber) throws ApiException {
    logger.trace("[deleteClinicProviderDocument] in", providerId, clinicProviderId, docControlNumber);
    try {
      lobService.deleteClinicProviderDocument(clinicProviderId, docControlNumber);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicProviderDocument] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/clinics/{clinic-id}/documents", method = RequestMethod.GET)
  @ApiOperation(value = "List all documents associated with the clinic and provider", notes = "", response = Document.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Document.class, responseContainer = "List") })
  public ResponseEntity<List<Document>> getClinicProviderDocuments(
      @ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("clinic-id") Long clinicProviderId) throws ApiException {
    logger.trace("[getClinicProviderDocuments] in", providerId);
    List<Document> r = null;
    try {
      r = lobService.getClinicProviderDocuments(clinicProviderId);
      return new ResponseEntity<List<Document>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicProviderDocuments] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/clinics/{clinic-id}/documents", method = RequestMethod.POST)
  @ApiOperation(value = "Used to persist a clinic provider document", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicProviderDocument(
      @ApiParam(value = "the ClinicProvider to be persisted", required = true) @RequestBody @Valid NewDocument newDocumentControl,
      @ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("clinic-id") Long clinicProviderId) throws ApiException {
    logger.trace("[postClinicProviderDocument] in", newDocumentControl);
    try {
      Document r = lobService.createClinicProviderDocument(newDocumentControl, clinicProviderId);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicProviderDocument] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/clinics/{clinic-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a clinic provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchProviderClinic(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("clinic-id") Long providerClinicId,
      @ApiParam(value = "the ProviderClinic properties to patch the existent one", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchProviderClinic] in", providerId, providerClinicId, changes);
    try {
      lobService.patchProviderClinic(providerId, providerClinicId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchProviderClinic] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/clinics/{clinic-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Used to delete a clinic provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicProvider(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("clinic-id") Long clinicProviderId) throws ApiException {
    logger.trace("[deleteClinicProvider] in", providerId, clinicProviderId);
    try {
      lobService.deleteClinicProvider(clinicProviderId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicProvider] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/languages/{language-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Removes a reference to the language for the provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteProviderLanguage(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("language-id") Long languageId) throws ApiException {
    logger.trace("[deleteProviderLanguage] in", providerId, languageId);
    try {
      lobService.deleteProviderLanguage(providerId, languageId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteProviderLanguage] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/languages", method = RequestMethod.POST)
  @ApiOperation(value = "Used to create a new provider language association", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderLanguage(
      @ApiParam(value = "the language association to be persisted", required = true) @RequestBody @Valid NewLanguageImpl newLanguage,
      @ApiParam(value = "the related provider id", required = true) @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[postProviderLanguage] in", newLanguage);
    try {
      lobService.createProviderLanguage(providerId, newLanguage);
      return new ResponseEntity<Void>(HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderLanguage] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/languages", method = RequestMethod.GET)
  @ApiOperation(value = "Any extra languages the provider has", notes = "", response = Language.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Language.class, responseContainer = "List") })
  public ResponseEntity<List<Language>> getProviderLanguages(@ApiParam @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[getProviderLanguages] in", providerId);
    List<Language> r = null;
    try {
      r = lobService.getLanguagesByProvider(providerId);
      return new ResponseEntity<List<Language>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderLanguages] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/clinics", method = RequestMethod.GET)
  @ApiOperation(value = "List all clinics associated with the provider", notes = "", response = com.anthem.specialty.provider.datamodel.dto.ProviderClinic.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = com.anthem.specialty.provider.datamodel.dto.ProviderClinic.class, responseContainer = "List") })
  public ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.ProviderClinic>> getProviderClinics(
      @ApiParam @PathVariable("provider-id") Long providerId) throws ApiException {
    logger.trace("[getProviderClinics] in", providerId);
    List<com.anthem.specialty.provider.datamodel.dto.ProviderClinic> r = null;
    try {
      r = lobService.getClinicsByProvider(providerId);
      return new ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.ProviderClinic>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderClinics] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/clinics", method = RequestMethod.POST)
  @ApiOperation(value = "Used to persist a clinic provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderClinic(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the ClinicProvider to be persisted", required = true) @RequestBody @Valid NewProviderClinic newProviderClinic)
      throws ApiException {
    logger.trace("[postProviderClinic] in", newProviderClinic);
    try {
      ProviderClinic o = lobService.createProviderClinic(providerId, newProviderClinic);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .with("Location", LinkResolver.createLink(new String[] { providerId.toString(), o.getId().toString() },
              LinkResolver.Type.provider_clinic, true).getHref())
          .build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderClinic] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/sanctions", method = RequestMethod.GET)
  @ApiOperation(value = "List any sanctions associated with the provider", notes = "", response = Sanction.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Sanction.class, responseContainer = "List") })
  public ResponseEntity<List<Sanction>> getProviderSanctions(@ApiParam @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[getProviderSanctions] in", providerId);
    List<Sanction> r = null;
    try {
      r = lobService.getProviderSanctionsByProvider(providerId);
      return new ResponseEntity<List<Sanction>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderSanctions] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/sanctions", method = RequestMethod.POST)
  @ApiOperation(value = "Used to create a new provider sanction instance", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderSanction(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the Sanction to be persisted", required = true) @RequestBody @Valid NewSanction newSanction)
      throws ApiException {
    logger.trace("[postProviderSanction] in", newSanction);

    try {
      Sanction r = lobService.createProviderSanction(providerId, newSanction);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderSanction] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/credentials", method = RequestMethod.GET)
  @ApiOperation(value = "list the result of every credentialling exercise for this provider", notes = "", response = ProviderCredentials.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = ProviderCredentials.class, responseContainer = "List") })
  public ResponseEntity<List<ProviderCredentials>> getProviderCredentials(
      @ApiParam @PathVariable("provider-id") Long providerId) throws ApiException {
    logger.trace("[getProviderCredentials] in", providerId);
    List<ProviderCredentials> r = null;
    try {
      r = lobService.getProviderCredentialsByProvider(providerId);

      return new ResponseEntity<List<ProviderCredentials>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderCredentials] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/credentials", method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new provider credential record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderCredential(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the ProviderCredential to be persisted", required = true) @RequestBody @Valid NewProviderCredentials n)
      throws ApiException {
    logger.trace("[postProviderCredential] in", n);
    try {
      ProviderCredentials r = lobService.createProviderCredential(providerId, n);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderCredential] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/specialties", method = RequestMethod.GET)
  @ApiOperation(value = "Any specialties associated with the provider", notes = "", response = com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty.class, responseContainer = "List") })
  public ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty>> getProviderSpecialties(
      @ApiParam @PathVariable("provider-id") Long providerId) throws ApiException {
    logger.trace("[getProviderSpecialties] in", providerId);
    List<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty> r = null;
    try {
      r = lobService.getProviderSpecialtiesByProvider(providerId);
      return new ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderSpecialties] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/specialties", method = RequestMethod.POST)
  @ApiOperation(value = "Used to create a new provider specialty assignment", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderSpecialty(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the Provider Specialty to be persisted", required = true) @RequestBody @Valid NewProviderSpecialty n)
      throws ApiException {
    logger.trace("[postProviderSpecialty] in", n);
    try {
      lobService.createProviderSpecialty(providerId, n);
      return new ResponseEntity<Void>(HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderSpecialty] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/documents", method = RequestMethod.GET)
  @ApiOperation(value = "Any links to documents that might be associated with the provider", notes = "", response = Document.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Document.class, responseContainer = "List") })
  public ResponseEntity<List<Document>> getProviderDocuments(@ApiParam @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[getProviderDocuments] in", providerId);
    List<Document> r = null;
    try {
      r = lobService.getDocumentControlsByProvider(providerId);
      return new ResponseEntity<List<Document>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderDocuments] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/documents", method = RequestMethod.POST)
  @ApiOperation(value = "Adds a new reference to a document for a provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderDocument(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the Provider document to be persisted", required = true) @RequestBody @Valid NewDocument n)
      throws ApiException {
    logger.trace("[postProviderDocument] in", n);
    try {
      Document r = lobService.createProviderDocument(providerId, n);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderDocument] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/disciplinaryActions", method = RequestMethod.GET)
  @ApiOperation(value = "Any disciplinary actions that have been applied to the provider", notes = "", response = com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction.class, responseContainer = "List") })
  public ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction>> getProviderDisciplinaryActions(
      @ApiParam @PathVariable("provider-id") Long providerId) throws ApiException {
    logger.trace("[getProviderDisciplinaryActions] in", providerId);
    List<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction> r = null;
    try {
      r = lobService.getDisciplinaryActionsByProvider(providerId);
      return new ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderDisciplinaryActions] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/disciplinaryActions", method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new disciplinary action record for this provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderDisciplinaryAction(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the Provider Disciplinary Action to be persisted", required = true) @RequestBody @Valid NewDisciplinaryAction n)
      throws ApiException {
    logger.trace("[postProviderDisciplinaryAction] in", n);
    try {
      DisciplinaryAction r = lobService.createProviderDisciplinaryAction(providerId, n);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderDisciplinaryAction] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/licenses", method = RequestMethod.GET)
  @ApiOperation(value = "Any provider licenses associated with the provider", notes = "", response = License.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = License.class, responseContainer = "List") })
  public ResponseEntity<List<License>> getProviderLicenses(@ApiParam @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[getProviderLicenses] in", providerId);
    List<License> r = null;
    try {
      r = lobService.getLicensesByProvider(providerId);
      return new ResponseEntity<List<License>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderLicenses] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/licenses", method = RequestMethod.POST)
  @ApiOperation(value = "Adds a license for this provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderLicense(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the Provider License to be persisted", required = true) @RequestBody @Valid NewLicense n)
      throws ApiException {
    logger.trace("[postProviderLicense] in", n);
    try {
      License r = lobService.createProviderLicense(providerId, n);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderLicense] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/medicaid", method = RequestMethod.GET)
  @ApiOperation(value = "Returns any medicaid details that may be associated  with the provider", notes = "", response = Medicaid.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Medicaid.class, responseContainer = "List") })
  public ResponseEntity<List<Medicaid>> getProviderMedicaids(@ApiParam @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[getProviderMedicaids] in", providerId);
    List<Medicaid> r = null;
    try {
      r = lobService.getMedicaidsByProvider(providerId);
      return new ResponseEntity<List<Medicaid>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderMedicaids] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/medicaid", method = RequestMethod.POST)
  @ApiOperation(value = "Adds the medicaid number for provider within a state", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderMedicaid(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the Provider medicaid to be persisted", required = true) @RequestBody @Valid Medicaid n)
      throws ApiException {
    logger.trace("[postProviderMedicaid] in", n);
    try {

      lobService.createProviderMedicaid(providerId, n);
      return new ResponseEntity<Void>(HttpStatus.CREATED);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderMedicaid] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/focusReviews", method = RequestMethod.GET)
  @ApiOperation(value = "Returns any focus reviews associated with the provider", notes = "", response = ProviderFocusReview.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = ProviderFocusReview.class, responseContainer = "List") })
  public ResponseEntity<List<ProviderFocusReview>> getProviderFocusReviews(
      @ApiParam @PathVariable("provider-id") Long providerId) throws ApiException {
    logger.trace("[getProviderFocusReviews] in", providerId);
    List<ProviderFocusReview> r = null;
    try {
      r = lobService.getProviderFocusReviewsByProviderId(providerId);
      return new ResponseEntity<List<ProviderFocusReview>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderFocusReviews] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}/focusReviews", method = RequestMethod.POST)
  @ApiOperation(value = "Adds the details of a focus review for this provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postProviderFocusReview(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "the FocusReview to be persisted", required = true) @RequestBody @Valid NewProviderFocusReview n)
      throws ApiException {
    logger.trace("[postProviderFocusReview] in", n);
    try {
      ProviderFocusReview r = lobService.postProviderFocusReview(providerId, n);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProviderFocusReview] out");
    }

  }

  @RequestMapping(value = "/{provider-id}/focusReviews/{focus-review-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to alter the focus review details", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchProviderFocusReview(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "Uniquely identifies a focus review instance") @PathVariable("focus-review-id") Long id,
      @ApiParam(value = "the focus review properties to patch the existent one", required = true) @RequestBody @Valid Map<String, Object> properties)
      throws ApiException {

    logger.trace("[patchProviderFocusReview] in", providerId, id, properties);
    try {
      lobService.patchProviderFocusReview(providerId, id, properties);
      return new ResponseEntity<Void>(HttpStatus.OK);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchProviderFocusReview] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/focusReviews/{focus-review-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently archives the focus review record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteProviderFocusReview(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "Uniquely identifies a focus review instance") @PathVariable("focus-review-id") Long id)
      throws ApiException {
    logger.trace("[deleteProviderFocusReview] in", providerId, id);
    try {
      lobService.deleteProviderFocusReview(providerId, id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteProviderFocusReview] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/medicaid/{medicaid-number}", method = RequestMethod.PUT)
  @ApiOperation(value = "Used to change the assigned medicaid number", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class) })
  public ResponseEntity<Void> putProviderMedicaid(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "Selects this medicaid for this Provider") @PathVariable("medicaid-number") String medicaidNumber,
      @ApiParam(value = "the medicaid to update the existent one", required = true) @RequestBody @Valid Medicaid medicaid)
      throws ApiException {

    logger.trace("[putProviderMedicaid] in", providerId, medicaidNumber, medicaid);
    try {
      if (medicaidNumber.equals(medicaid.getNumber()))
        throw new IllegalArgumentException("medicaid number equals path variable !");

      lobService.putProviderMedicaid(providerId, medicaidNumber, medicaid);
      return new ResponseEntity<Void>(HttpStatus.OK);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[putProviderMedicaid] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/medicaid/{medicaid-number}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Used to permanently remove this medicaid number for this provider. The relationship is archived.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteProviderMedicaid(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "uniquely identifies the assigned medicaid number") @PathVariable("medicaid-number") String medicaidNumber)
      throws ApiException {
    logger.trace("[deleteProviderMedicaid] in", providerId, medicaidNumber);
    try {
      lobService.deleteProviderMedicaid(providerId, medicaidNumber);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteProviderMedicaid] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/licenses/{license-number}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to term a relationship", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchProviderLicense(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "Selects this License for this Provider") @PathVariable("license-number") String licenseNumber,
      @ApiParam(value = "the license properties to patch the existent one", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchProviderLicense] in", providerId, licenseNumber, changes);
    try {
      lobService.patchProviderLicense(providerId, licenseNumber, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchProviderLicense] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/licenses/{license-number}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Used to archive the relationship for a provider to this license. This is not terminating the relationship, but a permanent removal.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteProviderLicense(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "Selects this License for this Provider") @PathVariable("license-number") String licenseNumber)
      throws ApiException {
    logger.trace("[deleteProviderLicense] in", providerId, licenseNumber);
    try {
      lobService.deleteProviderLicense(providerId, licenseNumber);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteProviderLicense] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/disciplinaryActions/{disciplinary-action-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "allows a disciplinary action to be termed", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchDisciplinaryAction(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam(value = "Uniquely identifies this disciplanry action instance") @PathVariable("disciplinary-action-id") Long daId,
      @ApiParam(value = "the disciplinary action properties to patch the existent one", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchDisciplinaryAction] in", providerId, daId, changes);
    try {
      lobService.patchDisciplinaryAction(providerId, daId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchDisciplinaryAction] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/disciplinaryActions/{disciplinary-action-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Archives any reference to this disciplinary action record for this provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteDisciplinaryAction(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("disciplinary-action-id") Long disciplinaryActionId) throws ApiException {
    logger.trace("[deleteDisciplinaryAction] in", providerId, disciplinaryActionId);
    try {
      lobService.deleteDisciplinaryAction(providerId, disciplinaryActionId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteDisciplinaryAction] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/documents/{document-control-number}", method = RequestMethod.DELETE)
  @ApiOperation(value = "used to remove a reference to a document for this provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteProviderDocument(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("document-control-number") Long dcnId) throws ApiException {
    logger.trace("[deleteProviderDocument] in", providerId, dcnId);
    try {
      lobService.deleteProviderDocument(providerId, dcnId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteProviderDocument] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/specialties/{specialty-code}", method = RequestMethod.DELETE)
  @ApiOperation(value = "removes this specialty instance from the provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteProviderSpecialty(@ApiParam @PathVariable("provider-id") Long providerId,
      @ApiParam @PathVariable("specialty-code") String specialtyCode) throws ApiException {
    logger.trace("[deleteProviderSpecialty] in", providerId, specialtyCode);
    try {
      lobService.deleteProviderSpecialty(providerId, specialtyCode);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteProviderSpecialty] out");
    }
  }

  @RequestMapping(value = "/{provider-id}/networks", method = RequestMethod.GET)
  @ApiOperation(value = "Retrieves any network associations the provider has had", notes = "", response = RelatedNetwork.class, responseContainer = "Set")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedNetwork.class, responseContainer = "Set"),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Set<RelatedNetwork>> getProviderNetworks(@ApiParam @PathVariable("provider-id") Long providerId)
      throws ApiException {
    logger.trace("[getProviderNetworks] in", providerId);
    Set<RelatedNetwork> result = null;
    try {
      result = lobService.getProviderRelatedNetworks(providerId);
      return new ResponseEntity<Set<RelatedNetwork>>(result, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviderNetworks] out", result);
    }
  }

  @RequestMapping(value = "/{provider-id}", method = RequestMethod.GET)
  @ApiOperation(value = "Uniquely identifies the provider instance", notes = "", response = com.anthem.specialty.provider.datamodel.dto.ProviderImpl.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = com.anthem.specialty.provider.datamodel.dto.ProviderImpl.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<com.anthem.specialty.provider.datamodel.dto.Provider> getProvider(
      @ApiParam @PathVariable("provider-id") Long providerId) throws ApiException {
    logger.trace("[getProvider] in", providerId);
    com.anthem.specialty.provider.datamodel.dto.Provider r = null;
    try {
      r = lobService.getProvider(providerId);
      return new ResponseEntity<com.anthem.specialty.provider.datamodel.dto.Provider>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProvider] out", r);
    }
  }

  @RequestMapping(value = "/{provider-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a provider", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchProvider(@ApiParam @PathVariable("provider-id") Long id,
      @ApiParam(value = "the Provider properties to patch the existent one", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchProvider] in", id, changes);
    try {
      lobService.patchProvider(id, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchProvider] out");
    }
  }

  @RequestMapping(method = RequestMethod.POST)
  @ApiOperation(value = "Used to persist a provider", notes = "", response = Void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = Void.class),
      @ApiResponse(code = 422, message = "validation failure", response = Void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = Void.class) })
  public ResponseEntity<Void> postProvider(
      @ApiParam(value = "the Provider to be persisted", required = true) @RequestBody @Valid NewProvider provider)
      throws ApiException {
    logger.trace("[postProvider] in", provider);
    try {
      SimpleProvider r = lobService.createNewProvider(provider);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", dataEntityLocationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postProvider] out");
    }

  }

  @RequestMapping(method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for matching providers", notes = "", response = SimpleProvider.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = SimpleProvider.class, responseContainer = "List") })
  public ResponseEntity<List<SimpleProvider>> getProviders(
      @ApiParam(value = "first name value that need to be considered for filter", required = false) @RequestParam(name = "firstName", required = false) String firstName,
      @ApiParam(value = "last name value that need to be considered for filter", required = false) @RequestParam(name = "lastName", required = false) String lastName,
      @ApiParam(value = "optional query param: pageIndex", required = false) @RequestParam(required = false, defaultValue = "0") Integer pageIndex,
      @ApiParam(value = "optional query param: pageSize", required = false) @RequestParam(required = false, defaultValue = "0") Integer pageSize)
      throws ApiException {
    logger.trace("[getProviders] in", firstName, lastName, pageIndex, pageSize);
    Page<SimpleProvider> page = null;

    try {

      pageSize = pageSize <= 0 ? (int) config.getQuery().get("maxrows") : pageSize;

      page = lobService.getSimpleProviders(firstName, lastName, pageIndex, pageSize);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .with("X-Total-Count", Long.toString(page.getTotalElements())).build();

      return new ResponseEntity<List<SimpleProvider>>(page.getContent(), header, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getProviders] out");
    }
  }

}
