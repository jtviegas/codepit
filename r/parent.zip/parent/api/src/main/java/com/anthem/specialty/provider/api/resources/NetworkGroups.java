package com.anthem.specialty.provider.api.resources;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.api.util.HeaderMapBuilder;
import com.anthem.specialty.provider.datalayer.functional.LinkResolver;
import com.anthem.specialty.provider.datalayer.functional.NetworkGroupToNetworkGroupDto;
import com.anthem.specialty.provider.datalayer.functional.NewNetworkGroupToNetworkGroup;
import com.anthem.specialty.provider.datalayer.repositories.core.DataOwnerRepository;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.NetworkGroup;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkGroup;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api/networkGroups")
@Api(tags = { "networks" }, value = "Operates on the list of network groups for the line of business.")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class) })
public class NetworkGroups {
  private static final Logger logger = LoggerFactory.getLogger(NetworkGroups.class);

  private final LobService lobService;

  private NetworkGroupToNetworkGroupDto networkGroupToNetworkGroupDto;

  private NewNetworkGroupToNetworkGroup networkGroupDtoToNetworkGroup;

  public NetworkGroups(@Autowired LobService lobService, @Autowired Config config,
      @Autowired DataOwnerRepository dataOwnerRepository) {
    this.lobService = lobService;
    this.networkGroupToNetworkGroupDto = new NetworkGroupToNetworkGroupDto(new LinkResolver());
    this.networkGroupDtoToNetworkGroup = new NewNetworkGroupToNetworkGroup(dataOwnerRepository);
  }

  @RequestMapping(method = RequestMethod.GET)
  @ApiOperation(value = "Returns a list of all network groups for the line of business.", notes = "", response = NewNetworkGroup.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = NewNetworkGroup.class, responseContainer = "List") })
  @Transactional(rollbackFor = Exception.class)
  public ResponseEntity<List<NetworkGroup>> getNetworkGroups() throws ApiException {
    try {
      List<NetworkGroup> ret = lobService.getNetworkGroups();
      return new ResponseEntity<List<NetworkGroup>>(ret, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    }
  }

  @RequestMapping(method = RequestMethod.POST)
  @ApiOperation(value = "creates a new instance of a network group for the current line of business.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class, responseContainer = "List") })
  @Transactional(rollbackFor = Exception.class)
  public ResponseEntity<Void> postNetworkGroup(
      @ApiParam(required = true, value = "new network group") @RequestBody @Valid NewNetworkGroup ng)
      throws ApiException {
    try {
      com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup ret = lobService
          .setNetworkGroup(networkGroupDtoToNetworkGroup.apply(ng));
      NetworkGroup r = networkGroupToNetworkGroupDto.apply(ret);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .with("Location", LinkResolver
              .createLink(new String[] { r.getId().toString() }, LinkResolver.Type.networkgroup, true).getHref())
          .build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (Exception e) {
      throw new ApiException(e);
    }
  }

  @RequestMapping(method = RequestMethod.GET, value = "/{network-group-id}")
  @ApiOperation(value = "Returns a network group for the line of business.", notes = "", response = NetworkGroup.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = NetworkGroup.class) })
  @Transactional(rollbackFor = Exception.class)
  public ResponseEntity<NetworkGroup> getNetworkGroup(@ApiParam @PathVariable("network-group-id") Long networkGroupId)
      throws ApiException {
    try {
      com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup ret = lobService.getNetworkGroup(networkGroupId);
      return new ResponseEntity<NetworkGroup>(networkGroupToNetworkGroupDto.apply(ret), HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    }
  }

  @RequestMapping(method = RequestMethod.DELETE, value = "/{network-group-id}")
  @ApiOperation(value = "Deletes a network group for the line of business.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class) })
  @Transactional(rollbackFor = Exception.class)
  public ResponseEntity<Void> deleteNetworkGroup(@ApiParam @PathVariable("network-group-id") Long networkGroupId)
      throws ApiException {
    try {
      lobService.deleteNetworkGroup(networkGroupId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    }
  }

}
