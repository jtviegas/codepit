package com.anthem.specialty.provider.api.resources;

import static java.lang.String.format;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.NotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.api.exceptions.ApiException;
import com.anthem.specialty.provider.api.util.HeaderMapBuilder;
import com.anthem.specialty.provider.datalayer.exceptions.DataIntegrityException;
import com.anthem.specialty.provider.datalayer.exceptions.DataValidationException;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.LinkLocationResolver;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.Address;
import com.anthem.specialty.provider.datamodel.dto.AddressImpl;
import com.anthem.specialty.provider.datamodel.dto.Clinic;
import com.anthem.specialty.provider.datamodel.dto.ClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.ClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.ClinicMatch;
import com.anthem.specialty.provider.datamodel.dto.HttpStatusResponse;
import com.anthem.specialty.provider.datamodel.dto.HttpStatusResponseImpl;
import com.anthem.specialty.provider.datamodel.dto.HttpStatusResponseWithMatches;
import com.anthem.specialty.provider.datamodel.dto.HttpStatusResponseWithMatchesImpl;
import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.NewAddressImpl;
import com.anthem.specialty.provider.datamodel.dto.NewClinic;
import com.anthem.specialty.provider.datamodel.dto.NewClinicCredentialsImpl;
import com.anthem.specialty.provider.datamodel.dto.NewClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewLanguageImpl;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContactImpl;
import com.anthem.specialty.provider.datamodel.dto.NewW9EffectiveRelationshipImpl;
import com.anthem.specialty.provider.datamodel.dto.PhoneContact;
import com.anthem.specialty.provider.datamodel.dto.RelatedW9;
import com.anthem.specialty.provider.datamodel.dto.SimpleClinic;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ResponseHeader;

@RestController
@RequestMapping(value = "/api/clinics")
@Api(tags = { "clinics" }, value = "API root for clinic related functions")
@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid status value", response = void.class),
    @ApiResponse(code = 500, message = "Internal server error", response = void.class) })
public class Clinics {
  private static final Logger logger = LoggerFactory.getLogger(Clinics.class);

  private final LobService lobService;

  private final Config config;

  private final LinkLocationResolver locationResolver;

  public Clinics(@Autowired LobService lobService, @Autowired Config config) {
    this.locationResolver = new LinkLocationResolver();
    this.lobService = lobService;
    this.config = config;
  }

  @RequestMapping(value = "/match", method = RequestMethod.POST)
  @ApiOperation(value = "An endpoint used to check for the presence of an existing property matching the clinic properties int the message.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "No Matching Clinic", response = void.class, responseHeaders = {
          @ResponseHeader(name = "info", response = String.class, description = "description of what happened") }),
      @ApiResponse(code = 409, message = "Item Already Exists", response = void.class, responseHeaders = {
          @ResponseHeader(name = "matches", response = String.class, description = "one clinic id or multiple clinic id's joined by a comma"),
          @ResponseHeader(name = "info", response = String.class, description = "description of what happened") }) })
  public ResponseEntity<?> postClinicMatch(
      @ApiParam(value = "the Clinic Match to use in the query", required = true) @Valid @RequestBody ClinicMatch o)
      throws ApiException {
    logger.trace("[postClinicMatch] in", o);
    try {
      List<SimpleClinic> matches = lobService.doClinicMatch(o);

      // TODO: return json error in body rather than header
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json").build();
      ResponseEntity<?> response = null;

      if (matches.isEmpty()) {
        HttpStatusResponse status = new HttpStatusResponseImpl(HttpStatus.NOT_FOUND.value(), "No Matching Clinic");
        response = new ResponseEntity<HttpStatusResponse>(status, header, HttpStatus.NOT_FOUND);
      } else {
        HttpStatusResponseWithMatches status = new HttpStatusResponseWithMatchesImpl(HttpStatus.CONFLICT.value(),
            "Item Already Exists", matches);
        response = new ResponseEntity<HttpStatusResponseWithMatches>(status, header, HttpStatus.CONFLICT);
      }

      return response;

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicMatch] out");
    }

  }

  private String json(ObjectMapper mapper, Object o) {
    try {
      return mapper.writeValueAsString(o);
    } catch (JsonProcessingException e) {
      logger.error("Error convernting to json: " + o, e);
    }
    return null;
  }

  @RequestMapping(value = "/{clinic-id}/addresses/{address-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to alter the clinic address details", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchClinicAddress(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("address-id") Long addressId,
      @ApiParam(value = "the clinic address properties to patch the existent one", required = true) @RequestBody Map<String, Object> properties)
      throws ApiException {

    logger.trace("[patchClinicAddress] in", clinicId, addressId, properties);
    try {
      lobService.patchClinicAddress(clinicId, addressId, properties);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchClinicAddress] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/phoneContacts/{phone-contact-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to alter the clinic phone contact details", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchClinicPhoneContact(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("phone-contact-id") Long id,
      @ApiParam(value = "the clinic phone contact properties to patch the existent one", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {

    logger.trace("[patchClinicPhoneContact] in", clinicId, id, changes);
    try {
      lobService.patchClinicPhoneContact(clinicId, id, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchClinicPhoneContact] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/credentials/{credential-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to alter the clinic credential details", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchClinicCredential(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("credential-id") Long id,
      @ApiParam(value = "the clinic credential properties to patch the existent one", required = true) @RequestBody Map<String, Object> properties)
      throws ApiException {

    logger.trace("[patchClinicCredential] in", clinicId, id, properties);
    try {
      lobService.patchClinicCredential(clinicId, id, properties);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchClinicCredential] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/focusReviews/{focus-review-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently archives the clinic focus review record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicFocusReview(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("focus-review-id") Long id) throws ApiException {
    logger.trace("[deleteClinicFocusReview] in", clinicId, id);
    try {
      lobService.deleteClinicFocusReview(clinicId, id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicFocusReview] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/focusReviews/{focus-review-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to alter the focus review details.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchClinicFocusReview(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("focus-review-id") Long id,
      @ApiParam(value = "the clinic focus review properties to patch the existent one", required = true) @RequestBody Map<String, Object> properties)
      throws ApiException {

    logger.trace("[patchClinicFocusReview] in", clinicId, id, properties);
    try {
      lobService.patchProviderFocusReview(clinicId, id, properties);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchClinicFocusReview] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/addresses/{address-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the clinic address record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicAddress(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("address-id") Long addressId) throws ApiException {
    logger.trace("[deleteClinicAddress] in", clinicId, addressId);
    try {
      lobService.deleteClinicAddress(clinicId, addressId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicAddress] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/addresses/{address-id}", method = RequestMethod.GET)
  @ApiOperation(value = "returns the details for this specific clinic address.", notes = "", response = AddressImpl.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = AddressImpl.class) })
  public ResponseEntity<Address> getClinicAddress(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("address-id") Long addressId) throws ApiException {
    logger.trace("[getClinicAddress] in", clinicId);
    try {
      Address r = lobService.getClinicAddress(addressId);
      return new ResponseEntity<Address>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicAddress] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/addresses", method = RequestMethod.POST)
  @ApiOperation(value = "Used to add a new address for the clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicAddress(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic address to be persisted", required = true) @RequestBody @Valid NewAddressImpl address)
      throws ApiException {
    logger.trace("[postClinicAddress] in", address);
    try {
      com.anthem.specialty.provider.datamodel.dto.Address r = lobService.postClinicAddress(clinicId, address);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicAddress] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/focusReviews", method = RequestMethod.POST)
  @ApiOperation(value = "Adds the details of a focus review for this clinic..", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicFocusReview(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic focus review to be persisted", required = true) @RequestBody @Valid NewClinicFocusReview o)
      throws ApiException {
    logger.trace("[postClinicFocusReview] in", o);
    try {

      ClinicFocusReview r = lobService.postClinicFocusReview(clinicId, o);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicFocusReview] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/addresses", method = RequestMethod.PUT)
  @ApiOperation(value = "Used to add a new address for the clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation, updated address", response = void.class),
      @ApiResponse(code = 201, message = "successful operation, created new address", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> putClinicAddress(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic address to be persisted", required = true) @RequestBody @Valid NewAddressImpl address)
      throws ApiException {
    logger.trace("[putClinicAddress] in", address);
    try {
      HttpStatus code = HttpStatus.OK;

      if (!lobService.hasAddress(clinicId, address.getType()))
        code = HttpStatus.CREATED;

      com.anthem.specialty.provider.datamodel.dto.Address r = lobService.putClinicAddress(clinicId, address);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();

      return new ResponseEntity<Void>(header, code);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[putClinicAddress] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/w9/{w9-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the w9 record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicW9(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("w9-id") Long id) throws ApiException {
    logger.trace("[deleteClinicW9] in", clinicId, id);
    try {
      lobService.deleteClinicW9(clinicId, id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicW9] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/languages/{language-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Removes a reference to the language for the clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicLanguage(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("language-id") Long id) throws ApiException {
    logger.trace("[deleteClinicLanguage] in", clinicId, id);
    try {
      lobService.deleteClinicLanguage(clinicId, id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicLanguage] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/phoneContacts/{phone-contact-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the phone contact record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinicPhoneContact(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam @PathVariable("phone-contact-id") Long id) throws ApiException {
    logger.trace("[deleteClinicPhoneContact] in", clinicId, id);
    try {
      lobService.deleteClinicPhoneContact(clinicId, id);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinicPhoneContact] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}/w9", method = RequestMethod.GET)
  @ApiOperation(value = "Used to list all the W9 businesses associated with this clinic.", notes = "", response = RelatedW9.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = RelatedW9.class, responseContainer = "List") })
  public ResponseEntity<List<RelatedW9>> getClinicW9s(@ApiParam @PathVariable("clinic-id") Long clinicId)
      throws ApiException {
    logger.trace("[getClinicW9s] in", clinicId);
    List<RelatedW9> r = null;
    try {
      r = lobService.getW9sFromClinic(clinicId);
      return new ResponseEntity<List<RelatedW9>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicW9s] out", r);
    }
  }

  @RequestMapping(value = "/{clinic-id}/focusReviews", method = RequestMethod.GET)
  @ApiOperation(value = "Any focus reviews associated with the clinic.", notes = "", response = ClinicFocusReview.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = ClinicFocusReview.class, responseContainer = "List") })
  public ResponseEntity<List<ClinicFocusReview>> getClinicFocusReviews(
      @ApiParam @PathVariable("clinic-id") Long clinicId) throws ApiException {
    logger.trace("[getClinicFocusReviews] in", clinicId);
    List<ClinicFocusReview> r = null;
    try {
      r = lobService.getClinicFocusReviewsByClinicId(clinicId);
      return new ResponseEntity<List<ClinicFocusReview>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicFocusReviews] out", r);
    }
  }

  @RequestMapping(value = "/{clinic-id}/w9", method = RequestMethod.POST)
  @ApiOperation(value = "Used to add a new W9 business for the clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicW9(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic W9 to be persisted", required = true) @RequestBody @Valid NewW9EffectiveRelationshipImpl o)
      throws ApiException {
    logger.trace("[postClinicW9] in", o);
    try {
      RelatedW9 r = lobService.postClinicW9(clinicId, o);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r.getW9())).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (DataIntegrityException uv) {
      throw new ApiException(uv, HttpStatus.CONFLICT);
    } catch (DataValidationException uv) {
      throw new ApiException(uv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicW9] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/credentials", method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new clinic credential record.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicCredentials(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic Credential to be persisted", required = true) @RequestBody @Valid NewClinicCredentialsImpl o)
      throws ApiException {
    logger.trace("[postClinicCredentials] in", o);
    try {
      ClinicCredentials r = lobService.postClinicClinicCredentials(clinicId, o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);
    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (DataIntegrityException uv) {
      throw new ApiException(uv, HttpStatus.CONFLICT);
    } catch (DataValidationException uv) {
      throw new ApiException(uv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicCredentials] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/languages", method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new phone contact instance for this clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicLanguage(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic Language to be persisted", required = true) @RequestBody @Valid NewLanguageImpl o)
      throws ApiException {
    logger.trace("[postClinicLanguage] in", o);
    try {

      Language r = lobService.postClinicLanguage(clinicId, o);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (DataIntegrityException uv) {
      throw new ApiException(uv, HttpStatus.CONFLICT);
    } catch (DataValidationException uv) {
      throw new ApiException(uv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicLanguage] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/languages", method = RequestMethod.GET)
  @ApiOperation(value = "lists any extra languages the clinic supports.", notes = "", response = Language.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Language.class, responseContainer = "List") })
  public ResponseEntity<List<Language>> getClinicLanguages(@ApiParam @PathVariable("clinic-id") Long clinicId)
      throws ApiException {
    logger.trace("[getClinicLanguages] in", clinicId);
    List<Language> r = null;
    try {
      r = lobService.getLanguagesFromClinic(clinicId);
      return new ResponseEntity<List<Language>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicLanguages] out", r);
    }
  }

  @RequestMapping(value = "/{clinic-id}/credentials", method = RequestMethod.GET)
  @ApiOperation(value = "list the result of every credentialling exercise for this clinic.", notes = "", response = ClinicCredentials.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = ClinicCredentials.class, responseContainer = "List") })
  public ResponseEntity<List<ClinicCredentials>> getClinicCredentials(
      @ApiParam @PathVariable("clinic-id") Long clinicId) throws ApiException {
    logger.trace("[getClinicCredentials] in", clinicId);
    List<ClinicCredentials> r = null;
    try {
      r = lobService.getCredentialsFromClinic(clinicId);
      return new ResponseEntity<List<ClinicCredentials>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicCredentials] out", r);
    }
  }

  @RequestMapping(value = "/{clinic-id}/phoneContacts", method = RequestMethod.PUT)
  @ApiOperation(value = "Used to add a new phone contact for the clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation, updated address", response = void.class),
      @ApiResponse(code = 201, message = "successful operation, created new address", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class) })
  public ResponseEntity<Void> putClinicPhoneContact(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the clinic phone contact to be persisted", required = true) @RequestBody @Valid NewPhoneContact o)
      throws ApiException {
    logger.trace("[putClinicPhoneContact] in", o);
    try {
      HttpStatus code = HttpStatus.OK;
      if (!lobService.hasClinicPhoneContact(clinicId, o.getType()))
        code = HttpStatus.CREATED;

      PhoneContact r = lobService.putClinicPhoneContact(clinicId, o);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, code);
    } catch (NoEntityFoundException nefe) { // not found
      throw new ApiException(nefe, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[putClinicPhoneContact] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/phoneContacts", method = RequestMethod.POST)
  @ApiOperation(value = "Creates a new phone contact instance for this clinic.", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinicPhoneContact(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic Phone Contact to be persisted", required = true) @RequestBody @Valid NewPhoneContactImpl o)
      throws ApiException {
    logger.trace("[postClinicPhoneContact] in", o);
    try {
      PhoneContact r = lobService.postClinicPhoneContact(clinicId, o);

      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

    } catch (NoEntityFoundException ne) {
      throw new ApiException(ne, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (DataIntegrityException uv) {
      throw new ApiException(uv, HttpStatus.CONFLICT);
    } catch (DataValidationException uv) {
      throw new ApiException(uv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinicPhoneContact] out");
    }

  }

  @RequestMapping(value = "/{clinic-id}/phoneContacts", method = RequestMethod.GET)
  @ApiOperation(value = "returns all the phone number contact details associated with this clinic.", notes = "", response = PhoneContact.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = PhoneContact.class, responseContainer = "List") })
  public ResponseEntity<List<PhoneContact>> getClinicPhoneContacts(@ApiParam @PathVariable("clinic-id") Long clinicId)
      throws ApiException {
    logger.trace("[getClinicPhoneContacts] in", clinicId);
    List<PhoneContact> r = null;
    try {
      r = lobService.getPhoneContactsFromClinic(clinicId);
      return new ResponseEntity<List<PhoneContact>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicPhoneContacts] out", r);
    }
  }

  // TODO review all this method in light of new spec
  @RequestMapping(value = "/{clinic-id}/addresses", method = RequestMethod.GET)
  @ApiOperation(value = "Returns a a list aof all of the addresses associated with this clinic.", notes = "", response = Address.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Address.class, responseContainer = "List") })
  public ResponseEntity<List<Address>> getClinicAddresses(@ApiParam @PathVariable("clinic-id") Long clinicId)
      throws ApiException {
    logger.trace("[getClinicAddresses] in", clinicId);
    List<Address> r = null;
    try {
      r = lobService.getAddressesFromClinic(clinicId);
      return new ResponseEntity<List<Address>>(r, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinicAddresses] out", r);
    }
  }

  @RequestMapping(value = "/{clinic-id}", method = RequestMethod.GET)
  @ApiOperation(value = "Uniquely identifies the clinic instance", notes = "", response = Clinic.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = Clinic.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Clinic> getClinic(@ApiParam @PathVariable("clinic-id") Long clinicId) throws ApiException {
    logger.trace("[getClinic] in", clinicId);
    Clinic r = null;
    try {
      if (null == (r = lobService.getClinicDto(clinicId)))
        throw new NotFoundException(format("no clinic found for id: %s", clinicId.toString()));

      return new ResponseEntity<Clinic>(r, HttpStatus.OK);
    } catch (NotFoundException nf) {
      throw new ApiException(nf, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getClinic] out", r);
    }
  }

  @RequestMapping(value = "/{clinic-id}", method = RequestMethod.DELETE)
  @ApiOperation(value = "Permanently deletes the clinic record", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> deleteClinic(@ApiParam @PathVariable("clinic-id") Long clinicId) throws ApiException {
    logger.trace("[deleteClinic] in", clinicId);
    try {
      lobService.deleteClinic(clinicId);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[deleteClinic] out");
    }
  }

  @RequestMapping(value = "/{clinic-id}", method = RequestMethod.PATCH)
  @ApiOperation(value = "Used to patch a clinic instance", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 404, message = "no match", response = void.class) })
  public ResponseEntity<Void> patchClinic(@ApiParam @PathVariable("clinic-id") Long clinicId,
      @ApiParam(value = "the Clinic properties to patch the existent one", required = true) @RequestBody Map<String, Object> changes)
      throws ApiException {
    logger.trace("[patchClinic] in", clinicId, changes);
    try {
      lobService.patchClinic(clinicId, changes);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (DataValidationException dv) {
      throw new ApiException(dv, HttpStatus.UNPROCESSABLE_ENTITY);
    } catch (NoEntityFoundException nef) {
      throw new ApiException(nef, HttpStatus.NOT_FOUND);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[patchClinic] out");
    }
  }

  @RequestMapping(method = RequestMethod.GET)
  @ApiOperation(value = "Used to search for matching clinics", notes = "", response = SimpleClinic.class, responseContainer = "List")
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 200, message = "successful operation", response = SimpleClinic.class, responseContainer = "List") })
  public ResponseEntity<List<SimpleClinic>> getSimpleClinics(
      @ApiParam(value = "optional query param: pageIndex", required = false) @RequestParam(required = false, defaultValue = "0") Integer pageIndex,
      @ApiParam(value = "optional query param: pageSize", required = false) @RequestParam(required = false, defaultValue = "0") Integer pageSize,
      @ApiParam(value = "optional query param: CommonName", required = false) @RequestParam(required = false) String commonName)
      throws ApiException {
    logger.trace("[getSimpleClinics] in", commonName, pageIndex, pageSize);
    List<SimpleClinic> result = null;
    try {

      pageSize = pageSize <= 0 ? (int) config.getQuery().get("maxrows") : pageSize;

      if (null != commonName)
        result = lobService.getClinics(ImmutableMap.of("CommonName", commonName), pageIndex, pageSize);
      else
        result = lobService.getClinics(pageIndex, pageSize);

      return new ResponseEntity<List<SimpleClinic>>(result, HttpStatus.OK);
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[getSimpleClinics] out", result);
    }
  }

  @RequestMapping(method = RequestMethod.POST)
  @ApiOperation(value = "Used to persist a clinic", notes = "", response = void.class)
  @io.swagger.annotations.ApiResponses(value = {
      @ApiResponse(code = 201, message = "successful operation", response = void.class),
      @ApiResponse(code = 422, message = "validation failure", response = void.class),
      @ApiResponse(code = 409, message = "uniqueness violation", response = void.class) })
  public ResponseEntity<Void> postClinic(
      @ApiParam(value = "the Clinic to be persisted", required = true) @RequestBody @Valid NewClinic clinic)
      throws ApiException {
    logger.trace("[postClinic] in", clinic);
    try {
      Clinic r = lobService.setClinicAndGetDto(clinic);
      MultiValueMap<String, String> header = HeaderMapBuilder.create().with("Content-Type", "application/json")
          .withProbably("Location", locationResolver.apply(r)).build();
      return new ResponseEntity<Void>(header, HttpStatus.CREATED);

      // TODO
      /*
       * } catch (DataValidationException dve) { throw new ApiException(dve, HttpStatus.UNPROCESSABLE_ENTITY);
       * 
       * } catch (UniquenessViolationException uv) { throw new ApiException(uv, HttpStatus.CONFLICT);
       */
    } catch (Exception e) {
      throw new ApiException(e);
    } finally {
      logger.trace("[postClinic] out");
    }

  }

}
