package com.anthem.specialty.provider.api.config;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSourceConfig {

  @Bean
  @ConfigurationProperties(prefix = "spring.multitenancy.datasource1")
  public DataSourceProperties dataSource1Properties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = "spring.multitenancy.datasource2")
  public DataSourceProperties dataSource2Properties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = "spring.multitenancy.datasource3")
  public DataSourceProperties dataSource3Properties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = "spring.multitenancy.datasource4")
  public DataSourceProperties dataSource4Properties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = "spring.multitenancy.datasource5")
  public DataSourceProperties dataSource5Properties() {
    return new DataSourceProperties();
  }

  @Bean(name = { "dataSource", "dataSource1" })
  public DataSource dataSource1() {
    return dataSource1Properties().initializeDataSourceBuilder().build();
  }

  @Bean(name = "dataSource2")
  public DataSource dataSource2() {
    return dataSource2Properties().initializeDataSourceBuilder().build();
  }

  @Bean(name = "dataSource3")
  public DataSource dataSource3() {
    return dataSource3Properties().initializeDataSourceBuilder().build();
  }

  @Bean(name = "dataSource4")
  public DataSource dataSource4() {
    return dataSource4Properties().initializeDataSourceBuilder().build();
  }

  @Bean(name = "dataSource5")
  public DataSource dataSource5() {
    return dataSource5Properties().initializeDataSourceBuilder().build();
  }

}
