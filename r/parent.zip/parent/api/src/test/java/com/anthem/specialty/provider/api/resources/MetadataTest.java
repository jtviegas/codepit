package com.anthem.specialty.provider.api.resources;

import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datamodel.dto.Link;
import com.anthem.specialty.provider.datamodel.schemas.core.BusinessSegment;
import com.anthem.specialty.provider.datamodel.schemas.core.DataOwner;
import com.anthem.specialty.provider.datamodel.schemas.core.DentalProcedure;
import com.anthem.specialty.provider.datamodel.schemas.core.Language;
import com.anthem.specialty.provider.datamodel.dto.LargeGroup;
import com.anthem.specialty.provider.datamodel.schemas.core.Specialty;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;

@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MetadataTest extends BaseTest {

  @Test
  public void test_00_getMetadata() {

    Set<Link> links = restTemplate.exchange(properties.getUri("/api/metadata"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<Set<Link>>() {
        }).getBody();
    Assert.assertFalse(links.isEmpty());
  }

  @Test
  public void test_01_getTerminationLevels() {

    List<TerminationLevel> os = restTemplate.exchange(properties.getUri("/api/metadata/terminationLevels"),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<TerminationLevel>>() {
        }).getBody();
    Assert.assertFalse(os.isEmpty());
  }

  @Test
  public void test_02_getDataOwners() {

    List<DataOwner> os = restTemplate.exchange(properties.getUri("/api/metadata/dataOwners"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<DataOwner>>() {
        }).getBody();

    Assert.assertFalse(os.isEmpty());

  }

  @Test
  public void test_03_getDataOwner() {

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/metadata/dataOwners"))
        .path("/{data-owner-id}").buildAndExpand(new Long(1));
    ResponseEntity<DataOwner> r = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), DataOwner.class);

    Assert.assertNotNull(r.getBody());

  }

  @Test
  public void test_04_getTenants() {

    List<DataOwner> os = restTemplate.exchange(properties.getUri("/api/metadata/tenants"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<DataOwner>>() {
        }).getBody();

    Assert.assertFalse(os.isEmpty());

  }

  @Test
  public void test_05_getTenant() {

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/metadata/tenants"))
        .path("/{tenant-id}").buildAndExpand(new Long(1));
    ResponseEntity<DataOwner> r = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), DataOwner.class);

    Assert.assertNotNull(r.getBody());

  }

  @Test
  public void test_06_getSpecialties() {

    List<Specialty> os = restTemplate.exchange(properties.getUri("/api/metadata/specialties"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<Specialty>>() {
        }).getBody();

    Assert.assertFalse(os.isEmpty());

  }

  @Test
  public void test_07_getProcedureCodes() {

    List<DentalProcedure> os = restTemplate.exchange(properties.getUri("/api/metadata/procedureCodes"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<DentalProcedure>>() {
        }).getBody();

    Assert.assertFalse(os.isEmpty());

  }

  @Test
  public void test_08_getLanguages() {

    List<Language> os = restTemplate.exchange(properties.getUri("/api/metadata/languages"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<Language>>() {
        }).getBody();

    Assert.assertFalse(os.isEmpty());

  }

  @Test
  public void test_09_getBusinessSegments() {

    List<BusinessSegment> os = restTemplate.exchange(properties.getUri("/api/metadata/businessSegments"),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<BusinessSegment>>() {
        }).getBody();

    Assert.assertFalse(os.isEmpty());

  }

  @Test
  public void test_10_getLargeGroups() {
    HttpEntity<Object> entity = new HttpEntity<>(getHeaders());
    ParameterizedTypeReference<List<LargeGroup>> typeRef =  new ParameterizedTypeReference<List<LargeGroup>>(){};
    String url = properties.getUri("/api/metadata/largeGroups");
    List<LargeGroup> os = restTemplate.exchange( url, HttpMethod.GET, entity, typeRef).getBody();

    Assert.assertFalse(os.isEmpty());

  }

}
