package com.anthem.specialty.provider.api.resources;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datamodel.dto.NetworkGroup;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkGroup;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkGroupImpl;

@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworkGroupsTest extends BaseTest {
  public static String NETWORK_GROUP_DESCRIPTION = "A description of a network group";

  @Parameter
  public String schemaParameter;

  @Parameters
  public static Collection<String> data() {
    Collection<String> params = new ArrayList<>();
    // params.add("horizon");
    // params.add("wellmark");
    params.add(null);
    return params;
  }

  @Test
  public void testCRUD() {
    // Create
    NewNetworkGroup o = new NewNetworkGroupImpl();
    o.setDescription(NETWORK_GROUP_DESCRIPTION);
    // create - fail validation
    try {
      ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/networkGroups"), HttpMethod.POST,
          new HttpEntity<NewNetworkGroup>(o, getHeaders()), Void.class);
    } catch (HttpClientErrorException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    // create regular
    o.setDataOwnerId(getDataOwner(null).getId());
    ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/networkGroups"), HttpMethod.POST,
        new HttpEntity<NewNetworkGroup>(o, getHeaders()), Void.class);
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertNotNull(id);

    // Read one
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networkGroups"))
        .path("/{network-group-id}").buildAndExpand(id);
    ResponseEntity<NetworkGroup> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Long>(id, getHeaders()), NetworkGroup.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(NETWORK_GROUP_DESCRIPTION, rGet.getBody().getDescription());
    Assert.assertEquals(id, rGet.getBody().getId());

    // Read all
    ResponseEntity<List<NetworkGroup>> rGetAll = restTemplate.exchange(properties.getUri("/api/networkGroups"),
        HttpMethod.GET, new HttpEntity<Void>(getHeaders()), new ParameterizedTypeReference<List<NetworkGroup>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGetAll.getStatusCode());
    Assert.assertNotNull(rGetAll.getBody());
    Assert.assertNotEquals(0, rGetAll.getBody().size());
    Long found = null;
    for (NetworkGroup ng : rGetAll.getBody()) {
      if (ng.getId().equals(id)) {
        found = ng.getId();
        break;
      }
    }
    Assert.assertNotNull("Get did not return created object", found);

    // Update - not implemented

    // Delete
    ResponseEntity<Void> rDelete = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Long>(id, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDelete.getStatusCode());

    // verify deletion
    try {
      rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
          new HttpEntity<Long>(id, getHeaders()), NetworkGroup.class);
    } catch (HttpClientErrorException hcee) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, hcee.getStatusCode());
    }
  }
}
