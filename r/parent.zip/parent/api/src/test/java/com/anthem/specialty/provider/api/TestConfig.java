package com.anthem.specialty.provider.api;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Import(com.anthem.specialty.provider.common.Bootstrap.class)
@Configuration
@EnableConfigurationProperties(TestProperties.class)
public class TestConfig {
}
