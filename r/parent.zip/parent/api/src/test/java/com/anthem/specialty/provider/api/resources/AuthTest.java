package com.anthem.specialty.provider.api.resources;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;

@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AuthTest extends BaseTest {

  @Test
  public void test_AuthFailed() {

    try {
      UriComponents uriComponents = UriComponentsBuilder
          .fromHttpUrl(properties.getUri("/api/export/directoryVerification/providers")).queryParam("largeGroupId", "1")
          .build();
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
          new HttpEntity<Object>(getHeaders(false, false)), Void.class);
      Assert.fail();
    } catch (HttpClientErrorException e) {
      Assert.assertEquals(HttpStatus.UNAUTHORIZED, e.getStatusCode());
    }

  }

}
