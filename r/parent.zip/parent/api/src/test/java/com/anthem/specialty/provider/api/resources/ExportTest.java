package com.anthem.specialty.provider.api.resources;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datamodel.dto.verification.provider.ProviderVerificationElementImpl;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ExportTest extends BaseTest {

  // @Test
  public void test_providerDirectoryAccuracy() {

    ResponseEntity<List<ProviderVerificationElementImpl>> r = restTemplate.exchange(
        properties.getUri("/api/export/directoryVerification/providers"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<ProviderVerificationElementImpl>>() {
        });
    Assert.assertTrue(0 <= r.getBody().size());

  }

  @Test
  public void test_providerDirectoryAccuracy_paramLg() {

    UriComponents uriComponents = UriComponentsBuilder
        .fromHttpUrl(properties.getUri("/api/export/directoryVerification/providers")).queryParam("largeGroupId", "1")
        .build();

    ResponseEntity<List<ProviderVerificationElementImpl>> r = restTemplate.exchange(uriComponents.encode().toUri(),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()),
        new ParameterizedTypeReference<List<ProviderVerificationElementImpl>>() {
        });
    Assert.assertTrue(0 <= r.getBody().size());

  }

  @Test
  public void test_providerDirectoryAccuracy_paramN() {

    UriComponents uriComponents = UriComponentsBuilder
        .fromHttpUrl(properties.getUri("/api/export/directoryVerification/providers")).queryParam("networkId", "600")
        .build();

    ResponseEntity<List<ProviderVerificationElementImpl>> r = restTemplate.exchange(uriComponents.encode().toUri(),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()),
        new ParameterizedTypeReference<List<ProviderVerificationElementImpl>>() {
        });
    Assert.assertTrue(0 <= r.getBody().size());

  }

  // @Test
  public void test_clinicDirectoryAccuracy() {

    ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElementImpl>> r = restTemplate
        .exchange(properties.getUri("/api/export/directoryVerification/clinics"), HttpMethod.GET,
            new HttpEntity<Object>(getHeaders()),
            new ParameterizedTypeReference<List<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElementImpl>>() {
            });
    Assert.assertTrue(0 <= r.getBody().size());
  }

  @Test
  public void test_clinicDirectoryAccuracy_paramLg() {

    UriComponents uriComponents = UriComponentsBuilder
        .fromHttpUrl(properties.getUri("/api/export/directoryVerification/clinics")).queryParam("largeGroupId", "1")
        .build();

    ResponseEntity<List<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElementImpl>> r = restTemplate
        .exchange(uriComponents.encode().toUri(), HttpMethod.GET, new HttpEntity<Object>(getHeaders()),
            new ParameterizedTypeReference<List<com.anthem.specialty.provider.datamodel.dto.verification.clinic.ClinicVerificationElementImpl>>() {
            });
    Assert.assertTrue(0 <= r.getBody().size());

  }

  // ensure that API matches JSON example
  @Test
  public void testExample() throws JsonParseException, JsonMappingException, IOException {
    String fileName = "../../raml/examples/providerDirectoryVerification.json";
    File file = new File(fileName);
    Assert.assertTrue(file.exists());
    List<ProviderVerificationElementImpl> list = jsonMapper.readValue(file,
        new TypeReference<List<ProviderVerificationElementImpl>>() {
        });
    Assert.assertNotNull(list);
    // have to recreate mapper, some other test seems to reconfigure it!
    // we don't want EffectiveDate.from = null printed
    jsonMapper = new ObjectMapper().registerModule(new ParameterNamesModule()).registerModule(new Jdk8Module())
        .registerModule(new JavaTimeModule());
    // exclude nulls and empty arrays from serialisation - example does not contain them
    jsonMapper.setSerializationInclusion(Include.NON_NULL);
    jsonMapper.setSerializationInclusion(Include.NON_EMPTY);
    // and converted object must match whatever we read from example file
    List<?> objectList = jsonMapper.readValue(jsonMapper.writeValueAsString(list), List.class);
    List<?> fileList = jsonMapper.readValue(file, List.class);
    Assert.assertEquals(fileList, objectList);
  }
}
