package com.anthem.specialty.provider.api.resources;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.dto.Carrier;
import com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.CarrierPhoneContactType;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.NewCarrier;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierEffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewNetwork;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.testutils.UtilsPopulate;
import com.fasterxml.jackson.core.type.TypeReference;

@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CarriersTest extends BaseTest {

  @Parameter
  public String schemaParameter;

  @Parameters
  public static Collection<String> data() {
    Collection<String> params = new ArrayList<>();
    // params.add("horizon");
    // params.add("wellmark");
    params.add(null);
    return params;
  }

  private void deleteNetwork(Long id) throws NoEntityFoundException {
    lobService.deleteNetwork(id);
  }

  private HttpStatus deleteNetworkCarrier(Long networkId, Long nwCarrierId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers/{carrier-id}").buildAndExpand(networkId, nwCarrierId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private ResponseEntity<Void> postNewNetworkCarrier(Long networkId, NewCarrierEffectiveRelationship o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers").buildAndExpand(networkId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewCarrierEffectiveRelationship>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetworkCarrier(Long networkId, NewCarrierEffectiveRelationship o) {
    ResponseEntity<Void> rPost = postNewNetworkCarrier(networkId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> postNewNetwork(NewNetwork o) {
    /* NewNetwork o = UtilsPopulate.newNewNetwork(getDataOwner().getId()); */
    return restTemplate.exchange(properties.getUri("/api/networks"), HttpMethod.POST,
        new HttpEntity<NewNetwork>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetwork(Long dataOwnerId) {
    ResponseEntity<Void> rPost = postNewNetwork(UtilsPopulate.newNewNetwork(dataOwnerId));
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private DataOwner getDataOwner() {
    ResponseEntity<List<DataOwner>> r = restTemplate.exchange(properties.getUri("/api/metadata/dataOwners"),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders(schemaParameter)),
        new ParameterizedTypeReference<List<DataOwner>>() {
        });

    Assert.assertEquals("must get a dataOwner", HttpStatus.OK, r.getStatusCode());
    return r.getBody().stream().findAny().get();
  }

  private TerminationLevel getTerminationLevel() {
    ResponseEntity<List<TerminationLevel>> r = restTemplate.exchange(
        properties.getUri("/api/metadata/terminationLevels"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<TerminationLevel>>() {
        });

    Assert.assertEquals("must get a terminationLevel", HttpStatus.OK, r.getStatusCode());
    return r.getBody().stream().findAny().get();
  }

  private ResponseEntity<Void> postCarrier(NewCarrier o) {
    return restTemplate.exchange(properties.getUri("/api/carriers"), HttpMethod.POST,
        new HttpEntity<NewCarrier>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createCarrier(NewCarrier o) {
    ResponseEntity<Void> rPost = postCarrier(o);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private List<Long> createCarriers(int n) {
    List<Long> r = new ArrayList<Long>();
    Long dataOwnerId = getDataOwner().getId();
    for (int i = 0; i < n; i++) {
      ResponseEntity<Void> rPost = postCarrier(UtilsPopulate.newNewCarrier(dataOwnerId));
      String location = rPost.getHeaders().getFirst("Location");
      r.add(new Long(location.substring(location.lastIndexOf("/") + 1)));
    }
    return r;
  }

  private HttpStatus deleteCarrier(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}").buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private int getNumOfCarriers() {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .queryParam("numRows", 3).build();
    ResponseEntity<List<Carrier>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<Carrier>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertTrue(3 >= rGet.getBody().size());
    return Integer.parseInt(rGet.getHeaders().get("X-Total-Count").get(0));
  }

  private int getNumOfCarrierNetworks(Long carrierId) {
    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/networks").buildAndExpand(carrierId);
    ResponseEntity<List<RelatedNetwork>> rGet = restTemplate.exchange(u.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedNetwork>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    return rGet.getBody().size();
  }

  private int getNumOfPhoneContacts(Long carrierId) {
    return getPhoneContacts(carrierId).size();
  }

  private List<CarrierPhoneContact> getPhoneContacts(Long carrierId) {
    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts").buildAndExpand(carrierId);
    ResponseEntity<List<CarrierPhoneContact>> rGet = restTemplate.exchange(u.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<CarrierPhoneContact>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    return rGet.getBody();
  }

  private ResponseEntity<Void> postPhoneContact(Long carrierId, NewCarrierPhoneContact o) {
    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts").buildAndExpand(carrierId);
    return restTemplate.exchange(u.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewCarrierPhoneContact>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createPhoneContact(Long carrierId, NewCarrierPhoneContact o) {
    ResponseEntity<Void> rPost = postPhoneContact(carrierId, o);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private HttpStatus deletePhoneContact(Long carrierId, Long carrierPhoneContactId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts/{phone-contact-id}").buildAndExpand(carrierId, carrierPhoneContactId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private Carrier getCarrier(Long id) {
    Carrier result = null;
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .queryParam("numRows", 999999).build();
    ResponseEntity<List<Carrier>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<Carrier>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Optional<Carrier> opt = rGet.getBody().stream().filter(o -> o.getId().equals(id)).findFirst();
    if (opt.isPresent())
      result = opt.get();

    return result;
  }

  // get tests
  // - 000 - get num of objects, create object x, check num of objects is now n+1, delete object x
  // - 001 - create n+1 objects and get them with limit n, assert n, delete the n+1 objects
  @Test
  public void test_000() {

    int count = getNumOfCarriers();
    Long id = createCarrier(UtilsPopulate.newNewCarrier(getDataOwner().getId()));
    Assert.assertEquals(count + 1, getNumOfCarriers());

    deleteCarrier(id);
  }

  @Test
  public void test_000_fail() {

    int count = getNumOfCarriers();
    NewCarrier carrier = UtilsPopulate.newNewCarrier(getDataOwner().getId());
    carrier.getEffective().setFrom(null);
    try {
      Long id = createCarrier(carrier);
      deleteCarrier(id);
      Assert.fail("this should have failed");
    } catch (HttpClientErrorException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
  }

  @Test
  public void test_001() {

    int count = getNumOfCarriers();
    List<Long> cs = createCarriers(5);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .queryParam("numRows", count + 4).build();
    ResponseEntity<List<RelatedNetwork>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedNetwork>>() {
        });
    Assert.assertEquals(count + 4, rGet.getBody().size());

    for (Long i : cs)
      deleteCarrier(i);

  }

  // post tests
  // - 100 - count n Obj, create one, check n+1 and status code 201
  // - 101 - count n Obj, create z, check n+z and 201
  // - 102 - try to post invalid obj, get a 422
  // - 103 - check uniqueness constraint and get a 409
  @Test
  public void test_100() {

    int count = getNumOfCarriers();
    Long id = createCarrier(UtilsPopulate.newNewCarrier(getDataOwner().getId()));
    Assert.assertEquals(count + 1, getNumOfCarriers());

    deleteCarrier(id);
  }

  @Test
  public void test_101() {
    int n = 3;
    int count = getNumOfCarriers();
    List<Long> cs = createCarriers(n);
    Assert.assertEquals(count + n, getNumOfCarriers());
    for (Long i : cs)
      deleteCarrier(i);

  }

  @Test
  public void test_102() {

    NewCarrier o = UtilsPopulate.newNewCarrier(getDataOwner().getId());
    Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
    });
    map.put("kjhfadjkhg", 84749835);

    try {
      restTemplate.exchange(properties.getUri("/api/carriers"), HttpMethod.POST,
          new HttpEntity<Map<String, Object>>(map, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

  }

  // Caused by: java.sql.SQLIntegrityConstraintViolationException: ORA-00001: unique constraint
  // (ANTHEM.UIX_CARRIER_CLEAR) violated
  @Test
  public void test_103() {

    DataOwner dO = getDataOwner();
    NewCarrier o1 = UtilsPopulate.newNewCarrier(dO.getId());
    NewCarrier o2 = UtilsPopulate.newNewCarrier(dO.getId());
    o2.setClearCarrierNo(o1.getClearCarrierNo());

    Long id1 = createCarrier(o1);
    try {
      createCarrier(o2);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    } finally {
      deleteCarrier(id1);
    }

  }

  // delete tests
  // - 200 - create one, check n obj, delete obj, check n-1 and status code 200
  // - 201 - create z objects, check n objs, delete y obj, check n-y and status code 200, delete remaining objects
  // - 202 - try to delete invalid obj, get a 404

  @Test
  public void test_200() {
    Long id1 = createCarrier(UtilsPopulate.newNewCarrier(getDataOwner().getId()));
    int count = getNumOfCarriers();
    Assert.assertEquals(HttpStatus.OK, deleteCarrier(id1));
    Assert.assertEquals(count - 1, getNumOfCarriers());
  }

  @Test
  public void test_201() {
    int n = 8, n2 = 3;

    List<Long> ids = createCarriers(n);
    int count = getNumOfCarriers();
    for (int i = 0; i < n2; i++)
      Assert.assertEquals(HttpStatus.OK, deleteCarrier(ids.get(i)));

    Assert.assertEquals(count - n2, getNumOfCarriers());
    for (int i = 0; i < (n - n2); i++)
      Assert.assertEquals(HttpStatus.OK, deleteCarrier(ids.get(i + n2)));

    Assert.assertEquals(count - n, getNumOfCarriers());

  }

  @Test
  public void test_202() {
    try {
      deleteCarrier(0l);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
  }

  // patch tests
  // - 300 - create obj, patch it a property, get the object verify the property, delete the obj
  // - 301 - create obj, get it, patch it, get it, test equals, delete it
  // - 302 - create obj, get it, patch it with invalid property, get 422, delete the obj
  // - 303 - try to patch not existent obj, get 404

  @Test
  public void test_300() {
    Long id = createCarrier(UtilsPopulate.newNewCarrier(getDataOwner().getId()));
    Map<String, Object> m = new HashMap<String, Object>();
    m.put("Description", RandomStringUtils.random(8, true, false));

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}").buildAndExpand(id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    Carrier o = getCarrier(id);
    Assert.assertEquals(m.get("Description"), o.getDescription());
    deleteCarrier(id);
  }

  @Test
  public void test_301() {
    Long id = createCarrier(UtilsPopulate.newNewCarrier(getDataOwner().getId()));
    Carrier o = getCarrier(id);

    Map<String, Object> m = new HashMap<String, Object>();
    m.put("Description", RandomStringUtils.random(8, true, false));

    o.setDescription((String) m.get("Description"));

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}").buildAndExpand(id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    Carrier o2 = getCarrier(id);
    Assert.assertEquals(o, o2);

    deleteCarrier(id);
  }

  @Test
  public void test_302() {
    Long id = createCarrier(UtilsPopulate.newNewCarrier(getDataOwner().getId()));
    Map<String, Object> m = new HashMap<String, Object>();
    m.put("EEEescrsiption", RandomStringUtils.random(8, true, false));

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}").buildAndExpand(id);
    try {
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      deleteCarrier(id);
    }

  }

  @Test
  public void test_303() {

    Map<String, Object> m = new HashMap<String, Object>();
    m.put("Description", RandomStringUtils.random(8, true, false));

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}").buildAndExpand(1234567);
    try {
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
  }

  // get network tests
  // - 400 - get num of objects, create object x, check num of objects is now n+1, delete object x
  // - 401 - create n+1 objects and get them with limit n, assert n, delete the n+1 objects
  @Test
  public void test_400() throws NoEntityFoundException {

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfCarrierNetworks(carrierId);

    Long nwId = createNetwork(dO.getId());
    Long id = createNetworkCarrier(nwId, UtilsPopulate.newNewCarrierRelationship(carrierId));
    Assert.assertEquals(count + 1, getNumOfCarrierNetworks(carrierId));

    deleteNetworkCarrier(nwId, id);
    deleteNetwork(nwId);
    deleteCarrier(carrierId);

  }

  @Test
  public void test_401() throws NoEntityFoundException {

    int n = 6;

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfCarrierNetworks(carrierId);

    List<Long> nws = new ArrayList<>();
    List<Long> nwCrs = new ArrayList<>();

    for (int i = 0; i < n; i++) {
      Long nwId = createNetwork(dO.getId());
      nwCrs.add(createNetworkCarrier(nwId, UtilsPopulate.newNewCarrierRelationship(carrierId)));
      nws.add(nwId);
    }
    Assert.assertEquals(count + n, getNumOfCarrierNetworks(carrierId));

    for (int i = 0; i < n; i++) {
      Long nwId = nws.get(i);
      deleteNetworkCarrier(nwId, nwCrs.get(i));
      deleteNetwork(nwId);
    }

    deleteCarrier(carrierId);

  }

  // get phone contacts tests
  // - 500 - get num of objects, create object x, check num of objects is now n+1, delete object x
  // - 501 - create n+1 objects and get them with limit n, assert n, delete the n+1 objects

  @Test
  public void test_500() {

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfPhoneContacts(carrierId);

    Long cPhCntId = createPhoneContact(carrierId, UtilsPopulate.newNewCarrierPhoneContact());
    Assert.assertEquals(count + 1, getNumOfPhoneContacts(carrierId));
    Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, cPhCntId));

  }

  @Test
  public void test_501() {

    int n = 2;

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfPhoneContacts(carrierId);

    NewCarrierPhoneContact o1 = UtilsPopulate.newNewCarrierPhoneContact();
    NewCarrierPhoneContact o2 = UtilsPopulate.newNewCarrierPhoneContact();
    if (CarrierPhoneContactType.M.equals(o1.getType()))
      o2.setType(CarrierPhoneContactType.One);
    else
      o2.setType(CarrierPhoneContactType.M);

    List<Long> cPhCntIds = new ArrayList<Long>();
    cPhCntIds.add(createPhoneContact(carrierId, o1));
    cPhCntIds.add(createPhoneContact(carrierId, o2));

    Assert.assertEquals(count + n, getNumOfPhoneContacts(carrierId));

    for (Long id : cPhCntIds)
      Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id));

    Assert.assertEquals(count, getNumOfPhoneContacts(carrierId));

  }

  // post phone contacts tests
  // - 600 - count n Obj, create one, check n+1 and status code 201
  // - 601 - count n Obj, create z, check n+z and 201
  // - 602 - try to post invalid obj, get a 422
  // - 603 - check uniqueness constraint and get a 409
  @Test
  public void test_600() {

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfPhoneContacts(carrierId);
    ResponseEntity<Void> r = postPhoneContact(carrierId, UtilsPopulate.newNewCarrierPhoneContact());
    Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
    String location = r.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));

    Assert.assertEquals(count + 1, getNumOfPhoneContacts(carrierId));
    Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id));
  }

  @Test
  public void test_601() {

    int n = 2;

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfPhoneContacts(carrierId);

    NewCarrierPhoneContact o1 = UtilsPopulate.newNewCarrierPhoneContact();
    NewCarrierPhoneContact o2 = UtilsPopulate.newNewCarrierPhoneContact();
    if (CarrierPhoneContactType.M.equals(o1.getType()))
      o2.setType(CarrierPhoneContactType.One);
    else
      o2.setType(CarrierPhoneContactType.M);

    List<Long> cPhCntIds = new ArrayList<Long>();

    ResponseEntity<Void> r = postPhoneContact(carrierId, o1);
    Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
    String location = r.getHeaders().getFirst("Location");
    cPhCntIds.add(new Long(location.substring(location.lastIndexOf("/") + 1)));

    r = postPhoneContact(carrierId, o2);
    Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
    location = r.getHeaders().getFirst("Location");
    cPhCntIds.add(new Long(location.substring(location.lastIndexOf("/") + 1)));

    Assert.assertEquals(count + n, getNumOfPhoneContacts(carrierId));

    for (Long id : cPhCntIds)
      Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id));

    Assert.assertEquals(count, getNumOfPhoneContacts(carrierId));

  }

  @Test
  public void test_602() {

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));

    NewPhoneContact o = UtilsPopulate.newNewPhoneContact();
    Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
    });
    map.put("kjhfadjkhg", 84749835);

    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts").buildAndExpand(carrierId);

    try {
      restTemplate.exchange(u.encode().toUri(), HttpMethod.POST,
          new HttpEntity<Map<String, Object>>(map, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

  }

  @Test
  public void test_603() {

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));

    NewCarrierPhoneContact o1 = UtilsPopulate.newNewCarrierPhoneContact();
    Long id = createPhoneContact(carrierId, o1);
    NewCarrierPhoneContact o2 = UtilsPopulate.newNewCarrierPhoneContact();
    o2.setType(o1.getType());

    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts").buildAndExpand(carrierId);
    try {
      restTemplate.exchange(u.encode().toUri(), HttpMethod.POST,
          new HttpEntity<NewCarrierPhoneContact>(o2, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    } finally {
      deletePhoneContact(carrierId, id);
      deleteCarrier(carrierId);
    }

  }

  // delete phone contacts tests
  // - 700 - create one, check n obj, delete obj, check n-1 and status code 200
  // - 701 - create z objects, check n objs, delete y obj, check n-y and status code 200, delete remaining objects
  // - 702 - try to delete invalid obj, get a 404

  @Test
  public void test_700() {

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfPhoneContacts(carrierId);
    Long id = createPhoneContact(carrierId, UtilsPopulate.newNewCarrierPhoneContact());
    Assert.assertEquals(count + 1, getNumOfPhoneContacts(carrierId));
    Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id));
    Assert.assertEquals(count, getNumOfPhoneContacts(carrierId));

  }

  @Test
  public void test_701() {

    int n = 2;

    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    int count = getNumOfPhoneContacts(carrierId);

    NewCarrierPhoneContact o1 = UtilsPopulate.newNewCarrierPhoneContact();
    NewCarrierPhoneContact o2 = UtilsPopulate.newNewCarrierPhoneContact();
    if (CarrierPhoneContactType.M.equals(o1.getType()))
      o2.setType(CarrierPhoneContactType.One);
    else
      o2.setType(CarrierPhoneContactType.M);

    List<Long> cPhCntIds = new ArrayList<Long>();

    ResponseEntity<Void> r = postPhoneContact(carrierId, o1);
    Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
    String location = r.getHeaders().getFirst("Location");
    cPhCntIds.add(new Long(location.substring(location.lastIndexOf("/") + 1)));

    r = postPhoneContact(carrierId, o2);
    Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
    location = r.getHeaders().getFirst("Location");
    cPhCntIds.add(new Long(location.substring(location.lastIndexOf("/") + 1)));

    Assert.assertEquals(count + n, getNumOfPhoneContacts(carrierId));

    for (Long id : cPhCntIds)
      Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id));

    Assert.assertEquals(count, getNumOfPhoneContacts(carrierId));

  }

  @Test
  public void test_702() {
    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));

    try {
      deletePhoneContact(carrierId, 0l);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
  }

  // patch phone contacts tests
  // - 800 - create obj, patch it a property, get the object verify the property, delete the obj
  // - 801 - create obj, get it, patch it, get it, test equals, delete it
  // - 802 - create obj, get it, patch it with invalid property, get 422, delete the obj
  // - 803 - try to patch not existent obj, get 404

  @Test
  public void test_800() {
    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    Long id = createPhoneContact(carrierId, UtilsPopulate.newNewCarrierPhoneContact());

    Map<String, Object> m = new HashMap<String, Object>();
    m.put("AreaCode", RandomStringUtils.random(3, true, false));

    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts/{phone-contact-id}").buildAndExpand(carrierId, id);

    ResponseEntity<Void> rPatch = restTemplate.exchange(u.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    CarrierPhoneContact o = getPhoneContacts(carrierId).stream().filter(e -> e.getId().equals(id)).findFirst().get();

    Assert.assertEquals(m.get("AreaCode"), o.getAreaCode());
    /*
     * Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id)); Assert.assertEquals(HttpStatus.OK,
     * deleteCarrier(carrierId));
     */

  }

  @Test
  public void test_801() {
    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    Long id = createPhoneContact(carrierId, UtilsPopulate.newNewCarrierPhoneContact());
    CarrierPhoneContact o1 = getPhoneContacts(carrierId).stream().filter(e -> e.getId().equals(id)).findFirst().get();

    String newAreaCode = RandomStringUtils.random(3, true, false);

    Map<String, Object> m = new HashMap<String, Object>();
    m.put("AreaCode", newAreaCode);
    o1.setAreaCode(newAreaCode);

    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts/{phone-contact-id}").buildAndExpand(carrierId, id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(u.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    CarrierPhoneContact o2 = getPhoneContacts(carrierId).stream().filter(e -> e.getId().equals(id)).findFirst().get();

    Assert.assertEquals(o1, o2);
    Assert.assertEquals(HttpStatus.OK, deletePhoneContact(carrierId, id));
  }

  @Test
  public void test_802() {
    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));
    Long id = createPhoneContact(carrierId, UtilsPopulate.newNewCarrierPhoneContact());

    Map<String, Object> m = new HashMap<String, Object>();
    m.put("EEEescrsiption", RandomStringUtils.random(8, true, false));

    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts/{phone-contact-id}").buildAndExpand(carrierId, id);
    try {
      restTemplate.exchange(u.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      deletePhoneContact(carrierId, id);
    }

  }

  @Test
  public void test_803() {
    DataOwner dO = getDataOwner();
    Long carrierId = createCarrier(UtilsPopulate.newNewCarrier(dO.getId()));

    Map<String, Object> m = new HashMap<String, Object>();
    m.put("AreaCode", RandomStringUtils.random(3, true, false));

    UriComponents u = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}/phoneContacts/{phone-contact-id}").buildAndExpand(carrierId, 0l);
    try {
      restTemplate.exchange(u.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(m, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

  }

}
