package com.anthem.specialty.provider.api;

import static java.lang.String.format;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties("test.properties")
public class TestProperties {

  @NestedConfigurationProperty
  private String host;

  @NestedConfigurationProperty
  private String port;

  @NestedConfigurationProperty
  private String scheme;

  @NestedConfigurationProperty
  private String keystorefile;

  @NestedConfigurationProperty
  private String keystorepassword;

  @NestedConfigurationProperty
  private String apiuser;

  @NestedConfigurationProperty
  private String apipassword;

  public String getHost() {
    return host;
  }

  public void setHost(String host) {
    this.host = host;
  }

  public String getPort() {
    return port;
  }

  public void setPort(String port) {
    this.port = port;
  }

  public String getScheme() {
    return scheme;
  }

  public void setScheme(String scheme) {
    this.scheme = scheme;
  }

  public String getKeystorefile() {
    return keystorefile;
  }

  public void setKeystorefile(String keystorefile) {
    this.keystorefile = keystorefile;
  }

  public String getKeystorepassword() {
    return keystorepassword;
  }

  public void setKeystorepassword(String keystorepassword) {
    this.keystorepassword = keystorepassword;
  }

  public String getApiuser() {
    return apiuser;
  }

  public void setApiuser(String apiuser) {
    this.apiuser = apiuser;
  }

  public String getApipassword() {
    return apipassword;
  }

  public void setApipassword(String apipassword) {
    this.apipassword = apipassword;
  }

  public String getUri(String path) {
    return format("%s://%s:%s%s", getScheme(), getHost(), getPort(), path);
  }

}
