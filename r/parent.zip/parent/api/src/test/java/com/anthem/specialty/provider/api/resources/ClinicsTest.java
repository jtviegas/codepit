package com.anthem.specialty.provider.api.resources;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.AddressToNewAddress;
import com.anthem.specialty.provider.datamodel.dto.AddressImpl;
import com.anthem.specialty.provider.datamodel.dto.AddressType;
import com.anthem.specialty.provider.datamodel.dto.ClinicCredentials;
import com.anthem.specialty.provider.datamodel.dto.ClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.ClinicMatch;
import com.anthem.specialty.provider.datamodel.dto.ClinicMatchImpl;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.HttpStatusResponseWithMatches;
import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.NewAddress;
import com.anthem.specialty.provider.datamodel.dto.NewAddressImpl;
import com.anthem.specialty.provider.datamodel.dto.NewClinic;
import com.anthem.specialty.provider.datamodel.dto.NewClinicCredentialsImpl;
import com.anthem.specialty.provider.datamodel.dto.NewClinicFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewLanguageImpl;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContact;
import com.anthem.specialty.provider.datamodel.dto.NewPhoneContactImpl;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.NewW9EffectiveRelationshipImpl;
import com.anthem.specialty.provider.datamodel.dto.NewW9Impl;
import com.anthem.specialty.provider.datamodel.dto.PhoneContactImpl;
import com.anthem.specialty.provider.datamodel.dto.PhoneContactType;
import com.anthem.specialty.provider.datamodel.dto.RelatedW9Impl;
import com.anthem.specialty.provider.datamodel.dto.SimpleClinicImpl;
import com.anthem.specialty.provider.datamodel.dto.UpdatableAddressImpl;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkGroup;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClinicsTest extends BaseTest {

  @Parameter
  public String schemaParameter;

  @Parameters
  public static Collection<String> data() {
    Collection<String> params = new ArrayList<>();
    // params.add("horizon");
    // params.add("wellmark");
    params.add(null);
    return params;
  }

  private ResponseEntity<Void> postClinic(com.anthem.specialty.provider.datamodel.dto.DataOwner dow) {
    NewClinic clinic = UtilsPopulate.newNewClinic(dow);
    return restTemplate.exchange(properties.getUri("/api/clinics"), HttpMethod.POST,
        new HttpEntity<NewClinic>(clinic, getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> postClinic() {
    NewClinic clinic = UtilsPopulate.newNewClinic(getDataOwner(schemaParameter));
    return restTemplate.exchange(properties.getUri("/api/clinics"), HttpMethod.POST,
        new HttpEntity<NewClinic>(clinic, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetworkGroup(com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dOw) {

    Network n = lobService.setNetwork(UtilsPopulate.newNetwork(dOw));
    NetworkGroup o = UtilsPopulate.newNetworkGroup(dOw);
    o.addNetwork(n);
    NetworkGroup g = lobService.setNetworkGroup(o);
    return g.getId();

  }

  private Long createProvider(Long dOwId) {
    TerminationLevel terminationLevel = metadataService.getTerminationLevels().stream().findAny().get();
    NewProvider p = UtilsPopulate.newNewProvider(dOwId, terminationLevel);

    ResponseEntity<Void> r = restTemplate.exchange(properties.getUri("/api/providers"), HttpMethod.POST,
        new HttpEntity<NewProvider>(p, getHeaders(schemaParameter)), Void.class);
    String location = r.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private Long createClinic() {
    ResponseEntity<Void> rPost = postClinic();
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private Long createClinic(com.anthem.specialty.provider.datamodel.dto.DataOwner dow) {
    ResponseEntity<Void> rPost = postClinic(dow);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private HttpStatus deleteClinic(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}").buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private HttpStatus deleteProvider(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/providers"))
        .path("/{provider-id}").buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private ResponseEntity<Void> postClinicAddress(Long clinicId, NewAddressImpl address) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewAddressImpl>(address, getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> putClinicAddress(Long clinicId, NewAddressImpl address) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PUT,
        new HttpEntity<NewAddressImpl>(address, getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> putClinicPhoneContact(Long clinicId, NewPhoneContact phone) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PUT,
        new HttpEntity<NewPhoneContact>(phone, getHeaders(schemaParameter)), Void.class);
  }

  private Long createAddress(Long clinicId, NewAddressImpl address) {
    ResponseEntity<Void> rPost = postClinicAddress(clinicId, address);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private Long putAddress(Long clinicId, NewAddressImpl address) {
    ResponseEntity<Void> rPut = putClinicAddress(clinicId, address);
    String location = rPut.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> deleteClinicAddress(Long clinicId, Long addressId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses/{address-id}").buildAndExpand(clinicId, addressId);

    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> postClinicW9(Long clinicId, NewW9EffectiveRelationshipImpl w9) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/w9").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewW9EffectiveRelationshipImpl>(w9, getHeaders(schemaParameter)), Void.class);
  }

  private Long createClinicW9(Long clinicId, NewW9EffectiveRelationshipImpl w9) {
    ResponseEntity<Void> rPost = postClinicW9(clinicId, w9);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> deleteClinicW9(Long clinicId, Long w9Id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/w9/{w9-id}").buildAndExpand(clinicId, w9Id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  private Long createW9() {
    NewW9Impl o = UtilsPopulate.newNewW9(getDataOwner(schemaParameter));
    ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/w9"), HttpMethod.POST,
        new HttpEntity<NewW9Impl>(o, getHeaders(schemaParameter)), Void.class);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> deleteW9(Long w9leId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9")).path("/{w9-id}")
        .buildAndExpand(w9leId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> postClinicPhoneContact(Long clinicId, NewPhoneContact o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewPhoneContact>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createClinicPhoneContact(Long clinicId, NewPhoneContact o) {
    ResponseEntity<Void> rPost = postClinicPhoneContact(clinicId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> deleteClinicPhoneContact(Long clinicId, Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId, id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> postClinicCredential(Long clinicId, NewClinicCredentialsImpl o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/credentials").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewClinicCredentialsImpl>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createClinicCredential(Long clinicId, NewClinicCredentialsImpl o) {
    ResponseEntity<Void> rPost = postClinicCredential(clinicId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> postClinicLanguage(Long clinicId, NewLanguageImpl o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/languages").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewLanguageImpl>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createClinicLanguage(Long clinicId, NewLanguageImpl o) {

    ResponseEntity<Void> rPost = postClinicLanguage(clinicId, o);

    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));

  }

  private ResponseEntity<Void> deleteClinicLanguage(Long clinicId, Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/languages/{language-id}").buildAndExpand(clinicId, id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> postClinicFocusReview(Long clinicId, NewClinicFocusReview o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/focusReviews").buildAndExpand(clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewClinicFocusReview>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createClinicFocusReview(Long clinicId, NewClinicFocusReview o) {
    ResponseEntity<Void> rPost = postClinicFocusReview(clinicId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private ResponseEntity<Void> deleteClinicFocusReview(Long clinicId, Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/focusReviews/{focus-review-id}").buildAndExpand(clinicId, id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  @Test
  public void test_000_createClinic() {
    ResponseEntity<Void> rPost = postClinic();
    Assert.assertEquals("must get created status code on new clinic", HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue("post must have provide link in the header", rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    deleteClinic(new Long(location.substring(location.lastIndexOf("/") + 1)));
  }

  @Test
  public void test_000_createClinicValidationTest() {
    NewClinic clinic = UtilsPopulate.newNewClinic(getDataOwner(schemaParameter));
    clinic.getGeneralInsurance().setInsurer(null); // insurer is marked with @NotNull so this call should fail
    try {
      ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/clinics"), HttpMethod.POST,
          new HttpEntity<NewClinic>(clinic, getHeaders(schemaParameter)), Void.class);
      Assert.fail("This call is supposed to fail with 422 UNPROCESSABLE_ENTITY");
    } catch (HttpClientErrorException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
  }

  @Test
  public void test_001_deleteClinic() {
    Assert.assertEquals("must get created status code on new clinic", HttpStatus.OK, deleteClinic(createClinic()));
  }

  @Test
  public void test_005_getClinics() {

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .queryParam("pageSize", 3).build();

    ResponseEntity<List<SimpleClinicImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<SimpleClinicImpl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertTrue(3 >= rGet.getBody().size());

  }

  @Test
  public void test_010_patchClinic() {

    Long id = createClinic();
    // create changes to the clinic
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("CommonName", "aoao");

    // execute a patch
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}").buildAndExpand(id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the clinic and check for the changes made in the patch
    ResponseEntity<com.anthem.specialty.provider.datamodel.dto.ClinicImpl> rGet = restTemplate.exchange(
        uriComponents.encode().toUri(), HttpMethod.GET, new HttpEntity<Object>(getHeaders()),
        com.anthem.specialty.provider.datamodel.dto.ClinicImpl.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("CommonName"), rGet.getBody().getCommonName());
    deleteClinic(id);
  }

  @Test
  public void test_020_postClinicAddress() {
    Long clinicId = createClinic();
    ResponseEntity<Void> rPost = postClinicAddress(clinicId, UtilsPopulate.newNewAddress());
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue(rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    Long addressId = new Long(location.substring(location.lastIndexOf("/") + 1));
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_030_postSameClinicAddress() {

    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    // use post with the same address and expect a 409
    try {
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
          new HttpEntity<NewAddressImpl>(address, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_040_postClinicAddressToWrongClinic() {
    Long clinicId = createClinic();
    // use post with wrong clinicId and expect a 422
    try {
      postClinicAddress(clinicId + 6789, UtilsPopulate.newNewAddress());
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_050_putNewAddressSameType() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);

    // use put to add a new address of same type
    NewAddressImpl a2 = UtilsPopulate.newNewAddress();
    a2.setType(address.getType());
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    try {
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PUT,
          new HttpEntity<NewAddressImpl>(a2, getHeaders(schemaParameter)), Void.class);
      Assert.fail("Should cause ORA-00001: unique constraint (ANTHEM.UIX_CLINIC_ADDRESS) violated");
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_060_checkNumberOfAddresses() {

    Long clinicId = createClinic();
    NewAddress address = UtilsPopulate.newNewAddress();
    NewAddressImpl a2 = UtilsPopulate.newNewAddress();
    a2.setType(address.getType());
    Long addressId2 = createAddress(clinicId, a2);

    // we should have still only one address
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    ResponseEntity<List<AddressImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<AddressImpl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(1, rGet.getBody().size());
    deleteClinicAddress(clinicId, addressId2);
    deleteClinic(clinicId);
  }

  @Test
  public void test_070_checkExistentAddress() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);
    // address should match
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses/{address-id}").buildAndExpand(clinicId, addressId);
    ResponseEntity<AddressImpl> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<AddressImpl>() {
        });

    AddressImpl existent = rGet.getBody();
    Assert.assertEquals(address, new AddressToNewAddress().apply(existent));
    Assert.assertEquals(addressId, existent.getId());

    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_080_putNewAddressDifferentType() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);

    // use put to add a new address of different type
    NewAddressImpl a = UtilsPopulate.newNewAddress();
    for (AddressType at : AddressType.values()) {
      if (!at.equals(address.getType())) {
        a.setType(at);
        break;
      }
    }
    ResponseEntity<Void> rPut = putClinicAddress(clinicId, a);
    Assert.assertEquals(HttpStatus.CREATED, rPut.getStatusCode());
    Assert.assertTrue(rPut.getHeaders().containsKey("Location"));
    String location = rPut.getHeaders().getFirst("Location");
    Long addressId2 = new Long(location.substring(location.lastIndexOf("/") + 1));

    deleteClinicAddress(clinicId, addressId2);
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_090_checkNumberOfAddresses() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);
    NewAddressImpl a = UtilsPopulate.newNewAddress();
    for (AddressType at : AddressType.values()) {
      if (!at.equals(address.getType())) {
        a.setType(at);
        break;
      }
    }
    Long addressId2 = putAddress(clinicId, a);

    // we should have two addresses
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    ResponseEntity<List<AddressImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<AddressImpl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(2, rGet.getBody().size());

    deleteClinicAddress(clinicId, addressId2);
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_100_putOnWrongClinic() {
    // use put with wrong clinicId and expect a 404
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();

    try {
      putClinicAddress(clinicId + 6789, address);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_110_patchClinicAddressWrongClinic() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);
    UpdatableAddressImpl update = new UpdatableAddressImpl();
    update.setCity("whatever");
    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/addresses/{address-id}").buildAndExpand(clinicId + 6789, addressId);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<UpdatableAddressImpl>(update, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_120_patchClinicAddressWrongProperty() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommonName", "aoao");

      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/addresses/{address-id}").buildAndExpand(clinicId, addressId);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_130_patchClinicAddressAndCheck() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);

    // create changes to the clinic
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("Line3", "XPTO");

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses/{address-id}").buildAndExpand(clinicId, addressId);

    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter, true)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the address and check for the changes made in the patch
    ResponseEntity<AddressImpl> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), AddressImpl.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("Line3"), rGet.getBody().getLine3());

    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_140_deleteClinicAddress() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);

    ResponseEntity<Void> rDel = deleteClinicAddress(clinicId, addressId);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    deleteClinic(clinicId);
  }

  @Test
  public void test_141_deleteUnexistentClinicAddress() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);
    deleteClinicAddress(clinicId, addressId);

    try {
      deleteClinicAddress(clinicId, addressId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_150_checkNumberOfAddresses() {
    Long clinicId = createClinic();
    NewAddressImpl address = UtilsPopulate.newNewAddress();
    Long addressId = createAddress(clinicId, address);

    // we should have one addresses
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/addresses").buildAndExpand(clinicId);
    ResponseEntity<List<AddressImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<AddressImpl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(1, rGet.getBody().size());

    deleteClinicAddress(clinicId, addressId);
    deleteClinic(clinicId);
  }

  @Test
  public void test_160_deleteClinic() {
    Long clinicId = createClinic();

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}").buildAndExpand(clinicId);
    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
  }

  @Test
  public void test_170_checkClinic() {
    Long clinicId = createClinic();
    deleteClinic(clinicId);
    try {
      // we should not find the clinic
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}").buildAndExpand(clinicId);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
          new HttpEntity<Void>(getHeaders(schemaParameter)),
          com.anthem.specialty.provider.datamodel.dto.ClinicImpl.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

  }

  @Test
  public void test_180_deleteNotExistentClinic() {
    Long clinicId = createClinic();
    deleteClinic(clinicId);
    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}").buildAndExpand(clinicId);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
          new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
  }

  @Test
  public void test_190_createClinicW9() {
    Long w9leId = createW9();
    Long clinicId = createClinic();
    NewW9EffectiveRelationshipImpl w9 = UtilsPopulate.newNewW9Relationship(w9leId);

    ResponseEntity<Void> rPost = postClinicW9(clinicId, w9);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    String location = rPost.getHeaders().getFirst("Location");
    Long w9Id = new Long(location.substring(location.lastIndexOf("/") + 1));

    deleteClinicW9(clinicId, w9Id);
    deleteClinic(clinicId);
    deleteW9(w9leId);
  }

  @Test
  public void test_191_deleteClinicW9() {
    Long w9leId = createW9();
    Long clinicId = createClinic();
    NewW9EffectiveRelationshipImpl w9r = UtilsPopulate.newNewW9Relationship(w9leId);
    Long cW9Id = createClinicW9(clinicId, w9r);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/w9/{w9-id}").buildAndExpand(clinicId, cW9Id);
    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    deleteClinic(clinicId);
    deleteW9(w9leId);
  }

  @Test
  public void test_192_deleteClinicW9_noMatch() {
    Long w9leId = createW9();
    Long clinicId = createClinic();
    NewW9EffectiveRelationshipImpl w9r = UtilsPopulate.newNewW9Relationship(w9leId);
    Long cW9Id = createClinicW9(clinicId, w9r);
    deleteClinicW9(clinicId, cW9Id);

    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/w9/{w9-id}").buildAndExpand(clinicId, cW9Id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
          new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    deleteClinic(clinicId);
    deleteW9(w9leId);
  }

  @Test
  public void test_193_createClinicW9_noClinic() {
    Long w9leId = createW9();
    Long clinicId = createClinic();
    NewW9EffectiveRelationshipImpl w9 = UtilsPopulate.newNewW9Relationship(w9leId);

    try {
      postClinicW9(clinicId + 6789, w9);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

    deleteClinic(clinicId);
    deleteW9(w9leId);
  }

  @Test
  public void test_194_createClinicW9_conflict() {
    Long w9leId = createW9();
    Long clinicId = createClinic();
    NewW9EffectiveRelationshipImpl w9r = UtilsPopulate.newNewW9Relationship(w9leId);
    Long cW9Id = createClinicW9(clinicId, w9r);
    NewW9EffectiveRelationshipImpl w9r2 = UtilsPopulate.newNewW9Relationship(w9leId);
    w9r2.setW9(w9r.getW9());

    try {
      postClinicW9(clinicId, w9r2);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }
    deleteClinicW9(clinicId, cW9Id);
    deleteClinic(clinicId);
    deleteW9(w9leId);
  }

  @Test
  public void test_195_getClinicW9s() {

    Long w9leId = createW9();
    Long w9leId2 = createW9();
    Long clinicId = createClinic();

    NewW9EffectiveRelationshipImpl w9r = UtilsPopulate.newNewW9Relationship(w9leId);
    Long cW9Id = createClinicW9(clinicId, w9r);
    NewW9EffectiveRelationshipImpl w9r2 = UtilsPopulate.newNewW9Relationship(w9leId2);
    Long cW9Id2 = createClinicW9(clinicId, w9r2);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/w9").buildAndExpand(clinicId);
    ResponseEntity<List<RelatedW9Impl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedW9Impl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(2, rGet.getBody().size());

    deleteClinicW9(clinicId, cW9Id2);
    deleteClinicW9(clinicId, cW9Id);
    deleteClinic(clinicId);
    deleteW9(w9leId2);
    deleteW9(w9leId);
  }

  @Test
  public void test_200_createClinicPhoneContact() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();

    ResponseEntity<Void> rPost = postClinicPhoneContact(clinicId, o);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));

    deleteClinicPhoneContact(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_201_deleteClinicPhoneContact() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId, id);
    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    deleteClinic(clinicId);
  }

  @Test
  public void test_202_deleteClinicPhoneContact_noMatch() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);
    deleteClinicPhoneContact(clinicId, id);

    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
          new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_203_createClinicPhoneContact_noClinic() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();

    try {
      postClinicPhoneContact(clinicId + 6789, o);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_204_createClinicPhoneContact_sameType() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);
    NewPhoneContactImpl o2 = UtilsPopulate.newNewPhoneContact();
    o2.setType(o.getType());
    try {
      postClinicPhoneContact(clinicId, o2);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }
    deleteClinicPhoneContact(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_205_getClinicPhoneContacts() {

    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);
    NewPhoneContactImpl o2 = UtilsPopulate.newNewPhoneContact();
    // can't be equal otherwise we'll have a 409
    for (PhoneContactType pct : PhoneContactType.values()) {
      if (!pct.equals(o.getType())) {
        o2.setType(pct);
        break;
      }
    }
    Long id2 = createClinicPhoneContact(clinicId, o2);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts").buildAndExpand(clinicId);
    ResponseEntity<List<PhoneContactImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<PhoneContactImpl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(2, rGet.getBody().size());

    deleteClinicPhoneContact(clinicId, id);
    deleteClinicPhoneContact(clinicId, id2);
    deleteClinic(clinicId);

  }

  // TODO review if this is allowed: multiple clinic phone contacts of same type
  /*
   * @Test public void test_194_createClinicPhoneContact_conflict() { Long w9leId = createW9(); Long clinicId =
   * createClinic(); NewW9Relationship w9r = UtilsPopulate.newNewW9Relationship(w9leId); Long cW9Id =
   * createClinicW9(clinicId, w9r); NewW9Relationship w9r2 = UtilsPopulate.newNewW9Relationship(w9leId);
   * w9r2.setW9(w9r.getW9());
   * 
   * try { postClinicW9(clinicId, w9r2); Assert.fail(); } catch (HttpStatusCodeException e) {
   * Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode()); } deleteClinicW9(clinicId, cW9Id);
   * deleteClinic(clinicId); deleteW9(w9leId); }
   */

  @Test
  public void test_206_patchClinicPhoneContact_WrongClinic() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);
    Map<String, Object> changes = new HashMap<String, Object>();

    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId + 6789, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinicPhoneContact(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_207_patchClinicPhoneContact_WrongProperty() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommonName", "aoao");

      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      System.err.println(e.getResponseBodyAsString());
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteClinicPhoneContact(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_208_patchClinicPhoneContact_alreadyTakenType() {

    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    o.setType(PhoneContactType.A);
    createClinicPhoneContact(clinicId, o);

    NewPhoneContactImpl o2 = UtilsPopulate.newNewPhoneContact();
    o2.setType(PhoneContactType.E);
    Long id2 = createClinicPhoneContact(clinicId, o2);

    try {
      // create changes to the clinic, set it to an already used type
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Type", 'A');

      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId, id2);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }
  }

  @Test
  public void test_2090_patchClinicPhoneContactAndCheck() {
    Long clinicId = createClinic();
    NewPhoneContactImpl o = UtilsPopulate.newNewPhoneContact();
    Long id = createClinicPhoneContact(clinicId, o);

    // create changes to the clinic
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("Number", "999999");

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts/{phone-contact-id}").buildAndExpand(clinicId, id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve and check for the changes made in the patch
    uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/phoneContacts").buildAndExpand(clinicId);
    ResponseEntity<List<PhoneContactImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<PhoneContactImpl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    for (PhoneContactImpl p : rGet.getBody()) {
      if (p.getId().equals(id)) {
        Assert.assertEquals(changes.get("Number"), p.getNumber());
        break;
      }
    }
    deleteClinicPhoneContact(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_2091_putNewClinicPhoneContactSameType() {
    Long clinicId = createClinic();
    NewPhoneContact o1 = UtilsPopulate.newNewPhoneContact();
    // Long id1 =
    createClinicPhoneContact(clinicId, o1);

    // use put to add a new phone of same type
    NewPhoneContact o2 = UtilsPopulate.newNewPhoneContact();
    o2.setType(o1.getType());
    try {
      putClinicPhoneContact(clinicId, o2);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }
    /*
     * Assert.assertEquals(HttpStatus.OK, rPut.getStatusCode());
     * Assert.assertTrue(rPut.getHeaders().containsKey("Location")); String location =
     * rPut.getHeaders().getFirst("Location"); Long id2 = new Long(location.substring(location.lastIndexOf("/") + 1));
     * Assert.assertNotEquals(id1, id2);
     */
  }

  @Test
  public void test_2092_putNewPhoneContactDifferentType() {
    Long clinicId = createClinic();
    NewPhoneContact o1 = UtilsPopulate.newNewPhoneContact();
    createClinicPhoneContact(clinicId, o1);

    // use put to add a new phone of different type
    NewPhoneContact o2 = UtilsPopulate.newNewPhoneContact();
    for (PhoneContactType at : PhoneContactType.values()) {
      if (!at.equals(o1.getType())) {
        o2.setType(at);
        break;
      }
    }
    ResponseEntity<Void> rPut = putClinicPhoneContact(clinicId, o2);
    Assert.assertEquals(HttpStatus.CREATED, rPut.getStatusCode());
    Assert.assertTrue(rPut.getHeaders().containsKey("Location"));
  }

  @Test
  public void test_2093_putOnWrongClinic() {
    // use put with wrong clinicId and expect a 422
    Long clinicId = createClinic();
    NewPhoneContact o1 = UtilsPopulate.newNewPhoneContact();

    try {
      putClinicPhoneContact(clinicId + 6789, o1);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
  }

  @Test
  public void test_210_createClinicCredential() {
    Long clinicId = createClinic();
    NewClinicCredentialsImpl o = UtilsPopulate.newNewClinicCredentials();

    ResponseEntity<Void> rPost = postClinicCredential(clinicId, o);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());

    deleteClinic(clinicId);
  }

  @Test
  public void test_213_createClinicCredential_noClinic() {
    Long clinicId = createClinic();
    NewClinicCredentialsImpl o = UtilsPopulate.newNewClinicCredentials();

    try {
      postClinicCredential(clinicId + 6789, o);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
  }

  @Test
  public void test_215_getClinicCredentials() {

    Long clinicId = createClinic();
    NewClinicCredentialsImpl o = UtilsPopulate.newNewClinicCredentials();
    createClinicCredential(clinicId, o);
    NewClinicCredentialsImpl o2 = UtilsPopulate.newNewClinicCredentials();
    createClinicCredential(clinicId, o2);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/credentials").buildAndExpand(clinicId);
    ResponseEntity<List<ClinicCredentials>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<ClinicCredentials>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(2, rGet.getBody().size());
  }

  @Test
  public void test_216_patchClinicCredential_WrongClinic() {
    Long clinicId = createClinic();
    NewClinicCredentialsImpl o = UtilsPopulate.newNewClinicCredentials();
    Long id = createClinicCredential(clinicId, o);

    Map<String, Object> changes = new HashMap<String, Object>();

    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/credentials/{credential-id}").buildAndExpand(clinicId + 6789, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

  }

  @Test
  public void test_217_patchClinicCredential_WrongProperty() {
    Long clinicId = createClinic();
    NewClinicCredentialsImpl o = UtilsPopulate.newNewClinicCredentials();
    Long id = createClinicCredential(clinicId, o);
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommonName", "aoao");

      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/credentials/{credential-id}").buildAndExpand(clinicId, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      System.err.println(e.getResponseBodyAsString());
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

  }

  @Test
  public void test_218_patchClinicCredentialAndCheck() {
    Long clinicId = createClinic();
    NewClinicCredentialsImpl o = UtilsPopulate.newNewClinicCredentials();
    o.setEmergencyKit(false);
    Long id = createClinicCredential(clinicId, o);

    // create changes to the clinic
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("EmergencyKit", true);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/credentials/{credential-id}").buildAndExpand(clinicId, id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve and check for the changes made in the patch
    uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics")).path("/{clinic-id}/credentials")
        .buildAndExpand(clinicId);
    ResponseEntity<List<ClinicCredentials>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<ClinicCredentials>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    for (ClinicCredentials p : rGet.getBody()) {
      if (p.getId().equals(id)) {
        Assert.assertEquals(changes.get("EmergencyKit"), p.isEmergencyKit());
        break;
      }
    }

  }

  // TODO dto.Language should be a DataEntity to provide a link
  @Test
  public void test_220_createClinicLanguage() {
    Long clinicId = createClinic();
    NewLanguageImpl o = UtilsPopulate.newNewLanguage();

    ResponseEntity<Void> rPost = postClinicLanguage(clinicId, o);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));

    deleteClinicLanguage(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_221_createClinicLanguage_noClinic() {
    Long clinicId = createClinic();
    NewLanguageImpl o = UtilsPopulate.newNewLanguage();

    try {
      postClinicLanguage(clinicId + 6789, o);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_222_getClinicLanguages() {

    Long clinicId = createClinic();
    NewLanguageImpl o = UtilsPopulate.newNewLanguage();
    Long id = createClinicLanguage(clinicId, o);
    NewLanguageImpl o2 = UtilsPopulate.newNewLanguage();
    Long id2 = createClinicLanguage(clinicId, o2);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/languages").buildAndExpand(clinicId);
    ResponseEntity<List<Language>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<Language>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(2, rGet.getBody().size());

    deleteClinicLanguage(clinicId, id);
    deleteClinicLanguage(clinicId, id2);
    deleteClinic(clinicId);

  }

  @Test
  public void test_223_deleteClinicLanguage() {
    Long clinicId = createClinic();
    NewLanguageImpl o = UtilsPopulate.newNewLanguage();
    Long id = createClinicLanguage(clinicId, o);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/languages/{language-id}").buildAndExpand(clinicId, id);
    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    deleteClinic(clinicId);
  }

  @Test
  public void test_224_deleteClinicLanguage_noMatch() {
    Long clinicId = createClinic();
    NewLanguageImpl o = UtilsPopulate.newNewLanguage();
    Long id = createClinicLanguage(clinicId, o);
    deleteClinicLanguage(clinicId, id);

    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/languages/{language-id}").buildAndExpand(clinicId, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
          new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_230_createClinicFocusReview() {
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);

    ResponseEntity<Void> rPost = postClinicFocusReview(clinicId, o);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));

    deleteClinicFocusReview(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_231_createClinicFocusReview_noClinic() {
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);

    try {
      postClinicFocusReview(clinicId + 6789, o);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    deleteClinic(clinicId);

  }

  @Test
  public void test_232_getClinicFocusReviews() throws NoEntityFoundException {

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o1 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);
    NewClinicFocusReview o2 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/focusReviews").buildAndExpand(clinicId);
    ResponseEntity<List<ClinicFocusReview>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<ClinicFocusReview>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());

    postClinicFocusReview(clinicId, o1);
    postClinicFocusReview(clinicId, o2);
    rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<ClinicFocusReview>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());

    Assert.assertEquals(2, rGet.getBody().size());

    lobService.deleteNetworkGroup(networkGroupId);
    lobService.deleteProvider(providerId);
    lobService.deleteClinic(clinicId);

  }

  @Test
  public void test_233_deleteClinicFocusReview() throws NoEntityFoundException {
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o1 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);
    Long id = createClinicFocusReview(clinicId, o1);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/focusReviews/{focus-review-id}").buildAndExpand(clinicId, id);
    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());

    lobService.deleteNetworkGroup(networkGroupId);
    lobService.deleteProvider(providerId);
    lobService.deleteClinic(clinicId);
  }

  @Test
  public void test_234_deleteClinicFocusReview_noMatch() throws NoEntityFoundException {
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o1 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);
    Long id = createClinicFocusReview(clinicId, o1);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/focusReviews/{focus-review-id}").buildAndExpand(clinicId, id);
    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);

    try {
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
          new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    lobService.deleteNetworkGroup(networkGroupId);
    lobService.deleteProvider(providerId);
    lobService.deleteClinic(clinicId);
  }

  @Test
  public void test_235_patchClinicFocusReview_WrongClinic() throws NoEntityFoundException {
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o1 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);
    Long id = createClinicFocusReview(clinicId, o1);
    Map<String, Object> changes = new HashMap<String, Object>();
    try {
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/focusReviews/{focus-review-id}").buildAndExpand(clinicId + 6789, id);
      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
    lobService.deleteNetworkGroup(networkGroupId);
    lobService.deleteProvider(providerId);
    lobService.deleteClinic(clinicId);
  }

  @Test
  public void test_236_patchClinicFocusReviewWrongProperty() throws NoEntityFoundException {
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o1 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);
    Long id = createClinicFocusReview(clinicId, o1);
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommonName", "aoao");

      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
          .path("/{clinic-id}/focusReviews/{focus-review-id}").buildAndExpand(clinicId, id);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    lobService.deleteNetworkGroup(networkGroupId);
    lobService.deleteProvider(providerId);
    lobService.deleteClinic(clinicId);
  }

  // TODO finish this once /api/networks is done
  // @Test
  public void test_237_patchClinicFocusReviewAndCheck() {

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();

    Long clinicId = createClinic();
    Long networkGroupId = lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId();
    Long providerId = createProvider(dataOwner.getId());
    NewClinicFocusReview o1 = UtilsPopulate.newNewClinicFocusReview(dataOwner, providerId, networkGroupId);
    Long id = createClinicFocusReview(clinicId, o1);

    // create changes to the clinic
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("Comments", "XPTO");

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}/focusReviews/{focus-review-id}").buildAndExpand(clinicId, id);

    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the Language and check for the changes made in the patch
    ResponseEntity<ClinicFocusReview> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), ClinicFocusReview.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("Comments"), rGet.getBody().getComments());

    deleteClinicFocusReview(clinicId, id);
    deleteClinic(clinicId);
  }

  @Test
  public void test_240_clinicMatch_exactAddress() {

    DataOwner dow = getDataOwner(schemaParameter);
    Long clinicId = createClinic(dow);

    NewPhoneContactImpl p = new NewPhoneContactImpl();
    p.setCountryCode("353");
    p.setAreaCode("089");
    p.setCityCode("531");
    p.setNumber("3456789");
    p.setExtension(RandomStringUtils.random(5, true, false));
    p.setType(PhoneContactType.P);
    createClinicPhoneContact(clinicId, p);

    NewAddressImpl a = new NewAddressImpl();
    a.setLine1("street abcdef n35 r");
    a.setLine2("");
    a.setLine3("");
    a.setCity("bocanoga");
    a.setState("AL");
    a.setZipCode("AXLKI");
    a.setCounty("THEREABOUTS");
    a.setCountry("USA");
    a.setProvince("GUGUMBAR");
    a.setLatitude(19l);
    a.setLongitude(23l);
    a.setType(AddressType.D);
    createAddress(clinicId, a);

    ClinicMatch o = new ClinicMatchImpl();
    // different phone
    NewPhoneContactImpl p2 = new NewPhoneContactImpl();
    p2.setCountryCode("353");
    p2.setAreaCode("089");
    p2.setCityCode("531");
    p2.setNumber("3256789");
    p2.setType(PhoneContactType.P);

    o.setAddress(a);
    o.setPhone(p2);
    o.setDataOwnerId(dow.getId());

    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
      HttpStatusResponseWithMatches response = jsonMapper.convertValue(e.getResponseBodyAsString(),
          HttpStatusResponseWithMatches.class);
      Assert.assertEquals("Item Already Exists", response.getInfo());
      Assert.assertTrue(e.getResponseBodyAsString().contains("\"Id\":" + clinicId.toString()));
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_242_clinicMatch_almostExactAddress_but_exactPhone() {

    DataOwner dow = getDataOwner(schemaParameter);
    Long clinicId = createClinic(dow);

    NewPhoneContactImpl p = new NewPhoneContactImpl();
    p.setCountryCode("353");
    p.setAreaCode("089");
    p.setCityCode("531");
    p.setNumber("3256789");
    p.setExtension(RandomStringUtils.random(5, true, false));
    p.setType(PhoneContactType.P);
    createClinicPhoneContact(clinicId, p);

    NewAddressImpl a = new NewAddressImpl();
    a.setLine1("street abcdef n35 r");
    a.setLine2("");
    a.setLine3("");
    a.setCity("bocanoga");
    a.setState("AL");
    a.setZipCode("AXLKI");
    a.setCounty("THEREABOUTS");
    a.setCountry("USA");
    a.setProvince("GUGUMBAR");
    a.setLatitude(19l);
    a.setLongitude(23l);
    a.setType(AddressType.D);
    createAddress(clinicId, a);

    ClinicMatch o = new ClinicMatchImpl();

    // different address
    NewAddressImpl a2 = new NewAddressImpl();
    a2.setLine1("st abcdef n35 r");
    a2.setType(AddressType.D);

    o.setAddress(a2);
    o.setPhone(p);
    o.setDataOwnerId(dow.getId());

    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
      HttpStatusResponseWithMatches response = jsonMapper.convertValue(e.getResponseBodyAsString(),
          HttpStatusResponseWithMatches.class);
      Assert.assertEquals("Item Already Exists", response.getInfo());
      Assert.assertTrue(e.getResponseBodyAsString().contains("\"Id\":" + clinicId.toString()));
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_244_clinicMatch_exactPhone_notEnoughAddressSimilarity() {

    DataOwner dow = getDataOwner(schemaParameter);
    Long clinicId = createClinic(dow);

    NewPhoneContactImpl p = new NewPhoneContactImpl();
    p.setCountryCode("353");
    p.setAreaCode("089");
    p.setCityCode("531");
    p.setNumber("3256789");
    p.setExtension(RandomStringUtils.random(5, true, false));
    p.setType(PhoneContactType.P);
    createClinicPhoneContact(clinicId, p);

    NewAddressImpl a = new NewAddressImpl();
    a.setLine1("street abcdef n35 r");
    a.setLine2("");
    a.setLine3("");
    a.setCity("bocanoga");
    a.setState("AL");
    a.setZipCode("AXLKI");
    a.setCounty("THEREABOUTS");
    a.setCountry("USA");
    a.setProvince("GUGUMBAR");
    a.setLatitude(19l);
    a.setLongitude(23l);
    a.setType(AddressType.D);
    createAddress(clinicId, a);

    ClinicMatch o = new ClinicMatchImpl();

    // different address
    NewAddressImpl a2 = new NewAddressImpl();
    a2.setLine1("st ________ 32");
    a2.setType(AddressType.D);

    o.setAddress(a2);
    o.setPhone(p);
    o.setDataOwnerId(dow.getId());

    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
      Assert.assertEquals("{\"code\":404,\"info\":\"No Matching Clinic\"}", e.getResponseBodyAsString());

    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_246_clinicMatch_different() {

    DataOwner dow = getDataOwner(schemaParameter);
    Long clinicId = createClinic(dow);

    NewPhoneContactImpl p = new NewPhoneContactImpl();
    p.setCountryCode("353");
    p.setAreaCode("089");
    p.setCityCode("531");
    p.setNumber("3256789");
    p.setExtension(RandomStringUtils.random(5, true, false));
    p.setType(PhoneContactType.P);
    createClinicPhoneContact(clinicId, p);

    NewAddressImpl a = new NewAddressImpl();
    a.setLine1("street abcdef n35 r");
    a.setLine2("");
    a.setLine3("");
    a.setCity("bocanoga");
    a.setState("AL");
    a.setZipCode("AXLKI");
    a.setCounty("THEREABOUTS");
    a.setCountry("USA");
    a.setProvince("GUGUMBAR");
    a.setLatitude(19l);
    a.setLongitude(23l);
    a.setType(AddressType.D);
    createAddress(clinicId, a);

    ClinicMatch o = new ClinicMatchImpl();

    // different address
    NewAddressImpl a2 = new NewAddressImpl();
    a2.setLine1("rue de la belleview 456");
    a2.setType(AddressType.D);
    NewPhoneContactImpl p2 = new NewPhoneContactImpl();
    p2.setCountryCode("351");
    p2.setAreaCode("099");
    p2.setCityCode("534");
    p2.setNumber("9876543");
    p2.setType(PhoneContactType.P);

    o.setAddress(a2);
    o.setPhone(p2);
    o.setDataOwnerId(dow.getId());

    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
      Assert.assertEquals("{\"code\":404,\"info\":\"No Matching Clinic\"}", e.getResponseBodyAsString());
    }
    deleteClinic(clinicId);
  }

  @Test
  public void test_248_clinicMatch_validationFail() {
    DataOwner dow = getDataOwner(schemaParameter);

    ClinicMatch o = new ClinicMatchImpl();

    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

    o.setAddress(new NewAddressImpl());
    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

    o.setAddress(null);
    o.setPhone(new NewPhoneContactImpl());
    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<ClinicMatch>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
  }

  @Test
  public void test_247_clinicMatch_invalidEntity() {

    Map<String, Object> o = new HashMap<>();
    o.put("x", "x");

    try {
      restTemplate.exchange(properties.getUri("/api/clinics/match"), HttpMethod.POST,
          new HttpEntity<Map<String, Object>>(o, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

  }

}
