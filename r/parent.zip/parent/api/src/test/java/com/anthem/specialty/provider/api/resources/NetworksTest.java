package com.anthem.specialty.provider.api.resources;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datamodel.dto.CollectionRelatedCarrier;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.Network;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewCarrier;
import com.anthem.specialty.provider.datamodel.dto.NewCarrierEffectiveRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewClinic;
import com.anthem.specialty.provider.datamodel.dto.NewNetwork;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicProviderRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewNetworkClinicRelationship;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.RelatedCarrier;
import com.anthem.specialty.provider.datamodel.dto.RelatedClinic;
import com.anthem.specialty.provider.datamodel.dto.RelatedNetwork;
import com.anthem.specialty.provider.datamodel.dto.RelatedProvider;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.testutils.UtilsObjectDiff;
import com.anthem.specialty.provider.testutils.UtilsPopulate;
import com.google.common.collect.ImmutableSet;

@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NetworksTest extends BaseTest {

  @Parameter
  public String schemaParameter;

  @Parameters
  public static Collection<String> data() {
    Collection<String> params = new ArrayList<>();
    // params.add("horizon");
    // params.add("wellmark");
    params.add(null);
    return params;
  }

  private DataOwner getDataOwner() {
    ResponseEntity<List<DataOwner>> r = restTemplate.exchange(properties.getUri("/api/metadata/dataOwners"),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders(schemaParameter)),
        new ParameterizedTypeReference<List<DataOwner>>() {
        });

    Assert.assertEquals("must get a dataOwner", HttpStatus.OK, r.getStatusCode());
    return r.getBody().stream().findAny().get();
  }

  private TerminationLevel getTerminationLevel() {
    ResponseEntity<List<TerminationLevel>> r = restTemplate.exchange(
        properties.getUri("/api/metadata/terminationLevels"), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<TerminationLevel>>() {
        });

    Assert.assertEquals("must get a terminationLevel", HttpStatus.OK, r.getStatusCode());
    return r.getBody().stream().findAny().get();
  }

  private ResponseEntity<Void> postNewNetwork(NewNetwork o) {
    /* NewNetwork o = UtilsPopulate.newNewNetwork(getDataOwner().getId()); */
    return restTemplate.exchange(properties.getUri("/api/networks"), HttpMethod.POST,
        new HttpEntity<NewNetwork>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetwork() {
    ResponseEntity<Void> rPost = postNewNetwork(UtilsPopulate.newNewNetwork(getDataOwner().getId()));
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private Long createClinic() {
    ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/clinics"), HttpMethod.POST,
        new HttpEntity<NewClinic>(UtilsPopulate.newNewClinic(getDataOwner()), getHeaders(schemaParameter)), Void.class);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private Long createProvider() {
    ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/providers"), HttpMethod.POST,
        new HttpEntity<NewProvider>(UtilsPopulate.newNewProvider(getDataOwner().getId(), getTerminationLevel()),
            getHeaders(schemaParameter)),
        Void.class);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private Long createCarrier() {

    ResponseEntity<Void> rPost = restTemplate.exchange(properties.getUri("/api/carriers"), HttpMethod.POST,
        new HttpEntity<NewCarrier>(UtilsPopulate.newNewCarrier(getDataOwner().getId()), getHeaders(schemaParameter)),
        Void.class);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));

  }

  private HttpStatus deleteClinic(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/clinics"))
        .path("/{clinic-id}").buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private HttpStatus deleteCarrier(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/carriers"))
        .path("/{carrier-id}").buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private void deleteNetwork(Long id) throws NoEntityFoundException {
    lobService.deleteNetwork(id);
    /*
     * UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
     * .path("/{network-id}").buildAndExpand(id); return restTemplate.exchange(uriComponents.encode().toUri(),
     * HttpMethod.DELETE, new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
     */
  }

  private HttpStatus deleteProvider(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/providers"))
        .path("/{provider-id}").buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private ResponseEntity<Void> postNewNetworkCarrier(Long networkId, NewCarrierEffectiveRelationship o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers").buildAndExpand(networkId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewCarrierEffectiveRelationship>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetworkCarrier(Long networkId, NewCarrierEffectiveRelationship o) {
    ResponseEntity<Void> rPost = postNewNetworkCarrier(networkId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private int getNumOfNetworkCarriers(Long networkId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers").buildAndExpand(networkId);

    ResponseEntity<List<CollectionRelatedCarrier>> r = restTemplate.exchange(uriComponents.encode().toUri(),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders(schemaParameter)),
        new ParameterizedTypeReference<List<CollectionRelatedCarrier>>() {
        });
    return r.getBody().size();
  }

  private int getNumOfClinicProviders(Long networkId, Long networkClinicId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}/providers").buildAndExpand(networkId, networkClinicId);

    ResponseEntity<List<RelatedProvider>> r = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedProvider>>() {
        });
    return r.getBody().size();
  }

  private int getNumOfNetworks() {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks")).build();
    ResponseEntity<List<RelatedNetwork>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedNetwork>>() {
        });
    return rGet.getBody().size();
  }

  private com.anthem.specialty.provider.datamodel.dto.Network getNetwork(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}").buildAndExpand(id);
    ResponseEntity<com.anthem.specialty.provider.datamodel.dto.Network> rGet = restTemplate.exchange(
        uriComponents.encode().toUri(), HttpMethod.GET, new HttpEntity<Void>(getHeaders(schemaParameter)),
        com.anthem.specialty.provider.datamodel.dto.Network.class);
    return rGet.getBody();
  }

  private int getNumOfCarriers(Long networkId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers").buildAndExpand(networkId);
    ResponseEntity<List<RelatedCarrier>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedCarrier>>() {
        });
    return rGet.getBody().size();
  }

  private HttpStatus deleteNetworkCarrier(Long networkId, Long carrierId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers/{carrier-id}").buildAndExpand(networkId, carrierId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private HttpStatus deleteNetworkClinic(Long networkId, Long clinicId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}").buildAndExpand(networkId, clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private ResponseEntity<Void> postNewNetworkClinicProvider(Long networkId, Long clinicId,
      NewNetworkClinicProviderRelationship o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}/providers").buildAndExpand(networkId, clinicId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewNetworkClinicProviderRelationship>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetworkClinicProvider(Long networkId, Long clinicId, NewNetworkClinicProviderRelationship o) {
    ResponseEntity<Void> rPost = postNewNetworkClinicProvider(networkId, clinicId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private HttpStatus deleteNetworkClinicProvider(Long networkId, Long clinicId, Long providerId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}/providers/{provider-id}")
        .buildAndExpand(networkId, clinicId, providerId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  @Test
  public void test_000_getNetworks() {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .queryParam("numRows", 3).build();
    ResponseEntity<List<RelatedNetwork>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedNetwork>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertTrue(3 >= rGet.getBody().size());
  }

  @Test
  public void test_010_createNetworks() throws NoEntityFoundException {
    int count = getNumOfNetworks();
    NewNetwork n = UtilsPopulate.newNewNetwork(getDataOwner().getId());
    ResponseEntity<Void> rPost = postNewNetwork(n);
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue(rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    Assert.assertEquals(count + 1, getNumOfNetworks());
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));

    com.anthem.specialty.provider.datamodel.dto.Network o = getNetwork(id);

    UtilsObjectDiff diff = new UtilsObjectDiff(n, o);

    Assert.assertTrue(ImmutableSet.of("Links", "Id", "DataOwner").equals(diff.onlyOnRight()));
    Assert.assertTrue(ImmutableSet.of("DataOwnerId").equals(diff.onlyOnLeft()));
    Assert.assertTrue(diff.differing().isEmpty());
    deleteNetwork(id);
  }

  @Test
  public void test_010_createNetworks_fail() throws NoEntityFoundException {

    NewNetwork n = UtilsPopulate.newNewNetwork(getDataOwner().getId());
    n.getEffective().setFrom(null);
    try {
      ResponseEntity<Void> rPost = postNewNetwork(n);

      String location = rPost.getHeaders().getFirst("Location");
      Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
      deleteNetwork(id);
      Assert.fail("this should have failed");
    } catch (HttpClientErrorException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
  }

  /*
   * @Test public void test_020_deleteNetwork() { Assert.assertEquals("must get OK status code deleting w9",
   * HttpStatus.OK, deleteNetwork(createNetwork())); }
   */
  @Test
  public void test_030_patchNetwork() throws NoEntityFoundException {

    Long id = createNetwork();
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("Description", "aoao");
    changes.put("Manager", "Sir Alex");

    // execute a patch
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}").buildAndExpand(id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the clinic and check for the changes made in the patch
    ResponseEntity<Network> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), Network.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("Description"), rGet.getBody().getDescription());
    Assert.assertEquals(changes.get("Manager"), rGet.getBody().getManager());
    deleteNetwork(id);
  }

  @Test
  public void test_035_patchNetworkWrongProperty() throws NoEntityFoundException {
    Long id = createNetwork();
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommonName", "aoao");
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
          .path("/{network-id}").buildAndExpand(id);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteNetwork(id);
  }

  @Test
  public void test_040_postNetworkCarrier() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long carrierId = createCarrier();
    ResponseEntity<Void> rPost = postNewNetworkCarrier(networkId, UtilsPopulate.newNewCarrierRelationship(carrierId));
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue(rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
    deleteNetworkCarrier(networkId, id);
    deleteCarrier(carrierId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_045_deleteNetworkCarrier() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long carrierId = createCarrier();
    Long id = createNetworkCarrier(networkId, UtilsPopulate.newNewCarrierRelationship(carrierId));
    int count = getNumOfNetworkCarriers(networkId);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers/{carrier-id}").buildAndExpand(networkId, id);

    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    Assert.assertEquals(count - 1, getNumOfNetworkCarriers(networkId));
    deleteCarrier(carrierId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_050_patchNetworkCarrier() throws NoEntityFoundException {

    Long networkId = createNetwork();
    Long carrierId = createCarrier();
    Long id = createNetworkCarrier(networkId, UtilsPopulate.newNewCarrierRelationship(carrierId));
    Map<String, Object> effective = new HashMap<String, Object>();
    effective.put("From", LocalDate.of(2001, Month.JANUARY, 12));
    effective.put("To", LocalDate.of(2021, Month.JANUARY, 11));

    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("Effective", effective);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/carriers/{carrier-id}").buildAndExpand(networkId, id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve and check for the changes made in the patch
    ResponseEntity<CollectionRelatedCarrier> rGet = restTemplate.exchange(uriComponents.encode().toUri(),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()), CollectionRelatedCarrier.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(effective.get("From"), rGet.getBody().getEffective().getFrom());
    Assert.assertEquals(effective.get("To"), rGet.getBody().getEffective().getTo());
    deleteNetworkCarrier(networkId, id);
    deleteCarrier(carrierId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_055_patchNetworkCarrierWrongProperty() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long carrierId = createCarrier();
    Long id = createNetworkCarrier(networkId, UtilsPopulate.newNewCarrierRelationship(carrierId));
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommoznName", "aoao");
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
          .path("/{network-id}/carriers/{carrier-id}").buildAndExpand(networkId, id);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteNetworkCarrier(networkId, id);
    deleteCarrier(carrierId);
    deleteNetwork(networkId);
  }

  private ResponseEntity<Void> postNewNetworkClinic(Long networkId, NewNetworkClinicRelationship o) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics").buildAndExpand(networkId);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewNetworkClinicRelationship>(o, getHeaders(schemaParameter)), Void.class);
  }

  private Long createNetworkClinic(Long networkId, NewNetworkClinicRelationship o) {
    ResponseEntity<Void> rPost = postNewNetworkClinic(networkId, o);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private int getNumOfClinics(Long networkId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics").buildAndExpand(networkId);

    ResponseEntity<List<RelatedClinic>> r = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<RelatedClinic>>() {
        });
    return r.getBody().size();
  }

  @Test
  public void test_060_postNetworkClinic() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long clinicId = createClinic();
    ResponseEntity<Void> rPost = postNewNetworkClinic(networkId,
        UtilsPopulate.newNewNetworkClinicRelationship(clinicId));
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue(rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
    deleteNetworkClinic(networkId, id);
    deleteNetwork(networkId);
  }

  @Test
  public void test_065_deleteNetworkClinic() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long clinicId = createClinic();
    Long id = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(clinicId));
    int count = getNumOfClinics(networkId);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}").buildAndExpand(networkId, id);

    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    Assert.assertEquals(count - 1, getNumOfClinics(networkId));
    deleteNetwork(networkId);
  }

  @Test
  public void test_070_patchNetworkClinic() throws NoEntityFoundException {

    Long networkId = createNetwork();
    Long clinicId = createClinic();
    Long id = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(clinicId));
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("OfficeNumber", "aoao");

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}").buildAndExpand(networkId, id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the clinic and check for the changes made in the patch

    ResponseEntity<NetworkClinicRelationship> rGet = restTemplate.exchange(uriComponents.encode().toUri(),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()), NetworkClinicRelationship.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("OfficeNumber"), rGet.getBody().getOfficeNumber());
    deleteNetworkClinic(networkId, id);
    deleteNetwork(networkId);
  }

  @Test
  public void test_075_patchNetworkClinicWrongProperty() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long clinicId = createClinic();
    Long id = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(clinicId));
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommoznName", "aoao");
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
          .path("/{network-id}/clinics/{clinic-id}").buildAndExpand(networkId, id);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteNetworkClinic(networkId, id);
    deleteNetwork(networkId);
  }

  @Test
  public void test_080_postNetworkClinicProvider() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long cId = createClinic();

    Long clinicId = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(cId));
    Long pId = createProvider();
    ResponseEntity<Void> rPost = postNewNetworkClinicProvider(networkId, clinicId,
        UtilsPopulate.newNewNetworkClinicProviderRelationship(pId, getTerminationLevel()));
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue(rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
    deleteNetworkClinicProvider(networkId, clinicId, id);
    deleteNetworkClinic(networkId, clinicId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_085_deleteNetworkClinicProvider() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long cId = createClinic();
    Long clinicId = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(cId));
    Long pId = createProvider();

    Long id = createNetworkClinicProvider(networkId, clinicId,
        UtilsPopulate.newNewNetworkClinicProviderRelationship(pId, getTerminationLevel()));
    int count = getNumOfClinicProviders(networkId, clinicId);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}/providers/{provider-id}").buildAndExpand(networkId, clinicId, id);

    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    Assert.assertEquals(count - 1, getNumOfClinicProviders(networkId, clinicId));

    deleteNetworkClinic(networkId, clinicId);
    deleteClinic(cId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_090_patchNetworkClinicProvider() throws NoEntityFoundException {

    Long networkId = createNetwork();
    Long cId = createClinic();
    Long clinicId = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(cId));
    Long pId = createProvider();
    Long id = createNetworkClinicProvider(networkId, clinicId,
        UtilsPopulate.newNewNetworkClinicProviderRelationship(pId, getTerminationLevel()));
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("OfficeNumber", "aoao");

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/clinics/{clinic-id}/providers/{provider-id}").buildAndExpand(networkId, clinicId, id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the clinic and check for the changes made in the patch

    ResponseEntity<NetworkClinicProviderRelationship> rGet = restTemplate.exchange(uriComponents.encode().toUri(),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders()), NetworkClinicProviderRelationship.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("OfficeNumber"), rGet.getBody().getOfficeNumber());
    deleteNetworkClinicProvider(networkId, clinicId, id);
    deleteNetworkClinic(networkId, clinicId);
    deleteClinic(cId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_095_patchNetworkClinicProviderWrongProperty() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long cId = createClinic();
    Long clinicId = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(cId));
    Long pId = createProvider();
    Long id = createNetworkClinicProvider(networkId, clinicId,
        UtilsPopulate.newNewNetworkClinicProviderRelationship(pId, getTerminationLevel()));
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();

      changes.put("CommoznName", "aoao");
      // changes.put("OfficeNumber", null);
      // Map<String, Object> fakeDataOwner = new HashMap<String, Object>();
      // fakeDataOwner.put("Id", 1L);
      // fakeDataOwner.put("Name", "Security Breach Ltd");
      // changes.put("DataOwner", fakeDataOwner);

      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
          .path("/{network-id}/clinics/{clinic-id}/providers/{provider-id}").buildAndExpand(networkId, clinicId, id);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteNetworkClinicProvider(networkId, clinicId, id);
    deleteNetworkClinic(networkId, clinicId);
    deleteNetwork(networkId);
  }

  @Test
  public void test_100_getNetworkProviders() throws NoEntityFoundException {
    Long networkId = createNetwork();
    Long cId = createClinic();
    Long clinicId = createNetworkClinic(networkId, UtilsPopulate.newNewNetworkClinicRelationship(cId));
    Long pId = createProvider();
    Long id = createNetworkClinicProvider(networkId, clinicId,
        UtilsPopulate.newNewNetworkClinicProviderRelationship(pId, getTerminationLevel()));

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/networks"))
        .path("/{network-id}/providers").buildAndExpand(networkId);
    ResponseEntity<List<RelatedProvider>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), new ParameterizedTypeReference<List<RelatedProvider>>() {
        });
    int count = rGet.getBody().size();
    deleteNetworkClinicProvider(networkId, clinicId, id);
    rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET, new HttpEntity<Object>(getHeaders()),
        new ParameterizedTypeReference<List<RelatedProvider>>() {
        });
    Assert.assertEquals(count - 1, rGet.getBody().size());

    deleteNetworkClinic(networkId, clinicId);
    deleteNetwork(networkId);
  }

}
