package com.anthem.specialty.provider.api.resources;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datamodel.dto.AddressImpl;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.NewLegalAddressImpl;
import com.anthem.specialty.provider.datamodel.dto.NewW9Impl;
import com.anthem.specialty.provider.datamodel.dto.W9Impl;
import com.anthem.specialty.provider.testutils.UtilsPopulate;

@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class W9Test extends BaseTest {

  @Parameter
  public String schemaParameter;

  @Parameters
  public static Collection<String> data() {
    Collection<String> params = new ArrayList<>();
    // params.add("horizon");
    // params.add("wellmark");
    params.add(null);
    return params;
  }

  private DataOwner getDataOwner() {
    ResponseEntity<List<DataOwner>> r = restTemplate.exchange(properties.getUri("/api/metadata/dataOwners"),
        HttpMethod.GET, new HttpEntity<Object>(getHeaders(schemaParameter)),
        new ParameterizedTypeReference<List<DataOwner>>() {
        });

    Assert.assertEquals("must get a dataOwner", HttpStatus.OK, r.getStatusCode());
    return r.getBody().stream().findAny().get();
  }

  private ResponseEntity<Void> postW9() {
    NewW9Impl clinic = UtilsPopulate.newNewW9(getDataOwner());
    return restTemplate.exchange(properties.getUri("/api/w9"), HttpMethod.POST,
        new HttpEntity<NewW9Impl>(clinic, getHeaders(schemaParameter)), Void.class);
  }

  private Long createW9() {
    ResponseEntity<Void> rPost = postW9();
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private HttpStatus deleteW9(Long id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9")).path("/{w9-id}")
        .buildAndExpand(id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class).getStatusCode();
  }

  private int getNumOfW9s() {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9")).build();
    ResponseEntity<List<W9Impl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<W9Impl>>() {
        });
    return rGet.getBody().size();
  }

  private ResponseEntity<Void> deleteW9LegalAddress(Long w9Id, Long addressId) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9"))
        .path("/{w9-id}/legalAddresses/{legal-address-id}").buildAndExpand(w9Id, addressId);

    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
  }

  private ResponseEntity<Void> postW9LegalAddress(Long w9Id, NewLegalAddressImpl address) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9"))
        .path("/{w9-id}/legalAddresses").buildAndExpand(w9Id);
    return restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.POST,
        new HttpEntity<NewLegalAddressImpl>(address, getHeaders(schemaParameter)), Void.class);
  }

  private Long createW9LegalAddress(Long w9Id, NewLegalAddressImpl address) {
    ResponseEntity<Void> rPost = postW9LegalAddress(w9Id, address);
    String location = rPost.getHeaders().getFirst("Location");
    return new Long(location.substring(location.lastIndexOf("/") + 1));
  }

  private int getNumOfAddresses(Long w9id) {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9"))
        .path("/{w9-id}/legalAddresses").buildAndExpand(w9id);
    ResponseEntity<List<AddressImpl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<AddressImpl>>() {
        });
    return rGet.getBody().size();
  }

  @Test
  public void test_000_getW9s() {
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9"))
        .queryParam("numRows", 3).build();
    ResponseEntity<List<W9Impl>> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)), new ParameterizedTypeReference<List<W9Impl>>() {
        });
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertTrue(3 >= rGet.getBody().size());
  }

  @Test
  public void test_010_createW9() {
    int maxrows = (int) config.getQuery().get("maxrows");

    int count = getNumOfW9s();
    ResponseEntity<Void> rPost = postW9();
    Assert.assertEquals("must get created status code on new w9", HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue("post must have provide link in the header", rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");

    int nrows = getNumOfW9s();
    Assert.assertTrue((count + 1) == nrows || nrows == maxrows);
    deleteW9(new Long(location.substring(location.lastIndexOf("/") + 1)));
  }

  @Test
  public void test_020_deleteW9() {
    Assert.assertEquals("must get OK status code deleting w9", HttpStatus.OK, deleteW9(createW9()));
  }

  @Test
  public void test_030_patchW9() {

    Long id = createW9();
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("IRSName", "aoao");

    // execute a patch
    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9")).path("/{w9-id}")
        .buildAndExpand(id);
    ResponseEntity<Void> rPatch = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
        new HttpEntity<Map<String, Object>>(changes, getHeaders()), Void.class);
    Assert.assertEquals(HttpStatus.OK, rPatch.getStatusCode());

    // retrieve the clinic and check for the changes made in the patch
    ResponseEntity<W9Impl> rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Object>(getHeaders()), W9Impl.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(changes.get("IRSName"), rGet.getBody().getIrsName());
    deleteW9(id);
  }

  @Test
  public void test_035_patchw9WrongProperty() {
    Long id = createW9();
    try {
      // create changes to the clinic
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("CommonName", "aoao");
      UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9")).path("/{w9-id}")
          .buildAndExpand(id);

      restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PATCH,
          new HttpEntity<Map<String, Object>>(changes, getHeaders(schemaParameter)), Void.class);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteW9(id);
  }

  @Test
  public void test_040_postW9LegalAddress() {
    Long w9id = createW9();
    ResponseEntity<Void> rPost = postW9LegalAddress(w9id, UtilsPopulate.newNewLegalAddress());
    Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
    Assert.assertTrue(rPost.getHeaders().containsKey("Location"));
    String location = rPost.getHeaders().getFirst("Location");
    Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
    deleteW9LegalAddress(w9id, id);
    deleteW9(w9id);
  }

  @Test
  public void test_041_deleteW9LegalAddress() {
    Long w9id = createW9();
    Long id1 = createW9LegalAddress(w9id, UtilsPopulate.newNewLegalAddress());
    int count = getNumOfAddresses(w9id);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9"))
        .path("/{w9-id}/legalAddresses/{legal-address-id}").buildAndExpand(w9id, id1);

    ResponseEntity<Void> rDel = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.DELETE,
        new HttpEntity<Void>(getHeaders(schemaParameter)), Void.class);
    Assert.assertEquals(HttpStatus.OK, rDel.getStatusCode());
    Assert.assertEquals(count - 1, getNumOfAddresses(w9id));

    deleteW9(w9id);
  }

  @Test
  public void test_042_postLegalAddressToWrongW9() {
    Long w9id = createW9();
    // use post and expect a 422
    try {
      postW9LegalAddress(w9id + 6789, UtilsPopulate.newNewLegalAddress());
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }
    deleteW9(w9id);
  }

  @Test
  public void test_050_putW9LegalAddress() {

    Long w9id = createW9();
    NewLegalAddressImpl a1 = UtilsPopulate.newNewLegalAddress();
    Long id1 = createW9LegalAddress(w9id, a1);

    UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(properties.getUri("/api/w9"))
        .path("/{w9-id}/legalAddresses/{legal-address-id}").buildAndExpand(w9id, id1);
    ResponseEntity<com.anthem.specialty.provider.datamodel.dto.LegalAddressImpl> rGet = restTemplate.exchange(
        uriComponents.encode().toUri(), HttpMethod.GET, new HttpEntity<Void>(getHeaders(schemaParameter)),
        com.anthem.specialty.provider.datamodel.dto.LegalAddressImpl.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    com.anthem.specialty.provider.datamodel.dto.LegalAddressImpl a2 = rGet.getBody();
    a2.setLine3(RandomStringUtils.random(6, true, false));

    ResponseEntity<Void> rPut = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.PUT,
        new HttpEntity<com.anthem.specialty.provider.datamodel.dto.LegalAddressImpl>(a2, getHeaders(schemaParameter)),
        Void.class);
    Assert.assertEquals(HttpStatus.OK, rPut.getStatusCode());

    rGet = restTemplate.exchange(uriComponents.encode().toUri(), HttpMethod.GET,
        new HttpEntity<Void>(getHeaders(schemaParameter)),
        com.anthem.specialty.provider.datamodel.dto.LegalAddressImpl.class);
    Assert.assertEquals(HttpStatus.OK, rGet.getStatusCode());
    Assert.assertEquals(rGet.getBody().getLine3(), a2.getLine3());

    deleteW9LegalAddress(w9id, a2.getId());
    deleteW9(w9id);
  }

}
