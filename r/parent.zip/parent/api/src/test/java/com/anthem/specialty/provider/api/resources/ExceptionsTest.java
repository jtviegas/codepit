package com.anthem.specialty.provider.api.resources;

import java.lang.reflect.Executable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;

import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.reflections.Reflections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;

import com.anthem.specialty.provider.api.BaseTest;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datamodel.dto.CoreDataEntity;
import com.anthem.specialty.provider.datamodel.dto.CoreDataEntityImpl;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriod;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.Patients;
import com.anthem.specialty.provider.datamodel.dto.PatientsImpl;
import com.anthem.specialty.provider.datamodel.dto.Services;
import com.anthem.specialty.provider.datamodel.dto.ServicesImpl;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiModelProperty;

/**
 * Uses reflection to inspect all methods of all controllers in package com.anthem.specialty.provider.api.resources. All
 * methods are then called with invalid parameters, and return code is compared with expected one. Create, Update -
 * POST, PUT, PATCH: 422 (Unable to process Entity) for validation failure, 409 (Conflict) if resource already exists.
 * Read - GET: 404 (Not Found), if ID not found or invalid.
 * 
 * @author jalmasi
 *
 */
@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ExceptionsTest extends BaseTest {

  public static final String PACKAGE = "com.anthem.specialty.provider.api.resources";

  @Autowired
  private LobService lobService;

  // fail after execution
  private boolean failAtEnd = false;

  private TreeSet<String> failures = new TreeSet<String>();

  // static to survive between tests
  private static TreeMap<String, Method> allMethods;

  // objects created during test(s), to be deleted afterwards
  private Map<String, String> created = new HashMap<String, String>();

  @Before
  @Override
  public void setUp() throws Exception {
    super.setUp();
    if (System.getProperty("failAtEnd") != null)
      failAtEnd = true;
  }

  private void processMetaData() throws Exception {
    if (allMethods == null)
      allMethods = new TreeMap<String, Method>();
    else
      return; // metadata already collected

    Reflections ref = new Reflections(PACKAGE);
    Set<Class<?>> classes = ref.getTypesAnnotatedWith(RestController.class);
    // int methodsTotal = 0;
    for (Class<?> cls : classes) {
      RequestMapping classMapping = cls.getAnnotation(RequestMapping.class);
      String topUri = classMapping.value()[0];
      if (topUri == null)
        topUri = "";

      Method[] methods = cls.getDeclaredMethods();
      for (Method m : methods) {
        RequestMapping rm = m.getAnnotation(RequestMapping.class);
        final String baseUri;
        if (rm == null) {
          continue;
        } else if (rm.value().length > 0) {
          baseUri = topUri + rm.value()[0];
        } else {
          baseUri = topUri;
        }
        // String uri = baseUri; // is going to be modified
        int skippedParamCount = 0;
        // Class<?> body = null;
        if (rm != null) {
          Assert.assertTrue("One class method must handle only one HTTP method", rm.method().length == 1);
          RequestMethod method = rm.method()[0];
          // analyse each parameter
          int pathVars = 0; // path variables contain object id
          for (Parameter p : m.getParameters()) {
            // each method parameter is either PathVariable, RequestParam or RequestBody
            PathVariable pv = p.getAnnotation(PathVariable.class);
            RequestParam rp = p.getAnnotation(RequestParam.class);
            RequestBody rb = p.getAnnotation(RequestBody.class);
            if (pv != null) {
              pathVars++;
              // uri = uri.replaceAll("\\{" + pv.value() + "\\}", "" + cnt--);
            } else if (rp != null) {
              if (rp.required()) {
                System.err.println("RequestParam required: " + methodName(m) + " " + rp.name());
                // All request parameters are optional, used for paging
                // Assert.fail("Mandatory parameters not supported yet!");
              } else {
                skippedParamCount++;
              }
            } else if (rb != null) {
              // body = p.getType();
            } else {
              // this method is not annotated with anything.
              // example GET /api/metadata -> MetaData.get(HttpServletRequest request)
              skippedParamCount++;
            }
          }
          System.out.println(method + " " + baseUri + ": " + m.getName() + " " + m.getParameterCount());
          // we process only methods having mandatory parameters
          if (m.getParameterCount() - skippedParamCount > 0) {
            allMethods.put(pathVars + "" + method + baseUri, m);
            // now we have all metadata we need
          }
        }

      }
    }

  }

  @Test
  public void testInvalidId() throws Exception {
    processMetaData();

    int methodsFailed = 0;
    int methodsPassed = 0;
    boolean fail = false;
    for (String key : allMethods.keySet()) {
      Method m = allMethods.get(key);
      String methodDescription = methodName(m);
      String httpMethod = key.substring(1, key.indexOf("/"));
      String uri = key.substring(key.indexOf("/"));

      Class<?> body = null;
      int cnt = Integer.MAX_VALUE;
      List<String> requestParams = null;
      for (Parameter p : m.getParameters()) {
        // each method parameter is either PathVariable, RequestParam or RequestBody
        PathVariable pv = p.getAnnotation(PathVariable.class);
        RequestBody rb = p.getAnnotation(RequestBody.class);
        RequestParam rp = p.getAnnotation(RequestParam.class);
        if (pv != null) {
          uri = uri.replaceAll("\\{" + pv.value() + "\\}", "" + cnt--);
        } else if (rp != null) {
          if (rp.required()) {
            if (requestParams == null)
              requestParams = new LinkedList<String>();
            // String param = rp.name() + "=" + p.getType().newInstance();
            String param = rp.name() + "=" + Integer.MAX_VALUE;
            requestParams.add(param);
          }
        } else if (rb != null) {
          body = p.getType();
        }
      }

      if ("GET".equals(httpMethod)) {
        if (body != null)
          Assert.fail("GET requests can't have body! Use path parameters in " + methodName(m));
        fail |= invoke(HttpMethod.GET, uri, HttpStatus.NOT_FOUND, m, requestParams);
      } else if ("DELETE".equals(httpMethod)) {
        if (body != null)
          Assert.fail("DELETE requests can't have body! Use path parameters in " + methodDescription);
        fail |= invoke(HttpMethod.DELETE, uri, HttpStatus.NOT_FOUND, m);
      } else if ("PUT".equals(httpMethod)) {
        if (body == null)
          Assert.fail("PUT request must have body! " + methodDescription);
        fail |= invoke(HttpMethod.PUT, uri, HttpStatus.UNPROCESSABLE_ENTITY, m, body);
      } else if ("PATCH".equals(httpMethod)) {
        if (body == null)
          Assert.fail("PATCH request must have body! " + methodDescription);
        // we test patch methods in-depth in another test
        // with validation implemented, we must have valid body value test this
        // fail |= invoke(HttpMethod.PATCH, uri, HttpStatus.NOT_FOUND, m, body);
      } else if ("POST".equals(httpMethod)) {
        if (body == null)
          Assert.fail("POST request must have body! " + methodDescription);
        // CHECKME: with validation implemented, we must have valid body value test this
        fail |= invoke(HttpMethod.POST, uri, HttpStatus.UNPROCESSABLE_ENTITY, m, body);
      } else {
        // ERROR
        Assert.fail("Unsupported method: " + httpMethod + ": " + methodDescription);
      }

      if (fail)
        methodsFailed++;
      else
        methodsPassed++;
    }

    for (String failed : failures) {
      System.err.println(failed);
    }
    System.err.println("Done, passed/failed/total " + methodsPassed + "/" + methodsFailed + "/" + allMethods.size());
    Assert.assertEquals("Tests passed", allMethods.size(), methodsPassed);
  }

  private String methodName(Method m) {
    if (m == null)
      return null;
    return m.getDeclaringClass().getSimpleName() + "." + m.getName();
  }

  private boolean invoke(HttpMethod method, String uri, HttpStatus expected, Method m, List<String> params) {
    return invoke(method, uri, expected, m, null, params);
  }

  private boolean invoke(HttpMethod method, String uri, HttpStatus expected, Method m)
      throws JsonProcessingException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    return invoke(method, uri, expected, m, (Class<?>) null);
  }

  private boolean invoke(HttpMethod method, String uri, HttpStatus expected, Method m, Class<?> body)
      throws JsonProcessingException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    String json = "";
    if (body != null) {
      Object instance = null;
      if (Map.class.isAssignableFrom(body)) {
        instance = new HashMap<Object, Object>();
      } else if (body.isInterface()) {
        instance = Class.forName(body.getName() + "Impl").newInstance();
      } else {
        instance = body.newInstance();
      }
      json = jsonMapper.writeValueAsString(instance);
    }
    return invoke(method, uri, expected, m, json, null);
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  private boolean invoke(HttpMethod method, String uri, HttpStatus expected, Method m, String json,
      List<String> params) {
    boolean fail = false;
    if (params != null) {
      // request parameters exist, append them to uri
      StringBuilder sb = new StringBuilder();
      for (String param : params) {
        sb.append(param);
        sb.append("&");
      }
      sb.deleteCharAt(sb.length() - 1);
      uri = uri + "?" + sb.toString();
    }
    System.out.println("Invoking " + method + " " + uri + " with " + json);
    try {
      ResponseEntity ret = restTemplate.exchange(properties.getUri(uri), method, new HttpEntity(json, getHeaders()),
          Void.class);
      fail = checkFail(m, expected, ret.getStatusCode());
    } catch (HttpStatusCodeException e) {
      System.out.println(methodName(m) + " -> " + e.getStatusCode());
      fail = checkFail(m, expected, e.getStatusCode());
    }
    return fail;
  }

  private boolean checkFail(Method m, HttpStatus expected, HttpStatus returned) {
    String call = methodName(m);
    if (!failAtEnd)
      Assert.assertEquals(call, expected, returned);
    if (!expected.equals(returned)) {
      String msg = call + " returned " + returned + " expected " + expected;
      failures.add(msg);
      System.err.println("ERROR: " + msg);
      return true;
    }
    return false;
  }

  @Test
  public void testUnprocessablePatch() throws Exception {
    processMetaData();

    failAtEnd = true; // last part of test is deletion of created objects

    int methodCount = 0;
    int methodsFailed = 0;
    int methodsPassed = 0;
    int methodsSkipped = 0;

    Stack<String> deleteMethods = new Stack<String>();
    // map is sorted by number of parameters, class and method
    for (String key : allMethods.keySet()) {
      boolean fail = false;
      if (key.contains("PATCH")) {

        methodCount++;
        Method patchMethod = allMethods.get(key);
        System.out.println(key + ": " + methodName(patchMethod));
        // process all parameters to patch method, we'll need them later
        StringBuilder paramKey = new StringBuilder();
        String patchUri = key.substring(key.indexOf("/"));
        Class<?> patchBody = null;
        String lastParameterName = null;
        for (Parameter p : patchMethod.getParameters()) {
          RequestBody rb = p.getAnnotation(RequestBody.class);
          PathVariable pv = p.getAnnotation(PathVariable.class);
          if (rb != null) {
            patchBody = p.getType();
          } else if (pv != null) {
            // paramKey is unique key to identify object and store ID returned from post method
            paramKey.append(pv.value());
            String id = created.get(paramKey.toString());
            // id is null only for one object, one that is about to be created by calling post method
            if (id != null)
              patchUri = patchUri.replaceAll("\\{" + pv.value() + "\\}", id);
            else
              lastParameterName = pv.value();
          }
        }

        // POST method has one path variable less than PATCH
        String postKey = key.replaceAll("PATCH", "POST");
        int pathVars = Integer.parseInt(postKey.substring(0, 1));
        int pos = postKey.lastIndexOf("/");
        postKey = (pathVars - 1) + postKey.substring(1, pos);

        Method postMethod = allMethods.get(postKey);
        Assert.assertNotNull("Method not found: " + postKey, postMethod);
        System.out.println("  " + postKey + ": " + methodName(postMethod));

        // now, first call POST method to create object
        String postUri = postKey.substring(postKey.indexOf("/"));
        Class<?> postBody = null;
        StringBuilder postParamKey = new StringBuilder();
        for (Parameter p : postMethod.getParameters()) {
          RequestBody rb = p.getAnnotation(RequestBody.class);
          PathVariable pv = p.getAnnotation(PathVariable.class);
          if (rb != null) {
            postBody = p.getType();
          } else if (pv != null) {
            postParamKey.append(pv.value());
            String id = created.get(postParamKey.toString());
            Assert.assertNotNull("No value found for " + postParamKey + " in " + postUri, id);
            postUri = postUri.replaceAll("\\{" + pv.value() + "\\}", id);
          }
        }

        // now finally execute POST method
        String id = create(HttpMethod.POST, postUri, postMethod, postBody, HttpStatus.CREATED);
        if (id == null) {
          // CHECKME: should every POST return ID?
          System.err.println("WARNING: No ID returned from " + postUri);
          // fail = true;
          methodsSkipped++;
          continue;
        }

        // at this point we know parameter name for object we just created, and it's id
        String createdParameterName = paramKey.toString();
        Assert.assertNull("INTERNAL ERROR: " + createdParameterName + " value already exists",
            created.get(createdParameterName));
        created.put(createdParameterName, id);
        System.out.println("Created " + createdParameterName + " = " + id);

        // find corresponding delete method
        String delKey = key.replaceAll("PATCH", "DELETE");
        Method delMethod = allMethods.get(delKey);
        System.out.println("  " + delKey + ": " + methodName(delMethod));
        deleteMethods.push(delKey); // CHECKME: prepare delete uri here?

        // try to post again, should fail
        // CHECKME: data model allow this for all relations-became-entities
        // create(HttpMethod.POST, postUri, postMethod, body, HttpStatus.CONFLICT);

        // then try to patch it with wrong data
        String wrongIdUri = patchUri.replaceAll("\\{" + lastParameterName + "\\}", "" + Integer.MAX_VALUE);
        patchUri = patchUri.replaceAll("\\{" + lastParameterName + "\\}", id);
        System.out.println("Patching " + patchUri);
        // 1) wrong ID has to return 404
        fail |= invoke(HttpMethod.PATCH, wrongIdUri, HttpStatus.NOT_FOUND, patchMethod, patchBody);
        // 2) null body has to return 422 HttpStatus.UNPROCESSABLE_ENTITY
        fail |= invoke(HttpMethod.PATCH, patchUri, HttpStatus.UNPROCESSABLE_ENTITY, patchMethod);
        // 3) empty body returns 200 OK
        fail |= invoke(HttpMethod.PATCH, patchUri, HttpStatus.OK, patchMethod, patchBody);
        // 4) validation failure has to result in 422 HttpStatus.UNPROCESSABLE_ENTITY
        fail |= invoke(HttpMethod.PATCH, patchUri, HttpStatus.UNPROCESSABLE_ENTITY, patchMethod,
            "{\"InvalidProperty\":\"something\"}", null);
        if (fail)
          methodsFailed++;
        else
          methodsPassed++;
      }
    }
    System.err.println("Inspected " + methodCount + " POST/PATCH methods, " + deleteMethods.size() + " DELETE methods");

    // call delete methods in opposite order, each has to return 200
    while (!deleteMethods.empty()) {
      String delKey = deleteMethods.pop();
      System.out.println(delKey);
      Method delMethod = allMethods.get(delKey);
      String uri = delKey.substring(delKey.indexOf("/"));
      if (delMethod != null) {
        StringBuilder paramKey = new StringBuilder();
        for (Parameter p : delMethod.getParameters()) {
          PathVariable pv = p.getAnnotation(PathVariable.class);
          if (pv != null) {
            paramKey.append(pv.value());
            String id = created.get(paramKey.toString());
            uri = uri.replaceAll("\\{" + pv.value() + "\\}", id);
          }
        }
        System.out.println(uri);
        if (invoke(HttpMethod.DELETE, uri, HttpStatus.OK, delMethod))
          methodsFailed++;
      } else {
        System.err.println("WARNING: delete method missing for " + delKey);
      }
    }

    lobService.deleteProvider(new Long(created.get("provider-id")));
    lobService.deleteNetwork(new Long(created.get("network-id")));

    System.err.println("Done, passed/skipped/failed/total " + methodsPassed + "/" + methodsSkipped + "/" + methodsFailed
        + "/" + methodCount);
    Assert.assertEquals("Tests passed", methodCount, methodsPassed + methodsSkipped);
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  private String create(HttpMethod method, String uri, Method m, Class<?> body, HttpStatus responseCode)
      throws JsonProcessingException, InstantiationException, IllegalAccessException, ClassNotFoundException,
      NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
    String json = "";
    String ret = null;
    if (body != null) {
      Object instance = null;
      if (Map.class.isAssignableFrom(body)) {
        instance = new HashMap();
        ((Map) instance).put("DataOwnerId", 1);
      } else if (body.isInterface()) {
        instance = Class.forName(body.getName() + "Impl").newInstance();
        setDefaults(body, instance);
      } else {
        instance = body.newInstance();
        setDefaults(body, instance);
      }
      json = jsonMapper.writeValueAsString(instance);
    }

    boolean fail = false;
    try {
      System.out.println("Invoking " + method + " " + uri + " with " + json);
      ResponseEntity response = restTemplate.exchange(properties.getUri(uri), method,
          new HttpEntity(json, getHeaders()), Void.class);
      fail = checkFail(m, responseCode, response.getStatusCode());
      // get header Location, id is behind last /
      List<String> location = response.getHeaders().get("Location");
      // CHECKME: fail test if no location is returned ?
      if (location == null) {
        System.err.println("WARNING: no location returned for POST " + uri);
      } else {
        // list should have one element only
        for (String loc : location) {
          ret = loc.substring(loc.lastIndexOf("/") + 1);
        }
      }
    } catch (HttpStatusCodeException e) {
      System.out.println(methodName(m) + " -> " + e.getStatusCode());
      fail = checkFail(m, responseCode, e.getStatusCode());
    }
    return ret;
  }

  String processApiModelProperty(Executable e, String defaultValue) {
    String value = defaultValue;
    ApiModelProperty a = e.getAnnotation(ApiModelProperty.class);
    if (a != null) {
      String allowed = a.allowableValues();
      if (allowed != null && allowed.length() > 0) {
        String[] values = allowed.split(",");
        value = values[0];
      }
    }
    return value;
  }

  private void setDefaults(Class<?> cls, Object instance) throws NoSuchMethodException, SecurityException,
      IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    for (Method m : cls.getMethods()) {
      if (m.getName().startsWith("set")) {
        for (Parameter p : m.getParameters()) {
          Executable e = p.getDeclaringExecutable();
          // if (e.getAnnotation(NotNull.class) != null) { // useful when object model matches database
          if (Long.class.equals(p.getType())) {
            m.invoke(instance, 1L);
          } else if (Integer.class.equals(p.getType())) {
            m.invoke(instance, 1);
          } else if (String.class.equals(p.getType())) {
            m.invoke(instance, processApiModelProperty(e, "1"));
          } else if (Boolean.class.equals(p.getType())) {
            m.invoke(instance, new Boolean(false));
          } else if (Character.class.equals(p.getType())) {
            String value = processApiModelProperty(e, "N");
            m.invoke(instance, value.toCharArray()[0]);
          } else if (Date.class.equals(p.getType())) {
            m.invoke(instance, new Date());
          } else if (p.getType().isEnum()) {
            m.invoke(instance, p.getType().getEnumConstants()[0]);

            // domain classes
          } else if (CoreDataEntity.class.equals(p.getType())) {
            // setSomething -> something-id
            String key = e.getName().substring(3).toLowerCase() + "-id";
            // get id of created object
            String id = created.get(key);
            if (id != null)
              m.invoke(instance, new CoreDataEntityImpl(new Long(id)));
            else
              System.err.print("No ID for " + key + " to use in " + m);
          } else if (EffectivePeriod.class.equals(p.getType())) {
            m.invoke(instance, new EffectivePeriodImpl(LocalDate.now(), null));
          } else if (Patients.class.equals(p.getType())) {
            Patients patients = new PatientsImpl();
            setDefaults(Patients.class, patients);
            m.invoke(instance, patients);
          } else if (Services.class.equals(p.getType())) {
            Services services = new ServicesImpl();
            setDefaults(Services.class, services);
            m.invoke(instance, services);
          } else {
            System.err.println("Unsupported parameter type " + p.getType() + " " + methodName(m));
          }
          // }
        }
      }
    }
  }

}
