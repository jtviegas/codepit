package com.anthem.specialty.provider.api.resources;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestContextManager;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;

import com.anthem.specialty.provider.api.TestProperties;
import com.anthem.specialty.provider.common.restclient.Id;
import com.anthem.specialty.provider.common.restclient.RestClient;
import com.anthem.specialty.provider.datalayer.exceptions.NoEntityFoundException;
import com.anthem.specialty.provider.datalayer.functional.ClinicDtoToRelatedClinic;
import com.anthem.specialty.provider.datalayer.functional.DataOwnerToDataOwnerDto;
import com.anthem.specialty.provider.datalayer.functional.LinkResolver;
import com.anthem.specialty.provider.datalayer.functional.NewDocumentToDocumentDto;
import com.anthem.specialty.provider.datalayer.functional.NewProviderClinicToProviderClinicDto;
import com.anthem.specialty.provider.datalayer.functional.NewProviderToProviderDto;
import com.anthem.specialty.provider.datalayer.functional.ProviderFocusReviewToNewProviderFocusReview;
import com.anthem.specialty.provider.datalayer.functional.ProviderToNewProvider;
import com.anthem.specialty.provider.datalayer.functional.SpecialtyToSpecialtyDto;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.dto.Clinic;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.DisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.Document;
import com.anthem.specialty.provider.datamodel.dto.DocumentType;
import com.anthem.specialty.provider.datamodel.dto.EffectivePeriodImpl;
import com.anthem.specialty.provider.datamodel.dto.Language;
import com.anthem.specialty.provider.datamodel.dto.License;
import com.anthem.specialty.provider.datamodel.dto.Medicaid;
import com.anthem.specialty.provider.datamodel.dto.NewDisciplinaryAction;
import com.anthem.specialty.provider.datamodel.dto.NewDocument;
import com.anthem.specialty.provider.datamodel.dto.NewLanguageImpl;
import com.anthem.specialty.provider.datamodel.dto.NewLicense;
import com.anthem.specialty.provider.datamodel.dto.NewLicenseImpl;
import com.anthem.specialty.provider.datamodel.dto.NewProvider;
import com.anthem.specialty.provider.datamodel.dto.NewProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.NewProviderClinicImpl;
import com.anthem.specialty.provider.datamodel.dto.NewProviderCredentials;
import com.anthem.specialty.provider.datamodel.dto.NewProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.NewProviderSpecialty;
import com.anthem.specialty.provider.datamodel.dto.NewSanctionImpl;
import com.anthem.specialty.provider.datamodel.dto.Provider;
import com.anthem.specialty.provider.datamodel.dto.ProviderClinic;
import com.anthem.specialty.provider.datamodel.dto.ProviderFocusReview;
import com.anthem.specialty.provider.datamodel.dto.ProviderSpecialty;
import com.anthem.specialty.provider.datamodel.dto.Specialty;
import com.anthem.specialty.provider.datamodel.dto.SpecialtyClassification;
import com.anthem.specialty.provider.datamodel.dto.SpecialtyType;
import com.anthem.specialty.provider.datamodel.dto.SpecialtyTypeImpl;
import com.anthem.specialty.provider.datamodel.schemas.core.TerminationLevel;
import com.anthem.specialty.provider.datamodel.schemas.lob.Network;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinic;
import com.anthem.specialty.provider.datamodel.schemas.lob.NetworkClinicProvider;
import com.anthem.specialty.provider.testutils.UtilTest;
import com.anthem.specialty.provider.testutils.UtilsPopulate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@ActiveProfiles("test")
@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProvidersTest {

  @Parameter
  public String schemaParameter;

  @Autowired
  private TestProperties properties;

  @Autowired
  protected LobService lobService;

  @Autowired
  protected MetadataService metadataService;

  @Autowired
  protected ObjectMapper jsonMapper;

  private UtilTest util;

  @Autowired
  private RestClient client;

  @Parameters
  public static Collection<String> data() {
    Collection<String> params = new ArrayList<>();
    // params.add("horizon");
    // params.add("wellmark");
    params.add(null);
    return params;
  }

  private String buildUrl(String path) {
    return String.format("%s://%s:%s%s", properties.getScheme(), properties.getHost(), properties.getPort(), path);
  }

  @Before
  public void setUp() throws Exception {
    new TestContextManager(getClass()).prepareTestInstance(this);
    util = new UtilTest();
  }

  // ================================== /

  // get collection tests
  // - 000_get_nplus1 - get n objects, create object x, check num of objects is now n+1, delete object x
  @Test
  public void test_provider_000_get_nplus1() throws NoEntityFoundException {

    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
    queryParams.add("pageSize", "3");
    Id id = null;
    try {
      int n = client.getXTotalCount(client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
          buildUrl("/api/providers"), queryParams);
      id = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl),
          client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
          buildUrl("/api/providers"));
      Assert.assertEquals(n + 1,
          client.getXTotalCount(client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
              buildUrl("/api/providers"), queryParams));
    } finally {
      lobService.deleteProvider(id.asLong());
    }
  }

  // - 001_get_z - count n objects, create z objects, get z starting in n, assert size z, delete the z objects
  @Test
  public void test_provider_001_get_z() throws NoEntityFoundException {
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
    queryParams.add("pageSize", "3");
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    List<Id> ids = new ArrayList<Id>();

    try {
      int n = client.getXTotalCount(header, path, queryParams);
      int z = 3;

      for (int i = 0; i < z; i++)
        ids.add(client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header, path));
      queryParams.clear();
      queryParams.add("pageSize", Integer.toString(0 == n ? z : n));
      queryParams.add("pageIndex", Integer.toString(0 == n ? 0 : 1));
      Assert.assertEquals(z, client.getCount(header, path, queryParams));
    } finally {
      for (Id id : ids)
        lobService.deleteProvider(id.asLong());
    }

  }

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
    queryParams.add("pageSize", "3");
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    Long id = null;

    try {
      int n = client.getXTotalCount(header, path, queryParams);
      Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
      TerminationLevel tl = util.getTerminationLevel();
      NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
      o.setFWAComplianceDate(LocalDate.of(2018, Month.MAY, 2));
      ResponseEntity<Void> r = client.post(o, header, path);
      Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
      String location = r.getHeaders().getFirst("Location");
      id = new Long(location.substring(location.lastIndexOf("/") + 1));
      Assert.assertEquals(n + 1, client.getXTotalCount(header, path, queryParams));
      Optional<?> a = client.get(new ParameterizedTypeReference<Provider>() {
      }, header, String.format("%s/{provider-id}", path), null, id);
      Assert.assertEquals(o, new ProviderToNewProvider().apply((Provider) a.get()));
    } finally {
      lobService.deleteProvider(id);
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
    queryParams.add("pageSize", "3");
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    List<Long> ids = new ArrayList<Long>();

    try {
      int n = client.getXTotalCount(header, path, queryParams);
      int nObjs = 3;
      Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
      TerminationLevel tl = util.getTerminationLevel();
      for (int i = 0; i < nObjs; i++) {
        NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
        o.setFWAComplianceDate(LocalDate.of(2018, Month.MAY, 2));
        ResponseEntity<Void> r = client.post(o, header, path);
        Assert.assertEquals(HttpStatus.CREATED, r.getStatusCode());
        String location = r.getHeaders().getFirst("Location");
        ids.add(new Long(location.substring(location.lastIndexOf("/") + 1)));
      }
      Assert.assertEquals(n + nObjs, client.getXTotalCount(header, path, queryParams));
    } finally {
      for (Long id : ids)
        lobService.deleteProvider(id);
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_102_post_notvalid() {

    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
    });
    map.put("kjhfadjkhg", 84749835);

    try {
      client.post(map, header, path);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409
  @Test
  public void test_provider_103_post_failconstraint() {
    // TODO no constraint in db to test
  }

  // ================================== /{provider-id}

  // patch tests
  // - 300_patch_checkprop - create obj, patch a property, get the object verify the property, delete the obj
  @Test
  public void test_provider_300_patch_checkprop() throws NoEntityFoundException {

    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Id id = client.postAndGetId(o, header, path);
    path = buildUrl("/api/providers/{provider-id}");

    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("StateProviderNo", "xpto");
    ResponseEntity<Void> r = client.patch(changes, header, path, id);
    Assert.assertEquals(HttpStatus.OK, r.getStatusCode());

    Provider p = (Provider) client.get(new ParameterizedTypeReference<Provider>() {
    }, header, path, null, id).get();
    Assert.assertEquals(changes.get("StateProviderNo"), p.getStateProviderNo());

    lobService.deleteProvider(id.asLong());

  }

  // - 301_patch_checkequals - create obj, get it, patch it, get it, test equals, delete it
  @Test
  public void test_provider_301_patch_checkequals() throws NoEntityFoundException {
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Id id = null;

    try {
      id = client.postAndGetId(o, header, path);
      path = buildUrl("/api/providers/{provider-id}");
      Provider p = (Provider) client.get(new ParameterizedTypeReference<Provider>() {
      }, header, path, null, id).get();
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("StateProviderNo", "xpto");
      ResponseEntity<Void> r = client.patch(changes, header, path, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      p.setStateProviderNo((String) changes.get("StateProviderNo"));
      Provider p2 = (Provider) client.get(new ParameterizedTypeReference<Provider>() {
      }, header, path, null, id).get();
      Assert.assertEquals(p, p2);
    } finally {
      lobService.deleteProvider(id.asLong());
    }

  }

  // - 302_patch_notvalid - create obj, get it, patch it with invalid property, get 422, delete the obj
  @Test
  public void test_provider_302_patch_notvalid() throws NoEntityFoundException {
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Id id = client.postAndGetId(o, header, path);

    path = buildUrl("/api/providers/{provider-id}");
    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("StatePXXroviderNo", "xpto");
    try {
      client.patch(changes, header, path, id);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    }

    lobService.deleteProvider(id.asLong());
  }

  // - 303_patch_notfound - try to patch not existent obj, get 404
  @Test
  public void test_provider_303_patch_notfound() throws NoEntityFoundException {
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Id id = null;

    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("StateProviderNo", "xpto");
    try {
      id = client.postAndGetId(o, header, path);
      path = buildUrl("/api/providers/{provider-id}");
      client.patch(changes, header, path, id.asLong() + 6789);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(id.asLong());
    }

  }

  // get not collection tests
  // - 500_post_get_and_check - create object , retrieve it and check equals, delete it
  @Test
  public void test_provider_500_get_nplus1() throws NoEntityFoundException {
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Id id = client.postAndGetId(o, header, path);

    Provider p0 = new NewProviderToProviderDto(new Function<Long, DataOwner>() {
      @Override
      public DataOwner apply(Long t) {
        com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dOw = null;
        try {
          dOw = metadataService.getDataOwner(t);
        } catch (NoEntityFoundException e) {
          throw new RuntimeException(String.format("couldn't find dataowner: %d", t));
        }
        return new DataOwnerToDataOwnerDto().apply(dOw);
      }
    }).apply(o);
    p0.setId(id.asLong());
    p0.setLinks(
        Arrays.asList(new LinkResolver().apply(new String[] { id.toString() }, LinkResolver.Type.provider, true)));

    path = buildUrl("/api/providers/{provider-id}");
    Provider p = (Provider) client.get(new ParameterizedTypeReference<Provider>() {
    }, header, path, null, id).get();

    Assert.assertEquals(p0, p);

    lobService.deleteProvider(id.asLong());
  }

  // - 501_get_notfound - try to get not existent obj, get 404
  @Test
  public void test_provider_501_get_notfound() throws NoEntityFoundException {
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    String path = buildUrl("/api/providers");
    NewProvider o = UtilsPopulate.newNewProvider(dataOwnerId, tl);
    Id id = null;

    try {
      id = client.postAndGetId(o, header, path);
      path = buildUrl("/api/providers/{provider-id}");
      client.get(new ParameterizedTypeReference<Provider>() {
      }, header, path, null, id.asLong() + 1234567).get();
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(id.asLong());
    }

  }

  // ================================== /{provider-id}/clinics

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_clinic_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinicImpl newProviderClinic = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      ResponseEntity<Void> rPost = client.post(newProviderClinic, header,
          buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      String location = rPost.getHeaders().getFirst("Location");
      Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId));
      Optional<List<ProviderClinic>> rObjs = client.get(new ParameterizedTypeReference<List<ProviderClinic>>() {
      }, header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      ProviderClinic oInDb = rObjs.get().stream().filter(o -> o.getId().equals(id)).findFirst().get();
      ProviderClinic oCreated = new NewProviderClinicToProviderClinicDto(new Function<Long, Clinic>() {
        @Override
        public Clinic apply(Long t) {
          return lobService.getClinicDto(t);
        }
      }).apply(newProviderClinic);
      oCreated.setId(oInDb.getId());
      Assert.assertEquals(oInDb, oCreated);
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_clinic_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;
    List<Id> clinicIds = new ArrayList<Id>();

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      int z = 3;
      for (int i = 0; i < z; i++) {
        Id clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
        clinicIds.add(clinicId);
        client.postAndGetId(UtilsPopulate.newNewProviderClinic(clinicId.asLong()), header,
            buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      }
      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId));
    } finally {
      for (Id cId : clinicIds)
        lobService.deleteClinic(cId.asLong());

      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_clinic_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
        buildUrl("/api/providers"));

    Id clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
    NewProviderClinicImpl o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
    Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
    });
    map.put("kjhfadjkhg", 84749835);

    try {
      client.post(map, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }
  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409
  @Test
  public void test_provider_clinic_103_post_failconstraint() throws NoEntityFoundException {
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
        buildUrl("/api/providers"));
    Id clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
    NewProviderClinicImpl o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());

    client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

    NewProviderClinicImpl o2 = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
    o2.setEffective(new EffectivePeriodImpl(o.getEffective().getFrom(), o.getEffective().getTo()));
    try {
      client.post(o2, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // get collection tests
  // - 000_get_nplus1 - get n objects, create object x, check num of objects is now n+1, delete object x
  @Test
  public void test_provider_clinic_000_get_nplus1() throws NoEntityFoundException {
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinicImpl o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId));
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/clinics/{clinic-id}

  // patch tests
  // - 300_patch_checkprop - create obj, patch a property, get the object verify the property, delete the obj
  @Test
  public void test_provider_clinic_300_patch_checkprop() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      Id id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Comments", RandomStringUtils.randomAlphabetic(12));

      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId, id);

      Optional<List<ProviderClinic>> rObjs = client.get(new ParameterizedTypeReference<List<ProviderClinic>>() {
      }, header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      ProviderClinic oInDb = rObjs.get().stream().filter(p -> p.getId().equals(id.asLong())).findFirst().get();

      Assert.assertEquals(changes.get("Comments"), oInDb.getComments());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 301_patch_checkequals - create obj, get it, patch it, get it, test equals, delete it
  @Test
  public void test_provider_clinic_301_patch_checkequals() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      Id id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      Optional<List<ProviderClinic>> rObjs = client.get(new ParameterizedTypeReference<List<ProviderClinic>>() {
      }, header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      ProviderClinic oInDb = rObjs.get().stream().filter(p -> p.getId().equals(id.asLong())).findFirst().get();
      oInDb.setComments(RandomStringUtils.randomAlphabetic(12));
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Comments", oInDb.getComments());
      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId, id);
      rObjs = client.get(new ParameterizedTypeReference<List<ProviderClinic>>() {
      }, header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      ProviderClinic oInDb2 = rObjs.get().stream().filter(p -> p.getId().equals(id.asLong())).findFirst().get();
      Assert.assertEquals(oInDb, oInDb2);
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 302_patch_notvalid - create obj, get it, patch it with invalid property, get 422, delete the obj
  @Test
  public void test_provider_clinic_302_patch_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
        buildUrl("/api/providers"));
    Id clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));

    NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());

    Map<String, Object> changes = new HashMap<String, Object>();
    changes.put("Com3333ments", "XYZ");

    try {
      Id id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);
      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId, id);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 303_patch_notfound - try to patch not existent obj, get 404
  @Test
  public void test_provider_clinic_303_patch_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null;

    Map<String, Object> changes = new HashMap<String, Object>();

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      Id id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      try {
        client.patch(changes, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"),
            providerId.asLong() + 6789, id);
        Assert.fail();
      } catch (HttpStatusCodeException e) {
        Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
      }

      try {
        client.patch(changes, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId,
            id.asLong() + 6789);
        Assert.fail();
      } catch (HttpStatusCodeException e) {
        Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
      }

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 200, check n objs
  @Test
  public void test_provider_clinic_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, id = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      ResponseEntity<Void> r = client.delete(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"),
          providerId, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n - 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId));

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_clinic_201_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));

      int z = 3, y = 2;
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId);
      List<Id> ids = new ArrayList<Id>();
      for (int i = 0; i < z; i++) {
        NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
        o.setEffective(
            new EffectivePeriodImpl(o.getEffective().getFrom().plusDays(1), LocalDate.now().plusDays(i + 1)));
        ids.add(client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId));
      }
      for (int i = 0; i < y; i++)
        client.delete(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId, ids.remove(i));

      Assert.assertEquals(n + z - y,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId));

      for (Id id : ids)
        client.delete(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId, id);

      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics"), null, providerId));

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_clinic_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, id = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic o = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      client.delete(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId,
          id.asLong() + 6789);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // ================================== /{provider-id}/clinics/{clinic-id}/documents

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_clinic_documents_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null,
          providerId, providerClinic);

      NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
      ResponseEntity<Void> rPost = client.post(obj, header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), providerId, providerClinic);
      String location = rPost.getHeaders().getFirst("Location");
      final Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));

      Optional<Document> oInDb = client.getFromCollection(new ParameterizedTypeReference<List<Document>>() {
      }, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"),
          o -> o.getControlNumber().equals(id), providerId, providerClinic);

      Clinic clinic = lobService.getClinicDto(clinicId.asLong());
      Document objCreated = new NewDocumentToDocumentDto(clinic.getDataOwner(), oInDb.get().getId(),
          oInDb.get().getLinks()).apply(obj);

      Assert.assertEquals(oInDb.get(), objCreated);

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  // @Test
  public void test_provider_clinic_documents_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;

    try {

      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null,
          providerId, providerClinic);

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
        ResponseEntity<Void> rPost = client.post(obj, header,
            buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), providerId, providerClinic);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_clinic_documents_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;
    try {

      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      NewDocument o = UtilsPopulate.newNewDocumentControl(docType);
      Map<String, Object> map = jsonMapper.convertValue(o, new TypeReference<Map<String, Object>>() {
      });
      map.put("kjhfadjkhg", 84749835);

      client.post(map, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), providerId,
          providerClinic);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409
  // no unique index except id

  // get collection tests
  // - 000_get_nplus1 - get n objects, create object x, check num of objects is now n+1, delete object x
  @Test
  public void test_provider_clinic_documents_000_get_nplus1() throws NoEntityFoundException {
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null,
          providerId, providerClinic);

      NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
      client.post(obj, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), providerId,
          providerClinic);
      Assert.assertEquals(n + 1, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/clinics/{clinic-id}/documents/{document-control-number}
  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs
  @Test
  public void test_provider_clinic_documents_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null,
          providerId, providerClinic);

      NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
      Id id = client.postAndGetId(obj, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"),
          providerId, providerClinic);
      Assert.assertEquals(n + 1, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));

      Optional<Document> oInDb = client.getFromCollection(new ParameterizedTypeReference<List<Document>>() {
      }, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"),
          o -> o.getControlNumber().equals(id), providerId, providerClinic);

      ResponseEntity<Void> r = client.delete(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents/{document-control-number}"), providerId,
          providerClinic, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_clinic_documents_201_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null,
          providerId, providerClinic);

      List<Id> ids = new ArrayList<Id>();
      int z = 3;
      for (int i = 0; i < z; i++) {
        NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
        ids.add(client.postAndGetId(obj, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"),
            providerId, providerClinic));
      }
      Assert.assertEquals(n + z, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));

      int y = 2;
      for (int i = 0; i < y; i++) {
        ResponseEntity<Void> r = client.delete(header,
            buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents/{document-control-number}"),
            providerId, providerClinic, ids.remove(i));
        Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      }
      Assert.assertEquals(n + z - y, client.getCount(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"), null, providerId, providerClinic));

      for (Id id : ids)
        client.delete(header,
            buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents/{document-control-number}"),
            providerId, providerClinic, id);

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_clinic_documents_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    DocumentType docType = util.getDocumentType();

    Id providerId = null, clinicId = null, providerClinic = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      NewProviderClinic pc = UtilsPopulate.newNewProviderClinic(clinicId.asLong());
      providerClinic = client.postAndGetId(pc, header, buildUrl("/api/providers/{provider-id}/clinics"), providerId);

      NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
      Id id = client.postAndGetId(obj, header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents"),
          providerId, providerClinic);

      client.delete(header,
          buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}/documents/{document-control-number}"), providerId,
          providerClinic, id.asLong() + 56789);
      Assert.fail();

    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // ================================== /{provider-id}/credentials

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  // can't implement completely, no location in header after posting a new one
  @Test
  public void test_provider_credentials_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/credentials"), null, providerId);

      NewProviderCredentials obj = UtilsPopulate.newNewProviderCredential();
      ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/credentials"),
          providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/credentials"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_credentials_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/credentials"), null, providerId);

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewProviderCredentials obj = UtilsPopulate.newNewProviderCredential();
        ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/credentials"),
            providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }
      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/credentials"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_credentials_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Com3333ments", "XYZ");

      client.post(changes, header, buildUrl("/api/providers/{provider-id}/credentials"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 103_post_failconstraint - check uniqueness constraint and get a 409 - no unique index apart from the id

  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x

  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/disciplinaryActions

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_disciplinaryActions_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId);

      NewDisciplinaryAction obj = UtilsPopulate.newNewDisciplinaryAction();
      ResponseEntity<Void> rPost = client.post(obj, header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs

  @Test
  public void test_provider_disciplinaryActions_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId);

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewDisciplinaryAction obj = UtilsPopulate.newNewDisciplinaryAction();
        ResponseEntity<Void> rPost = client.post(obj, header,
            buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }
      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_disciplinaryActions_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Com3333ments", "XYZ");

      client.post(changes, header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409 [ no unique constrain other that ID ]

  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/disciplinaryActions/{disciplinary-action-id}

  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs
  @Test
  public void test_provider_disciplinaryActions_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, id = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId);
      id = client.postAndGetId(UtilsPopulate.newNewDisciplinaryAction(), header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));
      ResponseEntity<Void> r = client.delete(header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"), providerId, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_disciplinaryActions_200_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    int z = 3;
    Id providerId = null;
    List<Id> ids = new ArrayList<Id>();
    try {

      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId);

      for (int i = 0; i < z; i++)
        ids.add(client.postAndGetId(UtilsPopulate.newNewDisciplinaryAction(), header,
            buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId));

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));

      ResponseEntity<Void> r = client.delete(header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"), providerId,
          ids.remove(0));
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());

      Assert.assertEquals(n + z - 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));

      for (Id id : ids) {
        r = client.delete(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"),
            providerId, id);
        Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      }

      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_disciplinaryActions_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, id = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      id = client.postAndGetId(UtilsPopulate.newNewDisciplinaryAction(), header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
      client.delete(header, buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"),
          providerId, id.asLong() + 6789);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // patch tests
  // - 300_patch_checkprop - create obj, patch a property, get the object verify the property, delete the obj
  @Test
  public void test_provider_disciplinaryActions_300_patch_checkprop() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));

      final Id id = client.postAndGetId(UtilsPopulate.newNewDisciplinaryAction(), header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);

      Optional<DisciplinaryAction> o = client
          .getFromCollection(new ParameterizedTypeReference<List<DisciplinaryAction>>() {
          }, header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), l -> l.getId().equals(id.asLong()),
              providerId);
      o.get().setDescription("xpto");

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Description", "xpto");

      ResponseEntity<Void> r = client.patch(changes, header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"), providerId, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Optional<DisciplinaryAction> o2 = client
          .getFromCollection(new ParameterizedTypeReference<List<DisciplinaryAction>>() {
          }, header, buildUrl("/api/providers/{provider-id}/disciplinaryActions"), l -> l.getId().equals(id.asLong()),
              providerId);
      Assert.assertEquals(o.get(), o2.get());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 301_patch_checkequals - create obj, get it, patch it, get it, test equals, delete it [duplicated on
  // 300_patch_checkprop]
  // - 302_patch_notvalid - create obj, get it, patch it with invalid property, get 422, delete the obj
  @Test
  public void test_provider_disciplinaryActions_302_patch_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      final Id id = client.postAndGetId(UtilsPopulate.newNewDisciplinaryAction(), header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Desscription", "xpto");
      client.patch(changes, header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"), providerId, id);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 303_patch_notfound - try to patch not existent obj, get 404
  @Test
  public void test_provider_disciplinaryActions_303_patch_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      final Id id = client.postAndGetId(UtilsPopulate.newNewDisciplinaryAction(), header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions"), providerId);
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Description", "xpto");
      client.patch(changes, header,
          buildUrl("/api/providers/{provider-id}/disciplinaryActions/{disciplinary-action-id}"), providerId,
          id.asLong() + 6789);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // ================================== /{provider-id}/documents

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj

  @Test
  public void test_provider_documents_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    DocumentType docType = util.getDocumentType();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/documents"), null, providerId);

      NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
      ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/documents"),
          providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/documents"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs

  @Test
  public void test_provider_documents_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    DocumentType docType = util.getDocumentType();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/documents"), null, providerId);

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewDocument obj = UtilsPopulate.newNewDocumentControl(docType);
        ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/documents"),
            providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }
      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/documents"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_documents_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Com3333ments", "XYZ");

      client.post(changes, header, buildUrl("/api/providers/{provider-id}/documents"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409 [ no unique index apart from ID]

  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/focusReviews

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_focusReviews_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId);

      NewProviderFocusReview obj = UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong());
      ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/focusReviews"),
          providerId);
      String location = rPost.getHeaders().getFirst("Location");
      final Long id = new Long(location.substring(location.lastIndexOf("/") + 1));
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId));

      Optional<ProviderFocusReview> s = client
          .getFromCollection(new ParameterizedTypeReference<List<ProviderFocusReview>>() {
          }, header, buildUrl("/api/providers/{provider-id}/focusReviews"), p -> p.getId().equals(id), providerId);

      // hand over the computed links to the initial object to perform the equals without breaking
      obj.setLinks(s.get().getLinks());
      Assert.assertEquals(new ProviderFocusReviewToNewProviderFocusReview().apply(s.get()), obj);

    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_focusReviews_100_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId);
      int z = 3;
      for (int i = 0; i < z; i++) {
        NewProviderFocusReview obj = UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(),
            networkGroupId.asLong());
        ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/focusReviews"),
            providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId));

    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422

  @Test
  public void test_provider_focusReviews_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Com3333ments", "XYZ");

      client.post(changes, header, buildUrl("/api/providers/{provider-id}/focusReviews"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // - 103_post_failconstraint - [no unique index besides ID] check uniqueness constraint and get a 409
  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/focusReviews/{focus-review-id}
  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs
  @Test
  public void test_provider_focusReviews_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId);

      NewProviderFocusReview obj = UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong());
      final Id id = client.postAndGetId(obj, header, buildUrl("/api/providers/{provider-id}/focusReviews"), providerId);

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId));
      ResponseEntity<Void> r = client.delete(header,
          buildUrl("/api/providers/{provider-id}/focusReviews/{focus-review-id}"), providerId, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId));
    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_focusReviews_200_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId);

      int z = 3;
      List<Id> ids = new ArrayList<Id>();
      for (int i = 0; i < z; i++)
        ids.add(client.postAndGetId(UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong()),
            header, buildUrl("/api/providers/{provider-id}/focusReviews"), providerId));

      Assert.assertEquals(n + 3,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId));

      for (Id id : ids)
        client.delete(header, buildUrl("/api/providers/{provider-id}/focusReviews/{focus-review-id}"), providerId, id);

      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/focusReviews"), null, providerId));

    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }
  // - 202_del_notfound - try to delete invalid obj, get a 404

  @Test
  public void test_provider_focusReviews_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      final Id id = client.postAndGetId(
          UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong()), header,
          buildUrl("/api/providers/{provider-id}/focusReviews"), providerId);

      client.delete(header, buildUrl("/api/providers/{provider-id}/focusReviews/{focus-review-id}"), providerId,
          id.asLong() + 6789);

      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // patch tests
  // - 300_patch_checkprop - create obj, patch a property, get the object verify the property, delete the obj
  @Test
  public void test_provider_focusReviews_300_patch_checkprop() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      final Id id = client.postAndGetId(
          UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong()), header,
          buildUrl("/api/providers/{provider-id}/focusReviews"), providerId);

      Optional<ProviderFocusReview> o = client
          .getFromCollection(new ParameterizedTypeReference<List<ProviderFocusReview>>() {
          }, header, buildUrl("/api/providers/{provider-id}/focusReviews"), l -> l.getId().equals(id.asLong()),
              providerId);
      o.get().setComments("xpto");

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Comments", "xpto");

      ResponseEntity<Void> r = client.patch(changes, header,
          buildUrl("/api/providers/{provider-id}/focusReviews/{focus-review-id}"), providerId, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());

      Optional<ProviderFocusReview> o2 = client
          .getFromCollection(new ParameterizedTypeReference<List<ProviderFocusReview>>() {
          }, header, buildUrl("/api/providers/{provider-id}/focusReviews"), l -> l.getId().equals(id.asLong()),
              providerId);

      Assert.assertEquals(o.get(), o2.get());
    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // - 301_patch_checkequals - [ already n 300_patch_checkprop ] create obj, get it, patch it, get it, test equals,
  // delete it
  // - 302_patch_notvalid - create obj, get it, patch it with invalid property, get 422, delete the obj
  @Test
  public void test_provider_focusReviews_302_patch_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      final Id id = client.postAndGetId(
          UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong()), header,
          buildUrl("/api/providers/{provider-id}/focusReviews"), providerId);

      Optional<ProviderFocusReview> o = client
          .getFromCollection(new ParameterizedTypeReference<List<ProviderFocusReview>>() {
          }, header, buildUrl("/api/providers/{provider-id}/focusReviews"), l -> l.getId().equals(id.asLong()),
              providerId);
      o.get().setComments("xpto");

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Commensssts", "xpto");

      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/focusReviews/{focus-review-id}"), providerId,
          id);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }
  // - 303_patch_notfound - try to patch not existent obj, get 404

  @Test
  public void test_provider_focusReviews_303_patch_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();

    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dataOwner = metadataService.getDataOwners().stream()
        .findFirst().get();
    Long dataOwnerId = dataOwner.getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, clinicId = null, networkGroupId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      networkGroupId = Id.create(lobService.setNetworkGroup(UtilsPopulate.newNetworkGroup(dataOwner)).getId());

      final Id id = client.postAndGetId(
          UtilsPopulate.newNewProviderFocusReview(clinicId.asLong(), networkGroupId.asLong()), header,
          buildUrl("/api/providers/{provider-id}/focusReviews"), providerId);

      Optional<ProviderFocusReview> o = client
          .getFromCollection(new ParameterizedTypeReference<List<ProviderFocusReview>>() {
          }, header, buildUrl("/api/providers/{provider-id}/focusReviews"), l -> l.getId().equals(id.asLong()),
              providerId);
      o.get().setComments("xpto");

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Comments", "xpto");

      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/focusReviews/{focus-review-id}"), providerId,
          id.asLong() + 6789);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteNetworkGroup(networkGroupId.asLong());
      lobService.deleteProvider(providerId.asLong());
      lobService.deleteClinic(clinicId.asLong());
    }

  }

  // ================================== /{provider-id}/languages

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_languages_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId);

      NewLanguageImpl obj = UtilsPopulate.newNewLanguage();
      ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/languages"),
          providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_languages_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId);

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewLanguageImpl obj = UtilsPopulate.newNewLanguage();
        ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/languages"),
            providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }
      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 102_post_notvalid - try to post invalid obj, check status code 422

  @Test
  public void test_provider_languages_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Com3333ments", "XYZ");

      client.post(changes, header, buildUrl("/api/providers/{provider-id}/languages"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409
  @Test
  public void test_provider_languages_103_post_failconstraint() throws NoEntityFoundException {
    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;
    NewLanguageImpl obj = UtilsPopulate.newNewLanguage();
    NewLanguageImpl obj2 = UtilsPopulate.newNewLanguage();
    obj2.setName(obj.getName());
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      client.post(obj, header, buildUrl("/api/providers/{provider-id}/languages"), providerId);
      client.post(obj2, header, buildUrl("/api/providers/{provider-id}/languages"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/languages/{language-id}

  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs
  @Test
  public void test_provider_language_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, languageId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId);

      client.post(UtilsPopulate.newNewLanguage(), header, buildUrl("/api/providers/{provider-id}/languages"),
          providerId);
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId));

      languageId = Id.create(client.get(new ParameterizedTypeReference<List<Language>>() {
      }, header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId).get().stream().findFirst().get()
          .getId());

      ResponseEntity<Void> r = client.delete(header, buildUrl("/api/providers/{provider-id}/languages/{language-id}"),
          providerId, languageId);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_language_200_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    List<Language> languages = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId);
      int z = 3;
      for (int i = 0; i < z; i++)
        client.post(UtilsPopulate.newNewLanguage(), header, buildUrl("/api/providers/{provider-id}/languages"),
            providerId);

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId));

      languages = client.get(new ParameterizedTypeReference<List<Language>>() {
      }, header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId).get().stream()
          .collect(Collectors.toList());
      for (Language l : languages) {
        ResponseEntity<Void> r = client.delete(header, buildUrl("/api/providers/{provider-id}/languages/{language-id}"),
            providerId, l.getId());
        Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      }
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_languages_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null, languageId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      client.post(UtilsPopulate.newNewLanguage(), header, buildUrl("/api/providers/{provider-id}/languages"),
          providerId);
      languageId = Id.create(client.get(new ParameterizedTypeReference<List<Language>>() {
      }, header, buildUrl("/api/providers/{provider-id}/languages"), null, providerId).get().stream().findFirst().get()
          .getId());

      client.delete(header, buildUrl("/api/providers/{provider-id}/clinics/{clinic-id}"), providerId,
          languageId.asLong() + 6789);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // ================================== /{provider-id}/licenses

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj

  @Test
  public void test_provider_licenses_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId);

      NewLicenseImpl obj = UtilsPopulate.newNewLicense();
      ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/licenses"),
          providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs

  @Test
  public void test_provider_licenses_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    int z = 3;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId);

      for (int i = 0; i < z; i++) {
        NewLicenseImpl obj = UtilsPopulate.newNewLicense();
        ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/licenses"),
            providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422

  @Test
  public void test_provider_licenses_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
        buildUrl("/api/providers"));
    NewLicenseImpl obj = UtilsPopulate.newNewLicense();
    Map<String, Object> map = jsonMapper.convertValue(obj, new TypeReference<Map<String, Object>>() {
    });
    map.put("kjhfadjkhg", 84749835);

    try {
      client.post(map, header, buildUrl("/api/providers/{provider-id}/licenses"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }
  }

  // - 103_post_failconstraint - [ only ID as unique index ] check uniqueness constraint and get a 409

  // get not collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/licenses/{license-number}

  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs

  @Test
  public void test_provider_licenses_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId);
      NewLicenseImpl obj = UtilsPopulate.newNewLicense();

      final Id id = client.postAndGetId(obj, header, buildUrl("/api/providers/{provider-id}/licenses"), providerId);

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId));

      ResponseEntity<Void> r = client.delete(header, buildUrl("/api/providers/{provider-id}/licenses/{license-number}"),
          providerId, id.asString());
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_licenses_201_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    List<License> objs = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId);
      int z = 3;
      for (int i = 0; i < z; i++)
        client.post(UtilsPopulate.newNewLicense(), header, buildUrl("/api/providers/{provider-id}/licenses"),
            providerId);

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId));

      objs = client.get(new ParameterizedTypeReference<List<License>>() {
      }, header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId).get().stream()
          .collect(Collectors.toList());

      for (License l : objs) {
        ResponseEntity<Void> r = client.delete(header,
            buildUrl("/api/providers/{provider-id}/licenses/{license-number}"), providerId, l.getLicenseNumber());
        Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      }
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/licenses"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_licenses_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, id = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      id = client.postAndGetId(UtilsPopulate.newNewLicense(), header, buildUrl("/api/providers/{provider-id}/licenses"),
          providerId);

      client.delete(header, buildUrl("/api/providers/{provider-id}/licenses/{license-number}"), providerId,
          String.format("%s-%s", id.asString(), "6789"));
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // patch tests
  // - 300_patch_checkprop - create obj, patch a property, get the object verify the property, delete the obj
  @Test
  public void test_provider_licenses_300_patch_checkprop() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      NewLicense o = UtilsPopulate.newNewLicense();
      o.setIssuingState("XI");
      final Id id = client.postAndGetId(o, header, buildUrl("/api/providers/{provider-id}/licenses"), providerId);
      Optional<License> opt1 = client.getFromCollection(new ParameterizedTypeReference<List<License>>() {
      }, header, buildUrl("/api/providers/{provider-id}/licenses"), l -> l.getLicenseNumber().equals(id.asString()),
          providerId);

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("IssuingState", "XO");

      opt1.get().setIssuingState((String) changes.get("IssuingState"));

      ResponseEntity<Void> r = client.patch(changes, header,
          buildUrl("/api/providers/{provider-id}/licenses/{license-number}"), providerId, id);
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());

      Optional<License> opt2 = client.getFromCollection(new ParameterizedTypeReference<List<License>>() {
      }, header, buildUrl("/api/providers/{provider-id}/licenses"), l -> l.getLicenseNumber().equals(id.asString()),
          providerId);

      Assert.assertEquals(changes.get("IssuingState"), opt2.get().getIssuingState());
      Assert.assertEquals(opt1.get(), opt2.get());

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 301_patch_checkequals - [ duplicated in 300_patch_checkprop ] create obj, get it, patch it, get it, test equals,
  // delete it
  // - 302_patch_notvalid - create obj, get it, patch it with invalid property, get 422, delete the obj
  @Test
  public void test_provider_licenses_302_patch_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      final Id id = client.postAndGetId(UtilsPopulate.newNewLicense(), header,
          buildUrl("/api/providers/{provider-id}/licenses"), providerId);

      Map<String, Object> changes = new HashMap<String, Object>();
      changes.put("Commensssts", "xpto");
      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/licenses/{license-number}"), providerId, id);

      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 303_patch_notfound - try to patch not existent obj, get 404

  @Test
  public void test_provider_licenses_303_patch_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      final Id id = client.postAndGetId(UtilsPopulate.newNewLicense(), header,
          buildUrl("/api/providers/{provider-id}/licenses"), providerId);

      Map<String, Object> changes = new HashMap<String, Object>();

      changes.put("IssuingState", "FF");

      client.patch(changes, header, buildUrl("/api/providers/{provider-id}/licenses/{license-number}"), providerId,
          String.format("%s-%s", id, "6789"));
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // ================================== /{provider-id}/medicaid

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_medicaid_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);

      Medicaid obj = UtilsPopulate.newNewMedicaid();
      ResponseEntity<Void> rPost = client.post(obj, header, buildUrl("/api/providers/{provider-id}/medicaid"),
          providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_medicaid_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);

      int z = 3;
      for (int i = 0; i < z; i++) {
        ResponseEntity<Void> rPost = client.post(UtilsPopulate.newNewMedicaid(), header,
            buildUrl("/api/providers/{provider-id}/medicaid"), providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422
  @Test
  public void test_provider_medicaid_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
        buildUrl("/api/providers"));
    Medicaid obj = UtilsPopulate.newNewMedicaid();
    Map<String, Object> map = jsonMapper.convertValue(obj, new TypeReference<Map<String, Object>>() {
    });
    map.put("kjhfadjkhg", 84749835);

    try {
      client.post(map, header, buildUrl("/api/providers/{provider-id}/medicaid"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }
  }

  // - 103_post_failconstraint - [ no unique index besides id] check uniqueness constraint and get a 409

  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // ================================== /{provider-id}/medicaid/{medicaid-number}
  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs
  @Test
  public void test_provider_medicaid_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);
      Medicaid obj = UtilsPopulate.newNewMedicaid();

      client.post(obj, header, buildUrl("/api/providers/{provider-id}/medicaid"), providerId);

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

      ResponseEntity<Void> r = client.delete(header,
          buildUrl("/api/providers/{provider-id}/medicaid/{medicaid-number}"), providerId, obj.getNumber());
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y
  @Test
  public void test_provider_medicaid_201_del_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    List<Medicaid> objs = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);
      int z = 3;
      for (int i = 0; i < z; i++)
        client.post(UtilsPopulate.newNewMedicaid(), header, buildUrl("/api/providers/{provider-id}/medicaid"),
            providerId);

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

      objs = client.get(new ParameterizedTypeReference<List<Medicaid>>() {
      }, header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId).get().stream()
          .collect(Collectors.toList());

      for (Medicaid l : objs) {
        ResponseEntity<Void> r = client.delete(header,
            buildUrl("/api/providers/{provider-id}/medicaid/{medicaid-number}"), providerId, l.getNumber());
        Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      }
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_medicaid_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    try {
      Medicaid obj = UtilsPopulate.newNewMedicaid();
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      client.post(obj, header, buildUrl("/api/providers/{provider-id}/medicaid"), providerId);

      client.delete(header, buildUrl("/api/providers/{provider-id}/medicaid/{medicaid-number}"), providerId,
          String.format("%s-%s", obj.getNumber(), "6789"));
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // put not collection tests
  // - 600_put_update - create obj, count, retrieve, post changed obj, check status 200 and n, retrieve and check
  // equals, delete

  @Test
  public void test_provider_medicaid_600_put_update() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);
      Medicaid obj = UtilsPopulate.newNewMedicaid();
      client.post(obj, header, buildUrl("/api/providers/{provider-id}/medicaid"), providerId);
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

      Medicaid o = client.getFromCollection(new ParameterizedTypeReference<List<Medicaid>>() {
      }, header, buildUrl("/api/providers/{provider-id}/medicaid"), e -> e.getNumber().equals(obj.getNumber()),
          providerId).get();
      o.setNumber(RandomStringUtils.random(20, true, false));

      ResponseEntity<Void> r = client.put(o, header,
          buildUrl("/api/providers/{provider-id}/medicaid/{medicaid-number}"), providerId, obj.getNumber());
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());

      Medicaid o2 = client.getFromCollection(new ParameterizedTypeReference<List<Medicaid>>() {
      }, header, buildUrl("/api/providers/{provider-id}/medicaid"), e -> e.getNumber().equals(o.getNumber()),
          providerId).get();
      Assert.assertEquals(o, o2);

    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 601_put_notvalid - try to post invalid obj, check status code 422

  @Test
  public void test_provider_medicaid_601_put_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);
      Medicaid obj = UtilsPopulate.newNewMedicaid();
      client.post(obj, header, buildUrl("/api/providers/{provider-id}/medicaid"), providerId);
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

      Medicaid o = client.getFromCollection(new ParameterizedTypeReference<List<Medicaid>>() {
      }, header, buildUrl("/api/providers/{provider-id}/medicaid"), e -> e.getNumber().equals(obj.getNumber()),
          providerId).get();
      o.setState("XX");

      client.put(o, header, buildUrl("/api/providers/{provider-id}/medicaid/{medicaid-number}"), providerId,
          obj.getNumber());
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 602_put_failconstraint - [ id is the only unique index ] try to put non unique constraint and get a 409
  // - 603_put_notfound - try to put not existent id, get 404
  @Test
  public void test_provider_medicaid_603_put_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();
    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));

      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId);
      Medicaid obj = UtilsPopulate.newNewMedicaid();
      client.post(obj, header, buildUrl("/api/providers/{provider-id}/medicaid"), providerId);
      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/medicaid"), null, providerId));

      Medicaid o = client.getFromCollection(new ParameterizedTypeReference<List<Medicaid>>() {
      }, header, buildUrl("/api/providers/{provider-id}/medicaid"), e -> e.getNumber().equals(obj.getNumber()),
          providerId).get();
      o.setState("XX");

      client.put(o, header, buildUrl("/api/providers/{provider-id}/medicaid/{medicaid-number}"), providerId,
          String.format("%s-%s", obj.getNumber(), "6789"));
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // ================================== /{provider-id}/networks
  // get collection tests
  // - 000_get_nplus1 - get n objects, create object x, check num of objects is now n+1,
  // delete object x
  @Test
  public void test_provider_networks_000_get_nplus1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dOwner = metadataService.getDataOwner(dataOwnerId);
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    Id clinicId = null, networkId = null, networkClinicId = null, networkClinicProviderId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
          buildUrl("/api/providers/{provider-id}/networks"), null, providerId);

      Network network = lobService.setNetwork(UtilsPopulate.newNetwork(dOwner));
      networkId = Id.create(network.getId());
      com.anthem.specialty.provider.datamodel.schemas.lob.Clinic clinic = lobService
          .setClinic(UtilsPopulate.newClinic(dOwner));
      clinicId = Id.create(clinic.getId());
      NetworkClinic nc = UtilsPopulate.newNetworkClinic(dOwner);
      nc.setClinic(clinic);
      nc.setNetwork(network);
      NetworkClinic networkClinic = lobService.setNetworkClinic(nc);
      networkClinicId = Id.create(networkClinic.getId());
      com.anthem.specialty.provider.datamodel.schemas.lob.Provider provider = lobService
          .findProvider(providerId.asLong());
      NetworkClinicProvider o = UtilsPopulate.newNetworkClinicProvider(dOwner,
          metadataService.getTerminationLevel(tl.getId()));
      o.setNetworkClinic(networkClinic);
      o.setProvider(provider);
      o = lobService.setNetworkClinicProvider(o);
      networkClinicProviderId = Id.create(o.getId());

      Assert.assertEquals(n + 1,
          client.getCount(client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
              buildUrl("/api/providers/{provider-id}/networks"), null, providerId));

    } finally {
      lobService.deleteNetworkClinicProvider(networkClinicProviderId.asLong());
      lobService.deleteNetworkClinic(networkClinicId.asLong());
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteNetwork(networkId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }
  }

  // - 001_get_z - get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects
  @Test
  public void test_provider_networks_001_get_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    com.anthem.specialty.provider.datamodel.schemas.core.DataOwner dOwner = metadataService.getDataOwner(dataOwnerId);
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    Id clinicId = null;
    List<Long> ncpIds = new ArrayList<Long>(), networkIds = new ArrayList<Long>(),
        networkClinicIds = new ArrayList<Long>();
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
          buildUrl("/api/providers/{provider-id}/networks"), null, providerId);

      com.anthem.specialty.provider.datamodel.schemas.lob.Clinic clinic = lobService
          .setClinic(UtilsPopulate.newClinic(dOwner));
      clinicId = Id.create(clinic.getId());

      com.anthem.specialty.provider.datamodel.schemas.lob.Provider provider = lobService
          .findProvider(providerId.asLong());

      int z = 3;
      for (int i = 0; i < z; i++) {

        Network network = lobService.setNetwork(UtilsPopulate.newNetwork(dOwner));
        networkIds.add(network.getId());

        NetworkClinic nc = UtilsPopulate.newNetworkClinic(dOwner);
        nc.setClinic(clinic);
        nc.setNetwork(network);
        NetworkClinic networkClinic = lobService.setNetworkClinic(nc);
        networkClinicIds.add(networkClinic.getId());

        NetworkClinicProvider o = UtilsPopulate.newNetworkClinicProvider(dOwner,
            metadataService.getTerminationLevel(tl.getId()));
        o.setNetworkClinic(networkClinic);
        o.setProvider(provider);
        o = lobService.setNetworkClinicProvider(o);
        ncpIds.add(o.getId());
      }

      Assert.assertEquals(n + z,
          client.getCount(client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter).build(),
              buildUrl("/api/providers/{provider-id}/networks"), null, providerId));

    } finally {
      for (Long id : ncpIds)
        lobService.deleteNetworkClinicProvider(id);
      for (Long id : networkClinicIds)
        lobService.deleteNetworkClinic(id);
      for (Long id : networkIds)
        lobService.deleteNetwork(id);
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }
  }
  // ================================== /{provider-id}/sanctions

  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - get n objects, create z+1 objects and get them with limit z, assert z, delete the z+1 objects
  @Test
  public void test_provider_sanctions_001_get_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId);
      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      Clinic clinic = client.get(new ParameterizedTypeReference<Clinic>() {
      }, header, buildUrl("/api/clinics/{clinic-id}"), null, clinicId.asString()).get();

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewSanctionImpl ns = UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic));
        ResponseEntity<Void> rPost = client.post(
            UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic)), header,
            buildUrl("/api/providers/{provider-id}/sanctions"), providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId));

    } catch (Exception e) {
      System.out.println(e);
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }
  }

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_sanctions_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId);

      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      Clinic clinic = client.get(new ParameterizedTypeReference<Clinic>() {
      }, header, buildUrl("/api/clinics/{clinic-id}"), null, clinicId.asString()).get();

      NewSanctionImpl ns = UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic));
      ResponseEntity<Void> rPost = client.post(
          UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic)), header,
          buildUrl("/api/providers/{provider-id}/sanctions"), providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId));

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_sanctions_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId);

      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      Clinic clinic = client.get(new ParameterizedTypeReference<Clinic>() {
      }, header, buildUrl("/api/clinics/{clinic-id}"), null, clinicId.asString()).get();

      int z = 3;
      for (int i = 0; i < z; i++) {
        NewSanctionImpl ns = UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic));
        ResponseEntity<Void> rPost = client.post(
            UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic)), header,
            buildUrl("/api/providers/{provider-id}/sanctions"), providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId));

    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 102_post_notvalid - try to post invalid obj, check status code 422

  @Test
  public void test_provider_sanctions_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null, clinicId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/sanctions"), null, providerId);

      clinicId = client.postAndGetId(UtilsPopulate.newNewClinic(dataOwnerId), header, buildUrl("/api/clinics"));
      Clinic clinic = client.get(new ParameterizedTypeReference<Clinic>() {
      }, header, buildUrl("/api/clinics/{clinic-id}"), null, clinicId.asString()).get();

      NewSanctionImpl ns = UtilsPopulate.newNewSanction(new ClinicDtoToRelatedClinic().apply(clinic));

      Map<String, Object> map = jsonMapper.convertValue(ns, new TypeReference<Map<String, Object>>() {
      });
      map.put("kjhfadjkhg", 84749835);

      client.post(map, header, buildUrl("/api/providers/{provider-id}/sanctions"), providerId);
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteClinic(clinicId.asLong());
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409 - [ no unique constraint other than id ]

  // ================================== /{provider-id}/specialties

  // get collection tests
  // - 000_get_nplus1 - [Duplicated on 100_post_1] get n objects, create object x, check num of objects is now n+1,
  // delete object x
  // - 001_get_z - [Duplicated on 101_post_z] get n objects, create z+1 objects and get them with limit z, assert z,
  // delete the z+1 objects

  // post tests
  // - 100_post_1 - count n objs, create one, check status 201 and n+1 objs, retrieve obj and check equals, delete obj
  @Test
  public void test_provider_specialties_100_post_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId);

      com.anthem.specialty.provider.datamodel.dto.Specialty spc = new SpecialtyToSpecialtyDto()
          .apply(metadataService.getSpecialties().stream().findAny().get());
      SpecialtyType spt = new SpecialtyTypeImpl();
      spt.setType(SpecialtyClassification.Primary);
      spt.setCode(spc.getCode());
      spt.setDescription(spc.getDescription());

      ResponseEntity<Void> rPost = client.post(UtilsPopulate.newNewProviderSpecialty(spt), header,
          buildUrl("/api/providers/{provider-id}/specialties"), providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId));

      Optional<ProviderSpecialty> o = client
          .getFromCollection(new ParameterizedTypeReference<List<ProviderSpecialty>>() {
          }, header, buildUrl("/api/providers/{provider-id}/specialties"),
              p -> p.getSpecialtyCode().getCode().equals(spt.getCode()), providerId);

      Assert.assertEquals(spc.getDescription(), o.get().getSpecialtyCode().getDescription());

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 101_post_z - count n objs, create z, check n+z and 201, delete z objs
  @Test
  public void test_provider_specialties_101_post_z() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId);

      final int z = 3;
      final List<Specialty> specialties = new ArrayList<Specialty>();

      for (int i = 0; i < z; i++) {
        Specialty spc = new SpecialtyToSpecialtyDto()
            .apply(metadataService.getSpecialties().stream().filter(p -> !specialties.contains(p)).findFirst().get());
        specialties.add(spc);

        SpecialtyType spt = new SpecialtyTypeImpl();
        spt.setType(SpecialtyClassification.Primary);
        spt.setCode(spc.getCode());
        spt.setDescription(spc.getDescription());

        ResponseEntity<Void> rPost = client.post(UtilsPopulate.newNewProviderSpecialty(spt), header,
            buildUrl("/api/providers/{provider-id}/specialties"), providerId);
        Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());
      }

      Assert.assertEquals(n + z,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId));

    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }
  // - 102_post_notvalid - try to post invalid obj, check status code 422

  @Test
  public void test_provider_specialties_102_post_notvalid() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId);

      com.anthem.specialty.provider.datamodel.dto.Specialty spc = new SpecialtyToSpecialtyDto()
          .apply(metadataService.getSpecialties().stream().findAny().get());
      SpecialtyType spt = new SpecialtyTypeImpl();
      spt.setType(SpecialtyClassification.Primary);
      spt.setCode(spc.getCode());
      spt.setDescription(spc.getDescription());

      NewProviderSpecialty nps = UtilsPopulate.newNewProviderSpecialty(spt);
      Map<String, Object> map = jsonMapper.convertValue(nps, new TypeReference<Map<String, Object>>() {
      });
      map.put("kjhfadjkhg", 84749835);

      client.post(map, header, buildUrl("/api/providers/{provider-id}/specialties"), providerId);
      Assert.fail();

    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 103_post_failconstraint - check uniqueness constraint and get a 409 [no unique index apart from id]

  // ================================== /{provider-id}/specialties/{specialty-code}

  // delete tests
  // - 200_del_1 - check n objs, create one obj, check n+1 objs, delete obj, check status 2000, check n objs
  @Test
  public void test_provider_specialties_200_del_1() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;

    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId);

      com.anthem.specialty.provider.datamodel.dto.Specialty spc = new SpecialtyToSpecialtyDto()
          .apply(metadataService.getSpecialties().stream().findAny().get());
      SpecialtyType spt = new SpecialtyTypeImpl();
      spt.setType(SpecialtyClassification.Primary);
      spt.setCode(spc.getCode());
      spt.setDescription(spc.getDescription());

      ResponseEntity<Void> rPost = client.post(UtilsPopulate.newNewProviderSpecialty(spt), header,
          buildUrl("/api/providers/{provider-id}/specialties"), providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId));

      ResponseEntity<Void> r = client.delete(header,
          buildUrl("/api/providers/{provider-id}/specialties/{specialty-code}"), providerId, spt.getCode());
      Assert.assertEquals(HttpStatus.OK, r.getStatusCode());
      Assert.assertEquals(n,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId));
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

  // - 201_del_z - check n objs, create z, check n+z, delete y objs and check status 200, check n+z-y, delete remaining
  // z-y

  // - 202_del_notfound - try to delete invalid obj, get a 404
  @Test
  public void test_provider_specialties_202_del_notfound() throws NoEntityFoundException {

    MultiValueMap<String, String> header = client.getHeadersBuilder().withAuthentication().withTenant(schemaParameter)
        .build();
    Long dataOwnerId = util.getDataOwner(schemaParameter).getId();
    TerminationLevel tl = util.getTerminationLevel();

    Id providerId = null;
    try {
      providerId = client.postAndGetId(UtilsPopulate.newNewProvider(dataOwnerId, tl), header,
          buildUrl("/api/providers"));
      int n = client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId);

      com.anthem.specialty.provider.datamodel.dto.Specialty spc = new SpecialtyToSpecialtyDto()
          .apply(metadataService.getSpecialties().stream().findAny().get());
      SpecialtyType spt = new SpecialtyTypeImpl();
      spt.setType(SpecialtyClassification.Primary);
      spt.setCode(spc.getCode());
      spt.setDescription(spc.getDescription());

      ResponseEntity<Void> rPost = client.post(UtilsPopulate.newNewProviderSpecialty(spt), header,
          buildUrl("/api/providers/{provider-id}/specialties"), providerId);
      Assert.assertEquals(HttpStatus.CREATED, rPost.getStatusCode());

      Assert.assertEquals(n + 1,
          client.getCount(header, buildUrl("/api/providers/{provider-id}/specialties"), null, providerId));

      client.delete(header, buildUrl("/api/providers/{provider-id}/specialties/{specialty-code}"), providerId,
          String.format("%s-%s", spt.getCode(), "6789"));
      Assert.fail();
    } catch (HttpStatusCodeException e) {
      Assert.assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    } finally {
      lobService.deleteProvider(providerId.asLong());
    }

  }

}
