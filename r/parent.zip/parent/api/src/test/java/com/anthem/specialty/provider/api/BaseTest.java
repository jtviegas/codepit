package com.anthem.specialty.provider.api;

import static java.lang.String.format;

import java.nio.charset.Charset;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestContextManager;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.anthem.specialty.provider.api.config.Config;
import com.anthem.specialty.provider.datalayer.services.LobService;
import com.anthem.specialty.provider.datalayer.services.MetadataService;
import com.anthem.specialty.provider.datamodel.dto.DataOwner;
import com.anthem.specialty.provider.datamodel.dto.DataOwnerImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Base test class to extend and implement integration tests. Provides an http client of type {@code RestTemplate} to
 * query the api endpoints. Note that {@code TestConfig} is wired in, reflecting the configuration specified in
 * application-test.yml
 * 
 * @author jviegas
 *
 */

@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@ActiveProfiles("test")
public class BaseTest {

  private static final String X_HTTP_METHOD_OVERRIDE_HEADER = "X-HTTP-Method-Override";

  @Autowired
  protected TestProperties properties;

  @Autowired
  protected LobService lobService;

  @Autowired
  protected Config config;

  @Autowired
  protected MetadataService metadataService;

  protected RestTemplate restTemplate;

  private TestContextManager testContextManager;

  @Autowired
  protected ObjectMapper jsonMapper;

  private static List<DataOwner> dataOwners = Arrays.asList(new DataOwnerImpl(1L, "Anthem"),
      new DataOwnerImpl(2L, "Wellmark"), new DataOwnerImpl(3L, "Horizon"), new DataOwnerImpl(4L, "Dentemax"),
      new DataOwnerImpl(6L, "Diversified"), new DataOwnerImpl(7L, "DeCare"), new DataOwnerImpl(8L, "Empire"),
      new DataOwnerImpl(9L, "Government"), new DataOwnerImpl(10L, "WellPoint"));

  @Before
  public void setUp() throws Exception {

    this.testContextManager = new TestContextManager(getClass());
    this.testContextManager.prepareTestInstance(this);

    KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());

    keyStore.load(BaseTest.class.getClassLoader().getResourceAsStream(properties.getKeystorefile()),
        properties.getKeystorepassword().toCharArray());

    SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(
        new SSLContextBuilder().loadTrustMaterial(null, new TrustSelfSignedStrategy())
            .loadKeyMaterial(keyStore, properties.getKeystorepassword().toCharArray()).build(),
        NoopHostnameVerifier.INSTANCE);

    HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();

    ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
    restTemplate = new RestTemplate(requestFactory);

  }

  protected MultiValueMap<String, String> getHeaders(boolean patchOverride, boolean headerAuthentication) {
    return getHeaders(null, patchOverride, headerAuthentication);
  }

  protected MultiValueMap<String, String> getHeaders() {
    return getHeaders(null, false);
  }

  protected MultiValueMap<String, String> getHeaders(boolean patchOverride) {
    return getHeaders(null, patchOverride);
  }

  protected MultiValueMap<String, String> getHeaders(String tenant) {
    return getHeaders(tenant, false);
  }

  protected MultiValueMap<String, String> getHeaders(String tenant, boolean patchOverride) {
    return getHeaders(tenant, patchOverride, true);
  }

  protected MultiValueMap<String, String> getHeaders(String tenant, boolean patchOverride,
      boolean headerAuthentication) {

    MultiValueMap<String, String> header = new LinkedMultiValueMap<String, String>();

    if (headerAuthentication) {
      String auth = format("%s:%s", properties.getApiuser(), properties.getApipassword());
      String encodedAuth = new String(Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII"))));
      String authHeader = format("Basic %s", new String(encodedAuth));
      header.add("Authorization", authHeader);
    }

    header.add("Content-Type", "application/json");

    if (patchOverride)
      header.add(X_HTTP_METHOD_OVERRIDE_HEADER, "patch");

    if (null != tenant)
      header.add("tenant", tenant);
    return header;
  }

  protected com.anthem.specialty.provider.datamodel.dto.DataOwner getDataOwner(String lob) {
    if (lob == null) {
      return dataOwners.stream().findFirst().get();
    }
    return dataOwners.stream().filter(dataOwner -> dataOwner.getName().equalsIgnoreCase(lob)).findAny().get();
  }
}
