*
******************************************************************************
* 			
* SET UP THE EXPERIMENT (PLEASE ENSURE YOU REMOVE EVERYTHING WHEN YOU FINISH)		
*			
******************************************************************************
*
* This is best performed on the lab PC rather than vDesktop!
*
******************************************************************************
*
* 0. Set the variable myIP to your computer name (better) or leave as 127.0.0.1
*
******************************************************************************
*
File 1.create_nodes.bat: In line 8, replace COM-C132-L51877 with the name of your computer. 
File 2.create_cluster.js: In line 11, replace COM-C132-L51877 with the name of your computer.
*
To find out your computer name, right click on Desktop-->Computer and Select Properties. 
*
******************************************************************************
*
* 1. Execute the first step: 1.create_nodes.bat
*
******************************************************************************
*
1.1. Use cmd.exe to open a terminal. 
*
1.2. Bring it to the sharding_example by using the command: cd complete_path_where_sharding_example_is_located 
*
1.3. Execute on the terminal the command: 1.create_nodes.bat
*
1.4. Wait at least 1 minute, and do not close the terminal.
*
******************************************************************************
*
* 2. Execute the remaining steps
*
******************************************************************************
*
2.1. Use cmd.exe to open a new terminal.
Please note that you have now 2 terminals: 
- The one from the previous step, which is still running and writing things constantly.
- The new one, which you have just opened.
*
2.2. Bring the new terminal to the sharding_example folder by using the command: cd complete_path_where_sharding_example_is_located 
*
2.3. Execute on the terminal the command: 2.create_cluster.bat
It will take it a few minutes to complete all the tasks. You must Wait for them to complete. 
*
2.4. Execute on the terminal the command: 3.insert_collection.bat
It will take it a few seconds to complete the task. You must Wait for it to complete.   
*
2.5. Execute on the terminal the command: 4.shard_collection.bat
It will take it a few seconds to complete the task. You must Wait for it to complete.   
*
2.6. At these stage the cluster is ready to play with it!
*
******************************************************************************
*
* 3. Play with the sharded collection
*
******************************************************************************
*
3.1. Open a new terminal or reuse the one of stage 2.1, 2.2, 2.3, 2.4, 2.5.
*
3.2. Execute on the terminal the command: mongo.exe
You will be connected to the cluster via a mongos.exe interface. 
It will appear the command prompt: mongos>
*
3.3. Use the database test by typing the command: mongos> use test 
switched to db test  
*
3.4. Play with the sharded collection restaurants by typing whatever commands you want. 
*
******************************************************************************
*
* 4. When finished, remove the cluster (VERY IMPORTANT, PLEASE DO SO)
*
******************************************************************************
*
4.1. Close all the terminals connected to MongoDB. 
That is, the one of stage 1 and the one you used on stage 3 to play with the sharded collection.
*
4.2. Use cmd.exe to open a terminal. 
*
4.3. Bring it to the sharding_example by using the command: cd complete_path_where_sharding_example_is_located 
*
4.4. Execute on the terminal the command: 5.remove_cluster.bat
It will kill and mongod and mongos process and will remove all the folders cfg*, dublin*, cork*, limerick* and galway* created in the session.
These folders occupy about 50GBs, that is why it is so important to remove them when we finish the session. 

 