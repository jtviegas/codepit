#!/usr/bin/python

# --------------------------------------------------------
#           PYTHON PROGRAM
# Here is where we are going to define our set of...
# - Imports
# - Global Variables
# - Functions
# ...to achieve the functionality required.
# When executing > python 'this_file'.py in a terminal,
# the Python interpreter will load our program,
# but it will execute nothing yet.
# --------------------------------------------------------

import sys

#---------------------------------------
#  FUNCTION get_key_value
#---------------------------------------
def get_key_value(line):
    pass

# ------------------------------------------
# FUNCTION create_initial_list
# ------------------------------------------
def create_initial_list(length):
    # Reuse from my_mapper.py
    pass

# ------------------------------------------
# FUNCTION check_if_popular
# ------------------------------------------
def check_if_popular(current_list, new_requests, new_tranferred, new_page):
    # Reuse from my_mapper.py
    pass

# ------------------------------------------
# FUNCTION print_key_value
# ------------------------------------------
def print_key_value(project, current_list, output_stream):
    # Reuse from my_mapper.py
    pass

# ------------------------------------------
# FUNCTION my_reduce
# ------------------------------------------
def my_reduce(input_stream, output_stream):
    # Reuse from my_mapper.py
    # Just replace the call to process line by get_key_value
    pass

# ------------------------------------------
# FUNCTION my_main
# ------------------------------------------
def my_main():
    # We pick the working mode:
    # Mode 1: Debug --> We pick our file to read test the program on it
    my_input_stream = open("sort_simulation.txt", "r")
    my_output_stream = open("reduce_simulation.txt", "w")

    # Mode 2: Actual MapReduce --> We pick std.stdin and std.stdout
    #my_input_stream = sys.stdin
    #my_output_stream = sys.stdout

    # We launch the Map program
    my_reduce(my_input_stream, my_output_stream)

# ---------------------------------------------------------------
#           PYTHON EXECUTION
# This is the main entry point to the execution of our program.
# It provides a call to the 'main function' defined in our
# Python program, making the Python interpreter to trigger
# its execution.
# ---------------------------------------------------------------
if __name__ == '__main__':
    my_main()
